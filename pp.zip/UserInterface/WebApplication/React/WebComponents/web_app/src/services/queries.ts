import { AxiosResponse } from 'axios';
import { useQuery } from 'react-query';
import { ApiRequestService } from './api-service';

import {validateDate} from '../util';

/**
 *
 * @returns Deals with character data api
 * Call this method from anywhere
 * Caching handled by react query
 * TODO: Enforce strong typing
 */
export const useCountriesList = () => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery('getCountries', async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.countriesList();
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
};

//get customer data
export const useCustomerHierarchy = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['baseLineData', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.customerHierarchy(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
};

//get productList
export const useProductHierarchy = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['productHierarchy', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.productHierarchy(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
};


//get baseline data
export const useBaseLineData = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['useBaseLineData', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.baseLineData(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
};


//get token for BI
export const useTokenBI = (reportId: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery('useTokenBI', async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.biToken(reportId);
    return res.data;
  }, { refetchOnWindowFocus: false, refetchInterval: 3300000, cacheTime: 0 });
};

//get elasticity data
export const useKcElasticityData = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['useKcElasticityData', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.baseLineData(data);
    return res.data;
  }, { refetchOnWindowFocus: false });
};

//GET KC PRODUCT LIST
export const useKcProductHierarchy = (data: string, hierarchyLevel?: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['kcproductHierarchy', data, hierarchyLevel], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.kcproductHierarchy(data, hierarchyLevel);
    return res.data;
  }, { refetchOnWindowFocus: false });
};

//GET TARGET PRODUCT LIST
export const useTargetProductHierarchy = (data: string) => {
  let enabled = true
  if (!data) {
    enabled = false;
  }
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['targetProductHierarchy', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.targetProductHierarchy(data);
    return res.data;
  }, { refetchOnWindowFocus: false, enabled });
};

//GET CORRELATION ANALYSIS
export const useCorrelationAnalysis = (data: any) => {
  let enabled = true
  if (!data || Object.keys(data).length === 0 || data.country === '' || data.scope === '' || data.hierarchyLevel === '' || data.initialNodeValues.length === 0 || data.targetNodeValues.length === 0) {
    enabled = false;
  }
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['correlationAnalysis', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.correlationAnalysis(data);
    return res.data;
  }, { refetchOnWindowFocus: false, enabled });
};

//GET OWN PRODUCT LIST
export const useOwnProductHierarchy = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['ownProductHierarchy', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.ownProductHierarchy(data);
    return res.data;
  }, { refetchOnWindowFocus: false });
};

//GET OWN ANALYSIS
export const useOwnAnalysis = (data: any) => {
  let enabled = true
  if (!data || Object.keys(data).length === 0 || (Object.keys(data).length !== 0 ? data.initialNodeValues.length === 0 : false) || data.country === '' || data.country === 'KR') {
    enabled = false;
  }
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['ownAnalysis', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.ownAnalysis(data);
    return res.data;
  }, { refetchOnWindowFocus: false, enabled });
};

export const useAvailableSource = (data: string) => {
  let enabled = true
  if (!data) {
    enabled = false;
  }
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['ownAvailableSource', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.ownAvailableSource(data);
    return res.data;
  }, { refetchOnWindowFocus: false, enabled });
}


const canEnableQueryFor2Params = (data1: string, data2: string) => {
  let enabled = true
  if (!data1 || !data2) {
    enabled = false;
  }

  const requiredParams1 = ['country=', 'initialNodeValues=']
  const requiredParams2 = ['targetNodeValues=', 'hierarchyLevel=']
  if (enabled) {
    const pass1 = requiredParams1.filter(param => {
      return data1.includes(param)
    })
    const pass2 = requiredParams2.filter(param => {
      return data2.includes(param)
    })
    enabled = (pass1.length === 2 && pass2.length === 2) ? true : false

  }
  return enabled;

}


const canEnableQueryFor1Param = (data: string) => {
  let enabled = true
  if (!data) {
    enabled = false;
  }

  const requiredParams = ['country=', 'initialNodeValues=', 'targetNodeValues=', 'hierarchyLevel=']
  if (enabled) {
    const pass1 = requiredParams.filter(param => {
      return data.includes(param)
    })

    enabled = pass1.length === 4 ? true : false

  }
  return enabled;

}



//GET CROSS ANALYSIS
export const useCrossAnalysis = (data: string) => {
  const enabled = canEnableQueryFor1Param(data)
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['crossElasticityAnalysis', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.crossElasticityAnalysis(data);
    return res.data;
  }, { refetchOnWindowFocus: false, enabled });
};

//GET PRODUCTS BASED ON CHANNEL CUSTOMER ALL
export const useOwnScopeSelector = (data: any) => {
  let enabled = true
  if (!data || Object.keys(data).length === 0 || (Object.keys(data).length !== 0 ? data.initialNodeValues.length === 0 : false) || data.country === '' || data.country !== 'KR' ) {
    enabled = false;
  }
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['ownScopeSelector', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.ownScopeSelector(data);
    return res.data;
  }, { refetchOnWindowFocus: false, enabled });
};


export const useCrossScopeSelector = (data: string) => {
  const enabled = canEnableQueryFor1Param(data)
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['ownCrossSelector', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.crossScopeSelector(data);
    return res.data;
  }, { refetchOnWindowFocus: false, enabled });
};


//get roi data
export const usePostROIData = (data: string) => {
  const isDateInValid = validateDate(data);

  let enabled = true;
  if (!data || isDateInValid) {
    enabled = false;
  }
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['usePostROIData', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.postRoi(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0, enabled });
};

//postRoiQuadrant data
export const usePostRoiQuadrant = (data: string) => {
  const isDateInValid = validateDate(data);

  let enabled = true;
  if (!data || isDateInValid) {
    enabled = false;
  }
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['usePostRoiQuadrant', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.postRoiQuadrant(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0, enabled });
};


//Roifile download uadrant data
export const useRoiFileDownload = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['useRoiFileDownload', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.roiFileDownload(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
};

//get event id data
export const useEventIDData = (data: string) => {
  const isDateInValid = validateDate(data);

  let enabled = true
  if (!data || isDateInValid) {
    enabled = false;
  }

  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['useEventIDData', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.getEventIds(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0, enabled });
};

//postRoiQuadrant data
export const useRoiQuadrant = (data: string) => {
  const isDateInValid = validateDate(data);

  let enabled = true
  if (!data || isDateInValid) {
    enabled = false;
  }
  
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['useRoiQuadrant', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.roiQuadrant(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0, enabled });
};


//get names list 
export const useGetImpactorNamesList = () => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery('usegetNamesList', async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.getImpactorNamesList();
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
};


//get Delete Impactor History 
export const useGetDeleteImpactorHistory = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['useGetDeleteImpactorHistory', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.getDeleteImpactorHistory(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
};


//get Impactor History 
export const useGetImpactorHistory = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['useGetImpactorHistory', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.getImpactorHistory(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
};


//GET ImpactorInfo
export const useImpactorInfo = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['useImpactorInfo', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.getImpactorInfo(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
};


//Impactor Delete
export const useImpactorDelete = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['useImpactorDelete', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.getImpactorDelete(data);
    return res.data;
  }, { refetchOnWindowFocus: false });
};

export enum TokenType {
  AccessToken,
  IdToken
}

export const validateToken = async (type: TokenType, token: string) => {
  try {
    const apiRequestService = ApiRequestService.createInstance()
    let res: AxiosResponse
    if (type === TokenType.AccessToken) {
      res = await apiRequestService.validateAccessToken(token);
    } else {
      res = await apiRequestService.validateIdToken(token);
    }
    console.log(res)
    return res.data;
  } catch (error) {
    console.log(error)
  }

}

export const authenticateWithServer = async (accessToken: string, idToken: string) => {
  try {
    const apiRequestService = ApiRequestService.createInstance()
    const res = await apiRequestService.autenticateWithAPI({
      accessToken,
      idToken
    });
    console.log(res)
    if (res.status === 200) {
      return res.data;
    } else {
      return {
        error: 'Unauthorized access'
      }
    }

  } catch (error) {
    console.log(error)
    return {
      error: 'Login error'
    }
  }

}


export const getAPITestResults = async (type: number) => {
  try {
    const apiRequestService = ApiRequestService.createInstance()
    let res
    if (type === 1) {
      res = await apiRequestService.testAPI()
    }else{
      res = await apiRequestService.testDataAPI()
    }
    console.log(res)
    if (res.status === 200) {
      return res.data;
    } else {
      console.log(res)
      return null
    }

  } catch (error) {
    console.log(error)
    return null
  }

}

//get customer data
export const usePrePOIPromoTypes = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['usePrePOIPromo', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.getPrePOIPromoTypes(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
};


export const useSellInSellOutCheck = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['useSellInSellOutCheck', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.hasSellInSelloutData(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
}

//check if daily data is available or not
export const useDailyDataCheck = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['useDailyDataCheck', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.dailyAvailable(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
}


//check if scope level data is available or not
export const useScopeLevelData = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['useScopeLevelData', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.marketScopeToggles(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
}

export const useLastModelRunDate = (country: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['useLastModelRunDate', country], async () => {
    const res: AxiosResponse = await apiRequestService.getLastModelRunDate(country);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
}

//fetch Sub Category level data 
export const useSubCategoryLevelData = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['useSubCategoryLevelData', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.getSubCategories(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
}

//Fetch Source and Scope information in Price Elasticity tab
export const useCountryMasterData = (data: string) => {
  const apiRequestService = ApiRequestService.createInstance();
  return useQuery(['useCountryMasterData',data], async () => {
    const res: AxiosResponse = await apiRequestService.getCountryMasterData(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 })

}

//fetch regression data (slope, intercept, rsquare)
export const useRegressionData = (data:object ) => {
  const apiRequestService = ApiRequestService.createInstance();

  return useQuery(['useRegressionData', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.getRegressionValues(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
};

//fetch Line Fitting data (slope, intercept, rsquare)
export const useLineFittingData = (data:object ) => {
  const apiRequestService = ApiRequestService.createInstance(); 

  return useQuery(['useLineFittingData', data], async () => {
    // done to avoid data.data nesting in container
    const res: AxiosResponse = await apiRequestService.getLineFittingWeeks(data);
    return res.data;
  }, { refetchOnWindowFocus: false, cacheTime: 0 });
};

