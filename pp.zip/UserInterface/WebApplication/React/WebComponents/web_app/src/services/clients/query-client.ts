import { QueryClient } from 'react-query';

export const AppQueryClient = new QueryClient();
