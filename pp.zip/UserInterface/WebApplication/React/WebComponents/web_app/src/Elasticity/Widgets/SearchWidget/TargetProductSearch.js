import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CustomSearch from "../../../CustomSearch";

import { useTargetProductHierarchy } from "../../../services/queries";
import useStore from "../../../store";

const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: theme.palette.primary.light,
    padding: theme.spacing(1),
    display: "flex",
    alignItems: "center",
    width: "100%",
    height: "4rem",
  },
  paper: {
    border: "1px solid",
    padding: theme.spacing(1),
    width: theme.spacing(143),
    backgroundColor: theme.palette.background.paper,
  },
  listbox: {
    backgroundColor: theme.palette.primary.light,
    color: theme.palette.primary.light,
    marginLeft: theme.spacing(1),
    flex: 1,
  },
  input: {
    color: theme.palette.primary.main,
  },
  iconButton: {
    float: "right",
    padding: 10,
    color: theme.palette.primary.main,
  },
  divider: {
    float: "right",
    height: 28,
    margin: 4,
  },
  checkBox: {
    color: theme.palette.primary.main,
  },
  dataDiv: {
    padding: theme.spacing(1),
    width: 390,
    backgroundColor: theme.palette.background.light,
  },
  hide: {
    "& .checkbox-item": {
      display: "none",
    },
    "& .radio-item": {
      display: "none",
    },
  },
  label: {
    display: "block",
    color: "black",
    fontWeight: "bold",
  },
}));

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

const TargetProductSearch = (props) => {
  const classes = useStyles();

  //------SELECTION: KC PRODUCT------//
  const setSelectedKcProducts = useStore(
    (state) => state.setSelectedKcProducts
  );
  let selectedKcProducts = useStore((state) => state.selectedKcProducts);
  let selectedTargetProducts = useStore(
    (state) => state.selectedTargetProducts
  );
  let selectedCountry = useStore((state) => state.selectedCountry);

  let hierarchyLevel = useStore((state) => state.hierarchyLevel);

  let rowData = useStore((state) => state.rowData);

  console.log("selectedKcProducts.apiUrl", selectedKcProducts);

  const { isLoading: isTargetProductData, data: targetProductData } =
    useTargetProductHierarchy(selectedKcProducts.apiUrl);
  //------Product Level Selection------//
  let selectedProductLevel = useStore((state) => state.selectedProductLevel);

  let productLevel = selectedProductLevel;
  let elasticityPrice = props.elasticityPrice;

  // useTargetProductHierarchy(`?country=PE&nodeValues=17702425642154&hierarchyLevel=EAN`);

  const [targetService, setTargetService] = useState([]);
  const [targetProductNew, setTargetProductNew] = useState([]);

  // API CALL: TARGET PRODUCT LIST
  useEffect(() => {
    if (!isTargetProductData && selectedKcProducts) {
      setTargetProductNew(generateProductHierarchy(targetProductData));
    }
  }, [isTargetProductData, selectedKcProducts, rowData]);

  var checkBoxShow = (show) => (show ? classes.dataDiv : classes.hide);

  var productLevelsData = {
    brand: {
      label: "BRAND",
      data: [],
    },
    subCategory: {
      label: "SUB_CATEGORY",
      data: [],
    },
    subBrand: {
      label: "SUB_BRAND",
      data: [],
    },
    pack: {
      label: "PACK",
      data: [],
    },
    ean: {
      label: "EAN",
      data: [],
    },
  };

  let subBrandArr = [];
  let packArr = [];
  let subCategoryArr = [];
  let brandArr = [];

    const sortProducts = (uniqueData) => {
      uniqueData.sort((a, b) => (a.label > b.label ? 1 : -1));
      return uniqueData;
    };

    const uniqueValueFilter = (data) => {
      var sortedResults = [];
      var resArr = [];
      data.filter(function (item) {
        var i = resArr.findIndex((x) => x.label == item.label);
        if (i <= -1) {
          resArr.push(item);
        }
        return null;
      });
      resArr = sortProducts(resArr);
      console.log(`RESULT`, resArr);
      return resArr;
    };

  const generateProductHierarchy = (data) => {
    console.log(data);
    let transformedData = [];
    let childrenOfCategories = [];
    var iterateEachCategory = (category) => {
      let childrenOfCategoryArr = [];
      let childrenOfCategory = [];
      let subCategory = {
        label: "SubCategories",
        value: "subCategories",
        disabled: false,
        className: checkBoxShow(false),
        children: childrenOfCategory,
      };

      if (category.subCategories) {
        for (var i in category.subCategories) {
          let eachSubCategory = {
            label: i,
            value: i,
            className: checkBoxShow(false),
            expanded: true,
            disabled: true,
            children: iterateEachSubCategory(category.subCategories[i]),
          };
          if (selectedProductLevel === "subCategory") {
            subCategoryArr.push({
              label: i,
              value: i,
              className: checkBoxShow(true),
              expanded: true,
              disabled: false,
              children: [],
            });
          }
          childrenOfCategory.push(eachSubCategory);
        }
        productLevelsData.subCategory.data = subCategoryArr;
      }
      childrenOfCategoryArr.push(subCategory);
      return childrenOfCategoryArr;
    };

    var iterateEachSubCategory = (subCategory) => {
      let childrenOfSubCategoryArr = [];
      let childrenOfSubCategory = [];
      let manufacturer = {
        label: "Manufacturers",
        value: "manufacturers",
        disabled: false,
        className: checkBoxShow(false),
        children: childrenOfSubCategory,
      };
      if (subCategory.manufacturers) {
        for (var i in subCategory.manufacturers) {
          let eachManufacturer = {
            label: i,
            value: i,
            className: checkBoxShow(false),
            expanded: true,
            disabled: true,
            children: iterateEachManufacturer(subCategory.manufacturers[i]),
          };
          childrenOfSubCategory.push(eachManufacturer);
        }
      }
      childrenOfSubCategoryArr.push(manufacturer);
      return childrenOfSubCategoryArr;
    };

    var iterateEachManufacturer = (manufacturer) => {
      let childrenOfManufacturerArr = [];
      let childrenOfManufacturer = [];
      let brands = {
        label: "Brands",
        value: "brands",
        disabled: false,
        className: checkBoxShow(false),
        children: childrenOfManufacturer,
      };
      if (manufacturer.brands) {
        for (var i in manufacturer.brands) {
          let eachBrand = {
            label: i,
            value: i,
            className: checkBoxShow(false),
            expanded: true,
            disabled: true,
            children: iterateEachBrand(manufacturer.brands[i]),
          };
          if (selectedProductLevel === "brand") {
            brandArr.push({
              label: i,
              value: i,
              className: checkBoxShow(true),
              expanded: true,
              disabled: false,
              children: [],
            });
          }
          childrenOfManufacturer.push(eachBrand);
        }
        productLevelsData.brand.data = brandArr;
      }
      childrenOfManufacturerArr.push(brands);
      return childrenOfManufacturerArr;
    };

    var iterateEachBrand = (brand) => {
      let childrenOfBrandArr = [];
      let childrenOfBrand = [];
      let subBrands = {
        label: "Sub Brands",
        value: "subBrands",
        disabled: false,
        className: checkBoxShow(false),
        children: childrenOfBrand,
      };
      if (brand.subBrands) {
        for (var i in brand.subBrands) {
          let eachSubBrand = {
            label: i,
            value: i,
            className: checkBoxShow(false),
            expanded: true,
            disabled: true,
            children: iterateEachSubBrand(brand.subBrands[i]),
          };

          if (selectedProductLevel === "subBrand") {
            subBrandArr.push({
              label: i,
              value: i,
              className: checkBoxShow(true),
              expanded: true,
              disabled: false,
              children: [],
            });
          }
          childrenOfBrand.push(eachSubBrand);
        }
        productLevelsData.subBrand.data = subBrandArr;
      }
      childrenOfBrandArr.push(subBrands);
      return childrenOfBrandArr;
    };

    var iterateEachSubBrand = (subBrand) => {
      let childrenOfSubBrandArr = [];
      let childrenOfSubBrand = [];
      let tiers = {
        label: "Tiers",
        value: "tiers",
        disabled: false,
        className: checkBoxShow(false),
        children: childrenOfSubBrand,
      };
      if (subBrand.tiers) {
        for (var i in subBrand.tiers) {
          let eachTier = {
            label: i,
            value: i,
            className: checkBoxShow(false),
            expanded: true,
            disabled: true,
            children: iterateEachTier(subBrand.tiers[i]),
          };
          childrenOfSubBrand.push(eachTier);
        }
      }
      childrenOfSubBrandArr.push(tiers);
      return childrenOfSubBrandArr;
    };

    var iterateEachTier = (tier) => {
      let childrenOfTierArr = [];
      let childrenOfTier = [];
      let packs = {
        label: "Packs",
        value: "packs",
        disabled: false,
        className: checkBoxShow(false),
        children: childrenOfTier,
      };
      if (tier.packs) {
        for (var i in tier.packs) {
          let eachPack = {
            label: i,
            value: i,
            className: checkBoxShow(false),
            expanded: true,
            disabled: true,
            children: iterateEachPack(tier.packs[i]),
          };
          if (selectedProductLevel === "pack") {
            packArr.push({
              label: i,
              value: i,
              className: checkBoxShow(true),
              expanded: true,
              disabled: false,
              children: [],
            });
          }
          childrenOfTier.push(eachPack);
        }
        productLevelsData.pack.data = packArr;
      }
      childrenOfTierArr.push(packs);
      return childrenOfTierArr;
    };

    var iterateEachPack = (pack) => {
      if (pack.length > 0) {
        var ean = iterateEans(pack);
      }
      return ean;
    };

    var iterateEans = (eachPack) => {
      let allEan = [];

      eachPack.map((ean) => {
        let eachEan = {
          label: ean,
          value: ean,
          disabled: false,
          className: checkBoxShow(true),
          children: [],
        };
        allEan.push(eachEan);
      });
      sortProducts(allEan);
      productLevelsData.ean.data = allEan;
      return allEan;
    };
    let topLevel = {
      label: "Categories",
      value: "categories",
      disabled: false,
      className: checkBoxShow(false),
      children: childrenOfCategories,
    };

    let categories = data.categories;
    // iterate through all categories
    if (data.categories) {
      for (var i in categories) {
        let eachCategory = {
          label: i,
          value: i,
          className: checkBoxShow(false),
          expanded: true,
          disabled: true,
          children: iterateEachCategory(categories[i]),
        };

        childrenOfCategories.push(eachCategory);
      }

      transformedData.push(topLevel);
    }

    return selectedProductLevel === "ean" || !selectedProductLevel
      ? transformedData
      : uniqueValueFilter(productLevelsData[selectedProductLevel].data);
  };
  console.log(`PROPS TARGET`, props);
  return (
    <Grid item xs={6} sm={4}>
      <div className={classes.paperDiv}>
        <div className={classes.label}>Target Products</div>

        {isTargetProductData && selectedKcProducts ? (
          <>
            <CustomSearch
              data={targetProductNew}
              dataFor="targetProducts"
              mode={
                props.searchIndex === "Cross" ? "radioSelect" : "hierarchical"
              }
              productLevel={
                !selectedProductLevel
                  ? "ean"
                  : productLevelsData[selectedProductLevel].label
              }
              elasticityPrice={props.elasticityPrice}
              currentTab={props.currentTab}
            />
            <div>Loading...</div>
          </>
        ) : selectedKcProducts && !isTargetProductData ? (
          <CustomSearch
            data={targetProductNew}
            dataFor="targetProducts"
            mode={
              props.searchIndex === "Cross" ? "radioSelect" : "hierarchical"
            }
            productLevel={
              !selectedProductLevel
                ? "ean"
                : productLevelsData[selectedProductLevel].label
            }
            elasticityPrice={props.elasticityPrice}
            currentTab={props.currentTab}
          />
        ) : (
          <CustomSearch
            data={targetProductNew}
            dataFor="targetProducts"
            mode={
              props.searchIndex === "Cross" ? "radioSelect" : "hierarchical"
            }
            productLevel={
              !selectedProductLevel
                ? "ean"
                : productLevelsData[selectedProductLevel].label
            }
            elasticityPrice={props.elasticityPrice}
            currentTab={props.currentTab}
          />
        )}
      </div>
    </Grid>
  );
};

export default TargetProductSearch;
