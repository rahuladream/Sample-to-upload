import { useEffect, useState } from "react";
import { SingleGrid } from "../single_grid";
import { ProductsOnComparison, ElasticityScopeRecord, Scope, CustomSortFuction, PriceType } from "../types"
import { ProductNames } from "./product_names";
import { SelectionRow } from "./selection_row";
import { ViewMore } from "./view_more";
import AppPagination from '../Pagination';

type Props = {
    records: ElasticityScopeRecord[],
    selectedCountry: string,
    unselectRow: (initial: string, target:string) => void,
    handleViewMore: (initial: string, target?:string, customer?: string) => void,
    loading: boolean,
    initialProductData: any
    handleSelectedValues: (obj:any) => void,
    customSort?: CustomSortFuction,
    allCustomers: string[],
    filterCustomer: (name:string[]) => void,
    priceType: PriceType,
    scope: Scope,
    marketScope?: String,
    source?: String,
    selectedProducts: any,
    selectedTargetProducts: any,
    pageData?: any,
    dataCount?: any,
    handlePageData?: any
}

export const CrossMarketScope = ({records, selectedCountry, unselectRow, handleViewMore, loading, initialProductData, handleSelectedValues, customSort,
     allCustomers, filterCustomer, priceType, scope, marketScope, source, selectedProducts, selectedTargetProducts, pageData, dataCount, handlePageData} : Props) => {
    const [comparisonCount, setcomparisonCount] = useState(0);   

    const sortedAllCustomers = [...allCustomers].sort();
    const sortedRecords = [...records].sort((record1:any, record2:any) => (record1.customer && record2.customer) && record1.customer.toLowerCase() > record2.customer.toLowerCase() ? 1 : record1.customer.toLowerCase() < record2.customer.toLowerCase() ? -1 : 0);

    const handleSelected = (kcObj : any) => {
        handleSelectedValues(kcObj)
    }

    const [canShowName, setcanShowName] = useState(false);

    const handleSort:CustomSortFuction = (field, direction) => {
        if (customSort){
            customSort(field, direction)
            setcanShowName(true)
        }
    }

    const [canShowCustomerFilter, setcanShowCustomerFilter] = useState(false);
    const [hiddenCustomers, setHiddenCustomers] = useState<string[]>([]);

    const ScopeFilter = () => <div className="relative flex justify-center p-2">
                            <button className="bg-white border border-primary text-primary rounded text-sm p-2" onClick={()=>setcanShowCustomerFilter(!canShowCustomerFilter)}>Filter {scope === Scope.CUSTOMER ? 'Customer' : 'Channel'}</button>
                            {
                                canShowCustomerFilter
                                ? <div className="absolute bg-white top-12 flex flex-col p-5 border shadow border-primary rounded z-50" onMouseLeave={()=> setcanShowCustomerFilter(false)}>
                                    <div  className="hover:bg-blue-200 p-1 flex justify-start items-center gap-1" onClick={(e)=> {
                                        if (hiddenCustomers.length === 0){
                                            setHiddenCustomers(sortedAllCustomers)
                                            filterCustomer(sortedAllCustomers)
                                        }else{
                                            setHiddenCustomers([])
                                            filterCustomer([])
                                        }
                                    }}>
                                        <input type="checkbox" checked={hiddenCustomers.length === 0}  />
                                        <span className="text-sm"> <b>All</b> </span>
                                    </div>
                                    {
                                        sortedAllCustomers.map((customer, idx)=> {
                                            return <div key={idx} className="hover:bg-blue-200 p-1 flex justify-start items-center gap-1" onClick={() => {
                                                if (hiddenCustomers.includes(customer)){
                                                    const except = hiddenCustomers.filter(e=>e !== customer)
                                                    setHiddenCustomers(except)
                                                    filterCustomer(except)
                                                }else{
                                                    const added =  [...hiddenCustomers, customer]
                                                    setHiddenCustomers(added)
                                                    filterCustomer(added)
                                                }
                                            }}>
                                                <input type="checkbox" checked={!hiddenCustomers.includes(customer)} />
                                                <span className="text-sm"> {customer} </span>
                                            </div>
                                        })
                                    }
                                </div>
                                : null
                            }
                        </div>
    
    return <div className="mt-10 flex flex-col  overflow-x-hidden relative w-full" style={{minHeight:5000}}>
        <SelectionRow initialProductData={initialProductData} handleSelectedValues={handleSelected} comparisonAdded={() => setcomparisonCount(comparisonCount+1)}
            emptySelection={true} source={source} scope={marketScope} selectedProducts={selectedProducts} selectedTargetProducts={selectedTargetProducts}/>
            
            <div className=" flex  bg-white w-full relative">
                {/* <div className="flex flex-col">
                     <div className="left-0  border border-gray-300 flex flex-col" style={{width:'36rem'}}>
                    {
                        (records && records.length > 0) || (selectedProducts.length > 0) ?
                        <ScopeFilter/>
                        : null
                    }
                    </div>
                    {   !canShowName || (records.length === 0 && selectedProducts.length > 0) ?
                        <div className="left-0  border border-gray-300 flex flex-col  " style={{width:'36rem'}}>
                            <ProductNames records={productsInComparison}/>
                        </div>
                        : null
                    }
                </div> */}
                <div className={`absolute flex flex-col left-0 right-0`} >
                    <div className="flex flex-row">
                        <div className="left-0  border border-gray-300 flex flex-col" style={{width:'36rem'}}>
                        {
                            (records && records.length > 0) || (selectedProducts.length > 0) ?
                            <ScopeFilter/>
                            : null
                        }                        
                        </div>
                        <div className="justify-end w-full">
                            <AppPagination 
                                pageData={pageData}
                                dataCount={dataCount}
                                handlePageData={handlePageData}
                                fromTab='cross'
                                applyPadding={false}
                            />
                        </div>
                    </div>
                    
                     <div className="flex w-full  ">
                       {
                           sortedRecords && sortedRecords.length > 0
                           ? <div className=" border w-full border-gray-300 overflow-x-scroll flex">
                              {
                                  sortedRecords.map((record, idx) => {
                                      return <div className="flex flex-col  border-l border-t border-gray-300 w-full w-full" key={idx}>
                                          <div className="flex  h-16 self-center items-center" >{record.customer}</div>
                                           <SingleGrid loading={false} records={record.data} customSort={handleSort} priceType={priceType}
                                            scope={Scope.CUSTOMER} showName={true} showOptions={true} selectedCountry={selectedCountry} showTargetProduct={true} handleViewMore={handleViewMore}
                                            ></SingleGrid>
                                      </div>
                                  })
                              }
                           </div>
                           : <SingleGrid loading={false} records={[]}  showTargetProduct={true}
                           scope={Scope.CUSTOMER} showName={false} showOptions={false} selectedCountry={selectedCountry} 
                           ></SingleGrid>
                       }
                    </div>
                </div>
            </div>  
    </div>
}