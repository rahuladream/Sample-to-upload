import React from 'react'
import TableRow from "@material-ui/core/TableRow";
import TableCell from "@material-ui/core/TableCell";
import Table from "@material-ui/core/Table";
import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles((theme)=> ({
  c1: {
    backgroundColor: "#F5F5F7",
    border: "2px solid rgba(224, 224, 224, 1)",
    height: "50px"
  }
}))

const EmptyGrid = () => {
    const classes = useStyles()
  return (
    <Table className="flex justify-center items-center">
        <TableRow>
            <TableCell colSpan={1} className={classes.c1}/>
            <TableCell colSpan={1} className={classes.c1}/>
        </TableRow>
        <TableRow>
            <TableCell colSpan={1} className={classes.c1}/>
            <TableCell colSpan={1} className={classes.c1}/>
        </TableRow>
    </Table>
  )
}

export default EmptyGrid