import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import ItemSearch from "./Widgets/SearchWidget/ItemSearch";
import useStore from "../store";

const useStyles = makeStyles((theme) => ({
  root: {
    maxHeight: '600px',
    width: '450px',
    zIndex: 5,
    backgroundColor: 'white',
    overflowY: 'auto',
    direction: 'rtl',
    padding: '1rem',
    boxShadow: '5px 5px 8px #d6d9dc',
    marginTop: '5px',
    borderRadius: '5px',
    marginBottom:'20px'
  },
  paperDiv: {
    display: "flex",
    flexWrap: "wrap",
    "& > *": {
      margin: theme.spacing(2),
      width: "100%",
    },
  },
  container: {
    backgroundColor: "#F6F8FC",
    height: "100vh",
  },
  searchBar: {
    display: "inline-block",
    paddingRight: "2.5rem",
  },
  searchContainer: {
    background: "#F6F8FC",
    width: "100%",
    boxShadow: "none",
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
  header: {
    color: "black",
  },
  checkBox: {
    color: theme.palette.primary.main,
  },
  autoCompleteSearch: {
    boxShadow:
      "0px 2px 4px -1px rgb(0 0 0 / 20%), 0px 4px 5px 0px rgb(0 0 0 / 14%), 0px 1px 10px 0px rgb(0 0 0 / 12%)",
    background: "#FFFFFF",
  },
  gridContainer: {
    background: "#F6F8FC",
  },
  showCheckBox: {},
  appTab: {
    fontSize: "15px",
  },
  hide: {
    color: theme.palette.primary.main,
    fontSize: "14px",
    fontWeight: "650",
    opacity: "0.70",
  },
  open: {
    fontSize: "14px",
    color: theme.palette.primary.dark,
    fontWeight: theme.typography.fontWeightBold,
  },
}));

let display = {
  ean: {
    data: [
      { name: "Manufacturer", value: "manufacturer" },
      { name: "Brands", value: "brand" },
      { name: "Sub Brands", value: "subBrand" },
      { name: "Pack", value: "pack" },
      { name: "EAN", value: "ean" },
    ],
  },
  pack: {
    data: [
      { name: "Manufacturer", value: "manufacturer" },
      { name: "Brands", value: "brand" },
      { name: "Sub Brands", value: "subBrand" },
      { name: "Pack", value: "pack" },
    ],
  },
  subBrand: {
    data: [
      { name: "Manufacturer", value: "manufacturer" },
      { name: "Brands", value: "brand" },
      { name: "Sub Brands", value: "subBrand" },
    ],
  },
  brand: {
    data: [
      { name: "Manufacturer", value: "manufacturer" },
      { name: "Brands", value: "brand" },
    ],
  },
  subCategory: {
    data: [{ name: "Sub Categories", value: "subCategory" }],
  },
};

const NestedSearch = (props) => {
  const classes = useStyles();
  let selectedCategoryLevel = useStore((state) => state.selectedCategoryLevel);
  let selectedSubCategoryLevel = useStore((state) => state.selectedSubCategoryLevel);

  let selectedProductLevel = useStore((state) =>
    state.selectedProductLevel ? state.selectedProductLevel : "ean"
  );
  let initialProductCheckBox = useStore(
    (state) => state.initialProductCheckBox
  );
  const setInitialProductCheckBox = useStore(
    (state) => state.setInitialProductCheckBox
  );
  
  let targetProductCheckBox = useStore(
    (state) => state.targetProductCheckBox
  );
  const setTargetProductCheckBox = useStore(
    (state) => state.setTargetProductCheckBox
  );

  const initial = {
    subCategory: false,
    manufacturer: false,
    brand: false,
    subBrand: false,
    pack: false,
    ean: false,
  };
  const [initialState, setInitialState] = useState({});
  const [initialParentState, setInitialParentState] = useState(initial);
  useEffect(() => {
    setInitialState(initial);
    setInitialParentState(initial); 
  }, [])

  function handleOpen(x) {
    setInitialState({
      ...initialState,
      [x]: !initialState[x],
    });
  }
  function transformDataUnique(values) {
    let arr = ["subCategory", "manufacturer", "brand", "subBrand", "pack", "ean"];
    arr.map((val) => {
      values[val] = [
        ...new Map(values[val].map((item) => [item["name"], item])).values(),
      ];
    });
    arr.map((val) => {
      values[val].sort(function (a, b) {
        if (a.name.toLowerCase() < b.name.toLowerCase()) return -1;
        else if (a.name.toLowerCase() > b.name.toLowerCase()) return 1;
        else return 0;
      });
    });

    return values;
  }
  function isSelected(x) {
    return x.isChecked;
  }
  function putAll(x) {
    return x.name;
  }
  let selectedCountry = useStore((state) => state.selectedCountry);
  const [kcProductData, setkcProductData] = useState(props.data);

  let selectedInitialProductState = useStore(
    (state) => state.selectedInitialProductState
  );
  
  let selectedTargetProductState = useStore(
    (state) => state.selectedTargetProductState
  );
  const setSelectedInitialProductState = useStore(
    (state) => state.setSelectedInitialProductState
  );
  const setSelectedTargetProductState = useStore(
    (state) => state.setSelectedTargetProductState
  );

  const initialValue = {
    subCategory: [],
    manufacturer: [],
    brand: [],
    subBrand: [],
    pack: [],
    ean: [],
  };
  function updateState(values)
  { 
    if (props.dataFor === "initial") {
      setSelectedInitialProductState({ ...values });
    } else {
      setSelectedTargetProductState({ ...values });
    }
  }
  const getHierarchy = () => {
    switch (selectedProductLevel) {
      case "ean":
        return "EAN";
      case "pack":
        return "PACK";
      case "subBrand":
        return "SUB_BRAND";
      case "brand":
        return "BRAND";
      default:
        return "SUB_CATEGORY";
    }
  }

  function calculateInitial()
  {
    let Values = { ...initialValue };
    if ( kcProductData?.categories[selectedCategoryLevel]?.subCategories) {
      Object.entries(
        kcProductData.categories[selectedCategoryLevel]?.subCategories
      ).map(
        ([key, subcategory]) => {
          if(selectedSubCategoryLevel.length === 0 || selectedSubCategoryLevel.includes(key)) {
          Values["subCategory"].push({ name: key, isChecked: false })
          subcategory!==null && Object.entries(subcategory?.manufacturers).map(
            ([key3, manufacturer]) => {
              Values["manufacturer"].push({ name: key3, isChecked: false })
              if (selectedProductLevel === 'brand'){
                manufacturer!==null && Object.keys(manufacturer?.brands).map(x=> {
                  Values["brand"].push({
                    name: x,
                    isChecked: false,
                  })
                })
                return
              }
              manufacturer!==null && Object.entries(manufacturer?.brands).map(
                ([key4, brand]) => {
                  Values["brand"].push({ name: key4, isChecked: false })
                  if (selectedProductLevel === 'subBrand'){
                    brand!==null && Object.keys(brand?.subBrands).map(x=> {
                      Values["subBrand"].push({
                        name: x,
                        isChecked: false,
                      })
                    })
                    return
                  }
                  brand!==null && Object.entries(brand?.subBrands).map(
                    ([key5, subBrand]) => {
                      Values["subBrand"].push({
                        name: key5,
                        isChecked: false,
                      })
                      if (subBrand!==null && subBrand.tiers){
                        subBrand!==null && Object.entries(subBrand?.tiers).map(([key6, tier]) =>
                          tier!==null && Object.entries(tier?.packs).map(
                            ([key7, pack]) => (
                              Values["pack"].push({
                                name: key7,
                                isChecked: false,
                              }),
                              pack!==null && pack.map((x) =>
                                Values["ean"].push({ name: x, isChecked: false })
                              )
                            )
                          )
                        )
                      }
                    }
                  )
                }
              )
            }
          )
        }
      }
      );
    }
    Values = transformDataUnique(Values);
    return Values;
  }


  useEffect(() => {
    if (!props.previouslySelected || !props.previouslySelected.length) {
      let Values = calculateInitial();
      updateState(Values);
      props.dataFor === "initial" ? setInitialProductCheckBox(initial) : setTargetProductCheckBox(initial);
    }
  }, [props]);

  let removeItem = useStore((state) =>
    state.removeItem
  );
  const setRemoveItem = useStore(
    (state) => state.setRemoveItem
  );

  useEffect(() => {
    if(props.clear){
      let Values=calculateInitial();
      setSelectedInitialProductState(Values);
      setSelectedTargetProductState(Values);
      props.dataFor === "initial" ? setInitialProductCheckBox(initial) : setTargetProductCheckBox(initial);
      props.handleClear();
    } 
    if(props.tabName==="own" && removeItem?.length)
    {
      let state=selectedTargetProductState;
      let rowDataNew=[];
      state[selectedProductLevel].map(row => rowDataNew.push({name: row.name, isChecked: removeItem.includes(row.name) ? false : row.isChecked }));  
      state[selectedProductLevel]=rowDataNew;
      updateState(state);
      setRemoveItem([]);
    }
  }, [props])

  const getDepthValue = (level) => {
    switch (level) {
      case 'subCategory':
        return 1;
      case 'manufacturer':
        return 2;
      case 'brand':
        return 3;
      case 'subBrand':
        return 4;
      case 'pack':
        return 5;
      default:
        return 6;
    }
  };

  //Function to updated selector values 
  const updateSelectedLevel = (level) => {
    let values = props.dataFor==="initial"?{ ...selectedInitialProductState }:{...selectedTargetProductState};
    let depth=getDepthValue(level);

    if (level === 'ean')
      return;

    let manufacturer = [];
    let brand = [];
    let subBrand = [];
    let pack = [];
    let ean = [];

    let selectedManufacturer = values['manufacturer']?.filter(isSelected);
    let selectedBrand = values['brand']?.filter(isSelected);
    let selectedSubBrand = values['subBrand']?.filter(isSelected);
    let selectedPack = values['pack']?.filter(isSelected);

    let selectedSubCategory =
      selectedSubCategoryLevel.length === 0
          ? values['subCategory'].map(putAll)
          : selectedSubCategoryLevel;
    
    if(depth>=2){
    selectedManufacturer =
      selectedManufacturer.length === 0
        ? values['manufacturer'].map(putAll)
        : selectedManufacturer.map(putAll);
    }
    if(depth>=3){
    selectedBrand =
      selectedBrand.length === 0
        ? values['brand'].map(putAll)
        : selectedBrand.map(putAll);
    }
    if(depth>=4){
    selectedSubBrand =
      selectedSubBrand.length === 0
        ? values['subBrand'].map(putAll)
        : selectedSubBrand.map(putAll);
    }
    if(depth>=5){
      selectedPack =
        selectedPack.length === 0
          ? values['pack'].map(putAll)
          : selectedPack.map(putAll);
      }


    Object.entries(
      kcProductData.categories[selectedCategoryLevel].subCategories
    ).map(([key, subcategory]) =>
      selectedSubCategory.map(function(c) {
          if (key === c) {
              Object.entries(subcategory.manufacturers).map(
                  ([key3, val3]) => (
                  depth<=1?manufacturer.push({ name: key3, isChecked: values['manufacturer'].some(p => p.name === key3 && p.isChecked)? true:false }):"",
                  (depth<=1?manufacturer.map(putAll):selectedManufacturer).map(function(m) {
                      if (key3 === m && val3 && val3.brands) {
                          Object.entries(val3.brands).map(([key4, val4]) => (
                              depth<=2?brand.push({ name: key4, isChecked: values['brand'].some(p => p.name === key4 && p.isChecked)? true:false }):"",
                              (depth<=2?brand.map(putAll):selectedBrand).map(function(b) {
                                  if (key4 === b && val4 && val4.subBrands) {
                                      Object.entries(val4.subBrands).map(
                                          ([key5, val5]) => (
                                          depth<=3?subBrand.push({ name: key5, isChecked: values['subBrand'].some(p => p.name === key5 && p.isChecked)? true:false }):"",
                                          (depth<=3?subBrand.map(putAll):selectedSubBrand).map(function(sb) {
                                              if (key5 === sb && val5 && val5.tiers) {
                                                  Object.entries(val5.tiers).map(
                                                      ([key6, tier]) =>
                                                      Object.entries(tier.packs).map(
                                                          ([key7, val7]) => (
                                                          depth<=4?pack.push({ name: key7, isChecked: values['pack'].some(p => p.name === key7 && p.isChecked)? true:false }):"",
                                                          (depth<=4?pack.map(putAll):selectedPack).map(function(item) {
                                                              if (item === key7) {
                                                                  val7.map((x) =>
                                                                      ean.push({ name: x, isChecked: values["ean"].some((p) => p.name === x && p.isChecked ) ? true :  false, })   
                                                                  );
                                                              }
                                                          })
                                                        )
                                                      )
                                                  );
                                              }
                                          })
                                        )
                                      );
                                  }
                              })
                            )
                          );
                      }
                  })
                )
              );
          }
      })
  );
    
    if (depth <= 1) {
      values['manufacturer'] = manufacturer;
    }
    if (depth <= 2) {
      values['brand'] = brand;
    }
    if (depth <= 3) {
      values['subBrand'] = subBrand;
    }
    if (depth <= 4) {
      values['pack'] = pack;
    }
    if (depth <= 5) {
      values['ean'] = ean;
    }
    values = transformDataUnique(values);
    updateState(values);
  };

  function generateUrl() {
    let values = props.dataFor === "initial" ? { ...selectedInitialProductState }:{ ...selectedTargetProductState };
    let arr = ["manufacturer", "brand", "subBrand", "pack", "ean"];
    let selectedManufacturer= [];
    let selectedBrand= [];
    let selectedSubBrands = [];
    let selectedPacks = [];

    for(let i=0;i<arr.length;i++) {
      switch(arr[i]) {
        case "manufacturer": 
          selectedManufacturer = values[arr[i]].filter(isSelected).map(putAll);
          break;
        case "brand": 
          selectedBrand = values[arr[i]].filter(isSelected).map(putAll);
          break;
        case "subBrand":
          selectedSubBrands = values[arr[i]].filter(isSelected).map(putAll);
            break;
        case "pack": 
          selectedPacks = values[arr[i]].filter(isSelected).map(putAll);
            break;
        default:
          break;
      }
    }
    let selectedNodes = values[selectedProductLevel].filter(isSelected).map(putAll);

    let reformatKcStr = "";
    let reformatKcStrNew = "";
    let reformatKcStrNewT = "";
    let crossT = "";
    let crossI = "";
    let hierarchy = getHierarchy();

    selectedNodes.map((val, i) => {
      if (i <= 0) {
        reformatKcStr += `country=${selectedCountry}&nodeValues=${encodeURIComponent(val)}`;
        reformatKcStrNew += `?country=${selectedCountry}&initialNodeValues=${encodeURIComponent(val)}`;
        crossI += `country=${selectedCountry}&initialNodeValues=${encodeURIComponent(val)}`;
        crossT += `&targetNodeValues=${encodeURIComponent(val)}`;
        reformatKcStrNewT += `&targetNodeValues=${encodeURIComponent(val)}`;
      } else {
        reformatKcStr += `&nodeValues=${encodeURIComponent(val)}`;
        reformatKcStrNew += `&initialNodeValues=${encodeURIComponent(val)}`;
        reformatKcStrNewT += `&targetNodeValues=${encodeURIComponent(val)}`;
      }
    });
    reformatKcStr += `&hierarchyLevel=${hierarchy}`;
    reformatKcStrNewT += `&hierarchyLevel=${hierarchy}`;
    crossT += `&hierarchyLevel=${hierarchy}`;

    return {
      reformatKcStr,
      reformatKcStrNew,
      reformatKcStrNewT,
      crossI,
      crossT,
      selectedManufacturer,
      selectedBrand,
      selectedSubBrands,
      selectedPacks
    };
  }

  const unCheckBelowParentLevels = (x) => {
    let toggleParentState = props.dataFor === "initial" ? {
      ...initialProductCheckBox
    } : {
      ...targetProductCheckBox
    };
    let flagP = false;
    for (let [key, value] of Object.entries(toggleParentState)) {
      if (key === x) flagP = true;
      if (flagP) toggleParentState[key] = false;
    }
    props.dataFor === "initial" ? setInitialProductCheckBox({
      ...toggleParentState
    }) : setTargetProductCheckBox({
      ...toggleParentState
    });
  };
  const onSelection = (data) => {
    let values = props.dataFor === "initial" ? selectedInitialProductState : selectedTargetProductState;
    let x = data[0]; //parent level name:subcat
    let y = data[1]; //value in subcat ex-subcat1
    let selectedArr = [];
    values[x].map(function (item) {
      if (item.name === y) item.isChecked = !item.isChecked;

      if (item.isChecked) {
        selectedArr.push(item.name);
      }
    });
    updateState(values);

    if (selectedArr.length === values[x].length) {
      props.dataFor === "initial" ? setInitialProductCheckBox({
        ...initialProductCheckBox,
        [x]: true,
      }) : setTargetProductCheckBox({
        ...targetProductCheckBox,
        [x]: true,
      });
    } else {
      props.dataFor === "initial" ? setInitialProductCheckBox({
        ...initialProductCheckBox,
        [x]: false,
      }) : setTargetProductCheckBox({
        ...targetProductCheckBox,
        [x]: false,
      });
      unCheckBelowParentLevels(x);
    }
    updateSelectedLevel(x);

    if (selectedProductLevel === x) {
      let url = generateUrl();
      props.handleSelectedValues({
        selectedKcArr: selectedArr,
        apiUrl: url.reformatKcStr,
        correlationAnalysisApiUrl: url.reformatKcStrNew,
        correlationAnalysisApiUrlT: url.reformatKcStrNewT,
        crossAnalysisApiUrl: url.crossI,
        crossAnalysisApiUrlT: url.crossT,
        dataFor: props.dataFor,
        selectedBrand:  url.selectedBrand,
        selectedManufacturer:  url.selectedManufacturer,
        selectedSubBrands: url.selectedSubBrands,
        selectedPacks: url.selectedPacks,
      });
    }
  };
  function SelectAllChildren(parentLevel) {
    let values = props.dataFor==="initial"?{ ...selectedInitialProductState }:{...selectedTargetProductState};
    let selectedArr = [];
    values[parentLevel].map(
      (x) => ((x.isChecked = true), selectedArr.push(x.name))
    );

    let size = display[selectedProductLevel].data.length;
    if (display[selectedProductLevel].data[size - 1].value === parentLevel) {
      let url = generateUrl(selectedArr);
      props.handleSelectedValues({
        selectedKcArr: selectedArr,
        apiUrl: url.reformatKcStr,
        correlationAnalysisApiUrl: url.reformatKcStrNew,
        correlationAnalysisApiUrlT: url.reformatKcStrNewT,
        crossAnalysisApiUrl: url.reformatKcStrNew,
        crossAnalysisApiUrlT: url.reformatKcStrNewT,
        dataFor: props.dataFor,
      });
    }
    updateSelectedLevel(parentLevel);
  }
  function DeSelectAllChildren(parentLevel) {
    let values = props.dataFor==="initial"?{ ...selectedInitialProductState }:{...selectedTargetProductState};
    values[parentLevel].map((x) => (x.isChecked = false));
    updateSelectedLevel(parentLevel);
    unCheckBelowParentLevels(parentLevel);
  }
  const handleParentClick = (e) => {
    let x = e.target.value;
    props.dataFor === "initial" ? setInitialProductCheckBox({
      ...initialProductCheckBox,
      [x]: !initialProductCheckBox[x],
    }) : setTargetProductCheckBox({
      ...targetProductCheckBox,
      [x]: !targetProductCheckBox[x],
    });
    if (!initialParentState[x]) SelectAllChildren(x);
    else DeSelectAllChildren(x);
  };

  return (
    <div className={`${classes.root} z-50`} id={props.id || null} onMouseLeave={() => props.onMouseLeave ? props.onMouseLeave() : null}>
      <div style={{ direction: 'ltr' }}>
      {Object.entries(display).map(([key, item]) => (
        key === selectedProductLevel
        ?  <>
          {
            item.data.map((x) => (
              <div key={x.value}>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <div
                    className={`selector_${x.value} w-3 cursor-pointer`}
                    onClick={() => handleOpen(x.value)}
                    style={{ cursor: "pointer", justifyContent: "center" }}
                  >
                    {initialState[x.value] ? "-" : "+"}
                  </div>
                  {props.tabName === "cross" &&
                  x.value === item.data[item.data.length - 1].value ? (
                    " "
                  ) : (
                    <input
                      type="checkbox"
                      checked={props.dataFor==="initial"?initialProductCheckBox[x.value]:targetProductCheckBox[x.value]}
                      value={x.value || ''}
                      onChange={handleParentClick}
                      className="ml-1"
                    />
                  )}
                  <label
                    className={
                      `${initialState[x.value] ? classes.open : classes.hide} levelHeader ml-1 cursor-pointer`
                    }
                  >
                    {x.name}
                  </label>
                </div>
                <div style={{ marginLeft: "20px" }}>           
                  {initialState[x.value] && (
                    <ItemSearch
                      values={props.dataFor==="initial"?selectedInitialProductState[x.value]:selectedTargetProductState[x.value]}
                      parentv={x.value}
                      onSelection={(e) => {
                        onSelection(e);
                      }}
                      id={`searcher_${x.value}`}
                      
                    />
                  )}
                </div>
              </div>
            ))}
        </>
        : null
      ))}
      </div>
    </div>
  );
};

export default NestedSearch;
