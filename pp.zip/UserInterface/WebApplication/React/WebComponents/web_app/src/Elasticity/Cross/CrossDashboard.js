import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Grid,
  TableBody,
  TableCell,
  TableRow,
  TableHead,
  Table,
} from "@material-ui/core";
import {MemoizedCrossReport} from "./CrossReport";

import { useCrossAnalysis, useRegressionData, useLineFittingData, useCrossScopeSelector } from "../../services/queries";
import { getCrossURLParams, convertDateRange } from "../utils";
import useStore from "../../store";
import Dialog from "@material-ui/core/Dialog";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import {MemoizedWeekSelector } from '../Own/WeekSelector';
import CloseIcon from "@material-ui/icons/Close";
import Tooltip from '@material-ui/core/Tooltip';
import Typography from '@material-ui/core/Typography';


const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    flexGrow: 1,
    paddingLeft: "0.75rem",
    paddingRight: "0.75rem",
    boxSizing: "border-box",
  },
  paperDiv: {
    display: "flex",
    flexWrap: "wrap",
    backgroundColor: "#FFFFF",
    "& > *": {
      margin: theme.spacing(2),
      width: "100%",
    },
    paddingTop: "25px",
    height: "auto",
  },
  headerCellLevel1: {
    borderBottom: "none",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
    borderTop: "1px solid rgba(224, 224, 224, 1)",
    borderLeft: "1px solid rgba(224, 224, 224, 1)",
    textAlign: "center",
    fontWeight: "bold",
  },
  container: {
    backgroundColor: "#F6F8FC",
    height: "100vh",
  },
  button: {
    display: "inline-flex",
    marginTop: theme.spacing(2),
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  table: {
    minWidth: 650,
    background: "#fff",
    border: "1px solid rgba(0,0,0,0.2)",
  },
  cellData: {
    borderLeft: "1px solid #ccc",
    textTransform: "capitalize",
  },
  xAddButtonCell: {
    color: "#2662FF",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
    width: 100,
    borderLeft: "1px solid rgba(224, 224, 224, 1)",
  },
  yAddButtonCell: {
    color: "#2662FF",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
    width: 100,
    borderLeft: "1px solid rgba(224, 224, 224, 1)",
  },
  dashBoardTable: {
    marginBottom: "3em",
    background: "inherit",
    width: "75%",
  },
  hide: {
    padding: theme.spacing(1),
    width: 390,
    backgroundColor: theme.palette.background.light,
  },
  gridHeader: {
    textAlign: "center",
    padding: "2.5rem",
  },
  tableHeadCell: {
    fontWeight: "bold",
    color: "#494949",
    whiteSpace: "nowrap",
    width: 100,
    borderRight: "1px solid rgba(224, 224, 224, 1)",
    borderTop: "1px solid rgba(224, 224, 224, 1)",
    borderLeft: "1px solid rgba(224, 224, 224, 1)",
  },
  correlationCell: {
    fontWeight: "bold",
    color: "#494949",
    whiteSpace: "nowrap",
    width: 100,
    borderTop: "none",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
  },
  cellTable: {
    padding: "0",
    verticalAlign: "top",
  },
  high: {
    backgroundColor: "#CBF2DB",
    fontWeight: "bold",
    color: "#2ECC71",
    textAlign: "center",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
  },
  medium: {
    backgroundColor: "#FDF2C5",
    fontWeight: "bold",
    textAlign: "center",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
    color: "#DFB202",
  },
  low: {
    backgroundColor: "#FBCCCC",
    fontWeight: "bold",
    textAlign: "center",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
    color: "#F03434",
  },
  viewMore: {
    backgroundColor: "inherit",
    fontWeight: "bold",
    textAlign: "center",
    borderTop: "1px solid rgba(224, 224, 224, 1)",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
    color: "#2663FF",
  },
  emptyHeader: {
    fontWeight: "bold",
    color: "#494949",
    whiteSpace: "nowrap",
    width: 100,
    border: "none",
  },
  emptyCell: {
    fontWeight: "bold",
    color: "#494949",
    whiteSpace: "nowrap",
    width: 100,
    borderBottom: "none",
    borderRight: "none",
  },
  iconButton: {
    backgroundColor: "#2663FF",
    color: "#FFFFFF",
    borderRadius: "50%",
    width: "2.5rem",
    height: "2.5rem",
    padding: "5px",
    flexShrink: "none",
    flex: "0 0 auto",
    transform: "rotate(180deg)",
  },
  buttonLabel: {
    fontWeight: "bold",
    display: "inline-flex",
    color: "#2663FF",
  },
  btnContainer: {
		display: "flex",
    justifyContent:'flex-end',
    marginRight: '15%',
    marginBottom: "1em",
	},
	btnReset: {
		background: "#cb0c0c",
		color: "#fff",
		textTransform: "none",
		margin: "0 20px",
		padding: "6px 20px",
		borderRadius: "10px",
	},
	btnSucess: {
		background: "#163c62",
		color: "#fff",
		textTransform: "none",
		margin: "0 10px",
		padding: "6px 35px",
		borderRadius: "10px",
	},
}));

const centerAlignText = {
  textAlign: "center",
};

let count = 5;

export default function CrossDashboard(props) {
  const classes = useStyles();

  const [crossParameters, setcrossParameters] = useState()
  const [selectedCountry, setselectedCountry] = useState()
  const [crossURLParams, setcrossURLParams] = useState('')
  const [crossScopeURLParams, setcrossScopeURLParams] = useState('')
  let selectedSubCategoryLevel = useStore((state) => state.selectedSubCategoryLevel);
  let selectedProductLevel = useStore((state) => state.selectedProductLevel);
  const [initial,setInitial] = useState("");
  const [target,setTarget] = useState("");
  const [open,setOpen] = useState(false);
  const [originalDataInstance, setOriginalDataInstance] = useState([]);
  const [treeDataInstance, setTreeDataInstance] = useState([]);
  const [slopeInt,setSlopeInt]= useState(0);
  const [slopeFrac,setSlopeFrac]= useState("0");
  const [interceptInt,setInterceptInt]= useState(0);
  const [interceptFrac,setInterceptFrac]= useState(0);
  const [rSquared,setRsquared]= useState("0");
  const [elasticityInt,setElasticityInt]= useState(0);
  const [elasticityFrac,setElasticityFrac]= useState("0");
  const [combinedYearWeeks, setCombinedYearWeeks] =  useState([]);
  const [productLevel,setProductLevel] = useState("");
  const [category,setCategory] = useState("");
  const [customer,setCustomer] = useState("");

  const handleClose = () => {
    setOpen(false)
  }

  useEffect(() => {
    const urlObj = new URL(window.location.href)
    var result = {
      country: urlObj.searchParams.get('country'),
      productLevel: urlObj.searchParams.get('productLevel'),
      initial: [urlObj.searchParams.get('initial')],
      target: [urlObj.searchParams.get('target')],
      source: urlObj.searchParams.get('source'),
      scope: urlObj.searchParams.get('scope'),
      category: urlObj.searchParams.get('category'),
      subCategoryInitial: urlObj.searchParams.get('subCategoryInitial'),
      subCategoryTarget: urlObj.searchParams.get('subCategoryTarget'),
      manufacturerInitial: urlObj.searchParams.get('manufacturerInitial'),
      manufacturerTarget: urlObj.searchParams.get('manufacturerTarget'),
      brandInitial: urlObj.searchParams.get('brandInitial'),
      brandTarget: urlObj.searchParams.get('brandTarget'),
      customer: urlObj.searchParams.get('customer'),
    };
    console.log("result:",result)
    if (result.productLevel === 'EAN') {
      setInitial(result.initial[0].split('-')[0].trim())
      setTarget(result.target[0].split('-')[0].trim())
    } else {
      setInitial(result.initial);
      setTarget(result.target);
    }
    setCategory(result.category)
    if(result.scope === 'PCUST'){
      setCustomer(result.customer)
    }
    setProductLevel(result.productLevel)
    setselectedCountry(result.country)
    setcrossParameters(result) 

    const url = getCrossURLParams(result.initial, result.target,result.category, result.productLevel, result.country, result.source, result.scope, [result.subCategoryInitial],[result.subCategoryTarget],[result.manufacturerInitial],[result.manufacturerTarget],[result.brandInitial],[result.brandTarget] || 'COUNTRY' );

    if(result.scope === 'WC') {
      setcrossURLParams(url)
    } else {
      setcrossScopeURLParams(url)
    }
    
  }, [])

  const setRegressionApiBodyCross = useStore((state) => state.setRegressionApiBodyCross);
  let regressionApiBodyCross = useStore((state) => state.regressionApiBodyCross);

  const {isLoading: loadingLineFittingData, data: lineFittingData, isError: isLineFittingError} = 
    useLineFittingData (`country=${selectedCountry}&initial=${initial}&target=${target}&hierarchyLevel=${productLevel}&category=${category},&customer=${customer}`);
  
  const {isLoading: loadingRegressionData, data: regressionData, isError: isRegressionError} = useRegressionData (regressionApiBodyCross);
  useEffect(() => {
  if(!loadingRegressionData && !isRegressionError) {
    let {
      elasticityDecimal,
      elasticityIntegral,
      interceptDecimal,
      interceptIntegral,
      rSquared,
      slopeDecimal,
      slopeIntegral,
    } = { ...regressionData };


    setSlopeInt(slopeIntegral);
    setSlopeFrac(slopeDecimal);
    setInterceptInt(interceptIntegral);
    setInterceptFrac(interceptDecimal);
    setRsquared(rSquared);
    setElasticityInt(elasticityIntegral);
    setElasticityFrac(elasticityDecimal);

    let combinedYearWeeksValues = [];

    for(let i=0;regressionApiBodyCross && i<regressionApiBodyCross['dataPoints']?.length;i++) {
      let obj = regressionApiBodyCross['dataPoints'][i];
      let y = obj.year.toString();
      let w = '0'+obj.week.toString();
      let c = y+w.slice(-2);

      combinedYearWeeksValues.push(c); //to apply PBI filter on combined year and week values
    }
    setCombinedYearWeeks(combinedYearWeeksValues);
  }
  },[loadingRegressionData])

  
  useEffect(()=>{
    if(!loadingLineFittingData) {
      let lineDataObj = {};
  
      for (let i = 0; i < lineFittingData.length; i++) {
        let obj = lineFittingData[i];
        let key = obj.year.toString();
        if (!lineDataObj[key]) {
          lineDataObj[key] = [obj];
        } else {
          lineDataObj[key].push(obj);
        }
      }
      
  
      // Constructing drop down tree select object
      let treeNodes = [];
      for(const key in lineDataObj) {
        let arr = [];
        if(lineDataObj.hasOwnProperty(key)) {
          let val = lineDataObj[key];
          for(let i=0;i<val.length;i++) {
            let item = {};
            item['label'] = `Week ${val[i]['week']}`
            item['checked'] = false;
            arr.push(item);
          }
        }
        let node = {};
        node['label'] = key;
        node['children'] = arr;
        treeNodes.push(node);
      }
        // setOriginalData(lineDataObj);
        // setTreeData(treeNodes);

        setOriginalDataInstance(lineDataObj);
        setTreeDataInstance(treeNodes);
        
        //On initial loading pushing all data points
        let result = {};
        let dp = [];
        for( const key in lineDataObj) {
          for(let i=0;i< lineDataObj[key].length;i++) {
              dp.push(lineDataObj[key][i]);
          }
        }
        result['country'] = selectedCountry;
        result['dataPoints'] = dp;
        // setRegressionApiBody(result);
        setRegressionApiBodyCross(result)

    }
  },[loadingLineFittingData])

  const { isLoading: isCrossDashboardData, data: crossDashboardData , isError: crossDashboardDataError} = useCrossAnalysis( crossURLParams || '');
  const { isLoading: isCrossDashboardScopeData, data: crossDashboardScopeData , isError: crossDashboardScopeDataError} = useCrossScopeSelector( crossScopeURLParams || '');


  const [crossObj, setCrossObj] = useState()

  const transformData = (dataArray) => {
    console.log(`DATA`, dataArray);
    let pattern = {
      id: "",
      initial: "",
      target: "",
      avgPrice: "",
      range: "",
      rsquared: "",
      basePrice: "",
      promoPrice: "",
      priceIndex: "",
      pvalue: "",
      averageVolume: "",

    };
    const data = dataArray && dataArray.length > 0 ? dataArray[0] : null

    if (data) {
      count += 1;
      pattern.id = count;

      pattern.initial = crossParameters.initial[0];
      pattern.target = crossParameters.target[0];
      pattern.averageVolume = {
        hasValue: data.averageVolume || data.averageVolume === 0 ? true : false,
        value:
          data.averageVolume || data.averageVolume === 0 ? data.averageVolume : null,
      };
      pattern.priceIndex = {
        hasValue: data.priceIndex || data.priceIndex === 0 ? true : false,
        value:
          data.priceIndex || data.priceIndex === 0 ? data.priceIndex : null,
      };
      pattern.range = data.range;
      pattern.rsquared = {
        hasValue: data.rsquared || data.rsquared === 0 ? true : false,
        value: data.rsquared || data.rsquared === 0 ? data.rsquared : null,
      };
      pattern.pvalue = {
        hasValue: data.pvalue || data.pvalue === 0 ? true : false,
        value: data.pvalue || data.pvalue === 0 ? data.pvalue : null,
      };
      pattern.avgPrice = {
        hasValue: data.averagePrice || data.averagePrice === 0 ? true : false,
        value:
          data.averagePrice || data.averagePrice === 0
            ? data.averagePrice
            : null,
      };
      pattern.basePrice = {
        hasValue: data.basePrice || data.basePrice === 0 ? true : false,
        value: data.basePrice || data.basePrice === 0 ? data.basePrice : null,
      };
      pattern.promoPrice = {
        hasValue: data.promoPrice || data.promoPrice === 0 ? true : false,
        value:
          data.promoPrice || data.promoPrice === 0 ? data.promoPrice : null,
      };
      pattern.nweeks = {
        hasValue: data.nweeks ? true : false,
        value: data.nweeks ? data.nweeks : null,
      };
      pattern.period = {
        hasValue: data.periodBegin && data.periodEnd ? true : false,
        periodBegin: data.periodBegin,
        periodEnd: data.periodEnd
      };
    }
    console.log(pattern);
    return pattern;
  };

  useEffect(() => {
    if (crossDashboardData){
      const _crossObj = transformData(crossDashboardData);
      setCrossObj(_crossObj)
    }
  }, [crossDashboardData])
  
  useEffect(() => {
    if (crossDashboardScopeData){
      const _crossObj = transformData(crossDashboardScopeData[crossParameters.customer]);
      setCrossObj(_crossObj)
    }
  }, [crossDashboardScopeData])

  const columns = [
    {
      Header: "Initial Product",
      accessor: "initialProduct",
    },
    {
      Header: "Target Product",
      accessor: "targetProduct",
    },
    {
      Header: selectedCountry === 'KR' ? 'Volume SU Target'  : "Average Volume",
      accessor: "averageVolume",
    },
    {
      Header: selectedCountry === 'KR' ? 'Price SU Initial'  :"Index Unit Price",
      accessor: "averagePrice",
    },
    {
      Header: "Range",
      accessor: "range",
    },
    {
      Header: "R-Squared",
      accessor: "rsquared",
    },
    {
      Header: "P Value",
      accessor: "pValue",
    },
  ];

  return (
    <Grid item xs={12} sm={12}>
      
      {(crossDashboardDataError || crossDashboardScopeDataError) && alert("Some thing went wrong, please reload page")}
      {
        crossObj
        ? <Grid className={classes.paperDiv}>
            <div className={classes.chartDiv}>
              <div className={classes.grid} style={{ display: "inline" }}>
                <Table align="center" className={classes.dashBoardTable}>
                  <TableHead>
                    <TableRow>
                      <TableCell
                        colSpan={12}
                        className={classes.headerCellLevel1}
                        style={centerAlignText}
                      >
                        {`Price Elasticity`} {customer?` - ${customer}`:""}
                      </TableCell>
                    </TableRow>
                    <TableRow className={classes.headRow}>
                      {columns.map((tableCell) => (
                        <Tooltip
                        title={<Typography fontSize={20}>{tableCell.Header}</Typography>}>
                        <TableCell
                          colSpan={1}
                          className={classes.tableHeadCell}
                          style={centerAlignText}
                        >
                          {tableCell.Header}
                        </TableCell>
                        </Tooltip>
                      ))}
                      {crossObj.avgPrice && crossObj.avgPrice.hasValue && (
                        <Tooltip
                        title={<Typography fontSize={20}>{`AVG`}</Typography>}>
                          <TableCell
                            colSpan={1}
                            className={classes.tableHeadCell}
                            style={centerAlignText}
                          >
                            {`AVG`}
                          </TableCell>
                          </Tooltip>
                        )}
                      {crossObj.promoPrice && crossObj.promoPrice.hasValue && (
                        <Tooltip
                        title={<Typography fontSize={20}>{`Promo`}</Typography>}>
                          <TableCell
                            colSpan={1}
                            className={classes.tableHeadCell}
                            style={centerAlignText}
                          >
                            {`Promo`}
                          </TableCell>
                          </Tooltip>
                        )}
                      {crossObj.basePrice && crossObj.basePrice.hasValue && (
                        <Tooltip
                        title={<Typography fontSize={20}>{`Base`}</Typography>}>
                        <TableCell
                          colSpan={1}
                          className={classes.tableHeadCell}
                          style={centerAlignText}
                        >
                          {`Base`}
                        </TableCell>
                        </Tooltip>
                      )}

                      {crossObj.nweeks && crossObj.nweeks.hasValue && (
                        <Tooltip
                        title={<Typography fontSize={20}>{`Number of weeks`}</Typography>}>
                        <TableCell
                          colSpan={1}
                          className={classes.tableHeadCell}
                          style={centerAlignText}
                        >
                          {`# of weeks`}
                        </TableCell>
                        </Tooltip>
                      )}
                       {crossObj.period && crossObj.period.hasValue && (
                        <Tooltip
                        title={<Typography fontSize={20}>{`Period`}</Typography>}>
                        <TableCell
                          colSpan={1}
                          className={classes.tableHeadCell}
                          style={centerAlignText}
                        >
                          {`Period`}
                        </TableCell>
                        </Tooltip>
                      )}
                    </TableRow>
                  </TableHead>

                  <TableBody>
                    <TableRow>
                      {crossObj && (
                        <>
                          <TableCell
                            style={centerAlignText}
                            className={classes.yAddButtonCell}
                          >
                            <div className="kcOvalShape">{crossObj.initial}</div>
                          </TableCell>
                          <TableCell
                            style={centerAlignText}
                            className={classes.yAddButtonCell}
                          >
                            <div className="targetOvalShape">{crossObj.target}</div>
                          
                          </TableCell>
                          <TableCell
                            style={centerAlignText}
                            className={
                              crossObj.range === "LOW"
                                ? classes.low
                                : crossObj.range === "HIGH"
                                ? classes.high
                                : classes.medium
                            }
                          >
                            {crossObj.averageVolume.hasValue &&
                              `${parseFloat(crossObj.averageVolume.value).toLocaleString("en-US", {maximumFractionDigits: 3, minimumFractionDigits: 3})}`}
                          </TableCell>
                          <TableCell
                            style={centerAlignText}
                            className={
                              crossObj.range === "LOW"
                                ? classes.low
                                : crossObj.range === "HIGH"
                                ? classes.high
                                : classes.medium
                            }
                          >
                            {crossObj.priceIndex.hasValue &&
                              selectedCountry === 'KR' ? `${parseFloat(crossObj.priceIndex.value).toLocaleString("en-US", {maximumFractionDigits: 0, minimumFractionDigits: 0})}` : `${parseFloat(crossObj.priceIndex.value).toLocaleString("en-US", {maximumFractionDigits: 3, minimumFractionDigits: 3})}`}
                          </TableCell>
                          <TableCell
                            style={centerAlignText}
                            className={
                              crossObj.range === "LOW"
                                ? classes.low
                                : crossObj.range === "HIGH"
                                ? classes.high
                                : classes.medium
                            }
                          >
                            {crossObj.range}
                          </TableCell>

                          <TableCell
                            style={centerAlignText}
                            className={
                              crossObj.range === "LOW"
                                ? classes.low
                                : crossObj.range === "HIGH"
                                ? classes.high
                                : classes.medium
                            }
                          >
                          {crossObj.rsquared.hasValue && parseFloat(crossObj.rsquared.value).toLocaleString("en-US", {maximumFractionDigits: 3, minimumFractionDigits: 3})}
                          </TableCell>

                          <TableCell
                            style={centerAlignText}
                            className={
                              crossObj.range === "LOW"
                                ? classes.low
                                : crossObj.range === "HIGH"
                                ? classes.high
                                : classes.medium
                            }
                          >
                          {crossObj?.pvalue?.hasValue ? parseFloat(crossObj?.pvalue?.value): "-"}
                          </TableCell>

                          {crossObj.avgPrice.hasValue && (
                            <TableCell
                              style={centerAlignText}
                              className={
                                crossObj.range === "LOW"
                                  ? classes.low
                                  : crossObj.range === "HIGH"
                                  ? classes.high
                                  : classes.medium
                              }
                            >
                            {parseFloat(crossObj.avgPrice.value).toLocaleString("en-US", {maximumFractionDigits: 3, minimumFractionDigits: 3})}
                            </TableCell>
                          )}
                          {crossObj.promoPrice.hasValue && (
                            <TableCell
                              style={centerAlignText}
                              className={
                                crossObj.range === "LOW"
                                  ? classes.low
                                  : crossObj.range === "HIGH"
                                  ? classes.high
                                  : classes.medium
                              }
                            >
                            { parseFloat(crossObj.promoPrice.value).toLocaleString("en-US", {maximumFractionDigits: 3, minimumFractionDigits: 3})}
                            </TableCell>
                          )}
                          {crossObj.basePrice.hasValue && (
                            <TableCell
                              style={centerAlignText}
                              className={
                                crossObj.range === "LOW"
                                  ? classes.low
                                  : crossObj.range === "HIGH"
                                  ? classes.high
                                  : classes.medium
                              }
                            >
                                {parseFloat(crossObj.basePrice.value).toLocaleString("en-US", {maximumFractionDigits: 3, minimumFractionDigits: 3})}
                            </TableCell>
                          )}

                        {crossObj.nweeks.hasValue && (
                            <TableCell
                              style={centerAlignText}
                              className={
                                crossObj.range === "LOW"
                                  ? classes.low
                                  : crossObj.range === "HIGH"
                                  ? classes.high
                                  : classes.medium
                              }
                            >
                              {crossObj.nweeks.value}
                            </TableCell>
                          )}

                        {crossObj.period.hasValue && (
                            <TableCell
                              style={centerAlignText}
                              className={
                                crossObj.range === "LOW"
                                  ? classes.low
                                  : crossObj.range === "HIGH"
                                  ? classes.high
                                  : classes.medium
                              }
                            >
                              {convertDateRange(crossObj.period.periodBegin)} - {convertDateRange(crossObj.period.periodEnd)}
                            </TableCell>
                          )}  
                        </>
                      )}
                    </TableRow>
                  </TableBody>
                </Table>
                {selectedCountry !== "KR" ? <div className={classes.btnContainer}> 
                  <button variant="contained" onClick={()=>setOpen(true)} className = "border border-primary text-primary rounded p-1 ">Edit Weeks</button>
                </div> : null}
                <Dialog
                  open={open}
                  keepMounted
                  onClose={handleClose}
                  aria-describedby="alert-dialog-slide-description"
                >
                  <DialogTitle>
                    <h2 className="w-full flex justify-between">
                      <span>Select week range</span>
                      <CloseIcon onClick={handleClose}/>
                    </h2>
                  </DialogTitle>
                  <DialogContent style={{height:'600px', alignItems:'center'}}>
                    <DialogContentText id="alert-dialog-slide-description">
                      <MemoizedWeekSelector 
                        initial = {initial}
                        target = {target}
                        originalDataInstance = {originalDataInstance}
                        treeDataInstance = {treeDataInstance}
                        handleClose = {handleClose}
                        tabName="cross"
                        />
                    </DialogContentText>
                  </DialogContent>
                </Dialog>
                {
                  crossParameters 
                  ? <MemoizedCrossReport 
                      {...crossParameters}
                      customer = {customer}
                      slopeInt = {slopeInt}
                      slopeFrac = {slopeFrac}
                      interceptInt = {interceptInt}
                      interceptFrac = {interceptFrac}
                      rSquared = {rSquared}
                      elasticityInt = {elasticityInt}
                      elasticityFrac = {elasticityFrac}
                      combinedYearWeeks = {combinedYearWeeks}
                    />
                  : null
                }
              </div>
            </div>
          </Grid>
          : null
      }
    </Grid>
  );
}
