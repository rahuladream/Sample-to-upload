import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Toolbar } from "@material-ui/core";
import ProductLevelSelector from "../Widgets/ProductLevelSelector";
import NestedSearch from "../NestedSearch";
import { useCorrelationAnalysis } from "../../services/queries";
import useStore from "../../store";
import { useKcProductHierarchy, useTargetProductHierarchy } from "../../services/queries";
import useClickOutside from "../../ClickOutside";
import { getHierarchyLevel, paginationPerPageDataLimit } from "../utils";
import CorrlelationGrid from "./CorrlelationGrid";
import EmptyGrid from "./EmptyGrid";
import AppTabs from "../../AppTabs";
import AppPagination from '../Pagination';

const useStyles = makeStyles((theme) => ({
  button: {
    display: "block",
    marginTop: theme.spacing(2),
  },
}));

const headCells = [
  
];

export default function CorrelationTab(props) {
  const classes = useStyles();

  let selectedCountry = useStore((state) => state.selectedCountry);
  const [canShowCustomerFilter,setCanShowCustomerFilter] = useState(false);
  const [hiddenCustomers,setHiddenCustomers] = useState([]);
  const [sortedAllCustomers,setSortedAllCustomers] = useState([])
  const [showCustomers,setShowCustomers] = useState([])
  const [tabsToShow, setTabsToShow] = useState([]);
  let selectedCustomer = useStore((state) => state.selectedCustomer);
  const setSelectedCustomer = useStore((state) => state.setSelectedCustomer);
  const setSelectedKcProducts = useStore(
    (state) => state.setSelectedKcProducts
  );

  const [correlationDataNew, setCorrelationDataNew] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [correlationTabPaginationCount, setCorrelationTabPaginationCount] = useState(0);
  const [correlationInitialProducts, setCorrelationInitialProducts] = useState([]);
  const [correlationAnalysisPayload, setCorrelationAnalysisPayload] = useState({});

  let selectedScopeLevel = useStore((state) =>
        state.selectedScopeLevel ? state.selectedScopeLevel : "WC"
    );

  //------SELECTION: TARGET PRODUCT------//
  const setSelectedTargetProducts = useStore(
    (state) => state.setSelectedTargetProducts
  );

  const [elasticityCol, setElasticityCol] = useState({
    avgPrice: true,
    promoPrice: false,
    basePrice: false,
  });
  let selectedProductLevel = useStore((state) =>
    state.selectedProductLevel ? state.selectedProductLevel : "ean"
  );

  const setSelectedProductLevel = useStore(
    (state) => state.setSelectedProductLevel
  );

  //Initial Product data
  const { isLoading: isKcProductData, data: kcProductData } = useKcProductHierarchy(selectedCountry, getHierarchyLevel(selectedProductLevel));


  const setSelectedCategoryLevel = useStore(
    (state) => state.setSelectedCategoryLevel
  );

  let selectedCategoryLevel = useStore((state) => state.selectedCategoryLevel);
  const [hasCategoryLevel, setHasCategoryLevel] = useState(selectedCategoryLevel !== "" ? true : false);

  const setSelectedScopeLevel = useStore(
    (state) => state.setSelectedScopeLevel
  );

  function clearGrid() {
    setTabsToShow([]);
    setSortedAllCustomers([]);
    setShowCustomers([]);
    setSelectedCustomer("");
  }

  const onchange = (data) => {
    if (data[0] === "productLevel") {
      setSelectedProductLevel(data[1]);
      setSelectedKcProducts("");
      setSelectedTargetProducts("");
    } else if (data[0] === "categoryLevel") {
      setSelectedCategoryLevel(data[1]);
      setHasCategoryLevel(true);
    } else {
      setElasticityCol(data[1]);
    }
    clearGrid();
  };

  const onScopeChange = (data) => {
    setSelectedScopeLevel(data);
    setSelectedKcProducts("");
    setSelectedTargetProducts("");
  };

  //Perform action on clicking outside
  let domNodeX = useClickOutside(()=>{
    setOpenXAxis(false);
  })
  let domNodeY = useClickOutside((flag)=>{
    if (flag) {
      onClickClear();
    }
    setOpenYAxis(false);
  })


  const [openXAxis, setOpenXAxis] = useState(false);
  const [openYAxis, setOpenYAxis] = useState(false);
  const handleOpenXAxis = () => {
    if (hasCategoryLevel) setOpenXAxis(!openXAxis);
  };
  const handleOpenYAxis = () => {
    if (hasCategoryLevel) setOpenYAxis(!openYAxis);
  };

  const [initialProductSelected, setInitialProductSelected] = useState([]);
  const [targetProductSelected, setTargetProductSelected] = useState([]);
  const [targetProductUrl, setTargetProductUrl] = useState("");
  const [clear, setClear] = useState(false);

  const setInitialValueCorrelationUrl = useStore(
      (state) => state.setInitialValueCorrelationUrl
    );
     
  const setTargetValueCorrelationUrl = useStore(
      (state) => state.setTargetValueCorrelationUrl
    );

  const handleSelectedValues = (kcObject) => {

    if (kcObject.dataFor === "target") {
      setTargetProductSelected(kcObject.selectedKcArr);
      setTargetValueCorrelationUrl(kcObject.correlationAnalysisApiUrlT);
      
    } else {
      setInitialProductSelected(kcObject.selectedKcArr);
      setTargetProductUrl(kcObject.apiUrl);
      setInitialValueCorrelationUrl(kcObject.correlationAnalysisApiUrl);
      if (!kcObject.selectedKcArr.length) {
        setTargetProductSelected([]);
        setTargetValueCorrelationUrl("");
      }
    }
  };

  useEffect(() => {
    const data = {
      country: selectedCountry,
      scope: selectedScopeLevel,
      initialNodeValues: initialProductSelected,
      targetNodeValues: targetProductSelected,
      hierarchyLevel: getHierarchyLevel(selectedProductLevel)
    }
    setCorrelationAnalysisPayload(data);
  }, [selectedCountry, selectedProductLevel, initialProductSelected, targetProductSelected, selectedScopeLevel])

  useEffect(() => {
    setInitialProductSelected([]);
    setTargetProductSelected([]);
    setOpenXAxis(false);
    setOpenYAxis(false);
  }, [selectedProductLevel, selectedCountry]);

  //API CALL: TARGET PRODUCT LIST
  const { isSuccess: haveTargetData, data: targetData } =
    useTargetProductHierarchy(targetProductUrl);

  let initialValueCorrelationUrl = useStore(
    (state) => state.initialValueCorrelationUrl
  );
    
  let targetValueCorrelationUrl = useStore(
      (state) => state.targetValueCorrelationUrl
  );
  
  useEffect(() => {
    setInitialValueCorrelationUrl("");
    setTargetValueCorrelationUrl("");
    clearGrid();
  }, [])
    
  //API CALL: GET Correlation data
  const { isLoading: isCorrelationData, data: correlationData } = useCorrelationAnalysis(correlationAnalysisPayload);
  
  const parseCorrelationData = (data) => {
    let cust = Object.keys(data).sort();
    let allTabs = [];
    for(const [index,_tab] of cust.entries()) {
      allTabs.push({ index: index, tag: _tab, value: _tab, id: _tab, name:"CUSTOMER"})
    }
    setTabsToShow(allTabs);
    setSortedAllCustomers(cust)
    setShowCustomers(cust)
    setSelectedCustomer(cust[0])
  }

  useEffect(() => {
    if (
      !isCorrelationData &&
      initialProductSelected &&
      targetProductSelected &&
      correlationData
    ) {
      parseCorrelationData(correlationData)
      setCorrelationDataNew(correlationData);
    }
     else if(correlationData){
      clearGrid();
    }
  }, [
    isCorrelationData,
    correlationData,
    initialProductSelected,
    targetProductSelected,
  ]);
  const onClickClear = () => {
    setInitialProductSelected([]);
    setTargetProductSelected([]);
    setTargetProductUrl("");
    setInitialValueCorrelationUrl("");
    setTargetValueCorrelationUrl("");
    setClear(true);  
    clearGrid();
  };
  const handleClear = () => {
    setClear(false);
  }

  useEffect(() => {
    setInitialProductSelected([]);
    setTargetProductSelected([]);
    setTargetProductUrl("");
    setInitialValueCorrelationUrl("");
    setTargetValueCorrelationUrl("");
    clearGrid();
  }, [selectedCategoryLevel]);

  useEffect(() => {
    const startIndex = currentPage * paginationPerPageDataLimit - paginationPerPageDataLimit;
    const endIndex = startIndex + paginationPerPageDataLimit;
    if(initialProductSelected && (showCustomers.length !== 0 && Object.entries(correlationDataNew[selectedCustomer]).length !== 0)) {      
      setCorrelationTabPaginationCount(initialProductSelected.length);
      setCorrelationInitialProducts(initialProductSelected.slice(startIndex, endIndex));
    } else {
      setCorrelationTabPaginationCount(0);
      setCorrelationInitialProducts([]);
    }
}, [currentPage, correlationData, selectedCustomer, initialProductSelected]);

const handlePageData = (currentPage) => {
  setCurrentPage(currentPage);
}

const TableToolbar = () => {
    return (
      <Toolbar className={classes.crossToolbar}>
        <button className = "border border-primary text-primary rounded p-1 w-20" onClick={onClickClear}>CLEAR</button>
      </Toolbar>
    );
  };

const filterCustomer = (except) => {
  const show = sortedAllCustomers.filter(e=>!except.includes(e))
  let custTabs = [];
  for(const _tab of show) {
    custTabs.push({ index: _tab.index, tag: _tab, value: _tab, id: _tab, name:"CUSTOMER"})
  }
  setTabsToShow(custTabs);
  setShowCustomers(show);
  setSelectedCustomer(show[0]);
}

const ScopeFilter = () => <div className="relative flex justify-start p-2">
<button className="bg-white border border-primary text-primary rounded text-sm p-2" onClick={()=>setCanShowCustomerFilter(!canShowCustomerFilter)}>Filter Customer</button>
{
    canShowCustomerFilter
    ? <div className="absolute bg-white top-12 flex flex-col p-5 border shadow border-primary rounded z-50" onMouseLeave={()=> setCanShowCustomerFilter(false)}>
        <div  className="hover:bg-blue-200 p-1 flex justify-start items-center gap-1" onClick={(e)=> {
            if (hiddenCustomers.length === 0){
                setHiddenCustomers(sortedAllCustomers)
                filterCustomer(sortedAllCustomers)
            }else{
                setHiddenCustomers([])
                filterCustomer([])
            }
        }}>
            <input type="checkbox" checked={hiddenCustomers.length === 0}  />
            <span className="text-sm"> <b>All</b> </span>
        </div>
        {
            sortedAllCustomers.map((customer, idx)=> {
                return <div key={idx} className="hover:bg-blue-200 p-1 flex justify-start items-center gap-1" onClick={() => {
                    if (hiddenCustomers.includes(customer)){
                        const except = hiddenCustomers.filter(e=>e !== customer)
                        setHiddenCustomers(except)
                        filterCustomer(except)
                    }else{
                        const added =  [...hiddenCustomers, customer]
                        setHiddenCustomers(added)
                        filterCustomer(added)
                    }
                }}>
                    <input type="checkbox" checked={!hiddenCustomers.includes(customer)} />
                    <span className="text-sm"> {customer} </span>
                </div>
            })
        }
    </div>
    : null
}
</div>

  return (
    <div className="flex flex-col p-5">
      <ProductLevelSelector
        onchange={(e) => {
          onchange(e);
        }}
        onScopeChange={(e) => {
          onScopeChange(e);
        }}
        tabName="correlation"
      />

      <TableToolbar/>
      <div className="flex pb-4">
        <span>Initial Products: </span>
        <div className={`relative flex pr-2 z-10}`}>
            <div onClick={handleOpenYAxis} className="cursor-pointer px-2 py-1 z-6 ">
                <svg  className="fill-primary cursor-pointer" focusable="false" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" id="prod_picker1"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"></path></svg>
            </div>
            {
                openYAxis ?
                  <div className="absolute z-30" ref={domNodeY}>
                    <NestedSearch
                     data={kcProductData}
                     handleSelectedValues={handleSelectedValues}
                     tabName="correlation"
                     dataFor="initial"
                     clear={clear}
                     handleClear={handleClear}
                     previouslySelected={initialProductSelected}
                     id="searchYAxis"
                    />
                  </div>
                : null
            }
        </div>
        <div className="flex gap-x-3">
          {
            initialProductSelected.map((x)=> {
                return <span className="text-xs p-2 bg-gray-300 rounded">{x}</span>
            })
          }
        </div>
      </div>

      <div className="flex pb-4">
        <span>Target Products: </span>
        <div className=" relative flex pr-2">
            <div onClick={handleOpenXAxis} className="cursor-pointer px-2 py-1">
                <svg  className="fill-purple-700 cursor-pointer" focusable="false" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" id="prod_picker1"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"></path></svg>
            </div>
            {
                openXAxis && haveTargetData 
                ?  <div className="absolute z-30" ref={domNodeX}>
                    <NestedSearch
                      data={targetData}
                      handleSelectedValues={handleSelectedValues}
                      tabName="correlation"
                      dataFor="target"
                      clear={clear}
                      handleClear={handleClear}
                      previouslySelected={targetProductSelected}
                      id="searchXAxis" />
                      </div>
                : null
            }
        </div>
        <div className="flex gap-x-3">
          {
            targetProductSelected.map((x)=> {
                return <span className="text-xs p-2 bg-gray-300 rounded">{x}</span>
            })
          }
        </div>
      </div>
      <div className="flex">
        <div className="w-1/4">
          <ScopeFilter/>
        </div>
        <div className="w-3/4">
          <AppPagination
            pageData={initialProductSelected}
            handlePageData={handlePageData}
            dataCount={correlationTabPaginationCount}
            fromTab='correlation'
            applyPadding={false}
          />
        </div>
      </div>

      <div className="flex-column shadow-sm shadow-md shadow-brown-600 p-5 justify-center overflow-x-auto" >
        <AppTabs tabs={tabsToShow} fromCorrelation/>
        <div className="mt-2.5 justify-center">
          {showCustomers.length === 0 || showCustomers.length === 0 ? (
            <EmptyGrid />
          ) : (
            <CorrlelationGrid
              initialProductSelected={correlationInitialProducts}
              targetProductSelected={targetProductSelected}
              headCells={headCells}
              correlationDataNew={correlationDataNew[selectedCustomer]}
              customer={selectedCustomer}
              productLevel={getHierarchyLevel(selectedProductLevel)}
            />
          )}
        </div>
      </div>
    </div>
  );
}
