import { ProductsOnComparison } from "../types"

type Props = {
    records: ProductsOnComparison[]
}
export const ProductNames = ({records}:Props) => {
    return <>
        <div className="flex w-full h-16">
                        <div className="w-72 h-full  border-r border-gray-300 flex justify-center items-center font-bold">
                            Initial Product
                        </div>
                        <div className="w-72 h-full border-r border-gray-300 flex justify-center items-center font-bold">
                            Target Product
                        </div>
                    </div>

                    {
                        records && records.length > 0
                        ?  records.map((record,idx) => {
                                return <div className="flex  h-24  border border-gray-300" key={idx}>
                                            <div className=" w-72 h-full border-r border-gray-300">
                                                <div className="inner w-full bg-white flex items-center py-5">
                                                    <span className="bg-primary font-bold text-white p-2 rounded-xl  mx-5 w-full text-sm">
                                                        {record.initial}
                                                    </span>    
                                                </div>
                                            </div>
                                            <div className="w-72 h-full border-r border-gray-300">
                                                <div className="inner w-full bg-white flex items-center py-5">
                                                    <span className="bg-purple-700 font-bold text-white p-2 rounded-xl  mx-5 w-full text-sm">
                                                        {record.target}
                                                    </span>    
                                                </div>
                                            </div>
                                            <div>
                                            </div>
                                    </div>
                        })
                        : null
                    }
    </>
}