import React, { useEffect, useState } from 'react';
import { PowerBIEmbed } from 'powerbi-client-react';
import { useTokenBI } from '../../services/queries';
import CircularProgress from '@mui/material/CircularProgress';
import { models } from 'powerbi-client';
import '../../styles.css'
import { PowerBITableMapWithProductlevel } from '../utils';
import useStore from "../../store";
import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles((theme) => ({
	spinner: {
		position: 'absolute',
		height: '50px',
		width: '50px',
		top: '50%',
		left:'50%'
	}
}))

export const OwnReport = (props) => {  
	const classes = useStyles(); 

	const [ selecteddValue , setSelecteddValue] = useState([]);
	const [ bookmark , setBookmark] = useState({});
	const [ progress , setProgress] = useState(true);
	let {slopeInt,slopeFrac,interceptInt,interceptFrac,rSquared,elasticityInt,elasticityFrac,combinedYearWeeks, customer, category} = {...props};
	let selectedCountry = useStore((state) => state.selectedCountry);
	

	useEffect(()=>{
		if (typeof props.initial === 'string' || props.initial instanceof String){
			let initial = props.initial.trim();
			if (props.productLevel === 'EAN'){
				initial = initial.split('-')[0].trim()
			  }
			let newAry = [];
			newAry.push(initial)
			setSelecteddValue(newAry)
		}
	},[props])
	
	const { isLoading: isTokenData, data: tokenData, isSuccess } = useTokenBI(process.env.REACT_APP_OWN_ID);
	const [biToken, setBiToken] = useState('');
	const [embedUrl, setEmbedUrl] = useState('');
	

	useEffect(() => {
		if (!isTokenData && tokenData) {
			setBiToken(tokenData?.accessToken);
			setEmbedUrl(tokenData?.url)
			console.log("token", tokenData?.accessToken)
		}
		if(props.productLevel === 'EAN') {
			if(selectedCountry === 'KR') {
				setBookmark({name:process.env.REACT_APP_OWN_KOREA_BOOKMARK})
			} else {
				setBookmark({name:process.env.REACT_APP_OWN_OTHER_BOOKMARK})
			}
		} else if(props.productLevel === 'SUB_BRAND') {
			if(selectedCountry === 'KR') {
				setBookmark({name:process.env.REACT_APP_OWN_SUB_BRAND_KOREA_BOOKMARK})
			} else {
				setBookmark({name:process.env.REACT_APP_OWN_SUB_BRAND_BOOKMARK})
			}
		}
	}, [isTokenData, tokenData])



	const basicFilterCountry = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: PowerBITableMapWithProductlevel[props.productLevel][0],
			column: "COUNTRY"
		},
		operator: "In",
		filterType: models.FilterType.BasicFilter
	}

	const basicFilterCountry_1 = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: PowerBITableMapWithProductlevel[props.productLevel][1],
			column: "COUNTRY"
		},
		operator: "In",
		filterType: models.FilterType.BasicFilter
	}

	const basicFilterCustomer = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: PowerBITableMapWithProductlevel[props.productLevel][0],
			column: "CUSTOMER"
		},
		operator: "In",
		filterType: models.FilterType.BasicFilter
	}

	const basicFilterCustomer_1 = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: PowerBITableMapWithProductlevel[props.productLevel][1],
			column: "CUSTOMER"
		},
		operator: "In",
		filterType: models.FilterType.BasicFilter
	}
	

	const basicFilterKCEans = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: PowerBITableMapWithProductlevel[props.productLevel][0],
			column:`${props.productLevel}_INITIAL`
		},
		operator: "In",
		filterType: models.FilterType.BasicFilter
	}

	const basicFilterKCEans_1 = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: PowerBITableMapWithProductlevel[props.productLevel][1],
			column:`${props.productLevel}_INITIAL`
		},
		operator: "In",
		filterType: models.FilterType.BasicFilter
	}

	const basicFilterCategory = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: PowerBITableMapWithProductlevel[props.productLevel][0],
			column:`CATEGORY`
		},
		operator: "In",
		values: [category],
		filterType: models.FilterType.BasicFilter
	}

	const basicFilterCategory_1 = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: PowerBITableMapWithProductlevel[props.productLevel][1],
			column:`CATEGORY`
		},
		operator: "In",
		values: [category],
		filterType: models.FilterType.BasicFilter
	}

	const basicFilterSlopeInt = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: "Slope Integer",
			column: "Slope Integer"
		},
		values: [slopeInt],
		operator: "In",
		filterType: models.FilterType.BasicFilter
	}
	
	const basicFilterSlopeFrac = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: "Slope Fraction",
			column: "Slope Fraction"
		},
		values: [slopeFrac],
		operator: "In",
		filterType: models.FilterType.BasicFilter
	}
	const basicFilterInterceptInt = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: "Intercept Integer",
			column: "Intercept"
		},
		values: [interceptInt],
		operator: "In",
		filterType: models.FilterType.BasicFilter
	}

	const basicFilterInterceptFrac = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: "Intercept Fraction",
			column: "Intercept Fraction"
		},
		values: [interceptFrac],
		operator: "In",
		filterType: models.FilterType.BasicFilter
	}
	
	const basicFilterrSquared = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: "R Square Table",
			column: "R Square"
		},
		values: [rSquared],
		operator: "In",
		filterType: models.FilterType.BasicFilter
	}
	
	const basicFilterElasticityInt = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: "Elasticity Integer",
			column: "Elasticity Integer"
		},
		values: [elasticityInt],
		operator: "In",
		filterType: models.FilterType.BasicFilter
	}

	const basicFilterElasticityFrac = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: "Elasticity Fraction",
			column: "Elasticity Fraction"
		},
		values: [elasticityFrac],
		operator: "In",
		filterType: models.FilterType.BasicFilter
	}

	const basicFilterYearWeek = {
		$schema: "http://powerbi.com/product/schema#basic",
		target: {
			table: PowerBITableMapWithProductlevel[props.productLevel][0],
			column: "YEAR_WEEK"
		},
		values: combinedYearWeeks,
		operator: "In",
		filterType: models.FilterType.BasicFilter
	}

	const [filtersValue, setFiltersValue] = useState([]) 
	const getPageName = () =>{
		console.log(process.env.REACT_APP_OWN_PAGENAME)
		switch(props.productLevel) {
			case 'SUB_BRAND':
				return process.env.REACT_APP_OWN_SUB_BRAND_PAGENAME;
			default:
				return process.env.REACT_APP_OWN_PAGENAME;
		}
	}

	useEffect(() => {
		const filter = []

		if (props.country && selecteddValue && selecteddValue.length > 0){
			if (props.country?.length > 0) {
				basicFilterCountry.values =  [props.country]
				basicFilterCountry_1.values =  [props.country]
				filter.push(basicFilterCountry) 
				filter.push(basicFilterCountry_1)
			}

			if (customer) {
				basicFilterCustomer.values =  [customer]
				basicFilterCustomer_1.values =  [customer]
				filter.push(basicFilterCustomer) 
				filter.push(basicFilterCustomer_1)
			}
			
			
			basicFilterKCEans_1.values = selecteddValue
			basicFilterKCEans.values = selecteddValue

			filter.push(basicFilterCategory)
			filter.push(basicFilterCategory_1)

			filter.push(basicFilterKCEans) 
			filter.push(basicFilterKCEans_1)

			filter.push(basicFilterSlopeInt) 
			filter.push(basicFilterSlopeFrac)
			filter.push(basicFilterInterceptInt) 
			filter.push(basicFilterInterceptFrac) 
			filter.push(basicFilterrSquared)
			filter.push(basicFilterElasticityInt) 
			filter.push(basicFilterElasticityFrac)
			filter.push(basicFilterYearWeek)
		}

		setFiltersValue(filter) 
		setProgress(true);
	}, [props, selecteddValue])

	
	const generateReport = () =>{
		return <header className="App-header">
			{progress && <CircularProgress className={classes.spinner}/>}
					<PowerBIEmbed
						embedConfig={{
							pageName: getPageName(),
							type: 'report',   // Supported types: report, dashboard, tile, visual and qna
							id: process.env.REACT_APP_OWN_ID,
							embedUrl: embedUrl,
							accessToken: biToken, 
							tokenType: models.TokenType.Embed,
							filters: filtersValue,
							bookmark: bookmark,
							settings: {
								panes: {
									filters: {
										expanded: false,
										visible: false
									},
									pageNavigation: {
										visible: false
									},
								},
							}
						}}

						eventHandlers={
						new Map([
							['loaded', function () { console.log('Report loaded'); setProgress(true) }],
							['rendered', function () { 
								console.log('Report rendered');
								setProgress(false);
								setTimeout(() => {
									const parent = document.getElementsByClassName('Embed-container')
									if (parent && parent.length > 0){
										const iframe = document.getElementsByTagName('iframe',parent)
										if (iframe && iframe[0]){
											iframe[0].setAttribute('id','powerBIFrame')
										}
									}
									
								}, 2000)
							}],
							['error', function (event) { console.log(event.detail); setProgress(true)}]
						])
						}
						cssClassName={"Embed-container"}
						getEmbeddedComponent={(embeddedReport) => {
							window.report = embeddedReport;
						}}
					/>
			</header>
			
	
	}

	return (
		<div className="App" style={{height: '100%'}}>
			{
				!isTokenData && biToken &&  isSuccess && filtersValue && filtersValue.length > 0 && embedUrl
				? generateReport()
				: <CircularProgress className={classes.spinner}/>
			}

		</div>
	);
}

export const MemoizedOwnReport = React.memo(OwnReport);