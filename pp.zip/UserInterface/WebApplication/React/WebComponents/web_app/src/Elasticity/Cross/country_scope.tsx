import { useEffect, useState } from "react";
import { useKcProductHierarchy, useTargetProductHierarchy } from "../../services/queries";
import NestedSearch from "../NestedSearch"
import { SingleGrid } from "../single_grid";
import { ElasticityRecord, Scope, ProductsOnComparison, CustomSortFuction, PriceType } from "../types"
import { ProductNames } from "./product_names";
import { SelectionRow } from "./selection_row";
import { ViewMore } from "./view_more";
import AppPagination from '../Pagination';

type Props= {
    records: ElasticityRecord[],
    selectedCountry: string,
    unselectRow: (initial: string, target?:string) => void,
    handleViewMore?: (Initial: string, target?:string, category?:string, subCategoryInitial?:string, subCategoryTarget?:string, manufacturerInitial?:string, manufacturerTarget?:string, brandInitial?:string, brandTarget?:string,
        ) => void,
    loading: boolean,
    handleSelectedValues: (obj:any) => void,
    initialProductData: any,
    customSort?: CustomSortFuction,
    priceType: PriceType,
    scope?: String,
    source?: String,
    selectedProducts: any,
    selectedTargetProducts: any
    pageData?: any
    dataCount?: any
    handlePageData?: any
}

  
export const CrossCountryScope = ({records,  selectedCountry, unselectRow, handleViewMore,
     loading, handleSelectedValues, initialProductData, customSort, priceType, scope, source,
     selectedProducts, selectedTargetProducts, pageData, dataCount, handlePageData} : Props) => {
    

    const [comparisonCount, setcomparisonCount] = useState(0);
    return <div className="mt-10 flex flex-col  overflow-x-hidden relative w-full" style={{minHeight:600}}>
           
            <div className=" min-h-20">
                <SelectionRow initialProductData={initialProductData} handleSelectedValues={handleSelectedValues} comparisonAdded={() => setcomparisonCount(comparisonCount+1)}
                     emptySelection={records && records.length > 0 && records.length === comparisonCount} source={source} scope={scope} selectedProducts={selectedProducts} selectedTargetProducts={selectedTargetProducts}/>

            </div>
            <AppPagination 
                pageData={pageData}
                dataCount={dataCount}
                handlePageData={handlePageData}
                fromTab='cross'
                applyPadding={true}
            />  
            <div className=" flex flex-col bg-white w-full relative">
               
                     <div className=" flex w-full  ">
                       {
                           records && records.length > 0
                           ? <div className=" border w-full border-gray-300">
                               <SingleGrid loading={loading} records={[...records]} priceType={priceType}
                                    scope={Scope.COUNTRY} showName={true} showOptions={true} selectedCountry={selectedCountry}  showTargetProduct={true} handleViewMore={handleViewMore}
                                    unselectRow={unselectRow}></SingleGrid>
                           </div>
                           : <span className="flex justify-center items-center  h-16 w-full border border-l-0 border-gray-300 "> Cross Elasticity </span>
                       }
                    </div>
                   

            </div>
       
    </div>
}