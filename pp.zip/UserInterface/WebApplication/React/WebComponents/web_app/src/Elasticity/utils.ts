import { TableColumn } from "react-data-table-component";
import { ElasticityRecord, ElasticityScopeRecord, SelectedProduct } from "./types";

export const parseOwnAnalysisData = (selectedProducts: SelectedProduct, result: any,category:string) => {
    if (selectedProducts.selectedOwnArr && result) {
        const parsed: ElasticityRecord[] = []
        for (const selectedVal of Object.keys(result[0])) {
            if (result[0]?.hasOwnProperty(selectedVal)) {
                let obj = result[0][selectedVal];
                const newObj: ElasticityRecord = {
                    initial: selectedVal,
                    priceIndex: obj.priceIndex,
                    range: obj.range,
                    rsquared: obj.rsquared,
                    averagePrice: obj.averagePrice,
                    promoPrice: obj.promoPrice,
                    basePrice: obj.basePrice,
                    viewMore: obj.viewMore,
                    modelRun: obj.modelRun,
                    periodBegin:  obj.periodBegin,
                    periodEnd:  obj.periodEnd,
                    nweeks:  obj.nweeks,
                    pvalue: obj.pvalue,
                    averageVolume: obj.averageVolume,
                    category: category,
    
                };
                parsed.push(newObj)
              }
        }
        return parsed
    }
    return []
}


export const parseCrossAnalysisData = ( response: any, scope?:string) => {
    if (response ){
        const results: ElasticityRecord[]  = []
        for (const result of response) {
            const record: ElasticityRecord = {
                initial:result.initial,
                target:result.target,
                customer: scope,
                category: result.category,
                subCategoryInitial: result.subCategoryInitial,
                subCategoryTarget: result.subCategoryTarget,
                manufacturerInitial: result.manufacturerInitial,
                manufacturerTarget: result.manufacturerTarget,
                brandInitial: result.brandInitial,
                brandTarget: result.brandTarget,
                averagePrice : result.averagePrice,
                elasticity : result.elasticity,
                range : result.range,
                rsquared : result.rsquared,
                basePrice : result.basePrice,
                promoPrice : result.promoPrice,
                priceIndex : result.priceIndex,
                viewMore : result.viewMore,
                modelRun: result.modelRun,
                periodBegin:  result.periodBegin,
                periodEnd:  result.periodEnd,
                nweeks:  result.nweeks,
                pvalue: result.pvalue,
                averageVolume: result.averageVolume,
            }
            results.push(record)
        }
        return results
    
    }
    return []
}

export const sortScopeData = (data: ElasticityScopeRecord[] ,field:  TableColumn<ElasticityRecord>, direction: string) => {
    const sorted  = data.map(customerData => {
        const cloned = [...customerData.data]
        cloned.sort((rowA, rowB) => {
            if (field.selector){
                let aField = rowA[ field.sortField as keyof ElasticityRecord]
                let bField = rowB[ field.sortField as keyof ElasticityRecord]
                if (!aField){
                    if (field.sortField === 'priceIndex' || field.sortField === 'basePrice' 
                        || field.sortField === 'averagePrice' || field.sortField === 'promoPrice'
                        || field.sortField === 'rsquared' ){
                            aField = -1000
                        }else{
                            aField = ''
                        }
                }
                if (!bField){
                    if (field.sortField === 'priceIndex' || field.sortField === 'basePrice' 
                    || field.sortField === 'averagePrice' || field.sortField === 'promoPrice'
                    || field.sortField === 'rsquared' ){
                        bField = -1000
                    }else{
                        bField = ''
                    }
                }

                let comparison = 0;

                if (aField > bField) {
                    comparison = 1;
                } else if (aField < bField) {
                    comparison = -1;
                }

                return direction === 'desc' ? comparison * -1 : comparison;
            }
            return 0

        })
        customerData.data = cloned
        return customerData
    })
    return sorted
}

export const PowerBITableMapWithProductlevel = {
    'EAN' : [
        'V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS',
        'V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_SIM'
    ],
    'SUB_BRAND' : [
        'V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS_SUB_BRAND',
        'V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_SIM_SUB_BRAND'
    ],
    'BRAND': [
        'V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS_BRAND',
        'V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_SIM_BRAND'
    ],
    'SUB_CATEGORY': [
        'V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS_SUB_CATEGORY',
        'V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_SIM_SUB_CATEGORY'
    ],
    'PACK': [
        'V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS_PACK',
        'V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_SIM_PACK'
    ]
}


export const getHierarchyLevel = (selectedProductLevel: string) => {
    let productLevelParameter = ''
    switch (selectedProductLevel) {
        case "category":
          productLevelParameter = "CATEGORY";
          break;
        case "subCategory":
          productLevelParameter = "SUB_CATEGORY";
          break;
        case "brand":
          productLevelParameter = "BRAND";
          break;
        case "subBrand":
          productLevelParameter = "SUB_BRAND";
          break;
        case "pack":
          productLevelParameter = "PACK";
          break;
        default:
          productLevelParameter = "EAN";
          break;
    }
    return productLevelParameter
}

export const getCrossURLParams = (initialNodes: string[], targetNodes: string[], category:string, hierarchy: string, country: string, source: string, scope: string, subCategoryInitial: string[],subCategoryTarget: string[],manufacturerInitial: string[], manufacturerTarget: string[], brandInitial: string[], brandTarget: string[], ) => {
    if (initialNodes.length > 0 &&targetNodes.length > 0){
        const params = new URLSearchParams({
            country: country.toUpperCase(),
            hierarchyLevel: hierarchy.toUpperCase(),
        })
        if (source){
            params.set('source', source.toUpperCase())
        }
        if(category) {
            params.append('category', category)
        }
        for (const _initial of initialNodes) {
            params.append('initialNodeValues', _initial)
        }

        for (const _target of targetNodes) {
            params.append('targetNodeValues', _target)
        }

        if (scope !== 'COUNTRY'){
            params.set('scope',scope?.toUpperCase())
        }

        for (const _initial of subCategoryInitial) {
            if(_initial!=="null")
                params.append('initialSubCategories', _initial)
        }

        if(manufacturerInitial[0]!=="null") {
            for (const _initial of manufacturerInitial) {
               
                    params.append('initialManufacturers', _initial)}
            
        }
        
        if(manufacturerTarget[0]!=="null") {
            for (const _initial of manufacturerTarget) {
                
                    params.append('targetManufacturers', _initial)
                }
            
        }
       
        if(brandInitial[0]!=="null") {
            for (const _initial of brandInitial) {
                    params.append('initialBrands', _initial)}
        }
        if(brandTarget[0]!=="null") {
            for (const _initial of brandTarget) {
                if(!_initial!== null) {
                    params.append('targetBrands', _initial)}
            }
        }
       
        
        return params.toString()
    }
    return null
  
}

export const getCrossViewMoreURL = (country: string, initial: string, target: string, productLevel: string, source: string, scope: string, category: string, subCategoryInitial: string,subCategoryTarget: string,manufacturerInitial: string, manufacturerTarget: string, brandInitial: string, brandTarget: string, customer?: string) => {
    
    const params = new URLSearchParams({
        country: country
    })
    params.append('initial', initial)
    params.append('target', target)
    params.append('productLevel', productLevel)
    params.append('source', source)
    params.append('scope', scope)
    params.append('category', category)
    params.append('subCategoryInitial', subCategoryInitial)
    params.append('subCategoryTarget', subCategoryTarget)
    params.append('manufacturerInitial',manufacturerInitial)
    params.append('manufacturerTarget', manufacturerTarget)
    params.append('brandInitial', brandInitial)
    params.append('brandTarget', brandTarget)
    if(customer) {
        params.append('customer', customer)
    }

    return params.toString()
}

export const getOwnViewMoreURL = (country: string, initial: string, category?: string, productLevel?: string, source?:string, scope?: string, customer?: string) => {
    const params = new URLSearchParams({
        country: country
    })
    if(category) {
        params.append('category',category);
    }
    
    params.append('initial', initial)
    if(productLevel) {
        params.append('productLevel', productLevel)
    }
    if(source) {
        params.append('source', source)
    }
    if(scope) {
        params.append('scope', scope)
    }
   
    if(customer) {
        params.append('customer', customer)
    }
    return params.toString()
}

export const getOwnURLParams = (initialNodes: string[], category: string, hierarchy: string, country: string, source?: string, scope?: string) => {

    const params = new URLSearchParams({
        country: country
    })
    if(initialNodes && initialNodes?.length>0) {  
        for(const _initial of initialNodes) {
            params.append('nodeValues',_initial)
        }  
    }
    if(category)
        params.append('category',category);
        
    params.append('hierarchyLevel',hierarchy);
    if(source) {
        params.append('source',source);
    }
    if(scope) {
        params.append('scope',scope);
    }
    if(hierarchy === 'CATEGORY' && !category) {
        return ''
    }
    return params.toString()
}

export const productLevelsOptionData = {
    subCategory: {
      label: "SUB_CATEGORY",
      display: "Sub Category",
    },
    brand: {
      label: "BRAND",
      display: "Brand",
    },
    subBrand: {
      label: "SUB_BRAND",
      display: 'Sub Brand',
    },
    pack: {
      label: "PACK",
      display: 'Pack',
    },
    ean: {
      label: "EAN",
      display: 'EAN',
    },
  };

  export const productLevelKROptionData = {
    category: {
      label: "CATEGORY",
      display: "Category",
    },
    subBrand: {
      label: "SUB_BRAND",
      display: 'Sub Brand',
    },
    ean: {
      label: "EAN",
      display: 'EAN',
    },
  };

  export const convertDateRange = (range:string) => {
    if(!range) return "";
    let monthNames =["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]; 
    let startDate = new Date(range);

    let stDay = startDate.getDate();
    let stMonthIndex = startDate.getMonth();
    let stMonthName = monthNames[stMonthIndex];
    let stYear = startDate.getFullYear();

    return `${stDay} ${stMonthName} ${stYear}`;
  }

  export const paginationPerPageDataLimit = 5;