import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Button,
  Grid,
  TableBody,
  TableCell,
  TableRow,
  TableHead,
  Table,
} from "@material-ui/core";
import ForwardIcon from "@material-ui/icons/Forward";
import { Link as RouterLink } from "react-router-dom";

import { useOwnAnalysis, useRegressionData, useLineFittingData, useOwnScopeSelector} from "../../services/queries";
import useStore from "../../store";
import { MemoizedOwnReport } from "./OwnReport";
import {currencySymbol} from '../../helper';
import { ApiRequestService } from '../../services/api-service';
import { MemoizedWeekSelector }from "./WeekSelector";
import Dialog from "@material-ui/core/Dialog";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import CloseIcon from "@material-ui/icons/Close";
import Tooltip from '@material-ui/core/Tooltip';
import Typography from '@material-ui/core/Typography';
import { ElasticityScopeRecord, ElasticityRecord, SelectedProduct, Scope } from "../types";
import { getOwnURLParams, convertDateRange } from "../utils";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    flexGrow: 1,
    paddingLeft: "0.75rem",
    paddingRight: "0.75rem",
    boxSizing: "border-box",
  },
  paperDiv: {
    display: "flex",
    flexWrap: "wrap",
    backgroundColor: "#FFFFF",
    "& > *": {
      margin: theme.spacing(2),
      width: "100%",
    },
    paddingTop: "25px",
    height: "auto",
  },
  container: {
    backgroundColor: "#F6F8FC",
    height: "100vh",
  },
  button: {
    display: "inline-flex",
    marginTop: theme.spacing(2),
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  table: {
    minWidth: 650,
    background: "#fff",
    border: "1px solid rgba(0,0,0,0.2)",
  },
  cellData: {
    borderLeft: "1px solid #ccc",
    textTransform: "capitalize",
  },
  xAddButtonCell: {
    color: "#2662FF",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
    width: 100,
    borderLeft: "1px solid rgba(224, 224, 224, 1)",
  },
  yAddButtonCell: {
    color: "#2662FF",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
    width: 100,
    borderLeft: "1px solid rgba(224, 224, 224, 1)",
  },
  dashBoardTable: {
    marginBottom: "1em",
    background: "inherit",
    width: "75%",
  },
  hide: {
    padding: theme.spacing(1),
    width: 390,
    backgroundColor: theme.palette.background.light,
  },
  gridHeader: {
    textAlign: "center",
    padding: "2.5rem",
  },
  tableHeadCell: {
    fontWeight: "bold",
    color: "#494949",
    whiteSpace: "nowrap",
    width: 100,
    borderRight: "1px solid rgba(224, 224, 224, 1)",
    borderTop: "1px solid rgba(224, 224, 224, 1)",
    borderLeft: "1px solid rgba(224, 224, 224, 1)",
  },
  headerCellLevel1: {
    borderBottom: "none",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
    borderTop: "1px solid rgba(224, 224, 224, 1)",
    borderLeft: "1px solid rgba(224, 224, 224, 1)",
    textAlign: "center",
    fontWeight: "bold",
  },
  correlationCell: {
    fontWeight: "bold",
    color: "#494949",
    whiteSpace: "nowrap",
    width: 100,
    borderTop: "none",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
  },
  cellTable: {
    padding: "0",
    verticalAlign: "top",
  },
  high: {
    backgroundColor: "#CBF2DB",
    fontWeight: "bold",
    color: "#2ECC71",
    textAlign: "center",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
  },
  medium: {
    backgroundColor: "#FDF2C5",
    fontWeight: "bold",
    textAlign: "center",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
    color: "#DFB202",
  },
  low: {
    backgroundColor: "#FBCCCC",
    fontWeight: "bold",
    textAlign: "center",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
    color: "#F03434",
  },
  viewMore: {
    backgroundColor: "inherit",
    fontWeight: "bold",
    textAlign: "center",
    borderTop: "1px solid rgba(224, 224, 224, 1)",
    borderRight: "1px solid rgba(224, 224, 224, 1)",
    color: "#2663FF",
  },
  emptyHeader: {
    fontWeight: "bold",
    color: "#494949",
    whiteSpace: "nowrap",
    width: 100,
    border: "none",
  },
  emptyCell: {
    fontWeight: "bold",
    color: "#494949",
    whiteSpace: "nowrap",
    width: 100,
    borderBottom: "none",
    borderRight: "none",
  },
  iconButton: {
    backgroundColor: "#2663FF",
    color: "#FFFFFF",
    borderRadius: "50%",
    width: "2.5rem",
    height: "2.5rem",
    padding: "5px",
    flexShrink: "none",
    flex: "0 0 auto",
    transform: "rotate(180deg)",
  },
  buttonLabel: {
    fontWeight: "bold",
    display: "inline-flex",
    color: "#2663FF",
  },
  btnContainer: {
		display: "flex",
    justifyContent:'flex-end',
    marginRight: '15%',
    marginBottom: "1em",
	},
	btnReset: {
		background: "#cb0c0c",
		color: "#fff",
		textTransform: "none",
		margin: "0 20px",
		padding: "6px 20px",
		borderRadius: "10px",
	},
	btnSucess: {
		background: "#163c62",
		color: "#fff",
		textTransform: "none",
		margin: "0 10px",
		padding: "6px 35px",
		borderRadius: "10px",
	},
}));

const centerAlignText = {
  textAlign: "center",
};
let count = 4;

export default function OwnDashboard(props) {
  const classes = useStyles();

  const [ownParameters, setownParameters] = useState()
  const [selectedCountry, setselectedCountry] = useState();

  const [productLevel,setProductLevel] = useState("");
  const [originalDataInstance, setOriginalDataInstance] = useState([]);
  const [treeDataInstance, setTreeDataInstance] = useState([]);

  const [slopeInt,setSlopeInt]= useState(0);
  const [slopeFrac,setSlopeFrac]= useState(0);
  const [interceptInt,setInterceptInt]= useState(0);
  const [interceptFrac,setInterceptFrac]= useState(0);
  const [rSquared,setRsquared]= useState(0);
  const [elasticityInt,setElasticityInt]= useState(0);
  const [elasticityFrac,setElasticityFrac]= useState(0);
  const [initial,setInitial] = useState("");
  const [combinedYearWeeks, setCombinedYearWeeks] =  useState([]);
  const [open, setOpen] = React.useState(false);
  const [category,setCategory] = useState("");
  const [customer,setCustomer] = useState("");

  let regressionApiBodyOwn = useStore((state) => state.regressionApiBodyOwn);
  const [ownURLParams, setOwnURLParams] = useState([]);
  const [ownScopeURLParams, setOwnScopeURLParams] = useState([]);
  
  const handleClose = () => {
		setOpen(false);
	};

  useEffect(() => {
    const urlObj = new URL(window.location.href)
    var result = {
      country: urlObj.searchParams.get('country'),
      productLevel: urlObj.searchParams.get('productLevel'),
      initial: urlObj.searchParams.get('initial'),
      source: urlObj.searchParams.get('source'),
      customer: urlObj.searchParams.get('customer'),
      scope: urlObj.searchParams.get('scope'),
      category: urlObj.searchParams.get('category')
    };
    if(result.productLevel === 'EAN') {
      setInitial(result.initial.split('-')[0].trim());
    } else {
      setInitial(result.initial.trim());
    }
    setCategory(result.category)
    if(result.scope === 'PCUST'){
      setCustomer(result.customer)
    }
   
    setProductLevel(result.productLevel);
    setselectedCountry(result.country);
    setownParameters(result);

    let ownElasticityPayload = {
      category: result.category,
      forOwn: true,
      country : result.country,
      hierarchyLevel: result.productLevel,
      initialBrands: [],
      initialManufacturers: [],
      initialNodeValues:[result.initial],
      initialPacks: [],
      initialSubBrands: [],
      scope: result.scope,
      source: result.source,
      subCategories: [],
      targetBrands: null,
      targetManufacturers: null,
      targetNodeValues: null,
      targetPacks: null,
      targetSubBrands: null,
      topNBottomN: 0
    }

    if (result.scope === 'WC') {
      setOwnURLParams(ownElasticityPayload);
    } else {
      setOwnScopeURLParams(ownElasticityPayload);
    }
  }, [])

  const {isLoading: loadingRegressionData, data: regressionData, isError: isRegressionError} = useRegressionData (regressionApiBodyOwn);

  const {isLoading: loadingLineFittingData, data: lineFittingData, isError: isLineFittingError} = 
  useLineFittingData (`country=${selectedCountry}&initial=${initial}&hierarchyLevel=${productLevel}&category=${category}&customer=${customer}`);

  useEffect(()=>{
    if(!loadingRegressionData)
    {
      let {
        elasticityDecimal,
        elasticityIntegral,
        interceptDecimal,
        interceptIntegral,
        rSquared,
        slopeDecimal,
        slopeIntegral,
      } = { ...regressionData };
  
      setSlopeInt(slopeIntegral);
      setSlopeFrac(slopeDecimal);
      setInterceptInt(interceptIntegral);
      setInterceptFrac(interceptDecimal);
      setRsquared(rSquared);
      setElasticityInt(elasticityIntegral);
      setElasticityFrac(elasticityDecimal);
  
      let combinedYearWeeksValues = [];
  
      for(let i=0;regressionApiBodyOwn && i<regressionApiBodyOwn['dataPoints']?.length;i++) {
        let obj = regressionApiBodyOwn['dataPoints'][i];
        let y = obj.year.toString();
        let w = '0'+obj.week.toString();
        let c = y+w.slice(-2);
  
        combinedYearWeeksValues.push(c); //to apply PBI filter on combined year and week values
      }
      setCombinedYearWeeks([...new Set(combinedYearWeeksValues)]);
    }
  },[loadingRegressionData,regressionApiBodyOwn])
    
  const setRegressionApiBodyOwn = useStore((state) => state.setRegressionApiBodyOwn);
  
  useEffect(()=>{
    if(!loadingLineFittingData) {
      let lineDataObj = {};
  
      for (let i = 0; i < lineFittingData.length; i++) {
        let obj = lineFittingData[i];
        let key = obj.year.toString();
        if (!lineDataObj[key]) {
          lineDataObj[key] = [obj];
        } else {
          lineDataObj[key].push(obj);
        }
      }
      
      // Constructing drop down tree select object
      let treeNodes = [];
      for(const key in lineDataObj) {
        let arr = [];
        if(lineDataObj.hasOwnProperty(key)) {
          let val = lineDataObj[key];
          for(let i=0;i<val.length;i++) {
            let item = {};
            item['label'] = `Week ${val[i]['week']}`
            arr.push(item);
          }
        }
        let node = {};
        node['label'] = key;
        //Removing duplicate labels
        node["children"] = arr.filter(
          (value, index, arr) =>
            index ===
            arr.findIndex((t) => t.label === value.label )
        );
        treeNodes.push(node);
      }
      setOriginalDataInstance(lineDataObj);
      setTreeDataInstance(treeNodes);
        
      //On initial loading pushing all data points
      let result = {};
      let dp = [];
      for( const key in lineDataObj) {
        for(let i=0;i< lineDataObj[key].length;i++) {
            dp.push(lineDataObj[key][i]);
        }
      }
      result['country'] = selectedCountry;
      result['dataPoints'] = dp;
      setRegressionApiBodyOwn(result);
    }
  },[loadingLineFittingData])

  const { isLoading: isOwnDashboardData, data: ownDashboardData, isError: ownDashboardDataError } = useOwnAnalysis(ownURLParams || '');
  const { isLoading: isOwnDashboardDataPerScope, data: ownDashboardDataPerScope, isError: ownDashboardScopeDataError} = useOwnScopeSelector(ownScopeURLParams || '');

  
  const [ownObj, setownObj] = useState()

  const transformData = (data) => {
    console.log(`own DASHBOARD DATA`, data);
    let pattern = {
      id: "",
      initial: "",
      avgPrice: "",
      range: "",
      rsquared: "",
      basePrice: "",
      promoPrice: "",
      priceIndex: "",
      pvalue: "",
      averageVolume: "",
    };
    if (data) {
      count += 1;
      pattern.id = count;

      pattern.initial = ownParameters.initial;
      pattern.averageVolume = {
        hasValue: data.averageVolume || data.averageVolume === 0 ? true : false,
        value:
          data.averageVolume || data.averageVolume === 0 ? data.averageVolume : null,
      };
      pattern.priceIndex = {
        hasValue: data.priceIndex || data.priceIndex === 0 ? true : false,
        value:
          data.priceIndex || data.priceIndex === 0 ? data.priceIndex : null,
      };
      pattern.range = data.range;
      pattern.rsquared = {
        hasValue: data.rsquared || data.rsquared === 0 ? true : false,
        value:
          data.rsquared || data.rsquared === 0
            ? data.rsquared
            : null,
      };
      pattern.avgPrice = {
        hasValue: data.averagePrice || data.averagePrice === 0 ? true : false,
        value:
          data.averagePrice || data.averagePrice === 0
            ? data.averagePrice
            : null,
      };
      pattern.basePrice = {
        hasValue: data.basePrice || data.basePrice === 0 ? true : false,
        value: data.basePrice || data.basePrice === 0 ? data.basePrice : null,
      };
      pattern.nweeks = {
        hasValue: data.nweeks ? true : false,
        value: data.nweeks ? data.nweeks : null,
      };
      pattern.period = {
        hasValue: data.periodBegin && data.periodEnd ? true : false,
        periodBegin: data.periodBegin,
        periodEnd: data.periodEnd
      };
      pattern.promoPrice = {
        hasValue:
          data.promoPrice ||
          data.promoPrice === 0
            ? true
            : false,
        value:
          data.promoPrice ||
          data.promoPrice === 0
            ? data.promoPrice
            : null,
      };
      pattern.pvalue = {
        hasValue: data.pvalue ? true : false,
        value: data.pvalue ? data.pvalue : null,
      };
    }
    console.log(`PATTERN`, pattern);
    return pattern;
  };

  useEffect(() => {
    if (ownDashboardData && ownParameters.scope === 'WC') {
      const data = transformData(ownDashboardData[0][ownParameters?.initial]);
      setownObj(data)
    }
  }, [ownDashboardData])

  
  useEffect(()=>{
    if(ownDashboardDataPerScope && ownParameters.scope !== 'WC') {
      let objectData = ownDashboardDataPerScope[ownParameters.initial][ownParameters.customer];
      const data = transformData(objectData);
      setownObj(data);
    }

  },[ownDashboardDataPerScope])
  

  const columns = [
    {
      Header: "Initial Product",
      accessor: "initialProduct",
    },
    {
      Header: selectedCountry === 'KR' ? 'Average Volume SU' : "Average Volume",
      accessor: "averageVolume",
    },
    {
      Header:selectedCountry === 'KR' ? 'Price SU' : "Average Unit Price",
      accessor: "priceIndex",
    },
    {
      Header: "Range",
      accessor: "range",
    },
    {
      Header: "R-Squared",
      accessor: "rsquared",
    },
    {
      Header: "P Value",
      accessor: "pvalue",
    },
  ];


  return (
    <Grid item xs={12} sm={12}>
     
      {
        (ownDashboardDataError || ownDashboardScopeDataError) && alert("Some thing went wrong, please reload page")
      }
      {
        ownObj
        ? <Grid className={classes.paperDiv}>
            <div className={classes.chartDiv}>
              <div className={classes.grid} style={{ display: "inline" }}>
                <Table align="center" className={classes.dashBoardTable}>
                  <TableHead>
                    <TableRow>
                      <Tooltip
                      title={<Typography fontSize={20}>{`Price Elasticity`}</Typography>}>
                      <TableCell
                        colSpan={11}
                        className={classes.headerCellLevel1}
                        style={centerAlignText}
                      >
                        {`Price Elasticity`} {customer?` - ${customer}`:""}
                      </TableCell>
                      </Tooltip>
                    </TableRow>
                    <TableRow className={classes.headRow}>
                      {columns.map((tableCell) => (
                        <Tooltip
                          title={<Typography fontSize={20}>{tableCell.Header}</Typography>}>
                        <TableCell
                          colSpan={1}
                          className={classes.tableHeadCell}
                          style={centerAlignText}
                        >
                          {tableCell.Header}
                        </TableCell>
                        </Tooltip>
                      ))}
                      {console.log(`insideelement`, ownObj)}
                      {ownObj.avgPrice && ownObj.avgPrice.hasValue && (
                        <Tooltip
                        title={<Typography fontSize={20}>{`AVG`}</Typography>}>
                        <TableCell
                          colSpan={1}
                          className={classes.tableHeadCell}
                          style={centerAlignText}
                        >
                          {`AVG`}
                        </TableCell>
                        </Tooltip>
                      )}
                      {ownObj.promoPrice && ownObj.promoPrice.hasValue && (
                        <Tooltip
                        title={<Typography fontSize={20}>{`Promo`}</Typography>}>
                        <TableCell
                          colSpan={1}
                          className={classes.tableHeadCell}
                          style={centerAlignText}
                        >
                          {`Promo`}
                        </TableCell>
                        </Tooltip>
                      )}
                      {ownObj.basePrice && ownObj.basePrice.hasValue && (
                        <Tooltip
                          title={<Typography fontSize={20}>{`Base`}</Typography>}>
                        <TableCell
                          colSpan={1}
                          className={classes.tableHeadCell}
                          style={centerAlignText}
                        >
                          {`Base`}
                        </TableCell>
                        </Tooltip>
                      )}
                      {ownObj.nweeks && ownObj.nweeks.hasValue && (
                        <Tooltip
                        title={<Typography fontSize={20}>{`Number of weeks`}</Typography>}>
                        <TableCell
                          colSpan={1}
                          className={classes.tableHeadCell}
                          style={centerAlignText}
                        >
                          {`# of weeks`}
                        </TableCell>
                        </Tooltip>
                      )}
                       {ownObj.period && ownObj.period.hasValue && (
                        <Tooltip
                        title={<Typography fontSize={20}>{`Period`}</Typography>}>
                        <TableCell
                          colSpan={1}
                          className={classes.tableHeadCell}
                          style={centerAlignText}
                        >
                          {`Period`}
                        </TableCell>
                        </Tooltip>
                      )}
                    </TableRow>
                  </TableHead>

                  <TableBody>
                    <TableRow>
                      {ownObj && (
                        <>
                          <TableCell
                            style={centerAlignText}
                            className={classes.yAddButtonCell}
                          >
                            <div className="kcOvalShape">{ownObj.initial}</div>
                          </TableCell>
                          <TableCell
                            style={centerAlignText}
                            className={
                              ownObj.range === "LOW"
                                ? classes.low
                                : ownObj.range === "HIGH"
                                ? classes.high
                                : classes.medium
                            }
                          >
                            {ownObj.averageVolume.hasValue &&
                              `${parseFloat(ownObj.averageVolume.value).toLocaleString("en-US", {maximumFractionDigits: 3, minimumFractionDigits: 3})}`}
                          </TableCell>
                          <TableCell
                            style={centerAlignText}
                            className={
                              ownObj.range === "LOW"
                                ? classes.low
                                : ownObj.range === "HIGH"
                                ? classes.high
                                : classes.medium
                            }
                          >
                            {ownObj.priceIndex.hasValue &&
                              selectedCountry === 'KR' ? `${parseFloat(ownObj.priceIndex.value).toLocaleString("en-US", {maximumFractionDigits: 0, minimumFractionDigits: 0})}` : `${parseFloat(ownObj.priceIndex.value).toLocaleString("en-US", {maximumFractionDigits: 3, minimumFractionDigits: 3})}`}
                          </TableCell>
                          <TableCell
                            style={centerAlignText}
                            className={
                              ownObj.range === "LOW"
                                ? classes.low
                                : ownObj.range === "HIGH"
                                ? classes.high
                                : classes.medium
                            }
                          >
                            {ownObj.range}
                          </TableCell>

                          <TableCell
                            style={centerAlignText}
                            className={
                              ownObj.range === "LOW"
                                ? classes.low
                                : ownObj.range === "HIGH"
                                ? classes.high
                                : classes.medium
                            }
                          >
                          {ownObj.rsquared.hasValue && parseFloat(ownObj.rsquared.value).toLocaleString("en-US", {maximumFractionDigits: 3, minimumFractionDigits: 3})}
                          </TableCell>

                          {(
                            <TableCell
                              style={centerAlignText}
                              className={
                                ownObj.range === "LOW"
                                  ? classes.low
                                  : ownObj.range === "HIGH"
                                  ? classes.high
                                  : classes.medium
                              }
                            >
                              {ownObj?.pvalue?.hasValue ? parseFloat(ownObj.pvalue.value):'-'}
                            </TableCell>
                          )}

                          {ownObj.avgPrice.hasValue && (
                            <TableCell
                              style={centerAlignText}
                              className={
                                ownObj.range === "LOW"
                                  ? classes.low
                                  : ownObj.range === "HIGH"
                                  ? classes.high
                                  : classes.medium
                              }
                            >
                            {parseFloat(ownObj.avgPrice.value).toLocaleString("en-US", {maximumFractionDigits: 3, minimumFractionDigits: 3})}
                            </TableCell>
                          )}
                          {ownObj.promoPrice.hasValue && (
                            <TableCell
                              style={centerAlignText}
                              className={
                                ownObj.range === "LOW"
                                  ? classes.low
                                  : ownObj.range === "HIGH"
                                  ? classes.high
                                  : classes.medium
                              }
                            >
                              {parseFloat(ownObj.promoPrice.value).toLocaleString("en-US", {maximumFractionDigits: 3, minimumFractionDigits: 3})}
                            </TableCell>
                          )}
                          {ownObj.basePrice.hasValue && (
                            <TableCell
                              style={centerAlignText}
                              className={
                                ownObj.range === "LOW"
                                  ? classes.low
                                  : ownObj.range === "HIGH"
                                  ? classes.high
                                  : classes.medium
                              }
                            >
                              {parseFloat(ownObj.basePrice.value).toLocaleString("en-US", {maximumFractionDigits: 3, minimumFractionDigits: 3})}
                            </TableCell>
                          )}

                        {ownObj.nweeks.hasValue && (
                            <TableCell
                              style={centerAlignText}
                              className={
                                ownObj.range === "LOW"
                                  ? classes.low
                                  : ownObj.range === "HIGH"
                                  ? classes.high
                                  : classes.medium
                              }
                            >
                              {ownObj.nweeks.value}
                            </TableCell>
                          )}

                        {ownObj.period.hasValue && (
                            <TableCell
                              style={centerAlignText}
                              className={
                                ownObj.range === "LOW"
                                  ? classes.low
                                  : ownObj.range === "HIGH"
                                  ? classes.high
                                  : classes.medium
                              }
                            >
                              {convertDateRange(ownObj.period.periodBegin)} - {convertDateRange(ownObj.period.periodEnd)}
                            </TableCell>
                          )}        
                        </>
                      )}
                    </TableRow>

                    
                  </TableBody>
                </Table>
                {selectedCountry !== "KR" ? <div className={classes.btnContainer}> 
                  <button variant="contained" onClick={()=>setOpen(true)} className = "border border-primary text-primary rounded p-1 ">Edit Weeks</button>
                </div> : null}
                <Dialog
                  open={open}
                  keepMounted
                  onClose={handleClose}
                  aria-describedby="alert-dialog-slide-description"
                >
                  <DialogTitle>
                    <h2 className="w-full flex justify-between">
                      <span>Select week range</span>
                      <CloseIcon onClick={handleClose}/>
                    </h2>
                  </DialogTitle>
                  <DialogContent style={{height:'600px', alignItems:'center'}}>
                    <DialogContentText id="alert-dialog-slide-description">
                      <MemoizedWeekSelector 
                        initial={initial}
                        originalDataInstance = {originalDataInstance}
                        treeDataInstance = {treeDataInstance}
                        handleClose = {handleClose}
                        tabName="own"
                        />
                    </DialogContentText>
                  </DialogContent>
          
                </Dialog>

                {
                  ownParameters
                    ? <MemoizedOwnReport 
                        {...ownParameters}
                        customer = {customer} 
                        category = {category}
                        slopeInt = {slopeInt}
                        slopeFrac = {slopeFrac}
                        interceptInt = {interceptInt}
                        interceptFrac = {interceptFrac}
                        rSquared = {rSquared}
                        elasticityInt = {elasticityInt}
                        elasticityFrac = {elasticityFrac}
                        combinedYearWeeks = {combinedYearWeeks}

                      />
                    : null
                  }
               
              </div>
            </div>
          </Grid>
          : null
      }
      
    </Grid>
  );
}
