import React, { useState, useEffect, useMemo } from "react";
import ReactDOM from "react-dom";
import { makeStyles } from "@material-ui/core/styles";
import DropdownTreeSelect from "react-dropdown-tree-select";
import "react-dropdown-tree-select/dist/styles.css";
import "./searchStyles.css";

import useStore from "./store";

const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: theme.palette.primary.light,
    padding: theme.spacing(1),
    display: "flex",
    alignItems: "center",
    width: "100%",
    height: theme.spacing(10),
  },
  paper: {
    // border: '1px solid',
    padding: theme.spacing(1),
    width: 407,
    backgroundColor: theme.palette.background.light,
    overflowY: "scroll",
  },
  listbox: {
    color: theme.palette.primary.main,
    backgroundColor: theme.palette.primary.light,
    color: theme.palette.primary.light,
    marginLeft: theme.spacing(1),
    flex: 1,
  },
  input: {
    color: theme.palette.primary.main,
  },
  iconButton: {
    float: "right",
    padding: 10,
    color: theme.palette.primary.main,
  },
  divider: {
    float: "right",
    height: 28,
    margin: 4,
  },
  checkBox: {
    color: theme.palette.primary.main,
    fontFamily: "sans-serif",
  },
}));

const onAction = (node, action) => {
  console.log("onAction::", action, node);
};
const onNodeToggle = (currentNode) => {
  console.log("onNodeToggle::", currentNode);
};

const ItemSelect = (props) => {
  const classes = useStyles();
  console.log(`item select`, props);
  //STORE
  const setSelectedCountry = useStore((state) => state.setSelectedCountry);
  let selectedCountry = useStore((state) => state.selectedCountry);

  const setSelectedBaseLineFilter = useStore(
    (state) => state.setSelectedBaseLineFilter
  );

  const setSelectedBaseLineCustomer = useStore(
    (state) => state.setSelectedBaseLineCustomer
  );
  //  let selectedBaseLineCustomer = useStore((state) => state.selectedBaseLineCustomer);

  const setSelectedBaseLineCustomerNew = useStore(
    (state) => state.setSelectedBaseLineCustomerNew
  );

  const setSelectedBaseLineProduct = useStore(
    (state) => state.setSelectedBaseLineProduct
  );
  let selectedBaseLineProduct = useStore(
    (state) => state.selectedBaseLineProduct
  );

  const setSelectedBaseLineProductNew = useStore(
    (state) => state.setSelectedBaseLineProductNew
  );

  //SELECTION: KC PRODUCT
  const setSelectedKcProducts = useStore(
    (state) => state.setSelectedKcProducts
  );

  const setSelectedKcProductsNew = useStore(
    (state) => state.setSelectedKcProductsNew
  );

  //SELECTION: TARGET PRODUCT
  const setSelectedTargetProducts = useStore(
    (state) => state.setSelectedTargetProducts
  );
  //let selectedTargetProducts = useStore((state) => state.selectedTargetProducts);

  //SELECTION: OWN PRODUCT
  const setSelectedOwnProducts = useStore(
    (state) => state.setSelectedOwnProducts
  );

  //SELECTION: CROSS PRODUCT
  const setSelectedCrossProducts = useStore(
    (state) => state.setSelectedCrossProducts
  );

  const setSelectedEventId = useStore((state) => state.setSelectedEventId);
  const setSelectedEventIdNew = useStore((state) => state.setSelectedEventIdNew);
  
  var productLevelsData = {
    brand: {
      label: "BRAND",
      data: [],
    },
    subCategory: {
      label: "SUB_CATEGORY",
      data: [],
    },
    subBrand: {
      label: "SUB_BRAND",
      data: [],
    },
    pack: {
      label: "PACK",
      data: [],
    },
    ean: {
      label: "EAN",
      data: [],
    },
  };

  let selectedProductLevel = useStore(
    (state) =>
      productLevelsData[
        !state.selectedProductLevel ? "ean" : state.selectedProductLevel
      ]?.label
  );

  var scopeLevelsData = {
    perCountry: "COUNTRY",
    perCustomer: "CUSTOMER",
    perChannel: "CHANNEL",
  };

  let selectedScopeLevel = useStore(
    (state) =>
      scopeLevelsData[
        !state.selectedScopeLevel ? "perCountry" : state.selectedScopeLevel
      ]
  );

  let productPathValue = "";
  let customerPathValue = "";
  let eventPathValue = "";

  let selectedKcProds = [];
  let selectedTargetProds = [];
  let selectedOwnProds = [];
  let selectedKcProdsNew = [];

  const onChange = (currentNode, selectedNodes) => {
    console.log("line 122", props.dataFor);

    console.log("Selected", selectedKcProds);
    console.log("Selected Product", selectedNodes);
    selectedKcProds = [];
    selectedKcProdsNew = [];
    selectedTargetProds = [];
    selectedOwnProds = [];

    const getProductDepthValue = (depth) => {
      switch (depth) {
        case 1:
          return "categories";
          break;
        case 3:
          return "subCategories";
          break;
        case 5:
          return "brands";
          break;
        case 7:
          return "subBrands";
          break;
        case 8:
          return "eans";
          break;
        default:
          break;
      }
      return "";
    };

    const getCustomerDepthValue = (depth) => {
      switch (depth) {
        case 3:
          return "planLevels";
        case 4:
          return "customers";
          break;
        default:
          break;
      }
      return "";
    };

    const getEventValue = (depth) => {
      switch (depth) {
        case 0:
          return "eventIds";
        default:
          break;
      }
      return "";
    };

    if (selectedNodes) {
      if (selectedNodes.length >= 0 && props.dataFor === "Product") {
        productPathValue = "";
        selectedNodes.map((item, i) => {
          if (getProductDepthValue(item._depth)) {
            productPathValue += `&${getProductDepthValue(item._depth)}=${
              item.label
            }`;
          }
          // setSelectedBaseLineProduct(productPathValue)
        });
      }

      if (selectedNodes.length >= 0 && props.dataFor === "customer") {
        customerPathValue = "";
        selectedNodes.map((item, i) => {
          if (getCustomerDepthValue(item._depth)) {
            customerPathValue += `&${getCustomerDepthValue(item._depth)}=${
              item.label
            }`;
          }
        });
        //setSelectedBaseLineCustomer(customerPathValue)
        //setSelectedBaseLineCustomer(customerPathValue);
      }

      if (selectedNodes.length >= 0 && props.dataFor === "EventId") {
        eventPathValue = "";
        selectedNodes.map((item, i) => {
          if (getEventValue(item._depth)) {
            eventPathValue += `&${getEventValue(item._depth)}=${item.label}`;
          }
        });
       // valuesSelected();
       
      }

      if (selectedNodes.length > 0 && props.dataFor === "kcProducts") {
        let kcObj = {
          selectedKcArr: [],
          apiUrl: "",
          crossAnalysisApiUrl: "",
          correlationAnalysisApiUrl: "",
        };

        let reformatKcStr = "";
        let reformatKcStrNew = "";
        // var level = "Ean";
        // console.log(`PROPS SELECTED`, props)
        //  if (selectedProductLevel) {
        //    level = selectedProductLevel;
        //  }

        //  level = level.toUpperCase();
        selectedNodes.map((val, i) => {
          if (i <= 0) {
            //reformatKcStr += `?${props.productLevel}=${val.value}`;
            reformatKcStr += `country=${selectedCountry}&nodeValues=${val.value}`;
            reformatKcStrNew += `country=${selectedCountry}&initialNodeValues=${val.value}`;
          } else {
            //reformatKcStr += `&${props.productLevel}=${val.value}`;
            reformatKcStr += `&nodeValues=${val.value}`;
            reformatKcStrNew += `&initialNodeValues=${val.value}`;
            //initialNodeValues
          }

          console.log(reformatKcStr);
          kcObj.selectedKcArr.push(val.value);
          //kcObjNew.selectedKcArr.push(val.value);
        });
        let withHierarchyParamsInKc = `&hierarchyLevel=${selectedProductLevel}`;
        kcObj.apiUrl = reformatKcStr += withHierarchyParamsInKc;
        kcObj.crossAnalysisApiUrl = reformatKcStrNew;
        kcObj.correlationAnalysisApiUrl = reformatKcStrNew;

        selectedKcProds.push(kcObj);
        //selectedKcProdsNew.push(kcObjNew)
        //selectedKcProds = selectedKcItems;
        console.log(kcObj);
      }
      if (selectedNodes.length > 0 && props.dataFor === "targetProducts") {
        console.log(`SELECTED TARGET1122`, selectedNodes);
        let targetObj = {
          selectedTargetArr: [],
          correlationAnalysisApiUrl: "",
          crossAnalysisApiUrl: "",
        };
        let reformatTargetStr = "";
        let level = "Ean";
        if (selectedProductLevel) {
          level = selectedProductLevel;
        }

        level = level.toUpperCase();

        selectedNodes.map((val, i) => {
          console.log(`VALUE`, val.value);
          if (i <= 0) {
            reformatTargetStr += `&targetNodeValues=${val.value}`;
            console.log(reformatTargetStr);
            targetObj.selectedTargetArr.push(val.value);
          } else {
            reformatTargetStr += `&targetNodeValues=${val.value}`;
            console.log(reformatTargetStr);
            targetObj.selectedTargetArr.push(val.value);
          }
        });
        let withHierarchyParamsInTarget =
          (reformatTargetStr += `&hierarchyLevel=${selectedProductLevel}`);
        targetObj.correlationAnalysisApiUrl = withHierarchyParamsInTarget;

        targetObj.crossAnalysisApiUrl = withHierarchyParamsInTarget;

        console.log(`TARGET OBJ`, targetObj);

        selectedTargetProds.push(targetObj);
        //console.log(selectedTargetProds)
      }

      if (selectedNodes.length > 0 && props.dataFor === "ownProducts") {
        var selectedOwnArr = [];
        let ownObj = {
          selectedOwnArr: [],
          apiUrl: "",
        };
        let reformatOwnStr = "";

        selectedNodes.map((val, i) => {
          if (i <= 0) {
            reformatOwnStr += `country=${selectedCountry}&nodeValues=${val.value}`;
          } else {
            reformatOwnStr += `&nodeValues=${val.value}`;
          }
          selectedOwnArr.push(val.value);
          console.log(reformatOwnStr);

        });
         ownObj.selectedOwnArr = selectedOwnArr;
        let withHierarchyParamsInOwn = `&hierarchyLevel=${selectedProductLevel}`;

        ownObj.apiUrl = reformatOwnStr += withHierarchyParamsInOwn;
        selectedOwnProds.push(ownObj);
        //selectedOwnProds = selectedOwnItems;
        console.log(ownObj);
      }
      console.log(props);
      if (props.mode === "radioSelect" && props.dataFor === "kcProducts") {
        setSelectedTargetProducts("");

        valuesSelected();
      } else if (
        props.mode === "radioSelect" &&
        props.dataFor !== "kcProducts"
      ) {
        valuesSelected();
      }
    }
  };
  const valuesSelected = () => {
    ////setSelectedBaseLineFilter("");
   
    if (props.dataFor === "customer") {
      //customerPathValue = ' ';
      //setSelectedBaseLineCustomer(' ');
      setSelectedBaseLineCustomerNew(customerPathValue || "");
    }

    if (props.dataFor === "Product") {
      setSelectedBaseLineProductNew(productPathValue || " ");
    }
    if (props.dataFor === "customer" || props.dataFor === "Product") {
      let params = productPathValue + customerPathValue;
      setSelectedBaseLineFilter(params);
      //setSelectedBaseLineCustomer(customerPathValue);
      //setSelectedBaseLineProduct(productPathValue);

      /* setSelectedBaseLineCustomerNew(customerPathValue);
      setSelectedBaseLineProductNew(productPathValue); */
    }
    if (props.dataFor == "EventId") {
      console.log("eventPathValue", eventPathValue);
     
      //setSelectedEventId(eventPathValue || " ");
       // setSelectedEventId(eventPathValue || " ");
       setSelectedEventIdNew(eventPathValue || " ");     
      
    }

    if (props.dataFor === "kcProducts" && selectedKcProds.length > 0) {
      console.log(selectedKcProds);
      setSelectedKcProducts(selectedKcProds[0]);
      //setSelectedKcProductsNew(selectedKcProdsNew[0])
    }
    if (props.dataFor === "targetProducts" && selectedTargetProds.length > 0) {
      setSelectedTargetProducts(selectedTargetProds[0]);
    }
    if (props.dataFor === "ownProducts" && selectedOwnProds.length > 0) {
      console.log(`SELECTED OWN PRODS`, selectedOwnProds);
      setSelectedOwnProducts(selectedOwnProds[0]);
    }
  };

  return (
   <DropdownTreeSelect
      disableUnderline
      texts={{ placeholder: "Search" }}
      className={classes.root}
      data={props.data}
      mode="hierarchical"
      onChange={onChange}
      onAction={onAction}
      onNodeToggle={onNodeToggle}
      onBlur={valuesSelected}
      productLevel={props.productLevel}
      scopeLevel={ props.scopeLevel}
      elasticityPrice={props.elasticityPrice}
      {...props}
    /> 
    
  );
};
export default ItemSelect;
