import { Switch, Route } from 'react-router-dom';
import LoginCallback from './OktaSSO/LoginCallback';
import { Security, SecureRoute } from '@okta/okta-react';
import { OktaAuth, toRelativeUrl } from '@okta/okta-auth-js';
import { useHistory } from 'react-router-dom';
import CssBaseline from '@material-ui/core/CssBaseline';
import { ThemeProvider } from '@material-ui/core/styles';
import theme from './theme';
import Profile from './profile';
import {oktaAuthConfig} from './OktaSSO/config'
import BaseLineLayout from './BaseLineLayout';
import RoiSimulatorLayout from './RoiSimulatorLayout';
import PriceElasticityLayout from './Elasticity/PriceElasticityLayout';
import OwnDashboard from './Elasticity/Own/OwnDashboard';
import CrossDashboard from './Elasticity/Cross/CrossDashboard';
import PoromoPerformaceLayout from './PromoPerformaceLayout';
import { Container, makeStyles } from '@material-ui/core';
import Navbar from './Navbar'
import useStore from './store';
import  { useEffect } from 'react'
import jwt_decode,{JwtPayload} from "jwt-decode";
import TestAPI from './testAPI';
import { PreROIDashboard } from './PreROI/PreROIDashboard';
import { OwnTab } from './Elasticity/Own/own_tab';
import { CrossTab } from './Elasticity/Cross/cross_tab';
import { TestDataAPI } from './testData';


const useStyles = makeStyles(theme => ({

  container: {
      backgroundColor: theme.palette.background.paper,
      height: '200vh',
  },


}))


const oktaAuth = new OktaAuth(oktaAuthConfig);

function SecureAll() {
  const classes = useStyles()
  const history = useHistory();

  const token = useStore(state => state.apiToken)
  const restoreOriginalUri = async (_oktaAuth, originalUri) => {
    history.replace(toRelativeUrl(originalUri || '/', window.location.origin)); 
  };
  useEffect(() => {
    localStorage.removeItem('req');  
      console.log("run from secureAll")
    }, [])



  // useEffect(() => {
  //   const checkTokenExpiry = async () => {
  //     const decoded = jwt_decode<JwtPayload>(token)
  //     if (decoded){
  //       if ((decoded.exp && Date.now() >= decoded.exp)){
  //         if ( authState && authState.accessToken && authState.idToken){
  //             const result = await authenticateWithServer(authState.accessToken.accessToken, authState.idToken.idToken)
  //             if (result.error || !result.jwtToken){
  //               useStore.setState({
  //                 loginState: false,
  //                 authError:  result.error || 'Invalid login',
  //               })
  //             }else{
  //               useStore.setState({
  //                 loginState: true,
  //                 authError: '',
  //                 apiToken: result.jwtToken
  //               })
  //               token = result.jwtToken
  //             }
  //           }else{
  //             window.location.reload()
  //           }
  //       }

  //     }
  //   }
  // }, [token])

 


  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Security
        oktaAuth={oktaAuth}
        scope={['openid', 'profile', 'groups']}
        restoreOriginalUri={restoreOriginalUri}
      >
         <Container style={{maxWidth:'100%'}} className={classes.container}>
          {
            oktaAuth.isAuthenticated && token
            ? <> 
              <Navbar/>
              <Switch>
                <SecureRoute exact path='/' component={BaseLineLayout} />
                <SecureRoute
                      exact
                      path="/baseline-forcasting"
                      component={BaseLineLayout}
                    />
                    <SecureRoute
                      exact
                      path="/roi-simulator"                       
                      component={RoiSimulatorLayout}
                    />
                    <SecureRoute
                      exact
                      path="/price-elasticity"
                      component={PriceElasticityLayout}
                    />
                    <SecureRoute
                      exact
                      path="/price-elasticity/own"
                      component={OwnTab}
                    />
                     <SecureRoute
                      exact
                      path="/price-elasticity/cross"
                      component={CrossTab}
                    />
                    <SecureRoute
                      exact
                      path="/promo-performace"
                      component={PoromoPerformaceLayout}
                    />

                    <SecureRoute
                      exact
                      path="/price-elasticity/own-dashboard"
                      component={OwnDashboard}
                    />
                    <SecureRoute
                      exact
                      path="/price-elasticity/cross-dashboard"
                      component={CrossDashboard}
                    />
                <SecureRoute exact path="/profile" component={Profile} />
                <SecureRoute exact path="/api_test" component={TestAPI} />
                <SecureRoute exact path="/test-data" component={TestDataAPI} />
                <SecureRoute
                      exact
                      path="/pre-roi"
                      component={PreROIDashboard}
                    />

                {/* <Route
                  path='/login'
                  render={() => <Login config={oktaSignInConfig} />}
                /> */}
                <Route path='/login/callback' component={LoginCallback} />
              </Switch>
              </>
              :  <Switch> 
                <SecureRoute exact path='/' component={Navbar} />
                <Route path='/login/callback' component={LoginCallback} />
              </Switch>
          }
          
        </Container>
      </Security>
    </ThemeProvider>
  );
}

export default SecureAll;
