// TODO replace individual usestate with proper types
// this reduces the number of lines and improve type safety
export type SimulatedValue = {
    cogs: number
    historicalVolume:number
    netProfitOrLoss:number
    npp: number
    roiPercentage: number
    taPct: number
    totalPromoInvestment: number
    tpPct: number
}