type PlusProps = {
    color: string
}
export const Plus = ({color}:PlusProps) => {
    return <svg version="1.1" id="Layer_1" x="0px" y="0px" width={30} height={30} viewBox="0 0 495 495" >
    <polygon style={{fill:color}}   points="495,227.5 267.5,227.5 267.5,0 227.5,0 227.5,227.5 0,227.5 0,267.5 227.5,267.5 227.5,495   267.5,495 267.5,267.5 495,267.5 "/>
    </svg>
} 