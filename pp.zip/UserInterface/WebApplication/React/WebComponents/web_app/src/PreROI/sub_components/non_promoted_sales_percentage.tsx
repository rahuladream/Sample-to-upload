export const NonPromotedSalesPercentage = () => {
    return <div className="flex flex-col">
        <div className="flex justify-between py-4 items-center bg-gray-100 text-sm  px-2">
            <div className="min-w-50 font-bold text-left">% CP / Non-Promoted Sales	</div>
            <div className="min-w-40 text-left">1,000,000,000</div>
            <div className="min-w-40 text-left">1,000,000,000</div>
            <div className="min-w-40 text-left">1,000,000,000</div>
            <div className="min-w-40 text-left">1,000,000,000</div>
        </div>
    </div>
}