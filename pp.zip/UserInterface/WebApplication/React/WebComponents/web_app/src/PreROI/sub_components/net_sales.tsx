export const NetSales = () => {
    return <div className="flex flex-col">
        <div className="flex justify-between py-4 items-center bg-gray-100 text-sm  px-2">
            <div className="min-w-50 font-bold text-left">Net Sales (NSV)</div>
            <div className="min-w-40 text-left"> 1,000,000,000</div>
            <div className="min-w-40 text-left">1,000,000,000</div>
            <div className="min-w-40 text-left">1,000,000,000</div>
            <div className="min-w-40 text-left">1,000,000,000</div>
        </div>
        <div className="flex justify-between py-4 items-center bg-white text-sm px-2">
            <div className="min-w-50 text-left font-bold">(-) CP Base % on Invoice</div>
            <div className="min-w-40 text-left"> 1,000,000,000</div>
            <div className="min-w-40 text-left">1,000,000,000</div>
            <div className="min-w-40 text-left">1,000,000,000</div>
            <div className="min-w-40 text-left">1,000,000,000</div>
        </div>
        <div className="flex justify-between py-4 items-center bg-white text-sm px-2">
            <div className="min-w-50 text-left font-bold">(-) CP Base % on Invoice</div>
            <div className="min-w-40 text-left"> 1,000,000,000</div>
            <div className="min-w-40 text-left">1,000,000,000</div>
            <div className="min-w-40 text-left">1,000,000,000</div>
            <div className="min-w-40 text-left">1,000,000,000</div>
        </div>
    </div>
}