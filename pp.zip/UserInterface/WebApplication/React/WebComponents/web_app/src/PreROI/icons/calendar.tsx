type CalendarProps = {
    color: string
}
export const Calendar = ({color}:CalendarProps) => {
    return <svg xmlns="http://www.w3.org/2000/svg"  version="1.1" id="Capa_1" x="0px" y="0px" width="20" height="20" viewBox="0 0 31.622 31.621">
    <g>
        <g>
            <path d="M31.43,4.945c0-1.194-0.968-2.162-2.162-2.162h-3.656V0.882C25.612,0.395,25.217,0,24.73,0h-1.905    c-0.485,0-0.883,0.395-0.883,0.882v1.902H9.802V0.882C9.802,0.395,9.407,0,8.92,0H7.142C6.655,0,6.26,0.395,6.26,0.882v1.902H2.35    c-1.194,0-2.162,0.968-2.162,2.162v7.704h1.139v16.749c0,1.229,0.995,2.223,2.223,2.223h24.394c1.229,0,2.223-0.994,2.223-2.223    v-16.75h1.267L31.43,4.945L31.43,4.945z M26.624,25.73c0,1.229-0.994,2.223-2.223,2.223H7.218c-1.228,0-2.223-0.994-2.223-2.223    V12.649h21.628V25.73L26.624,25.73z" style={{fill:color}} />
            <rect x="8.031" y="15.051" width="3.541" height="3.669" style={{fill:color}} />
            <rect x="14.102" y="15.051" width="3.541" height="3.669" style={{fill:color}} />
            <rect x="20.172" y="15.051" width="3.542" height="3.669" style={{fill:color}} />
            <rect x="8.031" y="21.502" width="3.541" height="3.668" style={{fill:color}} />
            <rect x="14.102" y="21.502" width="3.541" height="3.668" style={{fill:color}} />
            <rect x="20.172" y="21.502" width="3.542" height="3.668" style={{fill:color}} />
        </g>
    </g>
    </svg>
}
