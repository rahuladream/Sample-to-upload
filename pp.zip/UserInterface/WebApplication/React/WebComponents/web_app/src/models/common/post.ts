export interface IAddPost {
  title: string;
  body: string;
  userId: number;
}

export interface IROIPost{
   country: string,
    baseline?: number,    
    cogs?: number,      
    fromDate?: string,
    incrementalVolume?: number | string,
    name?: string,
    netProfit?: number,
    npp?: number,   
    roiPercent?: number,      
    targetRoi?: number  | string | null,
    toDate?: string,
    totalInvestment?: number,
    totalVolume?: number,   
    categories?: string[] ,
    subCategories?: string[] ,
    brands?: string[] ,
    subBrands?: string[] ,
    eans?: string[] ,
    planLevel?: string[],
    customers? : string[],
    promoInvestmentAbsValues? : any[]
    promoInvestmentNonAbsValues? : any[]

  }


  export interface ISimulationPost{
    profitLoss? : any[],
    totalInvestment?: any[]
   /*  add: boolean,
    country: string,
  currentTotalInvestment?: number,
  currentTotalProfit?: number,
  firstRequest?: boolean,
  investmentToReckon?: number,
  profitToReckon?: number, */
}

export interface PriceElasticityDownloadData {
  country: string,
  source: string,
  scope: string,
  hierarchyLevel: string,
  category?: string,
  forOwn: boolean,
  subCategories?: string[],
  initialNodeValues?: string[],
  targetNodeValues?: string[] | null,
  initialManufacturers?: string[],
  targetManufacturers?: string[] | null,
  initialBrands?: string[],
  targetBrands?: string[] | null,
  initialSubBrands?: string[],
  targetSubBrands?: string[] | null,
  initialPacks?: string[],
  targetPacks?: string[] | null,
}