export interface kcProducts {
    title: string;
    body: string;
    userId: number;
  }