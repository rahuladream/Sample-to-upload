
import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
//buromobelexperte
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {  faInfoCircle, faCalendarAlt, faUserAlt, faGlobeAmericas, faChartLine, faBarcode, faSitemap, faDotCircle } from '@fortawesome/free-solid-svg-icons'



const useStyles = makeStyles((theme) => ({


    table: {
        minWidth: 650,
       
       
    },
    cellData: {
       
        textTransform: 'capitalize'
    },
    cellDataCenter: {
       
        textTransform: 'capitalize',
        textAlign: 'center'
    },
    fieldNames: {
        fontWeight: 700,
        color: '#09309b'
    },
    fieldValue: {
        color: '#393737'
    }
}));




export default function InfoDialog(props) {

    const classes = useStyles();

    const dalVal = props.impactorData

    return (
        <div style={{ displya: "inline" }}>

{dalVal && (
            <TableContainer component={Paper} >

                <Table className={classes.table} aria-label="simple table">
                    <TableBody>
                        <TableRow>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                                <span className={classes.fieldNames}><FontAwesomeIcon icon={faUserAlt} color="blue" />  Created By</span>
                            </TableCell>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                               <span className= {classes.fieldValue}> {dalVal.createdBy}</span>
                            </TableCell>
                        </TableRow>

                        <TableRow>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                                <span className={classes.fieldNames}><FontAwesomeIcon icon={faCalendarAlt} color="blue" />  Created On (UTC)</span>
                            </TableCell>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                               <span className= {classes.fieldValue}>  {dalVal.createdOn}</span>
                            </TableCell>
                        </TableRow>

                        <TableRow>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                                <span className={classes.fieldNames}><FontAwesomeIcon icon={faUserAlt} color="blue" />  Deleted By</span>
                            </TableCell>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                               <span className= {classes.fieldValue}>  {dalVal.deletedBy}</span>
                            </TableCell>
                        </TableRow>

                        <TableRow>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                                <span className={classes.fieldNames}><FontAwesomeIcon icon={faCalendarAlt} color="blue" />  Deleted On (UTC)</span>
                            </TableCell>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                               <span className= {classes.fieldValue}>  {dalVal.deletedOn}</span>
                            </TableCell>
                        </TableRow>

                        <TableRow>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                                <span className={classes.fieldNames}><FontAwesomeIcon icon={faGlobeAmericas} color="blue" />  Country</span>
                            </TableCell>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                               <span className= {classes.fieldValue}>  {dalVal.country}</span>
                            </TableCell>
                        </TableRow>

                        <TableRow>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                                <span className={classes.fieldNames}><FontAwesomeIcon icon={faChartLine} color="blue" />  Planning Customer</span>
                            </TableCell>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                            {dalVal.planLevels}
                            </TableCell>
                        </TableRow>

                        <TableRow>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                                <span className={classes.fieldNames}><FontAwesomeIcon icon={faDotCircle} color="blue" />  Sold To</span>
                            </TableCell>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                            {dalVal.soldTo}
                            </TableCell>
                        </TableRow>

                        <TableRow>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                                <span className={classes.fieldNames}><FontAwesomeIcon icon={faInfoCircle} color="blue" />  Category</span>
                            </TableCell>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                            {dalVal.categories}
                            </TableCell>
                        </TableRow>

                        <TableRow>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                                <span className={classes.fieldNames}><FontAwesomeIcon icon={faSitemap} color="blue" /> Sub Category</span>
                            </TableCell>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                            {dalVal.subCategories}
                            </TableCell>
                        </TableRow>

                        <TableRow>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                                <span className={classes.fieldNames}><FontAwesomeIcon icon={faBarcode} color="blue" />  EANS</span>
                            </TableCell>
                            <TableCell component="th" scope="row" className={classes.cellData}>
                            {dalVal.eans}
                            </TableCell>
                        </TableRow>
                    </TableBody>

                </Table>
            </TableContainer>

)}
        </div>
    );
}