import React, { useEffect, useState } from 'react';
import { PowerBIEmbed } from 'powerbi-client-react';
import { useTokenBI } from './services/queries';
import { models } from 'powerbi-client';
import './styles.css'


import useStore from './store';


function PriceElasticityReport() {
  

  

  const [ selecteddValue , setSelecteddValue] = useState([]);
   
  let priceOwnsValue = useStore((state) => state.priceOwnsValue);

   useEffect(()=>{
   let val = priceOwnsValue;
    
      setSelecteddValue([parseInt(val)])
   },[priceOwnsValue])
   
  const { isLoading: isTokenData, data: tokenData } = useTokenBI('8cfc54ad-00a2-4f3e-a261-0a166147b4f3');
  const [biToken, setBiToken] = useState('');
  const [embedUrl, setEmbedUrl] = useState('');
  let selectedCountry = useStore((state) => state.selectedCountry);
  let selectedKCProductNew = useStore((state) => state.selectedKCProductNew);
  /* let selectedBaseLineProductNew = useStore((state) => state.selectedBaseLineProductNew);

  let selectedYear = useStore((state) => state.selectedYear);
let viewMonthly = useStore((state) => state.viewMonthly);
 */
 /*  const [customerValues, setCustomerValues] = useState([]); */
  const [KCProductValues, setKCProductValues] = useState([]);

   const [categories, setCategories] = useState([]);
 const [subCategories, setSubCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [subBrands, setSubBrands] = useState([]);
  const [eans, setEans] = useState([]);

  // let categories = []
   /*    let subCategories = []
      let brands = []
     let subBrands = []
     let eans = []; */

  /* useEffect(() => {
   
    setCustomerValues(' ')
    if (!selectedBaseLineCustomerNew !== '') {
    
      let val;
      val = selectedBaseLineCustomerNew?.trim().replaceAll('&customers=', ",");
      //val = val.substring(1)
     
      val = val.split(',');
      val.shift();      
      setCustomerValues(val)
    }

  }, [selectedBaseLineCustomerNew]) */

  useEffect(() => {
    if (!selectedKCProductNew !== '') {
    

      //starts here
      let queryParams = selectedKCProductNew?.replace('?', '');
      queryParams = queryParams ? queryParams.split('&') : [];

     let categoriesLocal = []
      let subCategoriesLocal = []
      let brandsLocal = []
      let subBrandsLocal = []
      let eansLocalLocal= [];

     setCategories([])
     setSubCategories([])
     setBrands([])
     setSubBrands([])
     setEans([])


      for (const param of queryParams) {
        const data = param.split('=');
        if (data[0] === 'categories') {
          categoriesLocal.push(data[1])
        } else if (data[0] === 'subCategories') {
          subCategoriesLocal.push(data[1])
        } else if (data[0] === 'brands') {
          brandsLocal.push(data[1])
        } else if (data[0] === 'subBrands') {
          subBrandsLocal.push(data[1])
        } else if (data[0] === 'eans') {
          eansLocalLocal.push(data[1])
        }
      }//ends here

      setCategories(categoriesLocal)
      setSubCategories(subCategoriesLocal)
      setBrands(brandsLocal)
      setSubBrands(subBrandsLocal)
      setEans(eansLocalLocal)

    }

  }, [selectedKCProductNew])

  useEffect(() => {
    if (!isTokenData) {
      setBiToken(tokenData?.accessToken);
      setEmbedUrl(tokenData?.url)      
    }

  }, [isTokenData])



  const basicFilterCountry = {
    $schema: "http://powerbi.com/product/schema#basic",
    target: {
      table: "V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS",
      column: "COUNTRY"
    },
    operator: "In",
    values: [selectedCountry],
    filterType: models.FilterType.BasicFilter
  }
 


  const basicFilterKCEans = {
    $schema: "http://powerbi.com/product/schema#basic",
    target: {
      table: "V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS",
      column: "EAN_INITIAL"
    },
    operator: "In",
    //values: ['36000451429'],
   values: selecteddValue,
    filterType: models.FilterType.BasicFilter
  }


 

   const [filtersValue, setFiltersValue] = useState([]) 

  useEffect(() => {

    let filter = []

    if (selectedCountry?.length > 0) {
      filter.push(basicFilterCountry)
    }
    //filter.push(basicFilterKCEans)

    setFiltersValue(filter) 

  }, [   selectedCountry, selecteddValue])

  return (
    <div className="App">
      {/*  {embedUrl} */}

  
  {/*   {JSON.stringify(selecteddValue)} */}
  
      <header className="App-header">

        {
          !isTokenData && biToken && (

            <PowerBIEmbed
              embedConfig={{
               
                pageName: 'ReportSection1105d2874a40cec584ac',
                type: 'report',   // Supported types: report, dashboard, tile, visual and qna
                id: '8cfc54ad-00a2-4f3e-a261-0a166147b4f3',
                embedUrl: embedUrl,
                accessToken: biToken, 
                tokenType: models.TokenType.Embed,
                //filters: [basicFilterKCEans],
                filters: basicFilterCountry,
                settings: {
                  panes: {
                    filters: {
                      expanded: false,
                      visible: false
                    },
                    pageNavigation: {
                      visible: false
                    },
                  },
                }
              }}

              eventHandlers={
                new Map([
                  ['loaded', function () { console.log('Report loaded'); }],
                  ['rendered', function () { console.log('Report rendered'); }],
                  ['error', function (event) { console.log(event.detail); }]
                ])
              }

              cssClassName={"Embed-container"}

              getEmbeddedComponent={(embeddedReport) => {
                window.report = embeddedReport;
              }}
            />
          )
        }

      </header>
    </div>
  );
}

export default PriceElasticityReport;