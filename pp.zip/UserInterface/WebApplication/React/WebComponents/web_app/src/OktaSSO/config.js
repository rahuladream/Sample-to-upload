const BASENAME = process.env.PUBLIC_URL || '';
export const oktaAuthConfig = {
    issuer: process.env.REACT_APP_OKTA_URL,
    clientId:  process.env.REACT_APP_OKTA_CLIENT_ID,
    redirectUri:  `${window.location.origin}${BASENAME}/login/callback`,
    scopes: ['openid', 'profile', 'groups']
};

  
  