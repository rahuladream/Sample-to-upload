/* eslint-disable no-unused-expressions */

const initLevelSelectionFor = async (browser , type, testables, target, searchBox ) => {
    browser.frameParent().click('.rdn.levelSelector')

    browser.frameParent()
        .waitForElementVisible('.levelItem',10000)
        .expect.elements('.levelItem').count.to.equal(5)

    const levelItemNodes = await browser.frameParent().findElements(`.levelItem`)
    const levelItems = []
    for (const elem of levelItemNodes.value) {
        const text = await browser.frameParent().elementIdAttribute(elem.getId(), 'innerText')
        levelItems.push(text.value)
    }
    const levelValues = [
        'Brand', 'Sub Category', 'Sub Brand', 'Pack', 'EAN'
    ]

    for (const _level of levelValues) {
        browser.assert.equal(levelItems.includes(_level), true, `Level ${_level} should be present in the dropdown`)
    }

    browser.frameParent()
        .expect.element(`.levelItem.level_${type}`).to.be.visible

    browser.frameParent().click(`.levelItem.level_${type}`)

    browser.pause(1000)

    browser.frameParent().click(target)

    browser.frameParent().waitForElementVisible(searchBox,1000)
    browser.frameParent()
        .expect.elements(`${searchBox} .levelHeader`).count.to.be.equal(testables.length)

    const result = await browser.frameParent().findElements(`${searchBox} .levelHeader`)
    browser.assert.equal(result.status, 0, "Product levels should be present"); 
    browser.assert.equal(result.value.length, testables.length, `Product level length should be equal to ${testables.length}  ` )
    const values = []
    for (const elem of result.value) {
        const text = await browser.frameParent().elementIdAttribute(elem.getId(), 'innerText')
        values.push(text.value)
    }
   

    for (const expected of testables) {
        const hasExpected = values.includes(expected)
        browser.assert.equal(hasExpected,true,  `Level ${expected} to be present in the product search box`)
    }


}


const selectComparisonIn = async (browser, type, searchBox, productClass) => {
    browser.frameParent()
        .click(`${searchBox} .selector_${type}`)

    browser.frameParent()
        .waitForElementVisible(`${searchBox} #searcher_${type} .checker`,2000)

    
    let result = await browser.frameParent().findElements(`${searchBox} #searcher_${type} .checker`)
    browser.assert.equal(result.status, 0, 'Product selector checkbox should be present'); 
    browser.elementIdClick(result.value[0].getId())

    result = await browser.frameParent().findElements(`${searchBox} #searcher_${type} .checkerName`)
    browser.assert.equal(result.status, 0, 'Product selector checkbox with product name should be present'); 
    const selectedValue = await browser.frameParent().elementIdAttribute(result.value[0].getId(), 'innerText')
    const selectedText  = selectedValue.value
    const displayedInTable = await browser.frameParent().findElements(productClass)
    const displayedText = []
    for (const row of displayedInTable.value) {
        const rowText = await browser.frameParent().elementIdAttribute(row.getId(), 'innerText')
        displayedText.push(rowText.value)
    }
    browser.assert.equal(displayedText.includes(selectedText),true,`Selected product ${selectedText} should be present in the table `)
    
}


module.exports = {

    'Elasticity Correlation Tests' : async (browser) => {

        browser.frameParent().click('#country-list')

        browser.frameParent()
            .waitForElementVisible('.countryItem',2000)
            .expect.elements('.countryItem').count.to.equal(4)

        browser.click('#countryItem_PE')

        browser.pause(1000)


        browser.frameParent().click('#tab-price-elasticity')

        browser.pause(1000)


        browser.frameParent()
            .waitForElementVisible('.rdn.categorySelector',5000)

        browser.frameParent().click('.rdn.categorySelector')

        browser.frameParent()
            .waitForElementVisible('.categoryItem',5000)
            .expect.elements('.categoryItem').count.to.equal(5)

        browser.frameParent().click('.categoryItem:nth-of-type(1)')

        

    },

    'Correlation subcategory selection test' : async (browser) => {
        initLevelSelectionFor(browser, 'subCategory',['Sub Categories'], '#comparison_vertical', '#searchYAxis')
    },

    'Correlation brand selection test' : async (browser) => {
        initLevelSelectionFor(browser, 'brand',['Sub Categories', 'Manufacturer', 'Brands'], '#comparison_vertical', '#searchYAxis')
    },

    'Correlation sub brand selection test' : async (browser) => {
        initLevelSelectionFor(browser, 'subBrand',['Sub Categories', 'Manufacturer', 'Brands', 'Sub Brands'], '#comparison_vertical', '#searchYAxis')
        
    },

    'Correlation pack selection test' : async (browser) => {
        initLevelSelectionFor(browser, 'pack',['Sub Categories', 'Manufacturer', 'Brands', 'Sub Brands', 'Pack'], '#comparison_vertical', '#searchYAxis')
    },

    'Correlation EAN selection test' : async (browser) => {
        initLevelSelectionFor(browser, 'ean',['Sub Categories', 'Manufacturer', 'Brands', 'Sub Brands', 'Pack','EAN'], '#comparison_vertical', '#searchYAxis')
    },

    'Correlation subcategory selection test with comparison' : async (browser) => {
        await initLevelSelectionFor(browser, 'subCategory',['Sub Categories'], '#comparison_vertical', '#searchYAxis')
        await selectComparisonIn(browser,'subCategory','#searchYAxis','.initialProduct')
        browser.pause(1000)

        await initLevelSelectionFor(browser, 'subCategory',['Sub Categories'], '#comparison_horizontal', '#searchXAxis')
        await  selectComparisonIn(browser,'subCategory','#searchXAxis','.targetProduct')
        browser.pause(2000)


    },
}