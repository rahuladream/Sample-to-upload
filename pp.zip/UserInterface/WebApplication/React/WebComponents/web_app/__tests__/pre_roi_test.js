const {searchBarTesting, sleep} = require( "./test_utils")



module.exports = {
    
   
    'Pre ROI  Customer searchBar testing' :  async(browser) => {
        await searchBarTesting(browser,'customer',4,0)
        browser.frameParent()
            .waitForElementPresent(`.icon_customer`,2000)
            .click(`.icon_customer`)
        await searchBarTesting(browser,'customer',4,1)

    },

    'Pre ROI   Product searchBar testing' :  async(browser) => {
        await searchBarTesting(browser,'product',5, 0)
        browser.frameParent()
            .waitForElementPresent(`.icon_product`,2000)
            .click(`.icon_product`)
        await searchBarTesting(browser,'product',5,1)
    },

    'Clear customer testing in pre ROI' : async (browser) => {
        browser.frameParent()
            .waitForElementPresent('#clearCustomer')
        
        browser.frameParent().click('#clearCustomer')
        const displayedInTable = await browser.frameParent().findElements(`.selected_customer`)
        browser.assert.equal(0,displayedInTable.status)
        browser.assert.equal(0,displayedInTable.value.length)

        await searchBarTesting(browser,'customer',4,0)
        browser.frameParent()
            .waitForElementPresent(`.icon_customer`,2000)
            .click(`.icon_customer`)
        await searchBarTesting(browser,'customer',4,1)

    },

    'Clear products testing in pre ROI' : async (browser) => {
        browser.frameParent()
            .waitForElementPresent('#clearProducts')
        
        browser.frameParent().click('#clearProducts')
        const displayedInTable = await browser.frameParent().findElements(`.selected_product`)
        browser.assert.equal(0,displayedInTable.status)
        browser.assert.equal(0,displayedInTable.value.length)

        await searchBarTesting(browser,'product',5, 0)
        browser.frameParent()
            .waitForElementPresent(`.icon_product`,2000)
            .click(`.icon_product`)
        await searchBarTesting(browser,'product',5,1)

    }

}