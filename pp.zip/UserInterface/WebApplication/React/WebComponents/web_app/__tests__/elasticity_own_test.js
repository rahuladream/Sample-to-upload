/* eslint-disable no-unused-expressions */

const selectComparisonIn = async (browser, type, searchBox, productClass, clickIndex) => {
    browser.frameParent()
        .click(`${searchBox} .selector_${type}`)

    
    browser.frameParent()
        .waitForElementVisible(`${searchBox} #searcher_${type} .checkerName`,2000)
   

    let resultText = await browser.frameParent().findElements(`${searchBox} #searcher_${type} .checkerName`)
    browser.assert.equal(resultText.status, 0, 'Checkbox label for product should be visible'); 
    const selectedValue = await browser.frameParent().elementIdAttribute(resultText.value[clickIndex].getId(), 'innerText')
    const selectedText  = selectedValue.value

    // browser.frameParent()
    //     .waitForElementVisible(`${searchBox} #searcher_${type} .checker`,2000)

    let result = await browser.frameParent().findElements(`${searchBox} #searcher_${type} .checker`)
    browser.assert.equal(result.status, 0, "Checkbox should be visible"); 
    browser.elementIdClick(result.value[clickIndex].getId())


    browser.frameParent()
        .waitForElementVisible(productClass, 50000)


    browser.pause(3000)
    const displayedInTable = await browser.frameParent().findElements(productClass)
    const displayedText = []
    for (const row of displayedInTable.value) {
        const rowText = await browser.frameParent().elementIdAttribute(row.getId(), 'innerText')
        displayedText.push(rowText.value)
    }
    console.log(selectedText)
    console.log(displayedText)
    browser.assert.equal(displayedText.includes(selectedText),true,`Selected product ${selectedText} should be present in the table `)
    
}

module.exports = {

    'Elasticity Own Tests' : async (browser) => {
        browser.frameParent()
            .click('#tab-OwnTab')

        browser.frameParent()
            .waitForElementVisible('.rdn.categorySelector',5000)

        browser.frameParent().click('.rdn.categorySelector')

        browser.frameParent()
            .waitForElementVisible('.categoryItem',5000)
            .expect.elements('.categoryItem').count.to.equal(5)

        browser.frameParent().click('.categoryItem:nth-of-type(1)')

        browser.frameParent().click('.rdn.levelSelector')

        browser.frameParent()
            .waitForElementVisible('.levelItem',10000)
            .expect.elements('.levelItem').count.to.equal(5)
    
        browser.frameParent()
            .expect.element(`.levelItem.level_ean`).to.be.visible
    
        browser.frameParent().click(`.levelItem.level_ean`)
    
        browser.frameParent()
            .waitForElementVisible('#prod_picker3',2000)

        browser.frameParent().click('#prod_picker3')

        browser.frameParent().waitForElementVisible('#searchOwn',1000)

        await selectComparisonIn(browser, 'ean', '#searchOwn', '.firstColumn',0 )
        browser.frameParent()
        .waitForElementVisible('.moreBtn',2000)
        browser.frameParent().click('.firstColumn')
        browser.frameParent()
            .waitForElementVisible('#prod_picker1',5000)
        browser.frameParent().click('#prod_picker1')
        await selectComparisonIn(browser, 'ean', '#searchOwn', '.firstColumn', 1)
    

    },

    'View more tests' : async(browser) => {
        browser.frameParent()
            .waitForElementVisible('.moreBtn',2000)
        const moreBtns = await browser.frameParent().findElements('.moreBtn')
        browser.assert.equal(moreBtns.value.length, 2, "There should be 2 View More Buttons present" )
       

        const selectedProductNodes = await browser.frameParent().findElements('.firstColumn')
        const displayedText = []
        for (const row of selectedProductNodes.value) {
            const rowText = await browser.frameParent().elementIdAttribute(row.getId(), 'innerText')
            displayedText.push(rowText.value)
        }

        const currentSelectedProduct = displayedText[0]

        browser.elementIdClick(moreBtns.value[0].getId())
        const windows = await browser.windowHandles()
        browser.assert.equal(2, windows.value.length, "Click on View more should open a new window")
        const viewMoreWindow = windows.value[1]
        await browser.switchWindow(viewMoreWindow)
        browser.assert.urlContains('/price-elasticity/own-dashboard',"View more should redirect to products own dashboard")

        browser.waitForElementVisible('.kcOvalShape', 5000)
        browser.assert.containsText('.kcOvalShape',currentSelectedProduct, `View more should show the selected product ${currentSelectedProduct}`)
        browser.assert.domPropertyContains('iframe','src','https://app.powerbi.com/reportEmbed')

        browser
        .waitForElementVisible('#powerBIFrame',30000)

        const lineCharts = await browser.frame('powerBIFrame').findElements('.visual-lineChart') 
        browser.assert.equal(2, lineCharts.value.length, "There should be 2 line charts in the power BI report (Evolution of Price and Volume & Volume (Actual) vs (Predicted)) ")

        const scatterCharts = await browser.frame('powerBIFrame').findElements('.visual-scatterChart') 
        browser.assert.equal(2, scatterCharts.value.length, "There should be 2 scatter charts in the power BI report ( Profit parabola & Demand Function) ")

    }

}
