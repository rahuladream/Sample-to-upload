/* eslint-disable @typescript-eslint/no-unused-expressions */
/* eslint-disable no-unused-expressions */

const {sleep} = require( "./test_utils")
var assert = require('assert')

module.exports = {

    'Baseline report tests' : async (browser) => {

        await browser.click('#country-list')

        await browser.pause(3000)

        await browser
            .waitForElementVisible('.countryItem',2000)
            
        browser.expect.elements('.countryItem').count.to.equal(5)

        await browser.click('#countryItem_UK')

        await browser
            .waitForElementVisible('#powerBIFrame',30000)

    },

    'Daily frequency testing' : async (browser) => {

        browser.elements('css selector', '.frequencyItem', function(result) {
            browser.assert.equal(result.value.length, 3, "All frequency items are visible for UK")
        });

        browser.elements('css selector', '#frequency_active_Daily', function(result) {
            browser.assert.equal(result.value.length, 0, "Daily level granularity is not available for UK")
        });

        await browser.click('#country-list')

        await browser.pause(2000)

        await browser
            .waitForElementVisible('.countryItem',2000)

        await browser.click('#countryItem_XY')

        await browser.pause(5000)

        browser.elements('css selector', '.frequencyItem', function(result) {
            browser.assert.equal(result.value.length, 3, "All frequency items are visible for TestDay")
        });

        browser.elements('css selector', '#frequency_active_Daily', function(result) {
            browser.assert.equal(result.value.length, 1, "Daily level granularity is available for TestDay")
        });

        await browser.pause(5000)

        await browser.click('#frequency_active_Daily')

        await browser.pause(5000)
  
        await browser
            .waitForElementVisible('#powerBIFrame',30000)

        // const result = await browser.frame('powerBIFrame').findElements('.bodyCells  .pivotTableCellWrap') 
        // await browser.assert.equal(result.status, 0, "Power BI graph for baseline should be loaded"); 
        // console.log(result.value)
        // const firstNode = result.value[0]
        // const ratioText = await browser.elementIdAttribute(firstNode.getId(), 'innerText')
        // browser.assert.equal(ratioText.status, 0, "Ratio text shoud be present"); 
        // console.log(ratioText.value)

    },

    'Baseline grid testing' : async(browser) => {
        await browser.pause(2000);
        await browser.frameParent()
            .waitForElementPresent('#tab-BaseLine',2000)
            .click('#tab-BaseLine')

        await browser.frameParent()
            .waitForElementPresent('.BaselineGrid',2000)
    },

}