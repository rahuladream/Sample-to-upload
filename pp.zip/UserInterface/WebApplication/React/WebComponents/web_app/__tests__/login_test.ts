// import {NightwatchBrowser} from 'nightwatch'


module.exports =  {

    'SSO Auth Flow' : async (browser) => {
        
        await browser.waitForElementVisible('.btnClose', 30000)
        await browser
            .click('.btnClose')

        await browser
            .waitForElementVisible('.user_profile',3000)
        await browser
            .assert.containsText('.user_profile','Velusamy, Ramesh K')

    },

    'Handling country selection' : async(browser) => {
       
        await browser
            .assert.containsText('#chartDiv','Please select country to view Reports/Graph.')

        await browser
            .assert.elementPresent('#country-list')
        
    },

    
}
