/* eslint-disable @typescript-eslint/no-unused-expressions */
/* eslint-disable no-unused-expressions */

const {searchBarTesting, sleep} = require( "./test_utils")

var assert = require('assert')


module.exports = {

    'Baseline report tests' : async (browser) => {

        await browser.click('#country-list')

        await browser
            .waitForElementVisible('.countryItem',2000)
            
        browser.expect.elements('.countryItem').count.to.equal(5)

        await browser.click('#countryItem_PE')

        await browser
            .waitForElementVisible('#powerBIFrame',30000)

        const result = await browser.frame('powerBIFrame').findElements('.bodyCells  .pivotTableCellWrap') 
        await browser.assert.equal(result.status, 0, "Power BI graph for baseline should be loaded"); 
        // browser.assert.equal(result.value.length, 2, `The graph should display 2 header labels` )
        const firstNode = result.value[0]
        const ratioText = await browser.elementIdAttribute(firstNode.getId(), 'innerText')
        browser.assert.equal(ratioText.status, 0, "Tatio text shoud be present"); 
        console.log(ratioText.value)
        // assert.include(ratioText, '%')
        // const ratio = ratioText.value.split('%')[0]
        // browser.assert.ok(parseInt(ratio) > 0)

    },

    'Baseline subtabs testing' : async(browser) => {

        await browser.frameParent()
            .waitForElementPresent('#tab-BaseLine',2000)
            .click('#tab-BaseLine')

        await browser.frameParent()
            .waitForElementPresent('#simple-tabpanel-0',30000)
            .expect.element('#simple-tabpanel-0 table').to.be.present

        
        await browser.frameParent()
            .waitForElementPresent('#tab-ImpactorsHistory',2000)
            .click('#tab-ImpactorsHistory')

        await browser.frameParent()
            .waitForElementPresent('#simple-tabpanel-1',30000)
            .expect.element('#simple-tabpanel-1 table').to.be.present

        await browser.frameParent()
            .waitForElementPresent('#tab-newImpactors',2000)
            .click('#tab-newImpactors')

        await browser.frameParent()
            .waitForElementPresent('#simple-tabpanel-3',30000)
            .expect.element('#simple-tabpanel-3 table').to.be.present


        await browser.frameParent()
            .waitForElementPresent('#tab-ImpactorsHistory',2000)
            .click('#tab-ImpactorsHistory')

        await browser.frameParent()
            .waitForElementPresent('#simple-tabpanel-1',30000)
            .expect.element('#simple-tabpanel-1 table').to.be.present


    },

    'Customer searchBar testing' :  async(browser) => {
        await searchBarTesting(browser,'customer',4,0)
        await browser.frameParent()
            .waitForElementPresent(`.icon_customer`,2000)
            .click(`.icon_customer`)
        await searchBarTesting(browser,'customer',4,1)



    },

    'Product searchBar testing' :  async(browser) => {
        await searchBarTesting(browser,'product',5, 0)
        await browser.frameParent()
            .waitForElementPresent(`.icon_product`,2000)
            .click(`.icon_product`)
        await searchBarTesting(browser,'product',5,1)
    },

    'Clear customer testing' : async (browser) => {
        await browser.frameParent()
            .waitForElementPresent('#clearCustomer')
        
        await browser.frameParent().click('#clearCustomer')
        const displayedInTable = await browser.frameParent().findElements(`.selected_customer`)
        browser.assert.equal(0,displayedInTable.status)
        browser.assert.equal(0,displayedInTable.value.length)

        await searchBarTesting(browser,'customer',4,0)
        await browser.frameParent()
            .waitForElementPresent(`.icon_customer`,2000)
            .click(`.icon_customer`)
        await searchBarTesting(browser,'customer',4,1)

    },

    'Clear products testing' : async (browser) => {
        await browser.frameParent()
            .waitForElementPresent('#clearProducts')
        
        await browser.frameParent().click('#clearProducts')
        const displayedInTable = await browser.frameParent().findElements(`.selected_product`)
        browser.assert.equal(0,displayedInTable.status)
        browser.assert.equal(0,displayedInTable.value.length)

        await searchBarTesting(browser,'product',5, 0)
        await browser.frameParent()
            .waitForElementPresent(`.icon_product`,2000)
            .click(`.icon_product`)
        await searchBarTesting(browser,'product',5,1)
        
    }

}