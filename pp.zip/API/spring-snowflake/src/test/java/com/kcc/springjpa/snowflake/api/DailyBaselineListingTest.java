package com.kcc.springjpa.snowflake.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.kcc.springjpa.snowflake.SpringJpaSnowflakeServiceApplication;
import com.kcc.springjpa.snowflake.model.BaseLineDataModel;
import com.kcc.springjpa.snowflake.service.BaseLineDataService;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.TestPropertySources;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.MOCK;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = {SpringJpaSnowflakeServiceApplication.class})
@AutoConfigureMockMvc
/*@TestPropertySource(locations = {"classPath:application.properties"})*/
public class DailyBaselineListingTest {

    @Autowired
    MockMvc mvc;

    @Autowired
    BaseLineDataService baseLineService;

    @Test
    public void givenBaselines_whenGetDailyBaseline_thenStatus200() throws Exception {
        List<Integer> years = new ArrayList<>();
        years.add(2022);
        List<BaseLineDataModel> results = baseLineService.getBaseLineData("XY", years, "daily", null, null, null, null, null, null, null);

        MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders
                .get("/baseLineData")
                .header("Authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiTXlzb3JlIFN1YmhhcyBDaGFuZHJhLCBHdXJ1cmFqYSIsImdyb3VwcyI6WyJBenVyZV9LQ19BZHZhbmNlZF9BbmFseXRpY3NfTm9uUHJvZF9Db250cmlidXRvciJdLCJqdGkiOiIxYjQxNjk4OS0yNTdkLTRlOGEtYTYxZC00NjkwNzc4OTI4MTYiLCJpYXQiOjE2NDczNDY4NTAsImV4cCI6MTY0NzM0NzE1MH0.Cahxugf7zyv0W8zUxms8wxBPnjZpw2_QG6fdHbvjUZY")
                .queryParam("country", "XY")
                .queryParam("years", "2022")
                .queryParam("granularity", "daily"))
                .andReturn();
        String restResponse = mvcResult.getResponse().getContentAsString();
        ObjectMapper objectMapper = new ObjectMapper();
        TypeFactory typeFactory = objectMapper.getTypeFactory();
        List<BaseLineDataModel> data = objectMapper.readValue(restResponse, typeFactory.constructCollectionType(List.class, BaseLineDataModel.class));

        BaseLineDataModel year2022 = new BaseLineDataModel();
        year2022.year = 2022;

        BaseLineDataModel m1 = results.get(results.indexOf(year2022));
        BaseLineDataModel m2 = data.get(data.indexOf(year2022));

        assertEquals(m1.adjustedBaseLine.getTotalQuantity(), m2.adjustedBaseLine.getTotalQuantity());
        assertEquals(m1.statisticalBaseLine.getTotalQuantity(), m2.statisticalBaseLine.getTotalQuantity());

        assertEquals(m1.adjustedBaseLine.getAverageQuantity(), m2.adjustedBaseLine.getAverageQuantity());
        assertEquals(m1.statisticalBaseLine.getAverageQuantity(), m2.statisticalBaseLine.getAverageQuantity());
    }
}
