package com.kcc.springjpa.snowflake.api;

import com.kcc.springjpa.snowflake.SpringJpaSnowflakeServiceApplication;
import com.kcc.springjpa.snowflake.model.Simulation;
import com.kcc.springjpa.snowflake.service.PreRoiDataService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.ParseException;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {SpringJpaSnowflakeServiceApplication.class})
public class SimulationsTest {

    @Autowired
    PreRoiDataService service;

    @Test
    public void whenGivenCountry_thenReturnAllSimulations() throws Exception {
        List<Simulation> simulations = service.findSimulations("PE", null, null, null, null, "Spring-Boot-Test");
        assert  simulations.size() > 0;
    }
}
