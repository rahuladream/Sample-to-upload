package com.kcc.springjpa.snowflake.model;

import java.sql.Timestamp;
import java.util.Date;

public class Simulation {

    public String name, tacticType, createdBy, modifiedBy, productHierarchy;
    public Date fromDate,  toDate;
    public Integer incrementalVolume,  totalVolume;
    public Float baseline, targetRoi,  roi,  netProfit, totalInvestment;

    public Simulation(String name, Date fromDate, Date toDate, Float baseline, Integer incrementalVolume, Integer totalVolume,
                      Float targetRoi, Float roi, Float netProfit, Float totalInvestment, String promoTypeSpec, String createdBy, String modifiedBy,
                      String productHierarchy) {
        this.name = name;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.baseline = baseline;
        this.incrementalVolume = incrementalVolume;
        this.totalVolume = totalVolume;
        this.targetRoi = targetRoi;
        this.roi = roi;
        this.netProfit = netProfit;
        this.totalInvestment = totalInvestment;
        this.tacticType = promoTypeSpec;
        this.createdBy = createdBy;
        this.modifiedBy = modifiedBy;
        this.productHierarchy = productHierarchy;
    }

    public Simulation() {}
}
