package com.kcc.springjpa.snowflake.service.impl;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collectors;

import com.kcc.springjpa.snowflake.dtos.GetElasticitiesRequest;
import com.kcc.springjpa.snowflake.dtos.GetRegressionStatsRequest;
import com.kcc.springjpa.snowflake.dtos.LineFittingDataPoint;
import com.kcc.springjpa.snowflake.dtos.RegressionStats;
import com.kcc.springjpa.snowflake.entity.*;
import com.kcc.springjpa.snowflake.model.CrossOwnView;
import com.kcc.springjpa.snowflake.model.OwnElasticityModelForDownload;
import com.kcc.springjpa.snowflake.repository.*;
import com.kcc.springjpa.snowflake.utility.ExcelHelper;
import org.apache.commons.math3.stat.regression.SimpleRegression;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kcc.springjpa.snowflake.dao.ElasticityDao;
import com.kcc.springjpa.snowflake.model.ElasticityProductHierarchy;
import com.kcc.springjpa.snowflake.model.OwnElasticityModel;
import com.kcc.springjpa.snowflake.service.OwnDataService;
import com.kcc.springjpa.snowflake.utility.EanUtility;
import com.kcc.springjpa.snowflake.utility.ElasticityUtility;
import com.kcc.springjpa.snowflake.utility.HierarchyLevel;

import static com.kcc.springjpa.snowflake.utility.NumberFormatUtility.roundedPValue;

@Service
public class OwnDataServiceImpl implements OwnDataService {
	
	private static final Logger logger = LogManager.getLogger(OwnDataServiceImpl.class);
	
	@Autowired
	OwnCrossEanRepository ownCrossEanRepository;
	
	@Autowired
	OwnCrossPackRepository ownCrossPackRepository;
	
	@Autowired
	OwnCrossSubbrandRepository ownCrossSubbrandRepository;
	
	@Autowired
	OwnCrossBrandRepository ownCrossBrandRepository;
	
	@Autowired
	OwnCrossSubCategoryRepository ownCrossSubCategoryRepository;
	
	@Autowired
	ElasticityHelperServiceImpl elasticityHelper;
	
	@Autowired
	ElasticityDao elasticityDao;

	@Autowired
	OwnCrossCategoryRepository ownCrossCategoryRepository;

	//Category --> SubCategory --> Manufacturer --> Brand --> SubBrand --> Tier --> Pack --> EAN - Description
	@Override
	public ElasticityProductHierarchy getOwnProductHierarchy(String country, String scope, String source, String levelIndicator) throws Exception {
		logger.info("Snowflake call to find OwnProducts by country initial: " + country);

		if(levelIndicator == null || levelIndicator.isEmpty()) {
			levelIndicator = "EAN";
		}

		List<CrossOwnView> views;
		List<String> leafValues = null;
		switch (levelIndicator) {
			case "SUB_CATEGORY":
				views = ownCrossSubCategoryRepository.findByInitials(country, leafValues, scope, source, HierarchyLevel.OWN, true);
				break;
			case "BRAND":
				views = ownCrossBrandRepository.findByInitials(country, leafValues, scope, source, HierarchyLevel.OWN, true);
				break;
			case "SUB_BRAND":
				views = elasticityDao.findByInitials(country, leafValues, scope, source, HierarchyLevel.OWN, true);
				break;
			case "PACK":
				views = ownCrossPackRepository.findByInitials(country, leafValues, scope, source, HierarchyLevel.OWN, true);
				break;
			case "CATEGORY":
				views = ownCrossCategoryRepository.findByInitials(country, scope, source, HierarchyLevel.OWN);
				break;
			default:
				views = ownCrossEanRepository.findByInitials(country, leafValues, scope, source, HierarchyLevel.OWN, true);
				break;
		}
		logger.info("Number of OwnProducts by country initial " + country + "----------" + views.size());

		return elasticityHelper.getInitialProductHierarchy(views);
	}

	private OwnElasticityModel populateElasticityModel(OwnCrossCommonFields entityObj, Map<String, Boolean> leafMap, String leafKey, boolean forKorea) {
		OwnElasticityModel ownElasticityModel = new OwnElasticityModel();
		ownElasticityModel.setPriceIndex(entityObj.getPriceIndexAvg());
		ownElasticityModel.setRange(ElasticityUtility.getRange(true, entityObj.getElasticityAvgPrice(), forKorea));
		ownElasticityModel.setRsquared(entityObj.getRSquaredAvg());
		ownElasticityModel.setAveragePrice(entityObj.getElasticityAvgPrice());
		ownElasticityModel.setPromoPrice(entityObj.getElasticityPromoPrice());
		ownElasticityModel.setBasePrice(entityObj.getElasticityBasePrice());
		ownElasticityModel.setModelRun(entityObj.getModelRun());
		ownElasticityModel.setNWeeks(entityObj.getNWeeks());
		ownElasticityModel.setPeriodBegin(entityObj.getPeriodBegin());
		ownElasticityModel.setPeriodEnd(entityObj.getPeriodEnd());
		ownElasticityModel.setViewMore(leafMap.getOrDefault(leafKey, false));
		ownElasticityModel.setPValue(roundedPValue(entityObj.getPValue()));
		ownElasticityModel.setAverageVolume(entityObj.getAvgQty());

		return ownElasticityModel;

	}

	private OwnElasticityModel populateElasticityModelForCategories(OwnCrossCategory entityObj, boolean forKorea) {
		OwnElasticityModel ownElasticityModel = new OwnElasticityModel();
		ownElasticityModel.setPriceIndex(entityObj.getPriceIndexAvg());
		ownElasticityModel.setRange(ElasticityUtility.getRange(true, entityObj.getElasticityAvgPrice(), forKorea));
		ownElasticityModel.setRsquared(entityObj.getRSquaredAvg());
		ownElasticityModel.setAveragePrice(entityObj.getElasticityAvgPrice());
		ownElasticityModel.setPromoPrice(entityObj.getElasticityPromoPrice());
		ownElasticityModel.setBasePrice(entityObj.getElasticityBasePrice());
		ownElasticityModel.setModelRun(entityObj.getModelRun());
		ownElasticityModel.setNWeeks(entityObj.getNWeeks());
		ownElasticityModel.setPeriodBegin(entityObj.getPeriodBegin());
		ownElasticityModel.setPeriodEnd(entityObj.getPeriodEnd());
		ownElasticityModel.setViewMore(false);
		ownElasticityModel.setPValue(roundedPValue(entityObj.getPValue()));
		ownElasticityModel.setAverageVolume(entityObj.getAvgQty());

		return ownElasticityModel;
	}

	@Override
	public List<Map<String, OwnElasticityModel>> getOwnElasticityModels(String country, List<String> leafValues, String levelIndicator, int topNBottomN, String category, String source, List<String> subCategories, List<String> manufacturers, List<String> brands, List<String> subBrands, List<String> packs) throws Exception {
		
		logger.info("Snowflake call to find Own Elasticity Models by OwnProducts: " + leafValues);
		List<Map<String, OwnElasticityModel>> ownElasticityData = new ArrayList<Map<String, OwnElasticityModel>>();
		Map<String, OwnElasticityModel> map = new HashMap<String, OwnElasticityModel>();
		Map<String , Boolean> leafMap = new HashMap<String, Boolean>();

		String type = HierarchyLevel.WC;

		boolean forKorea = country.equalsIgnoreCase("KR");

		if(levelIndicator.equals(HierarchyLevel.CATEGORY)) {
			List<OwnCrossCategory> categories = elasticityDao.categories(country, HierarchyLevel.OWN, type, source, category);
			for(OwnCrossCategory ocData : categories) {
				OwnElasticityModel ownElasticityModel = populateElasticityModelForCategories(ocData, forKorea);
				map.put(ocData.getCategory(), ownElasticityModel);
			}
			ownElasticityData.add(map);
		} else if (levelIndicator.equals(HierarchyLevel.SUB_CATEGORY)) {
			List<OwnCrossSubCategoryData> ownCrossSubCategoryData = new ArrayList<>();
			if(leafValues != null && !leafValues.isEmpty()) {
				leafMap = elasticityDao.isViewMoreOwn(country, leafValues, levelIndicator);
				ownCrossSubCategoryData = ownCrossSubCategoryRepository.findAllByCountryAndFlagAndTypeAndSourceAndInitialSubCategoryIn(country, HierarchyLevel.OWN, type, source, leafValues);
			}
			if(topNBottomN > 0) {
				List<OwnCrossSubCategoryData> topNSubC = ownCrossSubCategoryRepository.findTopN(country, HierarchyLevel.OWN, type, topNBottomN, category, source);
				List<OwnCrossSubCategoryData> bottomNSubC = ownCrossSubCategoryRepository.findBottomN(country, HierarchyLevel.OWN, type, topNBottomN, category, source);
				ownCrossSubCategoryData.addAll(topNSubC);
				ownCrossSubCategoryData.addAll(bottomNSubC);
			}

			logger.info("Number of Own Elasticity Models for given OwnProducts ------------------" + ownCrossSubCategoryData.size());
			for(OwnCrossSubCategoryData ocData : ownCrossSubCategoryData) {
				String leafKey = ocData.getInitialSubCategory();
				OwnElasticityModel ownElasticityModel = populateElasticityModel(ocData, leafMap, leafKey, forKorea);
				map.put(leafKey, ownElasticityModel);
			}
			ownElasticityData.add(map);
		} else if (levelIndicator.equals(HierarchyLevel.MANUFACTURER)) {
			//ownCrossData
		} else if (levelIndicator.equals(HierarchyLevel.BRAND)) {
			List<OwnCrossBrandData> ownCrossBrandData = new ArrayList<>();
			if(leafValues != null && !leafValues.isEmpty()) {
				leafMap = elasticityDao.isViewMoreOwn(country, leafValues, levelIndicator);
				ownCrossBrandData = ownCrossBrandRepository.findAllByCountryAndFlagAndTypeAndSourceAndInitialBrandIn(country, HierarchyLevel.OWN, type, source, leafValues);
			}
			if(topNBottomN > 0) {
				List<OwnCrossBrandData> topNBrand = ownCrossBrandRepository.findTopN(country, HierarchyLevel.OWN, type, topNBottomN, category, source);
				List<OwnCrossBrandData> bottomNBrand = ownCrossBrandRepository.findBottomN(country, HierarchyLevel.OWN, type, topNBottomN, category, source);
				ownCrossBrandData.addAll(topNBrand);
				ownCrossBrandData.addAll(bottomNBrand);
			}
			logger.info("Number of Own Elasticity Models for given OwnProducts ------------------" + ownCrossBrandData.size());
			for(OwnCrossBrandData ocData : ownCrossBrandData) {
				String leafKey = ocData.getInitialBrand();
				OwnElasticityModel ownElasticityModel = populateElasticityModel(ocData, leafMap, leafKey, forKorea);
				map.put(leafKey, ownElasticityModel);
			}
			ownElasticityData.add(map);
		} else if (levelIndicator.equals(HierarchyLevel.SUB_BRAND)) {
			List<OwnCrossSubbrandData> ownCrossSubbrandData = new ArrayList<>();
			if(leafValues != null && !leafValues.isEmpty()) {
				leafMap = elasticityDao.isViewMoreOwn(country, leafValues, levelIndicator);
				ownCrossSubbrandData = elasticityDao.products(country, HierarchyLevel.OWN, type, leafValues, null, source, category, subCategories, null, manufacturers, null, brands, null, subBrands, null, packs, null, levelIndicator, OwnCrossSubbrandData.class);
			}
			if(topNBottomN > 0) {
				List<OwnCrossSubbrandData> topNSubBrand = ownCrossSubbrandRepository.findTopN(country, HierarchyLevel.OWN, type, topNBottomN, category, source);
				List<OwnCrossSubbrandData> bottomNSubBrand = ownCrossSubbrandRepository.findBottomN(country, HierarchyLevel.OWN, type, topNBottomN, category, source);
				ownCrossSubbrandData.addAll(topNSubBrand);
				ownCrossSubbrandData.addAll(bottomNSubBrand);
			}
			logger.info("Number of Own Elasticity Models for given OwnProducts ------------------" + ownCrossSubbrandData.size());
			for(OwnCrossSubbrandData ocData : ownCrossSubbrandData) {
				String leafKey = ocData.getInitialSubBrand();
				OwnElasticityModel ownElasticityModel = populateElasticityModel(ocData, leafMap, leafKey, forKorea);
				map.put(leafKey, ownElasticityModel);
			}
			ownElasticityData.add(map);
		} else if (levelIndicator.equals(HierarchyLevel.TIER)) {
			//ownCrossData
		} else if (levelIndicator.equals(HierarchyLevel.PACK)) {
			List<OwnCrossPackData> ownCrossPackData = new ArrayList<>();
			if(leafValues != null && !leafValues.isEmpty()) {
				leafMap = elasticityDao.isViewMoreOwn(country, leafValues, levelIndicator);
				ownCrossPackData = ownCrossPackRepository.findAllByCountryAndFlagAndTypeAndSourceAndInitialPackIn(country, HierarchyLevel.OWN, type, source, leafValues);
			}
			if(topNBottomN > 0) {
				List<OwnCrossPackData> topNPack = ownCrossPackRepository.findTopN(country, HierarchyLevel.OWN, type, topNBottomN, category, source);
				List<OwnCrossPackData> bottomNPack = ownCrossPackRepository.findBottomN(country, HierarchyLevel.OWN, type, topNBottomN, category, source);
				ownCrossPackData.addAll(topNPack);
				ownCrossPackData.addAll(bottomNPack);
			}
			logger.info("Number of Own Elasticity Models for given OwnProducts ------------------" + ownCrossPackData.size());
			for(OwnCrossPackData ocData : ownCrossPackData) {
				String leafKey = ocData.getInitialPack();
				OwnElasticityModel ownElasticityModel = populateElasticityModel(ocData, leafMap, leafKey, forKorea);
				map.put(leafKey, ownElasticityModel);
			}
			ownElasticityData.add(map);
		} else if (levelIndicator.equals(HierarchyLevel.EAN)) {
			List<OwnCrossData> ownCrossData = new ArrayList<>();
			if(leafValues != null && !leafValues.isEmpty()) {
				leafMap = elasticityDao.isViewMoreOwn(country, EanUtility.getEanNumbersFromDescriptions(leafValues), levelIndicator);
				ownCrossData = elasticityDao.products(country, HierarchyLevel.OWN, type, EanUtility.getEanNumbersFromDescriptions(leafValues), null, source, category, subCategories, null, manufacturers, null, brands, null, subBrands, null, packs, null, levelIndicator, OwnCrossData.class);
			}
			if(topNBottomN > 0) {
				List<OwnCrossData> topNEan = ownCrossEanRepository.findTopN(country, HierarchyLevel.OWN, type, topNBottomN, category, source);
				List<OwnCrossData> bottomNEan = ownCrossEanRepository.findBottomN(country, HierarchyLevel.OWN, type, topNBottomN, category, source);
				ownCrossData.addAll(topNEan);
				ownCrossData.addAll(bottomNEan);
			}
			logger.info("Number of Own Elasticity Models for given OwnProducts ------------------" + ownCrossData.size());
			for(OwnCrossData ocData : ownCrossData) {
				String leafKey = ocData.getEanInitial();
				OwnElasticityModel ownElasticityModel = populateElasticityModel(ocData, leafMap, leafKey, forKorea);
				map.put(this.formEanInitialDescription(ocData, levelIndicator), ownElasticityModel);
			}
			ownElasticityData.add(map);
		}
		logger.info("Own Elasticity Models--------" + ownElasticityData.size());
		return ownElasticityData;
	}

	private String formEanInitialDescription(OwnCrossData ocData, String levelIndicator) {
		if(levelIndicator.equals(HierarchyLevel.CATEGORY)) {
			return ocData.getCategory();
		} else if (levelIndicator.equals(HierarchyLevel.SUB_CATEGORY)) {
			return ocData.getInitialSubCategory();
		} else if (levelIndicator.equals(HierarchyLevel.MANUFACTURER)) {
			return ocData.getInitialManufacturer();
		} else if (levelIndicator.equals(HierarchyLevel.BRAND)) {
			return ocData.getInitialBrand();
		} else if (levelIndicator.equals(HierarchyLevel.SUB_BRAND)) {
			return ocData.getInitialSubBrand();
		} else if (levelIndicator.equals(HierarchyLevel.TIER)) {
			return ocData.getInitialTier();
		} else if (levelIndicator.equals(HierarchyLevel.PACK)) {
			return ocData.getInitialPack();
		} else if (levelIndicator.equals(HierarchyLevel.EAN)) {
			return EanUtility.formEanNumberDescriptionCombination(ocData.getEanInitial(), ocData.getEanDescriptionInitial());
		}
		return levelIndicator;	
	}

	@Override
	public Map<String, Map<String, OwnElasticityModel>> getOwnElasticityModelsPerScope(String country,
																					   List<String> leafValues, String levelIndicator, String scope, int topNBottomN, String category, String source, List<String> subCategories, List<String> manufacturers, List<String> brands, List<String> subBrands, List<String> packs) throws SQLException, Exception {

		logger.info("Snowflake call to find Own Elasticity Models by OwnProducts: " + leafValues);
		Map<String, Map<String, OwnElasticityModel>> map = new HashMap<String, Map<String, OwnElasticityModel>>();
		Map<String , Boolean> leafMap = new HashMap<String, Boolean>();

		boolean forKorea = country.equalsIgnoreCase("KR");

		if(levelIndicator.equals(HierarchyLevel.CATEGORY)) {
			List<OwnCrossCategory> categories = elasticityDao.categories(country, HierarchyLevel.OWN, scope.toUpperCase(), source, category);
			for(OwnCrossCategory ocData : categories) {
				OwnElasticityModel ownElasticityModel = populateElasticityModelForCategories(ocData, forKorea);
				if(map.containsKey(ocData.getCategory())) {
					if(map.get(ocData.getCategory()).containsKey(ocData.getTypeDescription())) {
						//Already exists
					}else {
						map.get(ocData.getCategory()).put(ocData.getTypeDescription(), ownElasticityModel);
					}
				}else {
					Map<String, OwnElasticityModel> elasticityModelMap = new HashMap<String, OwnElasticityModel>();
					elasticityModelMap.put(ocData.getTypeDescription(), ownElasticityModel);
					map.put(ocData.getCategory(), elasticityModelMap);
				}
			}
		} else if (levelIndicator.equals(HierarchyLevel.SUB_CATEGORY)) {
			List<OwnCrossSubCategoryData> ownCrossSubCategoryData = new ArrayList<>();
			if(leafValues != null && !leafValues.isEmpty()) {
				leafMap = elasticityDao.isViewMoreOwn(country, leafValues, levelIndicator);
				ownCrossSubCategoryData = ownCrossSubCategoryRepository.findAllByCountryAndFlagAndTypeAndSourceAndInitialSubCategoryIn(country, HierarchyLevel.OWN, scope.toUpperCase(), source, leafValues);
			}
			if(topNBottomN > 0) {
				List<OwnCrossSubCategoryData> topNSubC = ownCrossSubCategoryRepository.findTopN(country, HierarchyLevel.OWN, scope.toUpperCase(), topNBottomN, category, source);
				List<OwnCrossSubCategoryData> bottomNSubC = ownCrossSubCategoryRepository.findBottomN(country, HierarchyLevel.OWN, scope.toUpperCase(), topNBottomN, category, source);
				ownCrossSubCategoryData.addAll(topNSubC);
				ownCrossSubCategoryData.addAll(bottomNSubC);
			}
			logger.info("Number of Own Elasticity Models for given OwnProducts ------------------" + ownCrossSubCategoryData.size());
			for(OwnCrossSubCategoryData ocData : ownCrossSubCategoryData) {
				String leafKey = ocData.getInitialSubCategory();
				OwnElasticityModel ownElasticityModel = populateElasticityModel(ocData, leafMap, leafKey, forKorea);
				if(map.containsKey(leafKey)) {
					if(map.get(leafKey).containsKey(ocData.getTypeDescription())) {
						//Already exists
					}else {
						map.get(leafKey).put(ocData.getTypeDescription(), ownElasticityModel);
					}
				}else {
					Map<String, OwnElasticityModel> elasticityModelMap = new HashMap<String, OwnElasticityModel>();
					elasticityModelMap.put(ocData.getTypeDescription(), ownElasticityModel);
					map.put(leafKey, elasticityModelMap);
				}
			}
		} else if (levelIndicator.equals(HierarchyLevel.MANUFACTURER)) {
			//ownCrossData
		} else if (levelIndicator.equals(HierarchyLevel.BRAND)) {
			List<OwnCrossBrandData> ownCrossBrandData = new ArrayList<>();
			if(leafValues != null && !leafValues.isEmpty()) {
				leafMap = elasticityDao.isViewMoreOwn(country, leafValues, levelIndicator);
				ownCrossBrandData = ownCrossBrandRepository.findAllByCountryAndFlagAndTypeAndSourceAndInitialBrandIn(country, HierarchyLevel.OWN, scope.toUpperCase(), source, leafValues);
			}
			if(topNBottomN > 0) {
				List<OwnCrossBrandData> topNBrand = ownCrossBrandRepository.findTopN(country, HierarchyLevel.OWN, scope.toUpperCase(), topNBottomN, category, source);
				List<OwnCrossBrandData> bottomNBrand = ownCrossBrandRepository.findBottomN(country, HierarchyLevel.OWN, scope.toUpperCase(), topNBottomN, category, source);
				ownCrossBrandData.addAll(topNBrand);
				ownCrossBrandData.addAll(bottomNBrand);
			}
			logger.info("Number of Own Elasticity Models for given OwnProducts ------------------" + ownCrossBrandData.size());
			for(OwnCrossBrandData ocData : ownCrossBrandData) {
				String leafKey = ocData.getInitialBrand();
				OwnElasticityModel ownElasticityModel = populateElasticityModel(ocData, leafMap, leafKey, forKorea);
				if(map.containsKey(leafKey)) {
					if(map.get(leafKey).containsKey(ocData.getTypeDescription())) {
						//Already exists
					}else {
						map.get(leafKey).put(ocData.getTypeDescription(), ownElasticityModel);
					}
				}else {
					Map<String, OwnElasticityModel> elasticityModelMap = new HashMap<String, OwnElasticityModel>();
					elasticityModelMap.put(ocData.getTypeDescription(), ownElasticityModel);
					map.put(leafKey, elasticityModelMap);
				}
			}
		} else if (levelIndicator.equals(HierarchyLevel.SUB_BRAND)) {
			List<OwnCrossSubbrandData> ownCrossSubbrandData = new ArrayList<>();
			if(leafValues != null && !leafValues.isEmpty()) {
				leafMap = elasticityDao.isViewMoreOwn(country, leafValues, levelIndicator);
				ownCrossSubbrandData = elasticityDao.products(country, HierarchyLevel.OWN, scope.toUpperCase(), leafValues, null, source, category, subCategories, null, manufacturers, null, brands, null, subBrands, null, packs, null, levelIndicator, OwnCrossSubbrandData.class);
			}
			if(topNBottomN > 0) {
				List<OwnCrossSubbrandData> topNSubBrand = ownCrossSubbrandRepository.findTopN(country, HierarchyLevel.OWN, scope.toUpperCase(), topNBottomN, category, source);
				List<OwnCrossSubbrandData> bottomNSubBrand = ownCrossSubbrandRepository.findBottomN(country, HierarchyLevel.OWN, scope.toUpperCase(), topNBottomN, category, source);
				ownCrossSubbrandData.addAll(topNSubBrand);
				ownCrossSubbrandData.addAll(bottomNSubBrand);
			}
			logger.info("Number of Own Elasticity Models for given OwnProducts ------------------" + ownCrossSubbrandData.size());
			for(OwnCrossSubbrandData ocData : ownCrossSubbrandData) {
				String leafKey = ocData.getInitialSubBrand();
				OwnElasticityModel ownElasticityModel = populateElasticityModel(ocData, leafMap, leafKey, forKorea);

				if(map.containsKey(leafKey)) {
					if(map.get(leafKey).containsKey(ocData.getTypeDescription())) {
						//Already exists
					}else {
						map.get(leafKey).put(ocData.getTypeDescription(), ownElasticityModel);
					}
				}else {
					Map<String, OwnElasticityModel> elasticityModelMap = new HashMap<String, OwnElasticityModel>();
					elasticityModelMap.put(ocData.getTypeDescription(), ownElasticityModel);
					map.put(leafKey, elasticityModelMap);
				}
			}
		} else if (levelIndicator.equals(HierarchyLevel.TIER)) {
			//ownCrossData
		} else if (levelIndicator.equals(HierarchyLevel.PACK)) {
			List<OwnCrossPackData> ownCrossPackData = new ArrayList<>();
			if(leafValues != null && !leafValues.isEmpty()) {
				leafMap = elasticityDao.isViewMoreOwn(country, leafValues, levelIndicator);
				ownCrossPackData = ownCrossPackRepository.findAllByCountryAndFlagAndTypeAndSourceAndInitialPackIn(country, HierarchyLevel.OWN, scope.toUpperCase(), source, leafValues);
			}
			if(topNBottomN > 0) {
				List<OwnCrossPackData> topNPack = ownCrossPackRepository.findTopN(country, HierarchyLevel.OWN, scope.toUpperCase(), topNBottomN, category, source);
				List<OwnCrossPackData> bottomNPack = ownCrossPackRepository.findBottomN(country, HierarchyLevel.OWN, scope.toUpperCase(), topNBottomN, category, source);
				ownCrossPackData.addAll(topNPack);
				ownCrossPackData.addAll(bottomNPack);
			}
			logger.info("Number of Own Elasticity Models for given OwnProducts ------------------" + ownCrossPackData.size());
			for(OwnCrossPackData ocData : ownCrossPackData) {
				String leafKey = ocData.getInitialPack();
				OwnElasticityModel ownElasticityModel = populateElasticityModel(ocData, leafMap, leafKey, forKorea);

				if(map.containsKey(leafKey)) {
					if(map.get(leafKey).containsKey(ocData.getTypeDescription())) {
						//Already exists
					}else {
						map.get(leafKey).put(ocData.getTypeDescription(), ownElasticityModel);
					}
				}else {
					Map<String, OwnElasticityModel> elasticityModelMap = new HashMap<String, OwnElasticityModel>();
					elasticityModelMap.put(ocData.getTypeDescription(), ownElasticityModel);
					map.put(leafKey, elasticityModelMap);
				}
			}
		} else if (levelIndicator.equals(HierarchyLevel.EAN)) {
			List<OwnCrossData> ownCrossData = new ArrayList<>();
			if(leafValues != null && !leafValues.isEmpty()) {
				leafMap = elasticityDao.isViewMoreOwn(country, EanUtility.getEanNumbersFromDescriptions(leafValues), levelIndicator);
				ownCrossData = elasticityDao.products(country, HierarchyLevel.OWN, scope.toUpperCase(), EanUtility.getEanNumbersFromDescriptions(leafValues), null, source, category, subCategories, null, manufacturers, null, brands, null, subBrands, null, packs, null, levelIndicator, OwnCrossData.class);
			}
			if(topNBottomN > 0) {
				List<OwnCrossData> topNEan = ownCrossEanRepository.findTopN(country, HierarchyLevel.OWN, scope.toUpperCase(), topNBottomN, category, source);
				List<OwnCrossData> bottomNEan = ownCrossEanRepository.findBottomN(country, HierarchyLevel.OWN, scope.toUpperCase(), topNBottomN, category, source);
				ownCrossData.addAll(topNEan);
				ownCrossData.addAll(bottomNEan);
			}
			logger.info("Number of Own Elasticity Models per Scope for given OwnProducts ------------------" + ownCrossData.size());		
			for(OwnCrossData ocData : ownCrossData) {
				String leafKey = ocData.getEanInitial();
				OwnElasticityModel ownElasticityModel = populateElasticityModel(ocData, leafMap, leafKey, forKorea);

				if(map.containsKey(EanUtility.formEanNumberDescriptionCombination(leafKey, ocData.getEanDescriptionInitial()))) {
					if(map.get(EanUtility.formEanNumberDescriptionCombination(leafKey, ocData.getEanDescriptionInitial())).containsKey(ocData.getTypeDescription())) {
						//Already exists
					}else {
						map.get(EanUtility.formEanNumberDescriptionCombination(leafKey, ocData.getEanDescriptionInitial())).put(ocData.getTypeDescription(), ownElasticityModel);
					}
				}else {
					Map<String, OwnElasticityModel> elasticityModelMap = new HashMap<String, OwnElasticityModel>();
					elasticityModelMap.put(ocData.getTypeDescription(), ownElasticityModel);
					map.put(EanUtility.formEanNumberDescriptionCombination(leafKey, ocData.getEanDescriptionInitial()), elasticityModelMap);
				}			
			}
		}
		logger.info("Own Elasticity Models--------" + map.size());
		return map;	
	}

	@Override
	public Map<String, Boolean> getMarketScopeToggles(String country, String category, String levelIndicator, String source) throws Exception {
		Map<String, Boolean> scopes = new HashMap<>(2);

		scopes.put("customerScope", elasticityDao.scopeExists(country, category, HierarchyLevel.CUSTOMER, levelIndicator, source));
		scopes.put("channelScope", elasticityDao.scopeExists(country, category, HierarchyLevel.CHANNEL, levelIndicator, source));

		return scopes;
	}

	@Override
	public Map<String, Boolean> getAvailableSources(String country, String productLevel) throws Exception {
		Map<String, Boolean> s = new HashMap<>();
		if (productLevel == null || productLevel.isEmpty()) {
			productLevel = "EAN";
		}
		List<String> sources = elasticityDao.getAvailableSources(country, productLevel);
		s.put("nielsenAvailable", sources.contains("NIELSEN"));
		s.put("posAvailable", sources.contains("POS"));
		return s;
	}

	private Object getValueForMethod(String name, Object object) {
		try {
			return object.getClass().getMethod(name, new Class<?>[] {}).invoke(object);
		}catch (Exception ex){
			return null;
		}
	}

	private OwnElasticityModelForDownload populateFieldsForDownload(OwnCrossCommonFields entityObj, boolean forKorea) {
		OwnElasticityModelForDownload ownElasticityModel = new OwnElasticityModelForDownload();
		ownElasticityModel.setPriceIndex(entityObj.getPriceIndexAvg());
		ownElasticityModel.setRange(ElasticityUtility.getRange(true, entityObj.getElasticityAvgPrice(), forKorea));
		ownElasticityModel.setRsquared(entityObj.getRSquaredAvg());
		ownElasticityModel.setAveragePrice(entityObj.getElasticityAvgPrice());
		ownElasticityModel.setPromoPrice(entityObj.getElasticityPromoPrice());
		ownElasticityModel.setBasePrice(entityObj.getElasticityBasePrice());
		ownElasticityModel.setModelRun(entityObj.getModelRun());
		ownElasticityModel.setNWeeks(entityObj.getNWeeks());
		ownElasticityModel.setPeriodBegin(entityObj.getPeriodBegin());
		ownElasticityModel.setPeriodEnd(entityObj.getPeriodEnd());
		ownElasticityModel.setSlope(entityObj.getSlope());
		ownElasticityModel.setIntercept(entityObj.getIntercept());
		ownElasticityModel.setCategory(entityObj.getCategory());
		ownElasticityModel.setCustomer(entityObj.getTypeDescription());
		ownElasticityModel.setPValue(roundedPValue(entityObj.getPValue()));
		ownElasticityModel.setAverageQuantity(entityObj.getAvgQty());
		ownElasticityModel.setElasticity(entityObj.getElasticityAvgPrice());

		String className = entityObj.getClass().getSimpleName();
		if (className.equals("OwnCrossSubCategoryData")
				|| className.equals("OwnCrossBrandData")
				|| className.equals("OwnCrossSubbrandData")
				|| className.equals("OwnCrossPackData")
				|| className.equals("OwnCrossData") ){

			ownElasticityModel.setSubCategoryInitial(getValueForMethod("getInitialSubCategory", entityObj).toString());
			ownElasticityModel.setSubCategoryTarget(getValueForMethod("getTargetSubCategory", entityObj).toString());
		}

		if (className.equals("OwnCrossBrandData")
				|| className.equals("OwnCrossSubbrandData")
				|| className.equals("OwnCrossPackData")
				|| className.equals("OwnCrossData")){
			Object iniitalManufacturer = getValueForMethod("getInitialManufacturer", entityObj);
			Object targetManufacturer = getValueForMethod("getTargetManufacturer", entityObj);
			ownElasticityModel.setManufacturerInitial(iniitalManufacturer != null ? iniitalManufacturer.toString() : null);
			ownElasticityModel.setManufacturerTarget(targetManufacturer != null ? targetManufacturer.toString() : null);

			Object initialBrand = getValueForMethod("getInitialBrand", entityObj);
			Object targetBrand = getValueForMethod("getTargetBrand", entityObj);
			ownElasticityModel.setBrandInitial(initialBrand != null ? initialBrand.toString() : null);
			ownElasticityModel.setBrandTarget(targetBrand != null ? targetBrand.toString() : null);
		}

		if (className.equals("OwnCrossSubbrandData")
				|| className.equals("OwnCrossPackData")
				|| className.equals("OwnCrossData")) {
			Object initial = getValueForMethod("getInitialSubBrand", entityObj);
			Object target = getValueForMethod("getTargetSubBrand", entityObj);
			ownElasticityModel.setSubBrandInitial(initial != null ? initial.toString() : null);
			ownElasticityModel.setSubBrandTarget(target != null ? target.toString() : null);
		}

		if (className.equals("OwnCrossPackData")
				|| className.equals("OwnCrossData")) {
			Object initialTier = getValueForMethod("getInitialTier", entityObj);
			Object targetTier = getValueForMethod("getTargetTier", entityObj);
			ownElasticityModel.setTierInitial(initialTier != null ? initialTier.toString() : null);
			ownElasticityModel.setTierTarget(targetTier != null ? targetTier.toString() : null);

			Object initial = getValueForMethod("getInitialPack", entityObj);
			Object target = getValueForMethod("getTargetPack", entityObj);
			ownElasticityModel.setPackInitial(initial != null ? initial.toString() : null);
			ownElasticityModel.setPackTarget(target != null ? target.toString() : null);
		}

		if (className.equals("OwnCrossData")) {
			Object initialEan = getValueForMethod("getEanInitial", entityObj);
			Object targetEan = getValueForMethod("getEanTarget", entityObj);
			ownElasticityModel.setEanInitial(initialEan != null ? initialEan.toString() : null);
			ownElasticityModel.setEanTarget(targetEan != null ? targetEan.toString() : null);

			Object initial = getValueForMethod("getEanDescriptionInitial", entityObj);
			Object target = getValueForMethod("getEanDescriptionTarget", entityObj);
			ownElasticityModel.setEanDescriptionInitial(initial != null ? initial.toString() : null);
			ownElasticityModel.setEanDescriptionTarget(target != null ? target.toString() : null);
		}
		return ownElasticityModel;

	}

	@Override
	public ByteArrayInputStream getOwnElasticityFile(GetElasticitiesRequest req) throws Exception {
		boolean forKorea = req.country.equalsIgnoreCase("KR");

		List<OwnElasticityModelForDownload> elasticities;
		String[] spreadsheetKey;
		switch (req.hierarchyLevel) {
			case HierarchyLevel.CATEGORY:
				List<OwnCrossCategory> categories = elasticityDao.categories(req.country,
						req.forOwn ? HierarchyLevel.OWN : HierarchyLevel.CROSS, req.scope, req.source, req.category);
				elasticities = categories.stream().map(c -> populateCategoryFieldsForDownload(c, forKorea)).collect(Collectors.toList());
				spreadsheetKey = new String[]{"Category Level Data", HierarchyLevel.CATEGORY};
				break;
			case HierarchyLevel.BRAND:
				List<OwnCrossBrandData> brandElasticities = elasticityDao.elasticitiesForDownload(req, OwnCrossBrandData.class);
				elasticities = brandElasticities.stream().map(c -> populateFieldsForDownload(c, false)).collect(Collectors.toList());
				spreadsheetKey = new String[]{"Brand Level Data", HierarchyLevel.BRAND};
				break;
			case HierarchyLevel.SUB_BRAND:
				List<OwnCrossSubbrandData> subBrandElasticities = elasticityDao.elasticitiesForDownload(req, OwnCrossSubbrandData.class);
				elasticities = subBrandElasticities.stream().map(record -> populateFieldsForDownload(record, forKorea)).collect(Collectors.toList());
				spreadsheetKey = new String[]{"Sub Brand Level Data", HierarchyLevel.SUB_BRAND};
				break;
			case HierarchyLevel.PACK:
				List<OwnCrossPackData> packElasticities = elasticityDao.elasticitiesForDownload(req, OwnCrossPackData.class);
				elasticities = packElasticities	.stream().map(c -> populateFieldsForDownload(c, false)).collect(Collectors.toList());
				spreadsheetKey = new String[]{"Pack Level Data", HierarchyLevel.PACK};
				break;
			default:
				req.initialNodeValues = EanUtility.getEanNumbersFromDescriptions(req.initialNodeValues);
				req.targetNodeValues = EanUtility.getEanNumbersFromDescriptions(req.targetNodeValues);
				List<OwnCrossData> eanElasticities = elasticityDao.elasticitiesForDownload(req, OwnCrossData.class);
			 	elasticities = eanElasticities.stream().map(record -> populateFieldsForDownload(record, forKorea)).collect(Collectors.toList());
			 	spreadsheetKey = new String[]{"EAN Level Data", HierarchyLevel.EAN};
				break;
		}
		Map<String[], List<OwnElasticityModelForDownload>> resultMap = new HashMap<>();
		resultMap.put(spreadsheetKey, elasticities);
		return ExcelHelper.ownElasticityDataToExcel(resultMap, req.forOwn);
	}

	private OwnElasticityModelForDownload populateCategoryFieldsForDownload(OwnCrossCategory c, boolean forKorea) {
		OwnElasticityModelForDownload m = new OwnElasticityModelForDownload();
		m.setPriceIndex(c.getPriceIndexAvg());
		m.setRange(ElasticityUtility.getRange(true, c.getElasticityAvgPrice(), forKorea));
		m.setRsquared(c.getRSquaredAvg());
		m.setAveragePrice(c.getElasticityAvgPrice());
		m.setPromoPrice(c.getElasticityPromoPrice());
		m.setBasePrice(c.getElasticityBasePrice());
		m.setModelRun(c.getModelRun());
		m.setNWeeks(c.getNWeeks());
		m.setPeriodBegin(c.getPeriodBegin());
		m.setPeriodEnd(c.getPeriodEnd());
		m.setSlope(c.getSlope());
		m.setIntercept(c.getIntercept());
		m.setCategory(c.getCategory());
		m.setCustomer(c.getTypeDescription());
		m.setPValue(roundedPValue(c.getPValue()));
		m.setAverageQuantity(c.getAvgQty());
		m.setElasticity(c.getElasticityAvgPrice());

		return m;
	}

	@Override
	public String lastModelUpdateDate(String country) throws Exception {
		return elasticityDao.lastModelUpdateDate(country);
	}

	@Override
	public List<LineFittingDataPoint> getLineFittingDataPoints(String country, String initial, String target, String levelIndicator, String customer) {
		return elasticityDao.getLineFittingDataPoints(country, initial, target, levelIndicator, customer);
	}

	@Override
	public RegressionStats runRegression(GetRegressionStatsRequest r) {
		SimpleRegression sr = new SimpleRegression(true);
		int numberOfObservations = 0;
		double totalPrice = 0;
		double totalVolume = 0;
		for (LineFittingDataPoint d : r.dataPoints) {
			sr.addData(d.price, d.volume);
			totalPrice += d.price;
			totalVolume += d.volume;
			numberOfObservations++;
		}
		double averagePrice = totalPrice / numberOfObservations;
		double averageVolume = totalVolume / numberOfObservations;

		RegressionStats s = new RegressionStats();

		BigDecimal slope = BigDecimal.valueOf(sr.getSlope()).setScale(2, RoundingMode.HALF_EVEN);
		s.slopeIntegral = slope.longValue();
		s.slopeDecimal = slope.subtract(new BigDecimal(s.slopeIntegral)).doubleValue();

		BigDecimal intercept = BigDecimal.valueOf(sr.getIntercept()).setScale(2, RoundingMode.HALF_EVEN);
		s.interceptIntegral = intercept.longValue();
		s.interceptDecimal = intercept.subtract(new BigDecimal(s.interceptIntegral)).doubleValue();

		s.rSquared = sr.getRSquare();
		s.rSquared = BigDecimal.valueOf(s.rSquared).setScale(2, RoundingMode.HALF_EVEN).doubleValue();

		double elasticity = 0;
		switch (r.country) {
			case "PE":
			case "UK":
				elasticity = (averagePrice / averageVolume) * slope.doubleValue();
				break;
			case "KR":
				elasticity = slope.doubleValue();
		}

		BigDecimal elasticity1 = BigDecimal.valueOf(elasticity).setScale(2, RoundingMode.HALF_EVEN);
		s.elasticityIntegral = elasticity1.longValue();
		s.elasticityDecimal = elasticity1.subtract(new BigDecimal(s.elasticityIntegral)).doubleValue();

		return s;
	}

	@Override
	public List<String> getSubCategories(String country, String category) {
		return ownCrossEanRepository.findSubCategoriesForCategory(country, category);
	}
}
