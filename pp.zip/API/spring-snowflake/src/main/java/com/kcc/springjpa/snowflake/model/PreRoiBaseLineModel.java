package com.kcc.springjpa.snowflake.model;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class PreRoiBaseLineModel {
	
	public PreRoiBaseLineModel() {	}

	public PreRoiBaseLineModel(Integer week, BigDecimal baseLineTotalQuantity, BigDecimal baseLineAdjustedQuantity) {
		super();
		this.week = week;
		this.baseLineTotalQuantity = baseLineTotalQuantity;
		this.baseLineAdjustedQuantity = baseLineAdjustedQuantity;
	}
	
	private Integer week;
	
	private BigDecimal baseLineTotalQuantity;
	
	private BigDecimal baseLineAdjustedQuantity;

}
