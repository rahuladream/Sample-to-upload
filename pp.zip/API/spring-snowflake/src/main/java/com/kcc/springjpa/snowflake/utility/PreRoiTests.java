package com.kcc.springjpa.snowflake.utility;

import com.kcc.springjpa.snowflake.dtos.DeleteSimulationsRequest;
import com.kcc.springjpa.snowflake.entity.PreRoiSim;
import com.kcc.springjpa.snowflake.model.PreRoiPromoSimulationModel;
import com.kcc.springjpa.snowflake.model.PromoSimulation;
import com.kcc.springjpa.snowflake.model.Simulation;
import com.kcc.springjpa.snowflake.service.PreRoiDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class PreRoiTests {

    StringBuilder logBuilder = new StringBuilder();

    @Autowired
    PreRoiDataService preRoiDataService;

    public String run() throws Exception {
        logBuilder.append("Creating request to get baseline value").append("<br/>");

        List<GetBaselineValueRequest> requests = loadBaselineValueRequests();
        for (GetBaselineValueRequest r : requests) {
            logBuilder.append("Reading baseline value for: ").append(r).append("<br/>");

            double baseline = getBaseline(r);

            logBuilder.append("Baseline: ").append(baseline).append("<br/>");

            int incrementalVolume = 100;
            String promotionType = "CP_Base_fixed_amount_Off_Invoice-20";

            logBuilder.append(String.format("Reading simulated values with Promotion Type %s Incremental Volume %d", promotionType, incrementalVolume)).append("<br/>");

            PreRoiPromoSimulationModel simulationModel = getSimulatedValues(r, promotionType, baseline, incrementalVolume);

            logBuilder.append("Simulated values: ").append(simulationModel).append("<br/>");

            float targetROI = 100.0f;
            String simulationName = "Guru-OnDemand-PreRoi-Test";

            logBuilder.append(String.format("Creating Simulation with name %s and Target ROI %f", simulationName, targetROI)).append("<br/>");

            PromoSimulation ps = getPromotionSimulation(r, simulationModel, simulationName, (float) baseline, incrementalVolume, targetROI);
            String createdBy = "Guru";
            PreRoiSim sim = preRoiDataService.savePromoSimulation(createdBy, ps);

            logBuilder.append("Verifying if Simulation was saved to table").append("<br/>");

            checkIfNewSimulationWasSaved(r, simulationName);

            logBuilder.append("Creating delete Simulation request").append("<br/>");

            DeleteSimulationsRequest dr = new DeleteSimulationsRequest();
            dr.country = r.country;
            dr.names = new ArrayList<>();
            dr.names.add(ps.getName());

            logBuilder.append("Deleting Simulation").append("<br/>");

            preRoiDataService.deleteSimulations(dr, createdBy);

            logBuilder.append("Verifying if Simulation was deleted").append("<br/>");

            checkIfNewSimulationWasDeleted(r, simulationName);
        }
        return logBuilder.toString();
    }

    private void checkIfNewSimulationWasDeleted(GetBaselineValueRequest r, String simulationName) throws Exception {
        List<Simulation> simulations = preRoiDataService.findSimulations(r.country, null, null, null, null, "Spring-Boot-Test");
        boolean notDeleted = false;
        for (Simulation s : simulations) {
            if (s.name.equals(simulationName)) {
                notDeleted = true;
                break;
            }
        }
        if (notDeleted) {
            logBuilder.append("Found simulation in listing even after delete call").append("<br/>");
        } else {
            logBuilder.append("Simulation removed with delete call. Not found in listing").append("<br/>");
        }
    }

    private void checkIfNewSimulationWasSaved(GetBaselineValueRequest r, String simulationName) throws Exception {
        List<Simulation> simulations = preRoiDataService.findSimulations(r.country, null, null, null, null, "Spring-Boot-Test");
        for (Simulation s : simulations) {
            if (s.name.equals(simulationName)) {
                logBuilder.append("Found simulation in listing").append("<br/>");
            }
        }
    }

    private PromoSimulation getPromotionSimulation(GetBaselineValueRequest r, PreRoiPromoSimulationModel simulationModel, String simulationName, float baseline, int incrementalVolume, float targetROI) {
        PromoSimulation ps = new PromoSimulation();
        ps.setName(simulationName);
        ps.setCountry(r.country);
        ps.setFromDate(r.fromDate);
        ps.setToDate(r.toDate);
        ps.setPlanLevels(r.planLevels);
        ps.setCustomers(r.customers);
        ps.setCategories(r.categories);
        ps.setSubCategories(r.subCategories);
        ps.setBrands(r.brands);
        ps.setSubBrands(r.subBrands);
        ps.setEans(r.eans);
        ps.setBaseline(baseline);
        ps.setTotalInvestment((float) simulationModel.totalPromoInvestment);
        ps.setTotalVolume((int) (baseline + incrementalVolume));
        ps.setIncrementalVolume(incrementalVolume);
        ps.setNetProfit((float) simulationModel.netProfitOrLoss);
        ps.setTargetRoi(targetROI);
        ps.setRoiPercent((float) simulationModel.roiPercentage);
        return ps;
    }

    private PreRoiPromoSimulationModel getSimulatedValues(GetBaselineValueRequest r, String promotionType, double baselineVolume, double incrementalVolume) throws SQLException, ParseException {
        return preRoiDataService.getSimulatedROIAndNPL(r.country,
                r.planLevels,
                r.customers,
                r.categories,
                r.subCategories,
                r.brands,
                r.subBrands,
                r.eans,
                r.fromDate,
                r.toDate,
                baselineVolume,
                incrementalVolume,
                Collections.singletonList(promotionType),
                null, null);
    }

    private double getBaseline(GetBaselineValueRequest r) throws SQLException, ParseException {
        StringResponse response = preRoiDataService.getBaselineValue(r.country,
                r.planLevels,
                r.customers,
                r.categories,
                r.subCategories,
                r.brands,
                r.subBrands,
                r.eans,
                r.fromDate,
                r.toDate);
        String res1 = response.getResponse();
        return Double.parseDouble(res1.substring(res1.lastIndexOf(":") + 1).trim());
    }

    private List<GetBaselineValueRequest> loadBaselineValueRequests() {
        List<GetBaselineValueRequest> rs = new ArrayList<>();
        GetBaselineValueRequest r1 = new GetBaselineValueRequest();
        r1.country = "PE";
        r1.planLevels.add("0043318446-CAS PC CENCOSUD RETAIL PERU S.A.");
        r1.customers.add("CENCOSUD RETAIL PERU S.A.");
        r1.categories.add("Bathroom Tissue");
        r1.subCategories.add("BATHROOM TISSUE DRY");
        r1.brands.add("BATHROOM TISSUE DRY SUAVE");
        r1.subBrands.add("BATHROOM TISSUE DRY SUAVE");
        r1.eans.add("17751493007921-BT SUAVE CUIDADO COMPLETO 2P 1X32 SANIT");
        r1.fromDate = "2022-04-01";
        r1.toDate = "2022-04-04";

        rs.add(r1);
        return rs;
    }

    static class GetBaselineValueRequest {
        public String country, fromDate, toDate;
        public List<String> planLevels = new ArrayList<>(1),
                customers = new ArrayList<>(1),
                categories = new ArrayList<>(1),
                subCategories = new ArrayList<>(1),
                brands = new ArrayList<>(1),
                subBrands = new ArrayList<>(1),
                eans = new ArrayList<>(1);

        @Override
        public String toString() {
            return "GetBaselineValueRequest{" +
                    "country='" + country + '\'' +
                    ", fromDate='" + fromDate + '\'' +
                    ", toDate='" + toDate + '\'' +
                    ", planLevels=" + planLevels +
                    ", customers=" + customers +
                    ", categories=" + categories +
                    ", subCategories=" + subCategories +
                    ", brands=" + brands +
                    ", subBrands=" + subBrands +
                    ", eans=" + eans +
                    '}';
        }
    }
}
