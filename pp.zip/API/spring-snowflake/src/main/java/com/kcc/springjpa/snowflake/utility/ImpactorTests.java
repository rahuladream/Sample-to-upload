package com.kcc.springjpa.snowflake.utility;

import com.kcc.springjpa.snowflake.dao.ImpactorDao;
import com.kcc.springjpa.snowflake.dtos.CreateImpactorRequest;
import com.kcc.springjpa.snowflake.model.BaseLineDataModel;
import com.kcc.springjpa.snowflake.model.ImpactorInfoModel;
import com.kcc.springjpa.snowflake.service.BaseLineDataService;
import com.kcc.springjpa.snowflake.service.ImpactorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ImpactorTests {

    @Autowired
    ImpactorService service;

    @Autowired
    ImpactorDao dao;

    @Autowired
    BaseLineDataService baseLineDataService;

    /*
    * Clear data for XX and XY country
    *
    * Test weekly and daily granularity
    *
    * /*
	* has a test for impactors that first cleans up impactors in XX and XY country,
makes an an absolute (non-percentage) impactor in XX country
uses the API to load the impactor and check for specific values
checks adjusted baseline values by calling the api directly (as if a REST request) to check that it is altered by the impactor.
makes an an percentage impactor in XY country
uses the API to load the impactor and check for specific values
checks adjusted baseline values by calling the api directly (as if a REST request) to check that it is altered by the impactor.
The assertions should emit text that is shown on the /api_test page
Notice that after the test is run, the test impactors remain. This allows one to inspect the database and also list the impactor. The test is repeatable since it cleans the slate beforehand.

	* */
    public String run() {
        StringBuilder logBuilder = new StringBuilder();
        try {
            dao.clearTestImpactors("XX");
            dao.clearTestImpactors("XY");

            List<CreateImpactorRequest> requests = new ArrayList<>();
            addTestData(requests);

            for (CreateImpactorRequest r : requests) {
                logBuilder.append("Creating impactor with following parameters").append("<br/>").append(r).append("<br/>");
                StringResponse response = service.createImpactor("Gururaja", r);
                logBuilder.append(response.getResponse()).append("<br/>");

                String[] strings = response.getResponse().split("::");
                String[] string3 = strings[2].split(" ");
                long numberOfRecordsAffected = Long.parseLong(string3[1].trim());

                logBuilder.append("Retrieving impactor ").append(r.impactorName).append("<br/>");
                ImpactorInfoModel m = service.getImpactorInfo(r.impactorName);
                logBuilder.append("Checking impactor value").append("<br/>");
                logBuilder.append("Request.impactorValue == Impactor.value ------ ").append(r.impactorValue == m.absValue).append("<br/>");

                logBuilder.append("Retrieving baselines").append("<br/>");
                List<BaseLineDataModel> baseLineData = baseLineDataService.getBaseLineData(r.country, Collections.singletonList(r.year), r.granularity, r.planLevels, r.customers, r.categories, r.subCategories, r.brands, r.subBrands, r.eans);
                if (baseLineData.isEmpty()) {
                    logBuilder.append("Could not find baseline for the input ").append(r).append("<br/>");
                }
                for (BaseLineDataModel b : baseLineData) {
                    if (r.granularity.equals("weekly")) {
                        if (r.weeks.get(0) == 1) {
                            long s1 = b.statisticalBaseLine.getJanuary().get("W1");
                            if (r.isAbs) {
                                logBuilder.append("Verifying Statistical and Adjusted baseline value for W1 (Absolute) ------ ")
                                        .append(b.adjustedBaseLine.getJanuary().get("W1") == (1 * r.impactorValue / numberOfRecordsAffected)).append("<br/>");
                            } else {
                                logBuilder.append("Verifying Statistical and Adjusted baseline value for W1 (Percentage) ------ ")
                                        .append(b.adjustedBaseLine.getJanuary().get("W1") == (s1 * (1 + (r.impactorValue / numberOfRecordsAffected)))).append("<br/>");
                            }
                        } else if (r.weeks.get(0) == 14) {
                            long s2 = b.statisticalBaseLine.getApril().get("W14");
                            if (r.isAbs) {
                                logBuilder.append("Verifying Statistical and Adjusted baseline value for W14 (Absolute) ------ ")
                                        .append(b.adjustedBaseLine.getApril().get("W14") == s2 + ((1 * r.impactorValue) / numberOfRecordsAffected)).append("<br/>");
                            } else {
                                logBuilder.append("Verifying Statistical and Adjusted baseline value for W14 (Percentage) ------ ")
                                        .append(b.adjustedBaseLine.getApril().get("W14") == (s2 * (1 + (r.impactorValue / numberOfRecordsAffected)))).append("<br/>");
                            }
                        }
                    } else if (r.granularity.equals("daily")) {
                        if (r.days.contains("2020-03-01") || r.days.contains("2020-03-20")) {
                            long s1 = b.statisticalBaseLine.getMarch().get("1");
                            long s2 = b.statisticalBaseLine.getMarch().get("20");
                            if (r.isAbs) {
                                logBuilder.append("Verifying Statistical and Adjusted baseline value for March 1 (Absolute) ------ ")
                                        .append(b.adjustedBaseLine.getMarch().get("1") == s1 + (2 * r.impactorValue / numberOfRecordsAffected)).append("<br/>");
                                logBuilder.append("Verifying Statistical and Adjusted baseline value for March 20 (Absolute) ------ ")
                                        .append(b.adjustedBaseLine.getMarch().get("20") == s2 + (2 * r.impactorValue / numberOfRecordsAffected)).append("<br/>");
                            } else {
                                logBuilder.append("Verifying Statistical and Adjusted baseline value for March 1 (Percentage) ------ ")
                                        .append(b.adjustedBaseLine.getMarch().get("1") == (s1 * (2 + (r.impactorValue / numberOfRecordsAffected)))).append("<br/>");
                                logBuilder.append("Verifying Statistical and Adjusted baseline value for March 20 (Percentage) ------ ")
                                        .append(b.adjustedBaseLine.getMarch().get("20") == (s2 * (2 + (r.impactorValue / numberOfRecordsAffected)))).append("<br/>");
                            }
                        }
                        if (r.days.contains("2020-10-01") || r.days.contains("2020-10-20")) {
                            long s1 = b.statisticalBaseLine.getOctober().get("1");
                            long s2 = b.statisticalBaseLine.getOctober().get("20");
                            if (r.isAbs) {
                                logBuilder.append("Verifying Statistical and Adjusted baseline value for October 1 (Absolute) ------ ")
                                        .append(b.adjustedBaseLine.getOctober().get("1") == s1 + (2 * r.impactorValue / numberOfRecordsAffected)).append("<br/>");
                                logBuilder.append("Verifying Statistical and Adjusted baseline value for October 20 (Absolute) ------ ")
                                        .append(b.adjustedBaseLine.getOctober().get("20") == s2 + (2 * r.impactorValue / numberOfRecordsAffected)).append("<br/>");
                            } else {
                                logBuilder.append("Verifying Statistical and Adjusted baseline value for October 1 (Percentage) ------ ")
                                        .append(b.adjustedBaseLine.getOctober().get("1") == (s1 * (2 + (r.impactorValue / numberOfRecordsAffected)))).append("<br/>");
                                logBuilder.append("Verifying Statistical and Adjusted baseline value for October 20 (Percentage) ------ ")
                                        .append(b.adjustedBaseLine.getOctober().get("20") == (s2 * (2 + (r.impactorValue / numberOfRecordsAffected)))).append("<br/>");
                            }
                        }
                    }
                }
                logBuilder.append("--------------------").append("<br/>");
            }
        } catch (Exception e) {
            logBuilder.append(e.getMessage()).append("<br/>");
        }
        return logBuilder.toString();
    }

    private void addTestData(List<CreateImpactorRequest> requests) {
        CreateImpactorRequest r = new CreateImpactorRequest();
        r.country = "XX";
        r.year = 2022;
        r.granularity = "weekly";
        r.weeks = new ArrayList<>();
        r.weeks.add(1);
        r.impactorName = "OnDemand-Weekly-Not-Absolute";
        r.impactorValue = 20.0f;
        r.isAbs = false;
        r.customers = new ArrayList<>();
        r.customers.add("GLOSER S.A.C.");
        r.categories = new ArrayList<>();
        r.categories.add("Feminine Care");
        r.subCategories = new ArrayList<>();
        r.subCategories.add("FEMININE CARE PADS");
        r.brands = new ArrayList<>();
        r.brands.add("FEMPAD KOTEX");
        r.subBrands = new ArrayList<>();
        r.subBrands.add("FEMPAD KOTEX");
        r.eans = new ArrayList<>();
        r.eans.add("17702425800776-FEM PAD KOT NOR TELA W/W 48X10 CORONA");
        requests.add(r);
        CreateImpactorRequest r1 = new CreateImpactorRequest();
        r1.country = "XX";
        r1.year = 2022;
        r1.granularity = "weekly";
        r1.weeks = new ArrayList<>();
        r1.weeks.add(14);
        r1.impactorName = "OnDemand-Weekly-Absolute";
        r1.impactorValue = 2.0f;
        r1.isAbs = true;
        r1.customers = new ArrayList<>();
        r1.customers.add("PUNTO BLANCO S.A.C.");
        r1.categories = new ArrayList<>();
        r1.categories.add("Feminine Care");
        r1.subCategories = new ArrayList<>();
        r1.subCategories.add("FEMININE CARE PADS");
        r1.brands = new ArrayList<>();
        r1.brands.add("FEMPAD KOTEX");
        r1.subBrands = new ArrayList<>();
        r1.subBrands.add("FEMPAD KOTEX");
        r1.eans = new ArrayList<>();
        r1.eans.add("17702425800776-FEM PAD KOT NOR TELA W/W 48X10 CORONA");
        requests.add(r1);
        CreateImpactorRequest r2 = new CreateImpactorRequest();
        r2.country = "XY";
        r2.year = 2022;
        r2.granularity = "daily";
        r2.days = new ArrayList<>();
        r2.days.add("2020-03-01");
        r2.days.add("2020-03-20");
        r2.impactorName = "OnDemand-Daily-Not-Absolute";
        r2.impactorValue = 2.0f;
        r2.isAbs = false;
        r2.customers = new ArrayList<>();
        r2.customers.add("Test");
        r2.categories = new ArrayList<>();
        r2.categories.add("Test");
        r2.subCategories = new ArrayList<>();
        r2.subCategories.add("Test");
        r2.brands = new ArrayList<>();
        r2.brands.add("Test");
        r2.subBrands = new ArrayList<>();
        r2.subBrands.add("Test");
        r2.eans = new ArrayList<>();
        r2.eans.add("26094563488128-Test Name");
        requests.add(r2);
        CreateImpactorRequest r3 = new CreateImpactorRequest();
        r3.country = "XY";
        r3.year = 2022;
        r3.granularity = "daily";
        r3.days = new ArrayList<>();
        r3.days.add("2020-10-01");
        r3.days.add("2020-10-20");
        r3.impactorName = "OnDemand-Daily-Absolute";
        r3.impactorValue = 2.0f;
        r3.isAbs = true;
        r3.customers = new ArrayList<>();
        r3.customers.add("Test");
        r3.categories = new ArrayList<>();
        r3.categories.add("Test");
        r3.subCategories = new ArrayList<>();
        r3.subCategories.add("Test");
        r3.brands = new ArrayList<>();
        r3.brands.add("Test");
        r3.subBrands = new ArrayList<>();
        r3.subBrands.add("Test");
        r3.eans = new ArrayList<>();
        r3.eans.add("26544158011728-Test Name");
        requests.add(r3);
    }
}
