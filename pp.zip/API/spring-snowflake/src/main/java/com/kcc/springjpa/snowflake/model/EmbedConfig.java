package com.kcc.springjpa.snowflake.model;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class EmbedConfig {
	
	public String reportId;

    public String embedUrl;

    public EmbedToken embedToken;

    public Boolean isEffectiveIdentityRolesRequired = false;

    public Boolean isEffectiveIdentityRequired = false;   

    public String datasetId;

    public Boolean enableRLS = false;

    public String username;

    public String roles;

    public String errorMessage;

}
