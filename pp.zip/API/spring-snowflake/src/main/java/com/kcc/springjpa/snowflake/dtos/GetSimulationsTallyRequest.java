package com.kcc.springjpa.snowflake.dtos;

import java.util.List;

public class GetSimulationsTallyRequest {
	
	public List<Double> profitLoss;
	
	public List<Double> totalInvestment;

}
