package com.kcc.springjpa.snowflake.repository;

import com.kcc.springjpa.snowflake.entity.OwnCrossCategory;
import com.kcc.springjpa.snowflake.model.CrossOwnView;
import net.snowflake.client.jdbc.internal.amazonaws.util.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;

@Repository
@Transactional
public interface OwnCrossCategoryRepository extends JpaRepository<OwnCrossCategory, Integer> {

    default List<CrossOwnView> findByInitials(String country, String scope, String source, String flag) {
        List<CrossOwnView> views = new ArrayList<>();
        Specification<OwnCrossCategory> spec = OwnCrossCategoryRepository.InitialSpecs.findBySubCategoryFilter(country, scope, source, flag);
        List<OwnCrossCategory> items = findAll(spec);
        for(OwnCrossCategory d : items) {
            CrossOwnView v = new CrossOwnView();
            v.category = d.getCategory();
            views.add(v);
        }
        return views;
    }

    class InitialSpecs {

        public static Specification<OwnCrossCategory> findBySubCategoryFilter(String country, String scope, String source, String flag) {
            return (root, query, builder) -> {
                Predicate result = builder.equal(root.get("country"), country);
                result = builder.and(result, root.get("flag").in(flag));
                if (StringUtils.isNullOrEmpty(scope)) {
                    if (source != null) {
                        result = builder.and(result, root.get("source").in(source));
                    }
                } else if (StringUtils.isNullOrEmpty(source)) {
                    result = builder.and(result, root.get("type").in(scope));
                } else {
                    result = builder.and(result, root.get("type").in(scope));
                    result = builder.and(result, root.get("source").in(source));
                }
                return result;
            };
        }
    }

    List<OwnCrossCategory> findAll(Specification<OwnCrossCategory> s);
}
