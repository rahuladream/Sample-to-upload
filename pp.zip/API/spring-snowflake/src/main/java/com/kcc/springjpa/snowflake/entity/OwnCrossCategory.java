package com.kcc.springjpa.snowflake.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "V_RGM_SLS_FCT_DATA_CROSS_OWN_CATEGORY", schema = "REPORTING")
@IdClass(value = OwnCrossCategoryKey.class)
@Getter
@Setter
public class OwnCrossCategory {

    @Column(name = "COUNTRY")
    private String country;

    @Column(name = "SOURCE")
    private String source;

    @Column(name = "TYPE")
    private String type;

    @Id
    @Column(name = "TYPE_DESCRIPTON")
    private String typeDescription;

    @Id
    @Column(name = "CATEGORY")
    private String category;

    @Column(name = "SLOPE")
    private Float slope;

    @Column(name = "INTERCEPT")
    private Float intercept;

    @Column(name = "R_SQUARED_AVG")
    private Float rSquaredAvg;

    @Column(name = "R_SQUARED_BASE")
    private Float rSquaredBase;

    @Column(name = "R_SQUARED_PROMO")
    private Float rSquaredPromo;

    @Column(name = "ELASTICITY_AVG_PRICE")
    private Float elasticityAvgPrice;

    @Column(name = "ELASTICITY_BASE_PRICE")
    private Float elasticityBasePrice;

    @Column(name = "ELASTICITY_PROMO_PRICE")
    private Float elasticityPromoPrice;

    @Column(name = "P_VALUE")
    private Float pValue;

    @Column(name = "AVG_QTY")
    private Float avgQty;

    @Column(name = "AVG_QTY_PROMO")
    private Float avgQtyPromo;

    @Column(name = "AVG_QTY_BASE")
    private Float avgQtyBase;

    @Column(name = "PRICE_INDEX_AVG")
    private Float priceIndexAvg;

    @Column(name = "PRICE_INDEX_PROMO")
    private Float priceIndexPromo;

    @Column(name = "PRICE_INDEX_BASE")
    private Float priceIndexBase;

    @Column(name = "CORR_AVG")
    private Float corrAvg;

    @Column(name = "CORR_PROMO")
    private Float corrPromo;

    @Column(name = "CORR_BASE")
    private Float corBase;

    @Column(name = "FLAG")
    private String flag;

    @Column(name = "N_WEEKS")
    public int nWeeks;

    @Column(name = "PERIOD_BEGIN")
    public String periodBegin;

    @Column(name = "PERIOD_END")
    public String periodEnd;

    @Column(name = "MODEL_RUN")
    public String modelRun;
}
