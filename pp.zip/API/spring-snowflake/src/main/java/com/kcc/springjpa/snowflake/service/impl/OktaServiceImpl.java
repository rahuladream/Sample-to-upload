package com.kcc.springjpa.snowflake.service.impl;

import java.time.Duration;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.kcc.springjpa.snowflake.model.OktaApiAuthenticator;
import com.kcc.springjpa.snowflake.service.OktaService;
import com.kcc.springjpa.snowflake.utility.StringResponse;
import com.kcc.springjpa.snowflake.utility.TokenGenerator;
import com.okta.jwt.AccessTokenVerifier;
import com.okta.jwt.Jwt;
import com.okta.jwt.JwtVerifiers;

@Service
public class OktaServiceImpl implements OktaService {

	private static final Logger logger = LogManager.getLogger(OktaServiceImpl.class);

	@Value("${okta.issuer.url}")
	private String issuerUrl;

	@Value("${okta.client.id}")
	private String clientId;

	@Value("${okta.client.audience}")
	private String audience;

	@Override
	public StringResponse validateAccessToken(String accessToken) throws Exception {

		logger.info("Calling OKTA API to validate access token----->");
		Jwt jwt = this.oktaJwtValidate(accessToken, audience);
		String response = "";
		if (jwt != null) {
			logger.info(jwt.getTokenValue()); // print the token
			logger.info(jwt.getClaims().get("invalidKey")); // an invalid key just returns null
			logger.info(jwt.getClaims().get("groups")); // handle an array value
			logger.info(jwt.getExpiresAt()); // print the expiration time

			response = jwt.getClaims().get("jti") + "  : " + jwt.getExpiresAt() + "  : " + jwt.getIssuedAt();
			logger.info(response);
		}

		StringResponse sr = new StringResponse();
		if (response.isEmpty()) {
			sr.setResponse("Invalid Token");
		} else {
			sr.setResponse(response);
		}
		return sr;
	}

	@Override
	public StringResponse validateIdToken(String idToken) throws Exception {

		logger.info("Calling OKTA API to validate ID token----->");
		Jwt jwt = this.oktaJwtValidate(idToken, clientId);
		String response = "";
		if (jwt != null) {
			logger.info(jwt.getTokenValue()); // print the token
			logger.info(jwt.getClaims().get("invalidKey")); // an invalid key just returns null
			logger.info(jwt.getClaims().get("groups")); // handle an array value
			logger.info(jwt.getExpiresAt()); // print the expiration time

			response = jwt.getClaims().get("jti") + "  : " + jwt.getExpiresAt() + "  : " + jwt.getIssuedAt();
			logger.info(response);
		}

		StringResponse sr = new StringResponse();
		if (response.isEmpty()) {
			sr.setResponse("Invalid Token");
		} else {
			sr.setResponse(response);
		}
		return sr;
	}

	private Jwt oktaJwtValidate(String token, String aud) {

		try {

			// 1. build the parser
			AccessTokenVerifier jwtVerifier = JwtVerifiers.accessTokenVerifierBuilder().setIssuer(issuerUrl)
					.setAudience(aud).setConnectionTimeout(Duration.ofSeconds(1)) // defaults to 1000ms
					.setRetryMaxAttempts(2) // defaults to 2
					.setRetryMaxElapsed(Duration.ofSeconds(10)) // defaults to 10s
					.build();

			// 2. Process the token (includes validation)
			Jwt jwt = jwtVerifier.decode(token);

			// 3. Do something with the token
			logger.info(jwt.getTokenValue()); // print the token
			logger.info(jwt.getClaims().get("invalidKey")); // an invalid key just returns null
			logger.info(jwt.getClaims().get("groups")); // handle an array value
			logger.info(jwt.getExpiresAt()); // print the expiration time

			String body = jwt.getClaims().get("sub") + "  : " + jwt.getExpiresAt() + "  : " + jwt.getIssuedAt();
			logger.info(body);

			StringResponse sr = new StringResponse();
			sr.setResponse(body);
			return jwt;

		} catch (Exception e) {
			logger.error(e);
			logger.error(e.getMessage());
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public OktaApiAuthenticator generateAuthenticateToken(String accessToken, String idToken) throws Exception {

		logger.info("Calling OKTA API to validate access token----->");
		Jwt accessjwt = this.oktaJwtValidate(accessToken, audience);

		logger.info("Calling OKTA API to validate ID token----->");
		Jwt idjwt = this.oktaJwtValidate(idToken, clientId);

		String jwtToken = "";
		ArrayList<String> groups = null;
		if (idjwt != null && accessjwt != null) {
			logger.info(idjwt.getTokenValue()); // print the token
			logger.info(idjwt.getClaims().get("invalidKey")); // an invalid key just returns null
			logger.info(idjwt.getClaims().get("groups")); // handle an array value
			logger.info(idjwt.getExpiresAt()); // print the expiration time
			
			groups = (ArrayList<String>) idjwt.getClaims().get("groups");
			jwtToken = TokenGenerator.jwtToken((String)idjwt.getClaims().get("name"), (String)idjwt.getClaims().get("username"), groups);
			logger.info("Generated JWT Token::::: " + jwtToken);
		}

		StringResponse sr = new StringResponse();
		OktaApiAuthenticator oktaValidator = new OktaApiAuthenticator();
		if (jwtToken.isEmpty()) {
			sr.setResponse("Invalid Token");
		} else {
			oktaValidator.setJwtToken(jwtToken);
			oktaValidator.setGroups(groups);
		}
		return oktaValidator;
	}

}
