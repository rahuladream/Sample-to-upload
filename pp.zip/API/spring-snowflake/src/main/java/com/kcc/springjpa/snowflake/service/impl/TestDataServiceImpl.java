package com.kcc.springjpa.snowflake.service.impl;

import com.kcc.springjpa.snowflake.configuration.DBConfig;
import com.kcc.springjpa.snowflake.model.TestData;
import com.kcc.springjpa.snowflake.service.TestDataService;
import com.kcc.springjpa.snowflake.utility.TestQueryUtility;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Repository
public class TestDataServiceImpl implements TestDataService {

    @Autowired
    DBConfig dbConfig;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<TestData> runDataTests() {
        List<TestData> results = new ArrayList<TestData>();
        try {
            TestData promoData =  executeDataTest(TestQueryUtility.getPromoTypes());
            results.add(promoData);

            TestData data2 =  executeDataTest(TestQueryUtility.getVarietiesOfOwnEanType());
            results.add(data2);

            TestData data3  =  executeDataTest(TestQueryUtility.getVarietiesOfOwnEanFlag());
            results.add(data3);

            TestData data4 =  executeDataTest(TestQueryUtility.getVarietiesOfOwnEanCountry());
            results.add(data4);

            TestData data5 = executeDataTest(TestQueryUtility.getDataSourcesInPostROI());
            results.add(data5);

            TestData data6 = executeDataTest(TestQueryUtility.getCurrentActiveBaselineModelRuns());
            results.add(data6);

            TestData data7 = executeDataTest(TestQueryUtility.assertNoNegativeAdjustedBaselineValues());
            results.add(data7);

            TestData data8 = executeDataTest(TestQueryUtility.getCountOfOwnElasticityAtEanLevelForAllMarketScope());
            results.add(data8);

            TestData data9 = executeDataTest(TestQueryUtility.getCountOfOwnElasticityAtEanLevelForCustomerMarketScope());
            results.add(data9);

            TestData data10 = executeDataTest(TestQueryUtility.getCountOfOwnElasticityAtEanLevelForChannelMarketScope());
            results.add(data10);

            TestData data11 = executeDataTest(TestQueryUtility.getCountOfCrossElasticityAtEanLevelForAllMarketScope());
            results.add(data11);

            TestData data12 = executeDataTest(TestQueryUtility.getCountOfCrossElasticityAtEanLevelForCustomerMarketScope());
            results.add(data12);

            TestData data13 = executeDataTest(TestQueryUtility.getCountOfCrossElasticityAtEanLevelForChannelMarketScope());
            results.add(data13);

            TestData data14 = executeDataTest(TestQueryUtility.getCategoryLevelElasticityByCountryAndMarketScope());
            results.add(data14);

            TestData data15 = executeDataTest(TestQueryUtility.getBrandLevelElasticityByCountryAndMarketScope());
            results.add(data15);

            TestData data16 = executeDataTest(TestQueryUtility.getSubBrandLevelElasticityByCountryAndMarketScope());
            results.add(data16);

            TestData data17 = executeDataTest(TestQueryUtility.getPackLevelElasticityByCountryAndMarketScope());
            results.add(data17);

            TestData data18 = executeDataTest(TestQueryUtility.getEanLevelElasticityByCountryAndMarketScope());
            results.add(data18);

            TestData data19 = executeDataTest(TestQueryUtility.getSelloutBaselineRecordsByCountry());
            results.add(data19);

            TestData data20 = executeDataTest(TestQueryUtility.getSellInBaselineRecordsByCountry());
            results.add(data20);

            TestData data21 = executeDataTest(TestQueryUtility.getHistoryOfModelRunsInBaseline());
            results.add(data21);

            TestData data22 = executeDataTest(TestQueryUtility.assertNoCountryHaveMoreThanOneModelRunActive());
            results.add(data22);

            TestData data23 = executeDataTest(TestQueryUtility.assertThereShouldBeNoDuplicateBaselineRecords());
            results.add(data23);

            TestData data24 = executeDataTest(TestQueryUtility.assertThereShouldBeNoDuplicateAdjustedBaselineRecords());
            results.add(data24);


            return  results;
        }catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    TestData executeDataTest(TestData testData) throws SQLException {
        Connection conn = dbConfig.getJdbcConnection();
        if (conn != null) {
            try {
                Statement stat = conn.createStatement();
                ResultSet resultSet = stat.executeQuery(testData.query);

                List<Map<String,Object>> jsonArray = new ArrayList<Map<String,Object>>();
                while (resultSet.next()) {
                    Map<String,Object> obj = new HashMap<String,Object>();
                    int total_rows = resultSet.getMetaData().getColumnCount();
                    for (int i = 0; i < total_rows; i++) {
                        obj.put(resultSet.getMetaData().getColumnLabel(i + 1)
                                .toLowerCase(), resultSet.getObject(i + 1));

                    }
                    jsonArray.add(obj);
                }
                testData.result = jsonArray;
                return testData;

            } catch (SQLException e) {
                testData.error  = e.toString();
                e.printStackTrace();
                return testData;
            } finally {
                conn.close();
            }
        }
        return null;
    }
}
