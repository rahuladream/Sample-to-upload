package com.kcc.springjpa.snowflake.entity;

import java.io.Serializable;
import java.util.Objects;

public class OwnCrossSubCategoryKey implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public int hashCode() {
		return Objects.hash(initialSubCategory, targetSubCategory, type, typeDescription);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OwnCrossSubCategoryKey other = (OwnCrossSubCategoryKey) obj;
		return Objects.equals(initialSubCategory, other.initialSubCategory)
				&& Objects.equals(targetSubCategory, other.targetSubCategory) && Objects.equals(type, other.type)
				&& Objects.equals(typeDescription, other.typeDescription);
	}

	private String initialSubCategory;
	
	private String targetSubCategory;
	
	private String type;
	
	private String typeDescription;

}
