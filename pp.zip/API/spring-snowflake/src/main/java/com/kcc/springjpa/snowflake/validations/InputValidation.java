package com.kcc.springjpa.snowflake.validations;

import com.kcc.springjpa.snowflake.exception.InvalidCustomerNameException;

public interface InputValidation {
    public boolean validate(Object object) throws Exception;
}
