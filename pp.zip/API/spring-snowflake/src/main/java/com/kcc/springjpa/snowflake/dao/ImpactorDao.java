package com.kcc.springjpa.snowflake.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.kcc.springjpa.snowflake.model.ImpactorHistoryModel;
import com.kcc.springjpa.snowflake.model.ImpactorInfoModel;

public interface ImpactorDao {

	public String findImpactorByName(String name) throws SQLException;
	
	public List<String> getImpactorNamesInOrder(String country, boolean deleted) throws SQLException;
	
	public Map<String, ImpactorHistoryModel> getImpactorHistory(String country, boolean deleted, String granularity) throws SQLException;
	
	public ImpactorInfoModel getImpactorInfo(String impactorName) throws SQLException;

	public int deleteImpactor(String deletedBy, String impactorName) throws SQLException;
	
	public int createImpactorMeta(String createdBy, String impactorName, boolean isAbs, float impactorValue, String country, String description) throws SQLException;
	
	public int createImpactorData(String country, Integer year, List<String> planLevels,
								  List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
								  List<String> subBrands, List<String> eans, String impactorName, List<Integer> weeks, boolean forDaily, Map<Integer, List<Integer>> daysForMonth) throws SQLException;
	
	public int applyImpactorNotAbs(String impactorName, float value, String country, boolean forDaily) throws SQLException;
	
	public int applyImpactorAbs(int numberOfRecords, int numberOfWeeksOrDays, String impactorName, float value, String country, boolean forDaily) throws SQLException;

	public int undoImpactorAfterDelete(float absValue, String impactorName, String country, boolean isAbs) throws SQLException;

	public Map<String, Float> minimumAdjustmentValue(String country, Integer year, List<String> planLevels, List<String> customers,
			List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands,
			List<String> eans, List<Integer> weeks) throws SQLException;

	void clearTestImpactors(String country) throws Exception;

	public Set<String> getNewBaselineLoads() throws SQLException;

	public void loadNewBaselineDataLoads(String country) throws SQLException;

	public void updateAdjustmentLogRecords() throws SQLException;
}
