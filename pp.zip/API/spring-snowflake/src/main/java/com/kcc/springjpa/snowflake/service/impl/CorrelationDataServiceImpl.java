package com.kcc.springjpa.snowflake.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.kcc.springjpa.snowflake.entity.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kcc.springjpa.snowflake.repository.OwnCrossBrandRepository;
import com.kcc.springjpa.snowflake.repository.OwnCrossEanRepository;
import com.kcc.springjpa.snowflake.repository.OwnCrossPackRepository;
import com.kcc.springjpa.snowflake.repository.OwnCrossSubCategoryRepository;
import com.kcc.springjpa.snowflake.repository.OwnCrossSubbrandRepository;
import com.kcc.springjpa.snowflake.service.CorrelationDataService;
import com.kcc.springjpa.snowflake.utility.EanUtility;
import com.kcc.springjpa.snowflake.utility.HierarchyLevel;

@Service
public class CorrelationDataServiceImpl implements CorrelationDataService {
	
	private static final Logger logger = LogManager.getLogger(CorrelationDataServiceImpl.class);

	// Category --> SubCategory --> Manufacturer --> Brand --> SubBrand --> Tier -->
			// Pack --> EAN - Description

	@Autowired
	OwnCrossEanRepository ownCrossEanRepository;
	
	@Autowired
	OwnCrossPackRepository ownCrossPackRepository;
	
	@Autowired
	OwnCrossSubbrandRepository ownCrossSubbrandRepository;
	
	@Autowired
	OwnCrossBrandRepository ownCrossBrandRepository;
	
	@Autowired
	OwnCrossSubCategoryRepository ownCrossSubCategoryRepository;

	@Override
	public Map<String, Map<String, String>> getCorrelationAnalysis(String country, List<String> initialLeafValues,
																   List<String> targetLeafValues, String levelIndicator, String scope) {
		
		logger.info("Snowflake Call to get the Correlation Values from given KC and Target Products");
		Map<String, Map<String, String>> map = new HashMap<>();

		if (levelIndicator.equals(HierarchyLevel.CATEGORY)) {
			// Not expected to get this Hierarchy Level
		} else if (levelIndicator.equals(HierarchyLevel.SUB_CATEGORY)) {
			List<OwnCrossSubCategoryData> ownCrossSubCategoryData = ownCrossSubCategoryRepository
					.findAllByCountryAndFlagAndTypeAndInitialSubCategoryInAndTargetSubCategoryIn(country, HierarchyLevel.CROSS, scope.toUpperCase(), initialLeafValues, targetLeafValues);
			logger.info("FIND CROSS ELASTICITY ANALYSIS BY SUB_CATEGORY INTIAL AND SUB_CATEGORY TARGET---------------" + ownCrossSubCategoryData.size());
			for (OwnCrossSubCategoryData ocData : ownCrossSubCategoryData) {
				String customerName = ocData.getTypeDescription();
				if(customerName == null || customerName.isEmpty()) {
					continue;
				}
				Map<String, String> coefficientPairs = map.computeIfAbsent(customerName, k -> new HashMap<>());
				coefficientPairs.put(this.formKeyHierarchyLevel(ocData.getInitialSubCategory(), ocData.getTargetSubCategory()), ocData.getCorrAvg().toString());
			}
		} else if (levelIndicator.equals(HierarchyLevel.MANUFACTURER)) {
			// Not expected to get this Hierarchy Level
		} else if (levelIndicator.equals(HierarchyLevel.BRAND)) {
			List<OwnCrossBrandData> ownCrossBrandData = ownCrossBrandRepository
					.findAllByCountryAndFlagAndTypeAndInitialBrandInAndTargetBrandIn(country, HierarchyLevel.CROSS, scope.toUpperCase(), initialLeafValues, targetLeafValues);
			logger.info("FIND CROSS ELASTICITY ANALYSIS BY BRAND INTIAL AND BRAND TARGET---------------"
					+ ownCrossBrandData.size());
			for (OwnCrossBrandData ocData : ownCrossBrandData) {
				String customerName = ocData.getTypeDescription();
				if(customerName == null || customerName.isEmpty()) {
					continue;
				}
				Map<String, String> coefficientPairs = map.computeIfAbsent(customerName, k -> new HashMap<>());
				coefficientPairs.put(this.formKeyHierarchyLevel(ocData.getInitialBrand(), ocData.getTargetBrand()), ocData.getCorrAvg().toString());
			}
		} else if (levelIndicator.equals(HierarchyLevel.SUB_BRAND)) {
			List<OwnCrossSubbrandData> ownCrossSubbrandData = ownCrossSubbrandRepository
					.findAllByCountryAndFlagAndTypeAndInitialSubBrandInAndTargetSubBrandIn(country, HierarchyLevel.CROSS, scope.toUpperCase(), initialLeafValues, targetLeafValues);
			logger.info("FIND CROSS ELASTICITY ANALYSIS BY SUB_BRAND INTIAL AND SUB_BRAND TARGET---------------"
					+ ownCrossSubbrandData.size());
			for (OwnCrossSubbrandData ocData : ownCrossSubbrandData) {
				String customerName = ocData.getTypeDescription();
				if(customerName == null || customerName.isEmpty()) {
					continue;
				}
				Map<String, String> coefficientPairs = map.computeIfAbsent(customerName, k -> new HashMap<>());
				coefficientPairs.put(this.formKeyHierarchyLevel(ocData.getInitialSubBrand(), ocData.getTargetSubBrand()), ocData.getCorrAvg().toString());
			}
		} else if (levelIndicator.equals(HierarchyLevel.TIER)) {
			// Not expected to get this Hierarchy Level
		} else if (levelIndicator.equals(HierarchyLevel.PACK)) {
			List<OwnCrossPackData> ownCrossPackData = ownCrossPackRepository
					.findAllByCountryAndFlagAndTypeAndInitialPackInAndTargetPackIn(country, HierarchyLevel.CROSS, scope.toUpperCase(), initialLeafValues, targetLeafValues);
			logger.info("FIND CROSS ELASTICITY ANALYSIS BY PACK INTIAL AND PACK TARGET---------------"
					+ ownCrossPackData.size());
			for (OwnCrossPackData ocData : ownCrossPackData) {
				String customerName = ocData.getTypeDescription();
				if(customerName == null || customerName.isEmpty()) {
					continue;
				}
				Map<String, String> coefficientPairs = map.computeIfAbsent(customerName, k -> new HashMap<>());
				coefficientPairs.put(this.formKeyHierarchyLevel(ocData.getInitialPack(), ocData.getTargetPack()), ocData.getCorrAvg().toString());
			}
		} else if (levelIndicator.equals(HierarchyLevel.EAN)) {
			List<OwnCrossData> ownCrossData = ownCrossEanRepository
					.findAllByCountryAndFlagAndTypeAndEanInitialInAndEanTargetIn(country, HierarchyLevel.CROSS, scope.toUpperCase(),
							EanUtility.getEanNumbersFromDescriptions(initialLeafValues), EanUtility.getEanNumbersFromDescriptions(targetLeafValues));
			logger.info(
					"FIND CROSS ELASTICITY ANALYSIS BY EAN INTIAL AND EAN TARGET---------------" + ownCrossData.size());
			for (OwnCrossData ocData : ownCrossData) {
				String customerName = ocData.getTypeDescription();
				if(customerName == null || customerName.isEmpty()) {
					continue;
				}
				Map<String, String> coefficientPairs = map.computeIfAbsent(customerName, k -> new HashMap<>());
				coefficientPairs.put(this.formKeyHierarchyLevel(ocData.getEanInitial(), ocData.getEanTarget()), ocData.getCorrAvg().toString());
			}
		}
		return map;
	}
	
	private String formKeyHierarchyLevel(String initialLeafValue, String targetLeafValue) {
		return initialLeafValue + ":" + targetLeafValue;
	}
}
