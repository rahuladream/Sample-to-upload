package com.kcc.springjpa.snowflake.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@IdClass(RoiKey.class)
@Table(name = "V_RGM_SLS_FCT_DATA_POST_ROI", schema = "REPORTING")
@Getter
@Setter
public class PostRoiData {

	@Column(name = "COUNTRY")
	private String country;

	@Column(name = "CATEGORY")
	private String category;

	@Column(name = "SUB_CATEGORY")
	private String subCategory;
	
	@Column(name = "BRAND")
	private String brand;

	@Column(name = "SUB_BRAND")
	private String subBrand;
	
	@Column(name = "PLAN_LEVEL")
	private String planLevel;
	
	@Column(name = "SOLD_TO")
	private String soldTo;

	@Id
	@Column(name = "SOLD_TO_DESC")
	private String soldToDesc;

	@Id
	@Column(name = "EAN")
	private String ean;

	@Id
	@Column(name = "WEEK")
	private Integer week;
	
	@Column(name = "MONTH")
	private Integer month;
	
	@Column(name = "YEAR")
	private Integer year;
	
	@Column(name = "EVENT_ID")
	private String eventId;
	
	@Column(name = "BASELINE_VOLUME")
	private double baselineVolume;

	@Column(name = "ACTUAL_VOLUME")
	private double actualVolumeCase;

	@Column(name = "ACTUAL_VOLUME_SU")
	private double actualVolumeSU;

	@Column(name = "COGS_PER_CASE")
	private Float cogsPerCase;

	@Column(name = "COGS_PER_SU")
	private double cogsPerSU;

	@Column(name = "NPP_PER_CASE")
	private Float nppPerCase;

	@Column(name = "NPP_PER_SU")
	private String nppPerSU;

	@Column(name = "PROMO_INVESTMENT")
	private double promoInvestment;

	@Column(name = "BASELINE_PROFIT")
	private double baselineProfitCase;

	@Column(name = "BASELINE_PROFIT_SU")
	private double baselineProfitSU;

	@Column(name = "PROMO_PROFIT")
	private double promoProfitCase;

	@Column(name = "PROMO_PROFIT_SU")
	private double promoProfitSU;

	@Column(name = "NET_PROFIT")
	private double netProfitCase;

	@Column(name = "NET_PROFIT_SU")
	private double netProfitSU;

	@Column(name = "TIER")
	private String tier;

	@Column(name = "TACTIC_TYPE")
	private String tacticType;

	@Column(name = "ROLL")
	private String roll;

	@Column(name = "PACK")
	private String pack;

	@Column(name = "SIZE")
	private String size;

	@Column(name = "DATA_SOURCE") // Can either be Sell in or sell out
	private String dataSource;

	@Column(name = "DAY")
	private Integer day;

	@Column(name = "SALES_OFFICE")
	private String salesOffice;

	@Column(name= "RETAILER_MARGIN")
	private double retailerMarginCase;

	@Column(name = "RETAILER_MARGIN_SU")
	private double retailerMarginSU;

	@Column(name= "RETAILER_MARGIN_PCT")
	private double retailerMarginPercentCase;

	@Column(name = "RETAILER_MARGIN_PCT_SU")
	private double retailerMarginPercentSU;

	@Column(name = "MECHANIC")
	private String mechanic;

	@Column(name = "DURATION")
	private long duration;

	@Column(name = "FEATURE")
	private String feature;

	@Column(name = "PRICE_POINT")
	private Float pricePointCase;

	@Column(name = "PRICE_POINT_SU")
	private Float pricePointSU;
}
