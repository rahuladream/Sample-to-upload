package com.kcc.springjpa.snowflake.configuration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class DBConfig {
	
	private static final Logger logger = LogManager.getLogger(DBConfig.class);
	
	@Value("${spring.datasource.url}")
	private String jdbcUrl;
	
	@Value("${spring.datasource.username}")
	private String dbUser;
	
	@Value("${spring.datasource.password}")
	private String dbPass;

//    @Bean
//    JdbcTemplate jdbcTemplate() throws IllegalAccessException, InvocationTargetException, InstantiationException {
//        logger.info("-----Configuring JDBCTemplate------");
//
//        HikariConfig config = new HikariConfig();
//        config.setDriverClassName("net.snowflake.client.jdbc.SnowflakeDriver");
//        // config.setDataSourceProperties(properties);
//        config.setJdbcUrl(jdbcUrl);
//        config.setUsername(dbUser);
//        config.setPassword(dbPass);
//        HikariDataSource ds = new HikariDataSource(config);
//
//        return new JdbcTemplate(ds);
//    }
    
    public Connection getJdbcConnection() {
    	//String url = "jdbc:snowflake://<account_identifier>.snowflakecomputing.com";
	    Properties prop = new Properties();
	    prop.put("user", dbUser);
	    prop.put("password", dbPass);
	    //prop.put("privateKey", PrivateKeyReader.get(PRIVATE_KEY_FILE));
	   // prop.put("db", "<database_name>");
	   // prop.put("schema", "<schema_name>");
	   // prop.put("warehouse", "<warehouse_name>");
	   // prop.put("role", "<role_name>");

	    Connection connection = null;
	    try {
	    	connection = DriverManager.getConnection(jdbcUrl, prop);
		} catch (SQLException e) {
			logger.error("Exception occured while creating a JDBC connection to Database :: ");
			logger.info(e.getMessage());
			e.printStackTrace();
		}
		return connection;
    }

}
