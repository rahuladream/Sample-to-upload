package com.kcc.springjpa.snowflake.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CrossOwnView {

    public String country;
    public String type;
    public String source;
    public String category;
    public String customer;
    public double pValue;
    public long volume;
    public String initialManufacturer;
    public String targetManufacturer;
    public String subCategory;
    public String initialSubCategory;
    public String targetSubCategory;
    public String initialBrand;
    public String targetBrand;
    public String initialSubBrand;
    public String targetSubBrand;
    public String initialPack;
    public String targetPack;
    public String eanInitial;
    public String eanTarget;
    public String initialTier;
    public String targetTier;
    public String eanDescriptionInitial;
    public String eanDescriptionTarget;
}
