package com.kcc.springjpa.snowflake.dtos;

import com.kcc.springjpa.snowflake.entity.PostRoiGroup;

import java.util.List;

public class PostRoiQueryResult {

    public List<PostRoiGroup> postRoiGroups;

    public List<PostRoiGroup> retailerMarginPercentages;

    public PostRoiQueryResult(List<PostRoiGroup> postRoiGroups, List<PostRoiGroup> retailerMarginPercentages) {
        this.postRoiGroups = postRoiGroups;
        this.retailerMarginPercentages = retailerMarginPercentages;
    }
}
