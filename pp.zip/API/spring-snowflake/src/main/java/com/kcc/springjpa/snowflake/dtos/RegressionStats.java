package com.kcc.springjpa.snowflake.dtos;

public class RegressionStats {

    public long slopeIntegral;
    public double slopeDecimal;
    public long interceptIntegral;
    public double interceptDecimal;

    public double rSquared;

    public long elasticityIntegral;
    public double elasticityDecimal;
}
