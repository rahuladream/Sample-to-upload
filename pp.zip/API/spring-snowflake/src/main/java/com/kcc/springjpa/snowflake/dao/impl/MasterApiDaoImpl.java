package com.kcc.springjpa.snowflake.dao.impl;

import com.kcc.springjpa.snowflake.configuration.DBConfig;
import com.kcc.springjpa.snowflake.dao.MasterApiDao;
import com.kcc.springjpa.snowflake.dtos.CountryMaster;
import com.kcc.springjpa.snowflake.dtos.ProductLocator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class MasterApiDaoImpl implements MasterApiDao {

    @Autowired
    DBConfig dbConfig;

    private final List<String> viewsToQuery = Arrays.asList("SUB_CATEGORY", "BRAND", "SUB_BRAND", "PACK", "EAN", "CATEGORY");

    @Override
    public CountryMaster getCountryMaster(String country) throws Exception {
        CountryMaster m = new CountryMaster();
        m.country = country;
        m.productLocators = new ArrayList<>();

        try (Connection c = dbConfig.getJdbcConnection()) {
            for (String v : viewsToQuery) {
                String viewPrefix = "RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_";
                String view = viewPrefix + v;
                String sql = "SELECT DISTINCT type, source, flag FROM viewName WHERE country = ?";
                sql = sql.replace("viewName", view);
                PreparedStatement s = c.prepareStatement(sql);
                s.setString(1, country);
                ResultSet rs = s.executeQuery();
                while (rs.next()) {
                    ProductLocator p = new ProductLocator();
                    p.name = v;
                    p.scope = rs.getString(1);
                    p.source = rs.getString(2);
                    p.flag = rs.getString(3);

                    m.productLocators.add(p);
                }
            }
        } catch (SQLException e) {
            throw new Exception("Could not retrieve master data", e);
        }
        return m;
    }
}
