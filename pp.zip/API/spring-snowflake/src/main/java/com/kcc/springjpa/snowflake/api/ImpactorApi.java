package com.kcc.springjpa.snowflake.api;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.kcc.springjpa.snowflake.dtos.CreateImpactorRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.kcc.springjpa.snowflake.entity.Customer;
import com.kcc.springjpa.snowflake.model.ImpactorData;
import com.kcc.springjpa.snowflake.model.ImpactorHistoryModel;
import com.kcc.springjpa.snowflake.model.ImpactorInfoModel;
import com.kcc.springjpa.snowflake.utility.StringResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "impactor", description = "IMPACTOR API")
public interface ImpactorApi {
	
	@ApiOperation(value = "", response = List.class, tags = { "Impactors", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Impactor Names", response = List.class) })
	@RequestMapping(value = "/getImpactorNames", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<List<String>> getImpactorNames() throws Exception;
	
	@ApiOperation(value = "", response = ImpactorData.class, tags = { "Impactors", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Impactor History", response = ImpactorData.class) })
	@RequestMapping(value = "/getImpactorHistory", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<Map<String, ImpactorHistoryModel>> getImpactorHistory(@RequestParam(value = "country") String country,
																		 @RequestParam(value = "granularity") String granularity) throws Exception;
	
	@ApiOperation(value = "", response = ImpactorData.class, tags = { "Impactors", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Deleted Impactor History", response = ImpactorData.class) })
	@RequestMapping(value = "/getDeletedImpactorHistory", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<Map<String, ImpactorHistoryModel>> getDeletedImpactorHistory(@RequestParam(value = "country", required = true) String country,
																				@RequestParam(value = "granularity") String granularity) throws Exception;
	
	@ApiOperation(value = "", response = ImpactorInfoModel.class, tags = { "Impactors", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Get Impactor Info", response = ImpactorInfoModel.class) })
	@RequestMapping(value = "/getImpactorInfo", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<ImpactorInfoModel> getImpactorInfo(@RequestParam(value = "impactorName", required = true) String impactorName) throws Exception;
	
	@ApiOperation(value = "", response = StringResponse.class, tags = { "Impactors", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "A successful Impactor record deleted", response = StringResponse.class) })
	@RequestMapping(value = "/admin/deleteImpactor", produces = { "application/json" }, method = RequestMethod.DELETE)
	ResponseEntity<StringResponse> deleteImpactor(HttpServletRequest request, @RequestParam(value = "name") String impactorName,
			@RequestParam(value = "country") String country) throws Exception;
	
	@ApiOperation(value = "", response = Customer.class, tags = { "Impactors", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "A successful Impactor created", response = StringResponse.class) })
	@RequestMapping(value = "/admin/createImpactor", produces = { "application/json" }, method = RequestMethod.POST)
	ResponseEntity<StringResponse> createImpactor(HttpServletRequest request, @RequestBody CreateImpactorRequest createRequest) throws Exception;
	
	@ApiOperation(value = "", response = Customer.class, tags = { "Impactors", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "A successful Impactor created", response = Map.class) })
	@RequestMapping(value = "/getMinAdjustmentValue", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<Map<String, Float>> getMinimumAdjustmentValue(@RequestParam(value = "country", required = true) String country,
			@RequestParam(value = "year", required = true) Integer year,
			@RequestParam(value = "planLevels", required = false) List<String> planLevels,
			@RequestParam(value = "customers", required = false) List<String> customers,
			@RequestParam(value = "categories", required = false) List<String> categories,
			@RequestParam(value = "subCategories", required = false) List<String> subCategories,
			@RequestParam(value = "brands", required = false) List<String> brands,
			@RequestParam(value = "subBrands", required = false) List<String> subBrands,
			@RequestParam(value = "eans", required = false) List<String> eans,  
			@RequestParam(value = "weeks", required = true) List<Integer> weeks) throws Exception;

}
