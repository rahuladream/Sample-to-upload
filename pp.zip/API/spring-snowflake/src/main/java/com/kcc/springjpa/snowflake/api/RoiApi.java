package com.kcc.springjpa.snowflake.api;

import java.util.List;
import java.util.Map;

import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kcc.springjpa.snowflake.model.PostRoiModel;
import com.kcc.springjpa.snowflake.model.PostRoiTpQuadrant;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "roi", description = "ROI API")
public interface RoiApi {
	
	@ApiOperation(value = "", response = PostRoiModel.class, tags = { "POST-ROI", })
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Successful Post ROI Model data", response = PostRoiModel.class) })
	@RequestMapping(value = "/postRoi", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<List<PostRoiModel>> getPostRoiData(@RequestParam(value = "country", required = true) String country,
													  @RequestParam(value = "planLevels", required = false) List<String> planLevels,
													  @RequestParam(value = "customers", required = false) List<String> customers,
													  @RequestParam(value = "source", required = false) List<String> source,
													  @RequestParam(value = "categories", required = false) List<String> categories,
													  @RequestParam(value = "subCategories", required = false) List<String> subCategories,
													  @RequestParam(value = "brands", required = false) List<String> brands,
													  @RequestParam(value = "subBrands", required = false) List<String> subBrands,
													  @RequestParam(value = "eans", required = false) List<String> eans,
													  @RequestParam(value = "eventIds", required = false) List<String> eventIds,
													  @RequestParam(value = "fromDate", required = true) String fromDate,
													  @RequestParam(value = "toDate", required = true) String toDate,
													  @RequestParam(value = "groupBy", required = true) String groupBy,
													  @RequestParam(value = "kpiType", required = false) String kpiType,
													  @RequestParam(value = "quadrants", required = false) List<Integer> quadrants) throws Exception;
	
	@ApiOperation(value = "", response = PostRoiModel.class, tags = { "POST-ROI", })
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Successful Post ROI Quadrant Model data", response = PostRoiModel.class) })
	@RequestMapping(value = "/postRoiQuadrant", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<PostRoiModel> getPostRoiQuadrantData(@RequestParam(value = "country", required = true) String country,
														@RequestParam(value = "planLevels", required = false) List<String> planLevels,
														@RequestParam(value = "customers", required = false) List<String> customers,
														@RequestParam(value = "source", required = false) List<String> source,
														@RequestParam(value = "categories", required = false) List<String> categories,
														@RequestParam(value = "subCategories", required = false) List<String> subCategories,
														@RequestParam(value = "brands", required = false) List<String> brands,
														@RequestParam(value = "subBrands", required = false) List<String> subBrands,
														@RequestParam(value = "eans", required = false) List<String> eans,
														@RequestParam(value = "eventIds", required = false) List<String> eventIds,
														@RequestParam(value = "fromDate", required = true) String fromDate,
														@RequestParam(value = "toDate", required = true) String toDate,
														@RequestParam(value = "kpiType", required = false) String kpiType) throws Exception;
	
	@ApiOperation(value = "", response = PostRoiModel.class, tags = { "POST-ROI", })
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Successful List of Event Ids for POst ROI", response = PostRoiModel.class) })
	@RequestMapping(value = "/getEventIds", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<List<String>> getPostRoiEventIds(@RequestParam(value = "country", required = true) String country,
			@RequestParam(value = "planLevels", required = false) List<String> planLevels,
			@RequestParam(value = "customers", required = false) List<String> customers,
			@RequestParam(value = "source", required = false) List<String> source,
			@RequestParam(value = "categories", required = false) List<String> categories,
			@RequestParam(value = "subCategories", required = false) List<String> subCategories,
			@RequestParam(value = "brands", required = false) List<String> brands,
			@RequestParam(value = "subBrands", required = false) List<String> subBrands,
			@RequestParam(value = "eans", required = false) List<String> eans,
			@RequestParam(value = "fromDate", required = true) String fromDate,
			@RequestParam(value = "toDate", required = true) String toDate) throws Exception;
	
	@ApiOperation(value = "", response = PostRoiTpQuadrant.class, tags = { "POST-ROI", })
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Successful Post ROI TP Quadrant", response = PostRoiTpQuadrant.class) })
	@RequestMapping(value = "/getTpQuadrant", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<PostRoiTpQuadrant> getPostRoiTpQuadrant(@RequestParam(value = "country", required = true) String country,
														   @RequestParam(value = "planLevels", required = false) List<String> planLevels,
														   @RequestParam(value = "customers", required = false) List<String> customers,
														   @RequestParam(value = "source", required = false) List<String> source,
														   @RequestParam(value = "categories", required = false) List<String> categories,
														   @RequestParam(value = "subCategories", required = false) List<String> subCategories,
														   @RequestParam(value = "brands", required = false) List<String> brands,
														   @RequestParam(value = "subBrands", required = false) List<String> subBrands,
														   @RequestParam(value = "eans", required = false) List<String> eans,
														   @RequestParam(value = "eventIds", required = false) List<String> eventIds,
														   @RequestParam(value = "fromDate", required = true) String fromDate,
														   @RequestParam(value = "toDate", required = true) String toDate,
														   @RequestParam(value = "kpiType", required = false) String kpiType) throws Exception;
	
	@ApiOperation(value = "", response = Resource.class, tags = { "POST-ROI", })
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Successful Post ROI Excel File", response = Resource.class) })
	@RequestMapping(path = "/downloadRoiFile", method = RequestMethod.GET)
	ResponseEntity<Resource> downloadFile(@RequestParam(value = "country", required = true) String country,
										  @RequestParam(value = "planLevels", required = false) List<String> planLevels,
										  @RequestParam(value = "customers", required = false) List<String> customers,
										  @RequestParam(value = "source", required = false) List<String> source,
										  @RequestParam(value = "categories", required = false) List<String> categories,
										  @RequestParam(value = "subCategories", required = false) List<String> subCategories,
										  @RequestParam(value = "brands", required = false) List<String> brands,
										  @RequestParam(value = "subBrands", required = false) List<String> subBrands,
										  @RequestParam(value = "eans", required = false) List<String> eans,
										  @RequestParam(value = "eventIds", required = false) List<String> eventIds,
										  @RequestParam(value = "fromDate", required = true) String fromDate,
										  @RequestParam(value = "toDate", required = true) String toDate,
										  @RequestParam(value = "kpiType", required = false) String kpiType) throws Exception;

	@ApiOperation(value = "", response = Map.class, tags = { "POST-ROI", })
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Successful Get Sell In Sell Out Data For Country", response = Map.class) })
	@RequestMapping(path = "/hasSellInSelloutData", method = RequestMethod.GET)
	ResponseEntity<Map<String, Boolean>> hasSellInSelloutData(
			@RequestParam(value = "country", required = true) String country
	) throws Exception;


}
