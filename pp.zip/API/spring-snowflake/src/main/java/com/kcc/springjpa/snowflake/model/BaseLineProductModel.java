package com.kcc.springjpa.snowflake.model;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class BaseLineProductModel {

	private String country;

	private String category;
	
	private String subCategory;

	private String brand;

	private String subBrand;
	
	private String ean;

}
