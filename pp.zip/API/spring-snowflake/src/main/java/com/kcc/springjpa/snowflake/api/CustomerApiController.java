package com.kcc.springjpa.snowflake.api;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import com.kcc.springjpa.snowflake.model.BaseLineDataModel;
import com.kcc.springjpa.snowflake.model.CustomerHierarchy;
import com.kcc.springjpa.snowflake.model.EmbedInfo;
import com.kcc.springjpa.snowflake.model.ProductHierarchy;
import com.kcc.springjpa.snowflake.service.BaseLineDataService;
import com.kcc.springjpa.snowflake.service.PowerBIService;

@Controller
public class CustomerApiController implements CustomerApi {
	
	private static final Logger logger = LogManager.getLogger(CustomerApiController.class);
    
    @Autowired
    BaseLineDataService baseLineDataService;
    
    @Autowired
    PowerBIService powerBIService;
    
    @Override
    public ResponseEntity<ProductHierarchy> getProductHierarchy(String country) throws Exception {
    	logger.info("API call to retrieve BaseLine Product Hierarchy for the country: " + country);
        return new ResponseEntity<>(baseLineDataService.getProductHierarchy(country.trim()), HttpStatus.OK);
    }

	@Override
	public ResponseEntity<CustomerHierarchy> getCustomerHierarchy(String country, List<String> source, String feature) throws Exception {
		logger.info("API call to retrieve BaseLine Customer Hierarchy for the country: " + country);
		return new ResponseEntity<>(baseLineDataService.getCustomerHierarchy(country.trim(), source, feature), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<String>> getCountriesList() throws Exception {
		logger.info("API call to retrieve list of Countries");
		return new ResponseEntity<>(baseLineDataService.getCountriesList(), HttpStatus.OK);
	}
	
	@Override
	public ResponseEntity<List<BaseLineDataModel>> getBaseLineData(String country, List<Integer> years,
																   String granularity, List<String> planLevels, List<String> customers, List<String> categories,
																   List<String> subCategories, List<String> brands, List<String> subBrands, List<String> eans)
			throws Exception {
		logger.info("API call to retrieve BaseLine Data for the filters selected: " + country);
		return new ResponseEntity<>(baseLineDataService.getBaseLineData(country.trim(), years, granularity, planLevels, customers, categories, subCategories, brands, subBrands, eans), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<EmbedInfo> getPowerBIToken(String reportId) throws Exception {
		logger.info("API call to retrieve PowerBI Token");
		return new ResponseEntity<EmbedInfo>(powerBIService.getPowerBIEmbedDetails(reportId.trim()), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Map<String, Boolean>> dailyAvailable(String country) {
		return new ResponseEntity<>(baseLineDataService.dailyAvailable(country), HttpStatus.OK);
	}

}