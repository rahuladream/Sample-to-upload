package com.kcc.springjpa.snowflake.dtos;

import java.util.List;

public class GetRegressionStatsRequest {

    public String country;
    public List<LineFittingDataPoint> dataPoints;
}
