package com.kcc.springjpa.snowflake.service.impl;

import java.sql.SQLException;
import java.util.*;

import com.kcc.springjpa.snowflake.dao.PreRoiDao;
import com.kcc.springjpa.snowflake.repository.PostRoiDataRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kcc.springjpa.snowflake.dao.BaseLineDao;
import com.kcc.springjpa.snowflake.model.AdjustedBaseLineModel;
import com.kcc.springjpa.snowflake.model.BaseLineCustomerModel;
import com.kcc.springjpa.snowflake.model.BaseLineDataModel;
import com.kcc.springjpa.snowflake.model.BaseLineProductModel;
import com.kcc.springjpa.snowflake.model.BaseLineResultsModel;
import com.kcc.springjpa.snowflake.model.Brand;
import com.kcc.springjpa.snowflake.model.Category;
import com.kcc.springjpa.snowflake.model.CustomerHierarchy;
import com.kcc.springjpa.snowflake.model.PlanLevelModel;
import com.kcc.springjpa.snowflake.model.ProductHierarchy;
import com.kcc.springjpa.snowflake.model.SalesOfficeModel;
import com.kcc.springjpa.snowflake.model.SubBrand;
import com.kcc.springjpa.snowflake.model.SubCategory;
import com.kcc.springjpa.snowflake.service.BaseLineDataService;

@Service
public class BaseLineDataServiceImpl implements BaseLineDataService {

	private static final Logger logger = LogManager.getLogger(BaseLineDataServiceImpl.class);

	// Category --> SubCategory --> Brand --> Subbrand <EAN>

//	@Autowired
//	BaseLineDataRepository baseLineDataRepository;

	@Autowired
	BaseLineDao baseLineDao;

	@Autowired
	PreRoiDao preRoiDao;

	@Autowired
	PostRoiDataRepository postRoiDataRepository;

	@Override
	public List<String> getCountriesList() throws SQLException {
		logger.info("List of countries provider Service");
		return baseLineDao.getCountriesList();
	}

	@Override
	public List<BaseLineDataModel> getBaseLineData(String country, List<Integer> years, String granularity,
			List<String> planLevels, List<String> customers, List<String> categories, List<String> subCategories,
			List<String> brands, List<String> subBrands, List<String> eans) throws SQLException {

		List<BaseLineDataModel> baseLineDataModels = new ArrayList<BaseLineDataModel>();
		logger.info("Snowflake call to get baseLineData");
		for (Integer year : years) {
			List<BaseLineResultsModel> baseLineData = baseLineDao.findByFilter(country.toUpperCase(), year, planLevels,
					customers, categories, subCategories, brands, subBrands, eans, granularity);
			// baseLineDataRepository.findByFilter(country.toUpperCase(), year, planLevels,
			// customers, categories, subCategories, brands, subBrands, eans);
			logger.info("Number of rows returned for baseLineData ----------" + baseLineData.size());

			BaseLineDataModel baseLineDataModel = new BaseLineDataModel();
			baseLineDataModel.setYear(year);
			if (granularity.equals("monthly")) {
				this.setWeeklyBaseLineData(baseLineDataModel, baseLineData);
				this.setMonthlyBaselineData(baseLineDataModel);
			} else if (granularity.equals("weekly")) {
				this.setWeeklyBaseLineData(baseLineDataModel, baseLineData);
			} else if (granularity.equals("daily")) {
				this.setDailyBaseLineData(baseLineDataModel, baseLineData);
			}

			baseLineDataModels.add(baseLineDataModel);
		}
		return baseLineDataModels;
	}

	private void setMonthlyBaselineData(BaseLineDataModel baseLineDataModel) {

		Map<String, Integer> januaryMonth = new TreeMap<String, Integer>();
		Map<String, Integer> februaryMonth = new TreeMap<String, Integer>();
		Map<String, Integer> marchMonth = new TreeMap<String, Integer>();
		Map<String, Integer> aprilMonth = new TreeMap<String, Integer>();
		Map<String, Integer> mayMonth = new TreeMap<String, Integer>();
		Map<String, Integer> juneMonth = new TreeMap<String, Integer>();
		Map<String, Integer> julyMonth = new TreeMap<String, Integer>();
		Map<String, Integer> augustMonth = new TreeMap<String, Integer>();
		Map<String, Integer> septemberMonth = new TreeMap<String, Integer>();
		Map<String, Integer> octoberMonth = new TreeMap<String, Integer>();
		Map<String, Integer> novemberMonth = new TreeMap<String, Integer>();
		Map<String, Integer> decemberMonth = new TreeMap<String, Integer>();
		
		Map<String, Integer> adjustedJanuaryMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedFebruaryMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedMarchMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedAprilMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedMayMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedJuneMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedJulyMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedAugustMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedSeptemberMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedOctoberMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedNovemberMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedDecemberMonth = new TreeMap<String, Integer>();

		januaryMonth.put("January",
				baseLineDataModel.getStatisticalBaseLine().getJanuary().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getStatisticalBaseLine().setJanuary(januaryMonth);
		
		adjustedJanuaryMonth.put("January",
				baseLineDataModel.getAdjustedBaseLine().getJanuary().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getAdjustedBaseLine().setJanuary(adjustedJanuaryMonth);
		
		februaryMonth.put("February",
				baseLineDataModel.getStatisticalBaseLine().getFebruary().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getStatisticalBaseLine().setFebruary(februaryMonth);

		adjustedFebruaryMonth.put("February",
				baseLineDataModel.getAdjustedBaseLine().getFebruary().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getAdjustedBaseLine().setFebruary(adjustedFebruaryMonth);
		
		marchMonth.put("March",
				baseLineDataModel.getStatisticalBaseLine().getMarch().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getStatisticalBaseLine().setMarch(marchMonth);

		adjustedMarchMonth.put("March",
				baseLineDataModel.getAdjustedBaseLine().getMarch().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getAdjustedBaseLine().setMarch(adjustedMarchMonth);
		
		aprilMonth.put("April",
				baseLineDataModel.getStatisticalBaseLine().getApril().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getStatisticalBaseLine().setApril(aprilMonth);

		adjustedAprilMonth.put("April",
				baseLineDataModel.getAdjustedBaseLine().getApril().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getAdjustedBaseLine().setApril(adjustedAprilMonth);
		
		mayMonth.put("May", baseLineDataModel.getStatisticalBaseLine().getMay().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getStatisticalBaseLine().setMay(mayMonth);

		adjustedMayMonth.put("May", baseLineDataModel.getAdjustedBaseLine().getMay().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getAdjustedBaseLine().setMay(adjustedMayMonth);
		
		juneMonth.put("June",
				baseLineDataModel.getStatisticalBaseLine().getJune().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getStatisticalBaseLine().setJune(juneMonth);

		adjustedJuneMonth.put("June",
				baseLineDataModel.getAdjustedBaseLine().getJune().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getAdjustedBaseLine().setJune(adjustedJuneMonth);
		
		julyMonth.put("July",
				baseLineDataModel.getStatisticalBaseLine().getJuly().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getStatisticalBaseLine().setJuly(julyMonth);

		adjustedJulyMonth.put("July",
				baseLineDataModel.getAdjustedBaseLine().getJuly().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getAdjustedBaseLine().setJuly(adjustedJulyMonth);
		
		augustMonth.put("August",
				baseLineDataModel.getStatisticalBaseLine().getAugust().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getStatisticalBaseLine().setAugust(augustMonth);

		adjustedAugustMonth.put("August",
				baseLineDataModel.getAdjustedBaseLine().getAugust().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getAdjustedBaseLine().setAugust(adjustedAugustMonth);
		
		septemberMonth.put("September",
				baseLineDataModel.getStatisticalBaseLine().getSeptember().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getStatisticalBaseLine().setSeptember(septemberMonth);

		adjustedSeptemberMonth.put("September",
				baseLineDataModel.getAdjustedBaseLine().getSeptember().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getAdjustedBaseLine().setSeptember(adjustedSeptemberMonth);
		
		octoberMonth.put("October",
				baseLineDataModel.getStatisticalBaseLine().getOctober().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getStatisticalBaseLine().setOctober(octoberMonth);

		adjustedOctoberMonth.put("October",
				baseLineDataModel.getAdjustedBaseLine().getOctober().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getAdjustedBaseLine().setOctober(adjustedOctoberMonth);
		
		novemberMonth.put("November",
				baseLineDataModel.getStatisticalBaseLine().getNovember().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getStatisticalBaseLine().setNovember(novemberMonth);

		adjustedNovemberMonth.put("November",
				baseLineDataModel.getAdjustedBaseLine().getNovember().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getAdjustedBaseLine().setNovember(adjustedNovemberMonth);
		
		decemberMonth.put("December",
				baseLineDataModel.getStatisticalBaseLine().getDecember().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getStatisticalBaseLine().setDecember(decemberMonth);

		adjustedDecemberMonth.put("December",
				baseLineDataModel.getAdjustedBaseLine().getDecember().values().stream().reduce(0, Integer::sum));
		baseLineDataModel.getAdjustedBaseLine().setDecember(adjustedDecemberMonth);

	}

	private void setWeeklyBaseLineData(BaseLineDataModel baseLineDataModel, List<BaseLineResultsModel> baseLineData) {

		AdjustedBaseLineModel statisticalBaseLine = new AdjustedBaseLineModel();
		AdjustedBaseLineModel adjustedBaseLine = new AdjustedBaseLineModel();
		AdjustedBaseLineModel upperBand = new AdjustedBaseLineModel();
		AdjustedBaseLineModel lowerBand = new AdjustedBaseLineModel();

		Map<String, Integer> januaryMonth = new TreeMap<String, Integer>();
		Map<String, Integer> februaryMonth = new TreeMap<String, Integer>();
		Map<String, Integer> marchMonth = new TreeMap<String, Integer>();
		Map<String, Integer> aprilMonth = new TreeMap<String, Integer>();
		Map<String, Integer> mayMonth = new TreeMap<String, Integer>();
		Map<String, Integer> juneMonth = new TreeMap<String, Integer>();
		Map<String, Integer> julyMonth = new TreeMap<String, Integer>();
		Map<String, Integer> augustMonth = new TreeMap<String, Integer>();
		Map<String, Integer> septemberMonth = new TreeMap<String, Integer>();
		Map<String, Integer> octoberMonth = new TreeMap<String, Integer>();
		Map<String, Integer> novemberMonth = new TreeMap<String, Integer>();
		Map<String, Integer> decemberMonth = new TreeMap<String, Integer>();

		Map<String, Integer> adjustedJanuaryMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedFebruaryMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedMarchMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedAprilMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedMayMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedJuneMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedJulyMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedAugustMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedSeptemberMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedOctoberMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedNovemberMonth = new TreeMap<String, Integer>();
		Map<String, Integer> adjustedDecemberMonth = new TreeMap<String, Integer>();

		for (BaseLineResultsModel bldDb : baseLineData) {
			if (bldDb.getMonth() != null && bldDb.getMonth() == 1) {
				this.setWeekQuantity(bldDb, januaryMonth);
				this.setAdjustedWeekQuantity(bldDb, adjustedJanuaryMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 2) {
				this.setWeekQuantity(bldDb, februaryMonth);
				this.setAdjustedWeekQuantity(bldDb, adjustedFebruaryMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 3) {
				this.setWeekQuantity(bldDb, marchMonth);
				this.setAdjustedWeekQuantity(bldDb, adjustedMarchMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 4) {
				this.setWeekQuantity(bldDb, aprilMonth);
				this.setAdjustedWeekQuantity(bldDb, adjustedAprilMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 5) {
				this.setWeekQuantity(bldDb, mayMonth);
				this.setAdjustedWeekQuantity(bldDb, adjustedMayMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 6) {
				this.setWeekQuantity(bldDb, juneMonth);
				this.setAdjustedWeekQuantity(bldDb, adjustedJuneMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 7) {
				this.setWeekQuantity(bldDb, julyMonth);
				this.setAdjustedWeekQuantity(bldDb, adjustedJulyMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 8) {
				this.setWeekQuantity(bldDb, augustMonth);
				this.setAdjustedWeekQuantity(bldDb, adjustedAugustMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 9) {
				this.setWeekQuantity(bldDb, septemberMonth);
				this.setAdjustedWeekQuantity(bldDb, adjustedSeptemberMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 10) {
				this.setWeekQuantity(bldDb, octoberMonth);
				this.setAdjustedWeekQuantity(bldDb, adjustedOctoberMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 11) {
				this.setWeekQuantity(bldDb, novemberMonth);
				this.setAdjustedWeekQuantity(bldDb, adjustedNovemberMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 12) {
				this.setWeekQuantity(bldDb, decemberMonth);
				this.setAdjustedWeekQuantity(bldDb, adjustedDecemberMonth);
			}
		}

		statisticalBaseLine.setJanuary(januaryMonth);
		adjustedBaseLine.setJanuary(adjustedJanuaryMonth);

		statisticalBaseLine.setFebruary(februaryMonth);
		adjustedBaseLine.setFebruary(adjustedFebruaryMonth);

		statisticalBaseLine.setMarch(marchMonth);
		adjustedBaseLine.setMarch(adjustedMarchMonth);

		statisticalBaseLine.setApril(aprilMonth);
		adjustedBaseLine.setApril(adjustedAprilMonth);

		statisticalBaseLine.setMay(mayMonth);
		adjustedBaseLine.setMay(adjustedMayMonth);

		statisticalBaseLine.setJune(juneMonth);
		adjustedBaseLine.setJune(adjustedJuneMonth);

		statisticalBaseLine.setJuly(julyMonth);
		adjustedBaseLine.setJuly(adjustedJulyMonth);

		statisticalBaseLine.setAugust(augustMonth);
		adjustedBaseLine.setAugust(adjustedAugustMonth);

		statisticalBaseLine.setSeptember(septemberMonth);
		adjustedBaseLine.setSeptember(adjustedSeptemberMonth);

		statisticalBaseLine.setOctober(octoberMonth);
		adjustedBaseLine.setOctober(adjustedOctoberMonth);

		statisticalBaseLine.setNovember(novemberMonth);
		adjustedBaseLine.setNovember(adjustedNovemberMonth);

		statisticalBaseLine.setDecember(decemberMonth);
		adjustedBaseLine.setDecember(adjustedDecemberMonth);

		statisticalBaseLine.setTotalQuantity(this.getAdded(statisticalBaseLine));
		statisticalBaseLine.setAverageQuantity(this.findAverage(statisticalBaseLine));

		adjustedBaseLine.setTotalQuantity(this.getAdded(adjustedBaseLine));
		adjustedBaseLine.setAverageQuantity(this.findAverage(adjustedBaseLine));

		baseLineDataModel.setAdjustedBaseLine(adjustedBaseLine);
		baseLineDataModel.setStatisticalBaseLine(statisticalBaseLine);
		baseLineDataModel.setLowerBand(lowerBand);
		baseLineDataModel.setUpperBand(upperBand);
	}

	private void setWeekQuantity(BaseLineResultsModel bldDb, Map<String, Integer> month) {

		if (bldDb.getWeek() != null && bldDb.getBaseLineTotalQuantity() != null) {
			month.merge("W" + bldDb.getWeek(), bldDb.getBaseLineTotalQuantity().intValue(), Integer::sum);
		}
	}

	private void setAdjustedWeekQuantity(BaseLineResultsModel bldDb, Map<String, Integer> month) {

		if (bldDb.getWeek() != null && bldDb.getBaseLineAdjustedQuantity() != null) {
			month.merge("W" + bldDb.getWeek(), bldDb.getBaseLineAdjustedQuantity().intValue(), Integer::sum);
		}
	}

	private Integer getAdded(AdjustedBaseLineModel statisticalBaseLine) {
		int sum = 0;
		sum = this.findSum(statisticalBaseLine.getJanuary(), sum);
		sum = this.findSum(statisticalBaseLine.getFebruary(), sum);
		sum = this.findSum(statisticalBaseLine.getMarch(), sum);
		sum = this.findSum(statisticalBaseLine.getApril(), sum);
		sum = this.findSum(statisticalBaseLine.getMay(), sum);
		sum = this.findSum(statisticalBaseLine.getJune(), sum);
		sum = this.findSum(statisticalBaseLine.getJuly(), sum);
		sum = this.findSum(statisticalBaseLine.getAugust(), sum);
		sum = this.findSum(statisticalBaseLine.getSeptember(), sum);
		sum = this.findSum(statisticalBaseLine.getOctober(), sum);
		sum = this.findSum(statisticalBaseLine.getNovember(), sum);
		sum = this.findSum(statisticalBaseLine.getDecember(), sum);
		return sum;
	}

	private Integer findSum(Map<String, Integer> month, Integer sum) {
		// int monthlyQuantity = 0;
		for (String key : month.keySet()) {
			sum = sum + month.get(key);
		}
		// System.out.println("After each step" + sum);
		return sum;
	}

	private Integer findAverage(AdjustedBaseLineModel statisticalBaseLine) {
		return statisticalBaseLine.getTotalQuantity() / 12;
	}

	private void setDailyBaseLineData(BaseLineDataModel baseLineDataModel, List<BaseLineResultsModel> baseLineData) {
		AdjustedBaseLineModel statisticalBaseLine = new AdjustedBaseLineModel();
		AdjustedBaseLineModel adjustedBaseLine = new AdjustedBaseLineModel();
		AdjustedBaseLineModel upperBand = new AdjustedBaseLineModel();
		AdjustedBaseLineModel lowerBand = new AdjustedBaseLineModel();

		Map<String, Integer> januaryMonth = new TreeMap<>();
		Map<String, Integer> februaryMonth = new TreeMap<>();
		Map<String, Integer> marchMonth = new TreeMap<>();
		Map<String, Integer> aprilMonth = new TreeMap<>();
		Map<String, Integer> mayMonth = new TreeMap<>();
		Map<String, Integer> juneMonth = new TreeMap<>();
		Map<String, Integer> julyMonth = new TreeMap<>();
		Map<String, Integer> augustMonth = new TreeMap<>();
		Map<String, Integer> septemberMonth = new TreeMap<>();
		Map<String, Integer> octoberMonth = new TreeMap<>();
		Map<String, Integer> novemberMonth = new TreeMap<>();
		Map<String, Integer> decemberMonth = new TreeMap<>();

		Map<String, Integer> adjustedJanuaryMonth = new TreeMap<>();
		Map<String, Integer> adjustedFebruaryMonth = new TreeMap<>();
		Map<String, Integer> adjustedMarchMonth = new TreeMap<>();
		Map<String, Integer> adjustedAprilMonth = new TreeMap<>();
		Map<String, Integer> adjustedMayMonth = new TreeMap<>();
		Map<String, Integer> adjustedJuneMonth = new TreeMap<>();
		Map<String, Integer> adjustedJulyMonth = new TreeMap<>();
		Map<String, Integer> adjustedAugustMonth = new TreeMap<>();
		Map<String, Integer> adjustedSeptemberMonth = new TreeMap<>();
		Map<String, Integer> adjustedOctoberMonth = new TreeMap<>();
		Map<String, Integer> adjustedNovemberMonth = new TreeMap<>();
		Map<String, Integer> adjustedDecemberMonth = new TreeMap<>();

		for (BaseLineResultsModel bldDb : baseLineData) {
			if (bldDb.getMonth() != null && bldDb.getMonth() == 1) {
				setDayQuantity(bldDb, januaryMonth);
				setAdjustedDayQuantity(bldDb, adjustedJanuaryMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 2) {
				setDayQuantity(bldDb, februaryMonth);
				setAdjustedDayQuantity(bldDb, adjustedFebruaryMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 3) {
				setDayQuantity(bldDb, marchMonth);
				setAdjustedDayQuantity(bldDb, adjustedMarchMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 4) {
				setDayQuantity(bldDb, aprilMonth);
				setAdjustedDayQuantity(bldDb, adjustedAprilMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 5) {
				setDayQuantity(bldDb, mayMonth);
				setAdjustedDayQuantity(bldDb, adjustedMayMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 6) {
				setDayQuantity(bldDb, juneMonth);
				setAdjustedDayQuantity(bldDb, adjustedJuneMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 7) {
				setDayQuantity(bldDb, julyMonth);
				setAdjustedDayQuantity(bldDb, adjustedJulyMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 8) {
				setDayQuantity(bldDb, augustMonth);
				setAdjustedDayQuantity(bldDb, adjustedAugustMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 9) {
				setDayQuantity(bldDb, septemberMonth);
				setAdjustedDayQuantity(bldDb, adjustedSeptemberMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 10) {
				setDayQuantity(bldDb, octoberMonth);
				setAdjustedDayQuantity(bldDb, adjustedOctoberMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 11) {
				setDayQuantity(bldDb, novemberMonth);
				setAdjustedDayQuantity(bldDb, adjustedNovemberMonth);
			} else if (bldDb.getMonth() != null && bldDb.getMonth() == 12) {
				setDayQuantity(bldDb, decemberMonth);
				setAdjustedDayQuantity(bldDb, adjustedDecemberMonth);
			}
		}

		statisticalBaseLine.setJanuary(januaryMonth);
		adjustedBaseLine.setJanuary(adjustedJanuaryMonth);

		statisticalBaseLine.setFebruary(februaryMonth);
		adjustedBaseLine.setFebruary(adjustedFebruaryMonth);

		statisticalBaseLine.setMarch(marchMonth);
		adjustedBaseLine.setMarch(adjustedMarchMonth);

		statisticalBaseLine.setApril(aprilMonth);
		adjustedBaseLine.setApril(adjustedAprilMonth);

		statisticalBaseLine.setMay(mayMonth);
		adjustedBaseLine.setMay(adjustedMayMonth);

		statisticalBaseLine.setJune(juneMonth);
		adjustedBaseLine.setJune(adjustedJuneMonth);

		statisticalBaseLine.setJuly(julyMonth);
		adjustedBaseLine.setJuly(adjustedJulyMonth);

		statisticalBaseLine.setAugust(augustMonth);
		adjustedBaseLine.setAugust(adjustedAugustMonth);

		statisticalBaseLine.setSeptember(septemberMonth);
		adjustedBaseLine.setSeptember(adjustedSeptemberMonth);

		statisticalBaseLine.setOctober(octoberMonth);
		adjustedBaseLine.setOctober(adjustedOctoberMonth);

		statisticalBaseLine.setNovember(novemberMonth);
		adjustedBaseLine.setNovember(adjustedNovemberMonth);

		statisticalBaseLine.setDecember(decemberMonth);
		adjustedBaseLine.setDecember(adjustedDecemberMonth);

		statisticalBaseLine.setTotalQuantity(this.getAdded(statisticalBaseLine));
		statisticalBaseLine.setAverageQuantity(this.findDailyAverage(statisticalBaseLine));

		adjustedBaseLine.setTotalQuantity(this.getAdded(adjustedBaseLine));
		adjustedBaseLine.setAverageQuantity(this.findDailyAverage(adjustedBaseLine));

		baseLineDataModel.setAdjustedBaseLine(adjustedBaseLine);
		baseLineDataModel.setStatisticalBaseLine(statisticalBaseLine);
		baseLineDataModel.setLowerBand(lowerBand);
		baseLineDataModel.setUpperBand(upperBand);
	}

	private Integer findDailyAverage(AdjustedBaseLineModel statisticalBaseLine) {
		int days = statisticalBaseLine.getJanuary().size();
		days += statisticalBaseLine.getFebruary().size();
		days += statisticalBaseLine.getMarch().size();
		days += statisticalBaseLine.getApril().size();
		days += statisticalBaseLine.getMay().size();
		days += statisticalBaseLine.getJune().size();
		days += statisticalBaseLine.getJuly().size();
		days += statisticalBaseLine.getAugust().size();
		days += statisticalBaseLine.getSeptember().size();
		days += statisticalBaseLine.getOctober().size();
		days += statisticalBaseLine.getNovember().size();
		days += statisticalBaseLine.getDecember().size();

		if(days == 0) {
			return 0;
		}

		return statisticalBaseLine.getTotalQuantity() / days;
	}

	private void setDayQuantity(BaseLineResultsModel bldDb, Map<String, Integer> month) {
		month.put("" + bldDb.getDay(), bldDb.getBaseLineTotalQuantity().intValue());
	}

	private void setAdjustedDayQuantity(BaseLineResultsModel bldDb, Map<String, Integer> month) {
		month.put("" + bldDb.getDay(), bldDb.getBaseLineAdjustedQuantity().intValue());
	}

	/**
	 * Distribution Channel --> Sales Office --> Plan Levels --> Sold to
	 * */
	@Override
	public CustomerHierarchy getCustomerHierarchy(String country, List<String> sources, String feature) throws Exception {
		logger.info("Snowflake call to get list of  Customers by country initial: " + country);
		List<BaseLineCustomerModel> baseLineData;
		if(feature == null || feature.isEmpty()) {
			feature = "Baseline Forecasting";
		}
		switch (feature) {
			case "ROI Simulator":
				baseLineData = preRoiDao.getCustomerHierarchy(country);
				break;
			case "Promo Performance":
				baseLineData = postRoiDataRepository.getCustomerHierarchy(country, sources);
				break;
			default:
				baseLineData = baseLineDao.getCustomerHierarchy(country);
		}
		logger.info("Number of rows returned for Customers for the country: " + country + "----------"
				+ baseLineData.size());

		CustomerHierarchy customerHierarchy = new CustomerHierarchy();
		Map<String, SalesOfficeModel> distChannels = new HashMap<>();
		customerHierarchy.setDistChannels(distChannels);

		for (BaseLineCustomerModel bldDb : baseLineData) {
			if (bldDb.getSalesOffice() == null) {
				bldDb.setSalesOffice("N/A");				
			}
			if (bldDb.getDistrChannelDesc() == null) {
				bldDb.setDistrChannelDesc("N/A");				
			}
			if (bldDb.getPlanLevel() == null) {
				bldDb.setPlanLevel("N/A");				
			}		
			if (customerHierarchy.getDistChannels().containsKey(bldDb.getDistrChannelDesc())) {
				if (customerHierarchy.getDistChannels().get(bldDb.getDistrChannelDesc()).getSalesOffice()
						.containsKey(bldDb.getSalesOffice())) {
					if (customerHierarchy.getDistChannels().get(bldDb.getDistrChannelDesc()).getSalesOffice()
							.get(bldDb.getSalesOffice()).getPlanLevel().containsKey(bldDb.getPlanLevel())) {
						customerHierarchy.getDistChannels().get(bldDb.getDistrChannelDesc()).getSalesOffice()
								.get(bldDb.getSalesOffice()).getPlanLevel().get(bldDb.getPlanLevel())
								.add(bldDb.getSoldToDesc());
					} else {
						this.createNewPlanLevelNode(customerHierarchy, bldDb);
					}
				} else {
					this.createNewSalesOfficeNode(customerHierarchy, bldDb);
				}
			} else {
				this.createNewDistChannelNode(customerHierarchy, bldDb);
			}
		}
		return customerHierarchy;
	}

	// Creating NODES in a hierarchical tree
	private void createNewDistChannelNode(CustomerHierarchy customerHierarchy, BaseLineCustomerModel bldDb) {
		customerHierarchy.getDistChannels().put(bldDb.getDistrChannelDesc(),
				this.createSalesOffice(customerHierarchy, bldDb));
	}

	private void createNewSalesOfficeNode(CustomerHierarchy customerHierarchy, BaseLineCustomerModel bldDb) {
		customerHierarchy.getDistChannels().get(bldDb.getDistrChannelDesc()).getSalesOffice()
				.put(bldDb.getSalesOffice(), this.createPlanLevel(customerHierarchy, bldDb));
	}

	private void createNewPlanLevelNode(CustomerHierarchy customerHierarchy, BaseLineCustomerModel bldDb) {
		Set<String> soldTo = new HashSet<String>();
		soldTo.add(bldDb.getSoldToDesc());
		customerHierarchy.getDistChannels().get(bldDb.getDistrChannelDesc()).getSalesOffice()
				.get(bldDb.getSalesOffice()).getPlanLevel().put(bldDb.getPlanLevel(), soldTo);
	}

	// Creating Leaf Values in a tree
	private PlanLevelModel createPlanLevel(CustomerHierarchy customerHierarchy, BaseLineCustomerModel bldDb) {
		PlanLevelModel planLevelModel = new PlanLevelModel();
		planLevelModel.setPlanLevel(new HashMap<String, Set<String>>());
		Set<String> soldTo = new HashSet<String>();
		soldTo.add(bldDb.getSoldToDesc());
		planLevelModel.getPlanLevel().put(bldDb.getPlanLevel(), soldTo);
		return planLevelModel;
	}

	private SalesOfficeModel createSalesOffice(CustomerHierarchy customerHierarchy, BaseLineCustomerModel bldDb) {
		SalesOfficeModel salesOfficeModel = new SalesOfficeModel();
		salesOfficeModel.setSalesOffice(new HashMap<String, PlanLevelModel>());
		salesOfficeModel.getSalesOffice().put(bldDb.getSalesOffice(), this.createPlanLevel(customerHierarchy, bldDb));
		return salesOfficeModel;
	}

	@Override
	public ProductHierarchy getProductHierarchy(String country) throws SQLException {

		logger.info("Snowflake call to get list of  Baseline Products by country initial: " + country);
		ProductHierarchy bld = new ProductHierarchy();
		Map<String, Category> countries = new HashMap<String, Category>();
		bld.setCountries(countries);

		List<BaseLineProductModel> baseLineData = baseLineDao.getProductHierarchy(country.toUpperCase());
		logger.info("Number of rows returned for BaseLine Product for the country: " + country + "----------"
				+ baseLineData.size());

		for (BaseLineProductModel product : baseLineData) {
			if (product.getCategory() == null || product.getSubCategory() == null || product.getBrand() == null
					|| product.getSubBrand() == null) {
				continue;
			}
			if (bld.getCountries().containsKey(product.getCountry())) {
				if (bld.getCountries().get(product.getCountry()).getCategories().containsKey(product.getCategory())) {
					if (bld.getCountries().get(product.getCountry()).getCategories().get(product.getCategory())
							.getSubCategories().containsKey(product.getSubCategory())) {
						if (bld.getCountries().get(product.getCountry()).getCategories().get(product.getCategory())
								.getSubCategories().get(product.getSubCategory()).getBrands()
								.containsKey(product.getBrand())) {
							if (bld.getCountries().get(product.getCountry()).getCategories().get(product.getCategory())
									.getSubCategories().get(product.getSubCategory()).getBrands().get(product.getBrand())
									.getSubBrands().containsKey(product.getSubBrand())) {
								bld.getCountries().get(product.getCountry()).getCategories().get(product.getCategory())
										.getSubCategories().get(product.getSubCategory()).getBrands()
										.get(product.getBrand()).getSubBrands().get(product.getSubBrand())
										.add(product.getEan());
							} else {
								Set<String> eans = new HashSet<String>();
								eans.add(product.getEan());
								bld.getCountries().get(product.getCountry()).getCategories().get(product.getCategory())
										.getSubCategories().get(product.getSubCategory()).getBrands()
										.get(product.getBrand()).getSubBrands().put(product.getSubBrand(), eans);
							}
						} else {
							this.createBrandNode(bld, product);
						}
					} else {
						this.createSubCategoryNode(bld, product);
					}
				} else {
					this.createNewCategoryNode(bld, product);
				}
			} else {
				this.createNewCountryNode(bld, product);
			}
		}
		return bld;
	}

	public void createNewCountryNode(ProductHierarchy bld, BaseLineProductModel bldDb) {
		logger.info("Creating new country Node for BaseLineProduct Hierarchy");
		SubBrand sb = new SubBrand();
		sb.setSubBrands(new HashMap<String, Set<String>>());
		Set<String> eans = new HashSet<String>();
		eans.add(bldDb.getEan());
		sb.getSubBrands().put(bldDb.getSubBrand(), eans);

		Brand b = new Brand();
		b.setBrands(new HashMap<String, SubBrand>());
		b.getBrands().put(bldDb.getBrand(), sb);

		SubCategory sc = new SubCategory();
		sc.setSubCategories(new HashMap<String, Brand>());
		sc.getSubCategories().put(bldDb.getSubCategory(), b);

		Category c = new Category();
		c.setCategories(new HashMap<String, SubCategory>());
		c.getCategories().put(bldDb.getCategory(), sc);

		bld.getCountries().put(bldDb.getCountry(), c);

	}

	public void createNewCategoryNode(ProductHierarchy bld, BaseLineProductModel bldDb) {
		logger.info("Creating new category Node for BaseLineProduct Hierarchy");
		SubBrand sb = new SubBrand();
		sb.setSubBrands(new HashMap<String, Set<String>>());
		Set<String> eans = new HashSet<String>();
		eans.add(bldDb.getEan());
		sb.getSubBrands().put(bldDb.getSubBrand(), eans);

		Brand b = new Brand();
		b.setBrands(new HashMap<String, SubBrand>());
		b.getBrands().put(bldDb.getBrand(), sb);

		SubCategory sc = new SubCategory();
		sc.setSubCategories(new HashMap<String, Brand>());
		sc.getSubCategories().put(bldDb.getSubCategory(), b);

		bld.getCountries().get(bldDb.getCountry()).getCategories().put(bldDb.getCategory(), sc);

	}

	public void createSubCategoryNode(ProductHierarchy bld, BaseLineProductModel bldDb) {
		logger.info("Creating new subCategory Node for BaseLineProduct Hierarchy");
		SubBrand sb = new SubBrand();
		sb.setSubBrands(new HashMap<String, Set<String>>());
		Set<String> eans = new HashSet<String>();
		eans.add(bldDb.getEan());
		sb.getSubBrands().put(bldDb.getSubBrand(), eans);

		Brand b = new Brand();
		b.setBrands(new HashMap<String, SubBrand>());
		b.getBrands().put(bldDb.getBrand(), sb);

		bld.getCountries().get(bldDb.getCountry()).getCategories().get(bldDb.getCategory()).getSubCategories()
				.put(bldDb.getSubCategory(), b);

	}

	public void createBrandNode(ProductHierarchy bld, BaseLineProductModel bldDb) {
		logger.info("Creating new brand Node for BaseLineProduct Hierarchy");
		SubBrand sb = new SubBrand();
		sb.setSubBrands(new HashMap<String, Set<String>>());
		Set<String> eans = new HashSet<String>();
		eans.add(bldDb.getEan());
		sb.getSubBrands().put(bldDb.getSubBrand(), eans);

		bld.getCountries().get(bldDb.getCountry()).getCategories().get(bldDb.getCategory()).getSubCategories()
				.get(bldDb.getSubCategory()).getBrands().put(bldDb.getBrand(), sb);

	}

	@Override
	public Map<String, Boolean> dailyAvailable(String country) {
		Map<String, Boolean> a = new HashMap<>(1);
		a.put("dailyAvailable", baseLineDao.dailyAvailable(country));
		return a;
	}
}
