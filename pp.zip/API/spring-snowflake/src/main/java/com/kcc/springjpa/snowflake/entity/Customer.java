package com.kcc.springjpa.snowflake.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "CUSTOMER_TABLE")
@Getter
@Setter
public class Customer {
    @Id
    @Column(name = "C_NAME")
    @NotBlank(message = "Customer name is mandatory")
    private String cName;

    @NotBlank(message = "Customer account type is mandatory")
    @Column(name = "C_ACT_TYPE")
    private String cActName;

    @Column(name = "C_INFO")
    private String cInfo;

    @Column(name = "C_LOCATION")
    private String cLocation;

}
