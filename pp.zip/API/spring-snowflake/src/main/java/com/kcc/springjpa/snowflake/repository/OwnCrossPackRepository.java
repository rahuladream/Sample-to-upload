package com.kcc.springjpa.snowflake.repository;

import java.util.ArrayList;
import java.util.List;

import com.kcc.springjpa.snowflake.model.CrossOwnView;
import net.snowflake.client.jdbc.internal.amazonaws.util.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.kcc.springjpa.snowflake.entity.OwnCrossPackData;
import org.springframework.util.CollectionUtils;

import javax.persistence.criteria.Predicate;

@Repository
@Transactional
public interface OwnCrossPackRepository extends JpaRepository<OwnCrossPackData, Integer> {
	
	// Query to get OWN Elasticity Data
	public List<OwnCrossPackData> findAllByCountryAndFlagAndTypeAndSourceAndInitialPackIn(String country, String flag, String type, String source, List<String> packs);

	//Query to get CROSS Elasticity Data
	public List<OwnCrossPackData> findAllByCountryAndFlagAndTypeAndSourceAndInitialPackInAndTargetPackIn(String country, String flag, String type,
																										 String source, List<String> initialLeafValues, List<String> targetLeafValues);

	public List<OwnCrossPackData> findAllByCountryAndFlagAndTypeAndInitialPackInAndTargetPackIn(String country, String flag, String type,
																										 List<String> initialLeafValues, List<String> targetLeafValues);

	public List<OwnCrossPackData> findAllByCountry(String country);

	@Query(value = "SELECT * FROM REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_PACK s " +
			"WHERE s.COUNTRY = :country AND s.FLAG = :flag AND s.TYPE = :type AND s.CATEGORY = :category AND s.SOURCE = :source " +
			"ORDER BY s.ELASTICITY_AVG_PRICE DESC " +
			"LIMIT :limit", nativeQuery = true)
	List<OwnCrossPackData> findTopN(@Param("country") String country,
									@Param("flag") String flag,
									@Param("type") String type,
									@Param("limit") int limit,
									@Param("category") String category,
									@Param("source") String source);

	@Query(value = "SELECT * FROM REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_PACK s " +
			"WHERE s.COUNTRY = :country AND s.FLAG = :flag AND s.TYPE = :type AND s.CATEGORY = :category AND s.SOURCE = :source " +
			"ORDER BY s.ELASTICITY_AVG_PRICE ASC " +
			"LIMIT :limit", nativeQuery = true)
	List<OwnCrossPackData> findBottomN(@Param("country") String country,
									   @Param("flag") String flag,
									   @Param("type") String type,
									   @Param("limit") int limit,
									   @Param("category") String category,
									   @Param("source") String source);

	default List<CrossOwnView> findByInitials(String country, List<String> leafValues, String scope, String source, String flag, boolean initial){
		List<CrossOwnView> views = new ArrayList<>();
		Specification<OwnCrossPackData> spec3 = InitialSpecs.findByPackFilter(country, leafValues, scope, source, flag);
		List<OwnCrossPackData> items3 = findAll(spec3);
		for (OwnCrossPackData d : items3) {
			CrossOwnView v = new CrossOwnView();
			if(initial) {
				v.category = d.getCategory();
				v.initialSubCategory = d.getInitialSubCategory();
				v.initialManufacturer = d.getInitialManufacturer();
				v.initialBrand = d.getInitialBrand();
				v.initialSubBrand = d.getInitialSubBrand();
				v.initialPack = d.getInitialPack();
				v.initialTier = d.getInitialTier();
			} else {
				v.category = d.getCategory();
				v.targetSubCategory = d.getTargetSubCategory();
				v.targetManufacturer = d.getTargetManufacturer();
				v.targetBrand = d.getTargetBrand();
				v.targetSubBrand = d.getTargetSubBrand();
				v.targetPack = d.getTargetPack();
				v.targetTier = d.getTargetTier();
			}
			views.add(v);
		}
		return views;
	}

	class InitialSpecs {
		public static Specification<OwnCrossPackData> findByPackFilter(String country, List<String> leafValues, String scope, String source, String flag) {
			return (root, query, builder) -> {
				Predicate result = builder.equal(root.get("country"), country);
				result = builder.and(result, root.get("flag").in(flag));
				if (StringUtils.isNullOrEmpty(scope)) {
					if (source != null) {
						result = builder.and(result, root.get("source").in(source));
					}
				} else if (StringUtils.isNullOrEmpty(source)) {
					result = builder.and(result, root.get("type").in(scope));
				} else {
					result = builder.and(result, root.get("type").in(scope));
					result = builder.and(result, root.get("source").in(source));
				}
				if (!CollectionUtils.isEmpty(leafValues)) {
					result = builder.and(result, root.get("initialPack").in(leafValues));
				}
				return result;
			};
		}
	}

	List<OwnCrossPackData> findAll(Specification<OwnCrossPackData> s);

}
