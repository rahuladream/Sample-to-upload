package com.kcc.springjpa.snowflake.utility;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

public class EanUtility {
	
	public static List<String> getEanNumbersFromDescriptions(List<String> eanNumberDescriptions) {
		
		List<String> eanNumbersList = new ArrayList<String>();
		if(!CollectionUtils.isEmpty(eanNumberDescriptions)) {
			for(String eanNumberDesc : eanNumberDescriptions) {
				if (eanNumberDesc.contains("-")) {
					eanNumbersList.add(getEanNumber(eanNumberDesc));
				}	
			}
		}	
		return eanNumbersList;
	}
	
	public static String getEanNumber(String eanNumberDesc) {
		String[] parts = eanNumberDesc.split("-");
		return parts[0].trim(); // 004
	}
	
	public static String formEanNumberDescriptionCombination(String eanNumber, String eanDescription) {
		return eanNumber + " - " + eanDescription;
	}
	
	public static String formattedEanString(String eanNumberDesc) {
		if(eanNumberDesc.contains("-")) {
			String[] parts = eanNumberDesc.split("-", 2);
			if(parts.length == 2) {
				String eanNumber = parts[0].trim();
				String eanDesc = parts[1].trim();
				String formattedEanNumber = String.format("%1$" + 18 + "s", eanNumber).replace(' ', '0');
						//String.format("%18d", Integer.valueOf(eanNumber));
				return formattedEanNumber + "-" + eanDesc;
			}
		}	
		return eanNumberDesc;
	}
}
