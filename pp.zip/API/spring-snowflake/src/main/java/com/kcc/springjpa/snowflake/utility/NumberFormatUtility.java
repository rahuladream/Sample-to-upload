package com.kcc.springjpa.snowflake.utility;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class NumberFormatUtility {

    public static String roundedPValue(Float pValue) {
        if (pValue == 0) {
            return "0";
        }
        BigDecimal bd = BigDecimal.valueOf(pValue);
        float roundedPValue = bd.setScale(3, RoundingMode.HALF_EVEN).floatValue();
        return new DecimalFormat("###.###").format(roundedPValue);
    }
}
