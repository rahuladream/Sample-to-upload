package com.kcc.springjpa.snowflake.utility;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.snowflake.client.jdbc.internal.amazonaws.util.CollectionUtils;

public class StringUtility {
	
	public static Map<String, Double> getMapFromString(List<String> values) {
		Map<String, Double> map = new HashMap<String, Double>();
		for(String s : values) {
			// split on ':' and on '::'
			String[] parts = s.split("-");
		    for (int i = 0; i < parts.length; i += 2) {
		        map.put(parts[i].trim(), Double.valueOf(parts[i + 1].trim()));
		    }
		}    
		return map;
	}
	
	public static String getCommaSeparatedStringFromList(List<String> list) {
		String commaSeparated = "";
		if(!CollectionUtils.isNullOrEmpty(list)) {
			commaSeparated = String.join(",", list);
		}
		return commaSeparated;
	}

}
