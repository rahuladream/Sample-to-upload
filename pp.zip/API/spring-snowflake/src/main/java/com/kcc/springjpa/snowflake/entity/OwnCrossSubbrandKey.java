package com.kcc.springjpa.snowflake.entity;

import java.io.Serializable;
import java.util.Objects;

public class OwnCrossSubbrandKey implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public int hashCode() {
		return Objects.hash(initialSubBrand, targetSubBrand, type, typeDescription);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OwnCrossSubbrandKey other = (OwnCrossSubbrandKey) obj;
		return Objects.equals(initialSubBrand, other.initialSubBrand)
				&& Objects.equals(targetSubBrand, other.targetSubBrand) && Objects.equals(type, other.type)
				&& Objects.equals(typeDescription, other.typeDescription)
				&& Objects.equals(initialSubCategory, other.initialSubCategory)
				& Objects.equals(targetSubCategory, other.targetSubCategory)
				& Objects.equals(initialBrand, other.initialBrand)
				& Objects.equals(targetBrand, other.targetBrand);
	}

	private String initialSubBrand;
	
	private String targetSubBrand;
	
	private String type;
	
	private String typeDescription;

	private String initialSubCategory;

	private String targetSubCategory;

	private String initialBrand;

	private String targetBrand;



}
