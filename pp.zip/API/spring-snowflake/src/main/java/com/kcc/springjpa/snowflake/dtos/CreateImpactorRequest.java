package com.kcc.springjpa.snowflake.dtos;

import java.util.List;

public class CreateImpactorRequest {

    public String country, impactorName, granularity;
    public int year;
    public List<String> planLevels, customers, categories, subCategories, brands, subBrands, eans;
    public boolean isAbs;
    public float impactorValue;
    public List<Integer> weeks;
    public List<String> days;

    @Override
    public String toString() {
        return "CreateImpactorRequest{" +
                " country='" + country + '\'' +
                " year=" + year +
                " granularity='" + granularity + '\'' +
                " planLevels=" + planLevels +
                " customers=" + customers +
                " categories=" + categories +
                " subCategories=" + subCategories +
                " brands=" + brands +
                " subBrands=" + subBrands +
                " eans=" + eans +
                " weeks=" + weeks +
                " days='" + days + '\'' +
                " impactorName='" + impactorName + '\'' +
                " impactorValue=" + impactorValue +
                " isAbs=" + isAbs +
                '}';
    }
}
