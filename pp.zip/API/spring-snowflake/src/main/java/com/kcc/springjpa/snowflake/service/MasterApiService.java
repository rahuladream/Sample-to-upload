package com.kcc.springjpa.snowflake.service;

import com.kcc.springjpa.snowflake.dtos.CountryMaster;

public interface MasterApiService {

    CountryMaster getCountryMaster(String country) throws Exception;
}
