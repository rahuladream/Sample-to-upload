package com.kcc.springjpa.snowflake.model;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class PreRoiPromoSimulationModel {

	public double roiPercentage;
	
	public double netProfitOrLoss;
	
	public double totalPromoInvestment;
	
	public double npp;
	
	public double cogs;
	
	public double taPct;
	
	public double tpPct;
	
	public double historicalVolume;

	@Override
	public String toString() {
		return "PreRoiPromoSimulationModel [roiPercentage=" + roiPercentage + ", netProfitOrLoss=" + netProfitOrLoss
				+ ", totalPromoInvestment=" + totalPromoInvestment + ", npp=" + npp + ", cogs=" + cogs + ", taPct="
				+ taPct + ", tpPct=" + tpPct + ", historicalVolume=" + historicalVolume + "]";
	}
}
