package com.kcc.springjpa.snowflake.api;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.kcc.springjpa.snowflake.dtos.CreateImpactorRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import com.kcc.springjpa.snowflake.model.ImpactorHistoryModel;
import com.kcc.springjpa.snowflake.model.ImpactorInfoModel;
import com.kcc.springjpa.snowflake.service.ImpactorService;
import com.kcc.springjpa.snowflake.utility.StringResponse;

@Controller
public class ImpactorApiController implements ImpactorApi {

	private static final Logger logger = LogManager.getLogger(ImpactorApiController.class);

	@Autowired
	ImpactorService impactorService;

	@Override
	public ResponseEntity<List<String>> getImpactorNames() throws Exception {
		logger.info("API call to retrieve existing Impactor Names");
		return new ResponseEntity<>(impactorService.getImactorNames(), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Map<String, ImpactorHistoryModel>> getImpactorHistory(String country, String granularity) throws Exception {
		logger.info("API call to retrieve Impactor History");
		return new ResponseEntity<>(impactorService.getImpactorHistory(country, granularity), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Map<String, ImpactorHistoryModel>> getDeletedImpactorHistory(String country, String granularity) throws Exception {
		logger.info("API call to retrieve Deleted Impactor History");
		return new ResponseEntity<>(impactorService.getDeletedImpactorHistory(country, granularity), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ImpactorInfoModel> getImpactorInfo(String impactorName) throws Exception {
		logger.info("API call to retrieve Impactor Info: " + impactorName);
		return new ResponseEntity<>(impactorService.getImpactorInfo(impactorName), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<StringResponse> deleteImpactor(HttpServletRequest request, String impactorName, String country) throws Exception {
		logger.info("API call to delete Impactor: " + impactorName);
		String deletedBy = (String) request.getAttribute("createdBy");
		return new ResponseEntity<>(impactorService.deleteImpactor(deletedBy, impactorName), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<StringResponse> createImpactor(HttpServletRequest request, CreateImpactorRequest createRequest) throws Exception {
		logger.info("API call to create Impactor: " + createRequest.impactorName);
		
		String name = (String) request.getAttribute("createdBy");		
		return new ResponseEntity<>(impactorService.createImpactor(name, createRequest), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Map<String, Float>> getMinimumAdjustmentValue(String country, Integer year,
			List<String> planLevels, List<String> customers, List<String> categories, List<String> subCategories,
			List<String> brands, List<String> subBrands, List<String> eans, List<Integer> weeks) throws Exception {
		logger.info("API call to get minimum adjustment value : ");
		return new ResponseEntity<>(impactorService.getMinimumAdjustmentValue(country.trim(), year, planLevels,
				customers, categories, subCategories, brands, subBrands, eans, weeks), HttpStatus.OK);
	}

}
