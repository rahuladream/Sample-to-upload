package com.kcc.springjpa.snowflake.exception;

import java.util.Date;

public class CustomerAlreadyExistsExceptionResponse extends ExceptionResponse{
    String cusomerId;

    public CustomerAlreadyExistsExceptionResponse(Date timestamp, String message, String details, String cusomerId) {
        super(timestamp, message, details);
        this.cusomerId = cusomerId;
    }
}
