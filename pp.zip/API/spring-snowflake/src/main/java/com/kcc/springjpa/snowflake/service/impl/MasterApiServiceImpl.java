package com.kcc.springjpa.snowflake.service.impl;

import com.kcc.springjpa.snowflake.dao.MasterApiDao;
import com.kcc.springjpa.snowflake.dtos.CountryMaster;
import com.kcc.springjpa.snowflake.service.MasterApiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MasterApiServiceImpl implements MasterApiService {

    @Autowired
    MasterApiDao masterApiDao;

    @Override
    public CountryMaster getCountryMaster(String country) throws Exception {
        return masterApiDao.getCountryMaster(country);
    }
}
