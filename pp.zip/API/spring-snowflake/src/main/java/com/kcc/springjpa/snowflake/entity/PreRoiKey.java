package com.kcc.springjpa.snowflake.entity;

import java.io.Serializable;
import java.util.Objects;

public class PreRoiKey implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public int hashCode() {
		return Objects.hash(ean, soldTo, subBrand);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PreRoiKey other = (PreRoiKey) obj;
		return Objects.equals(ean, other.ean) && Objects.equals(soldTo, other.soldTo)
				&& Objects.equals(subBrand, other.subBrand);
	}

	private String subBrand;
	
	private String soldTo;
	
	private String ean;

}
