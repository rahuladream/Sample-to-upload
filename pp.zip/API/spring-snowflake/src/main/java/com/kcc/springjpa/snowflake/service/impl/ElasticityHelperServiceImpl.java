package com.kcc.springjpa.snowflake.service.impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.kcc.springjpa.snowflake.model.*;
import org.springframework.stereotype.Component;

import com.kcc.springjpa.snowflake.utility.EanUtility;

@Component
public class ElasticityHelperServiceImpl {

	public ElasticityProductHierarchy getInitialProductHierarchy(List<CrossOwnView> views) {

		ElasticityProductHierarchy elasticityProductHierarchy = new ElasticityProductHierarchy();
		Map<String, ElasticitySubCategory> categories = new HashMap<String, ElasticitySubCategory>();
		elasticityProductHierarchy.setCategories(categories);

		for (CrossOwnView ocData : views) {
			if (elasticityProductHierarchy.getCategories().containsKey(ocData.getCategory())) {
				if(ocData.initialSubCategory == null) {
					continue;
				}
				if (elasticityProductHierarchy.getCategories().get(ocData.getCategory()).getSubCategories()
						.containsKey(ocData.getInitialSubCategory())) {
					if(ocData.initialManufacturer == null) {
						continue;
					}
					if (elasticityProductHierarchy.getCategories().get(ocData.getCategory()).getSubCategories()
							.get(ocData.getInitialSubCategory()).getManufacturers()
							.containsKey(ocData.getInitialManufacturer())) {
						if (elasticityProductHierarchy.getCategories().get(ocData.getCategory()).getSubCategories()
								.get(ocData.getInitialSubCategory()).getManufacturers()
								.get(ocData.getInitialManufacturer()).getBrands()
								.containsKey(ocData.getInitialBrand())) {
							if(ocData.initialSubBrand == null) {
								continue;
							}
							if (elasticityProductHierarchy.getCategories().get(ocData.getCategory()).getSubCategories()
									.get(ocData.getInitialSubCategory()).getManufacturers()
									.get(ocData.getInitialManufacturer()).getBrands().get(ocData.getInitialBrand())
									.getSubBrands().containsKey(ocData.getInitialSubBrand())) {
								if(ocData.initialTier == null) {
									continue;
								}
								if (elasticityProductHierarchy.getCategories().get(ocData.getCategory())
										.getSubCategories().get(ocData.getInitialSubCategory()).getManufacturers()
										.get(ocData.getInitialManufacturer()).getBrands().get(ocData.getInitialBrand())
										.getSubBrands().get(ocData.getInitialSubBrand()).getTiers()
										.containsKey(ocData.getInitialTier())) {
									if (elasticityProductHierarchy.getCategories().get(ocData.getCategory())
											.getSubCategories().get(ocData.getInitialSubCategory()).getManufacturers()
											.get(ocData.getInitialManufacturer()).getBrands()
											.get(ocData.getInitialBrand()).getSubBrands()
											.get(ocData.getInitialSubBrand()).getTiers().get(ocData.getInitialTier())
											.getPacks().containsKey(ocData.getInitialPack())) {
										elasticityProductHierarchy.getCategories().get(ocData.getCategory())
												.getSubCategories().get(ocData.getInitialSubCategory())
												.getManufacturers().get(ocData.getInitialManufacturer()).getBrands()
												.get(ocData.getInitialBrand()).getSubBrands()
												.get(ocData.getInitialSubBrand()).getTiers()
												.get(ocData.getInitialTier()).getPacks().get(ocData.getInitialPack())
												.add(EanUtility.formEanNumberDescriptionCombination(ocData.getEanInitial(), ocData.getEanDescriptionInitial()));
									} else {
										Set<String> eans = new HashSet<String>();
										eans.add(EanUtility.formEanNumberDescriptionCombination(ocData.getEanInitial(), ocData.getEanDescriptionInitial()));
										elasticityProductHierarchy.getCategories().get(ocData.getCategory())
												.getSubCategories().get(ocData.getInitialSubCategory())
												.getManufacturers().get(ocData.getInitialManufacturer()).getBrands()
												.get(ocData.getInitialBrand()).getSubBrands()
												.get(ocData.getInitialSubBrand()).getTiers()
												.get(ocData.getInitialTier()).getPacks()
												.put(ocData.getInitialPack(), eans);
									}
								} else {
									this.createNewTierDataInitialNode(elasticityProductHierarchy, ocData);
								}
							} else {
								this.createNewSubBrandInitialNode(elasticityProductHierarchy, ocData);
							}
						} else {
							this.createNewBrandInitialNode(elasticityProductHierarchy, ocData);
						}
					} else {
						this.createNewManufacturerInitialNode(elasticityProductHierarchy, ocData);
					}
				} else {
					this.createNewSubCategoryInitialNode(elasticityProductHierarchy, ocData);
				}
			} else {
				this.createNewCategoryIntialNode(elasticityProductHierarchy, ocData);
			}
		}
		return elasticityProductHierarchy;
	}

	// Creating INITIAL NODES in a hierarchical tree
	private void createNewCategoryIntialNode(ElasticityProductHierarchy elasticityProductHierarchy,
											 CrossOwnView view) {
		elasticityProductHierarchy.getCategories().put(view.getCategory(),
				this.createInitialSubCategory(elasticityProductHierarchy, view));
	}

	private void createNewSubCategoryInitialNode(ElasticityProductHierarchy elasticityProductHierarchy,
												 CrossOwnView view) {
		elasticityProductHierarchy.getCategories().get(view.getCategory()).getSubCategories().put(
				view.getInitialSubCategory(), this.createInitialManufacturer(elasticityProductHierarchy, view));
	}

	private void createNewManufacturerInitialNode(ElasticityProductHierarchy elasticityProductHierarchy,
												  CrossOwnView view) {
		elasticityProductHierarchy.getCategories().get(view.getCategory()).getSubCategories()
				.get(view.getInitialSubCategory()).getManufacturers()
				.put(view.getInitialManufacturer(), this.createInitialBrand(elasticityProductHierarchy, view));
	}

	private void createNewBrandInitialNode(ElasticityProductHierarchy elasticityProductHierarchy, CrossOwnView view) {
		elasticityProductHierarchy.getCategories().get(view.getCategory()).getSubCategories()
				.get(view.getInitialSubCategory()).getManufacturers().get(view.getInitialManufacturer()).getBrands()
				.put(view.getInitialBrand(), this.createInitialSubBrand(elasticityProductHierarchy, view));
	}

	private void createNewSubBrandInitialNode(ElasticityProductHierarchy elasticityProductHierarchy,
											  CrossOwnView view) {
		elasticityProductHierarchy.getCategories().get(view.getCategory()).getSubCategories()
				.get(view.getInitialSubCategory()).getManufacturers().get(view.getInitialManufacturer()).getBrands()
				.get(view.getInitialBrand()).getSubBrands()
				.put(view.getInitialSubBrand(), this.createInitialTierData(elasticityProductHierarchy, view));
	}

	private void createNewTierDataInitialNode(ElasticityProductHierarchy elasticityProductHierarchy,
											  CrossOwnView view) {
		elasticityProductHierarchy.getCategories().get(view.getCategory()).getSubCategories()
				.get(view.getInitialSubCategory()).getManufacturers().get(view.getInitialManufacturer()).getBrands()
				.get(view.getInitialBrand()).getSubBrands().get(view.getInitialSubBrand()).getTiers()
				.put(view.getInitialTier(), this.createInitialElasticityPack(elasticityProductHierarchy, view));
	}

	// Creating INITIAL Leaf Values in a tree
	private ElasticityPack createInitialElasticityPack(ElasticityProductHierarchy elasticityProductHierarchy,
			CrossOwnView view) {
		if(view.initialPack == null) {
			return null;
		}
		ElasticityPack elasticityPack = new ElasticityPack();
		elasticityPack.setPacks(new HashMap<String, Set<String>>());
		Set<String> eans = new HashSet<String>();
		eans.add(EanUtility.formEanNumberDescriptionCombination(view.getEanInitial(), view.getEanDescriptionInitial()));
		elasticityPack.getPacks().put(view.getInitialPack(), eans);
		return elasticityPack;
	}

	private TierData createInitialTierData(ElasticityProductHierarchy elasticityProductHierarchy, CrossOwnView ocData) {
		if(ocData.initialTier == null) {
			return null;
		}
		TierData tierData = new TierData();
		tierData.setTiers(new HashMap<String, ElasticityPack>());
		tierData.getTiers().put(ocData.getInitialTier(),
				this.createInitialElasticityPack(elasticityProductHierarchy, ocData));
		return tierData;
	}

	private ElasticitySubBrand createInitialSubBrand(ElasticityProductHierarchy elasticityProductHierarchy,
			CrossOwnView ocData) {
		if(ocData.initialSubBrand == null) {
			return null;
		}
		ElasticitySubBrand elasticitySubBrand = new ElasticitySubBrand();
		elasticitySubBrand.setSubBrands(new HashMap<String, TierData>());
		elasticitySubBrand.getSubBrands().put(ocData.getInitialSubBrand(),
				this.createInitialTierData(elasticityProductHierarchy, ocData));
		return elasticitySubBrand;
	}

	private ElasticityBrand createInitialBrand(ElasticityProductHierarchy elasticityProductHierarchy,
			CrossOwnView ocData) {
		if(ocData.initialBrand == null) {
			return null;
		}
		ElasticityBrand elasticityBrand = new ElasticityBrand();
		elasticityBrand.setBrands(new HashMap<String, ElasticitySubBrand>());
		elasticityBrand.getBrands().put(ocData.getInitialBrand(),
				this.createInitialSubBrand(elasticityProductHierarchy, ocData));
		return elasticityBrand;
	}

	private Manufacturer createInitialManufacturer(ElasticityProductHierarchy elasticityProductHierarchy,
			CrossOwnView ocData) {
		if(ocData.initialManufacturer == null) {
			return null;
		}
		Manufacturer manufacturer = new Manufacturer();
		manufacturer.setManufacturers(new HashMap<String, ElasticityBrand>());
		manufacturer.getManufacturers().put(ocData.getInitialManufacturer(),
				this.createInitialBrand(elasticityProductHierarchy, ocData));
		return manufacturer;
	}

	private ElasticitySubCategory createInitialSubCategory(ElasticityProductHierarchy elasticityProductHierarchy,
			CrossOwnView ocData) {
		if(ocData.initialSubCategory == null) {
			return null;
		}
		ElasticitySubCategory elasticitySubCategory = new ElasticitySubCategory();
		elasticitySubCategory.setSubCategories(new HashMap<String, Manufacturer>());
		elasticitySubCategory.getSubCategories().put(ocData.getInitialSubCategory(),
				this.createInitialManufacturer(elasticityProductHierarchy, ocData));
		return elasticitySubCategory;
	}

	public ElasticityProductHierarchy getTargetProductHierarchy(List<CrossOwnView> crossOwnViews) {

		ElasticityProductHierarchy elasticityProductHierarchy = new ElasticityProductHierarchy();
		Map<String, ElasticitySubCategory> categories = new HashMap<String, ElasticitySubCategory>();
		elasticityProductHierarchy.setCategories(categories);

		for (CrossOwnView ocData : crossOwnViews) {
			if (elasticityProductHierarchy.getCategories().containsKey(ocData.getCategory())) {
				if (elasticityProductHierarchy.getCategories().get(ocData.getCategory()).getSubCategories()
						.containsKey(ocData.getTargetSubCategory())) {
					if(ocData.targetManufacturer == null) {
						continue;
					}
					if (elasticityProductHierarchy.getCategories().get(ocData.getCategory()).getSubCategories()
							.get(ocData.getTargetSubCategory()).getManufacturers()
							.containsKey(ocData.getTargetManufacturer())) {
						if (elasticityProductHierarchy.getCategories().get(ocData.getCategory()).getSubCategories()
								.get(ocData.getTargetSubCategory()).getManufacturers()
								.get(ocData.getTargetManufacturer()).getBrands().containsKey(ocData.getTargetBrand())) {
							if(ocData.targetSubBrand == null) {
								continue;
							}
							if (elasticityProductHierarchy.getCategories().get(ocData.getCategory()).getSubCategories()
									.get(ocData.getTargetSubCategory()).getManufacturers()
									.get(ocData.getTargetManufacturer()).getBrands().get(ocData.getTargetBrand())
									.getSubBrands().containsKey(ocData.getTargetSubBrand())) {
								if(ocData.targetTier == null) {
									continue;
								}
								if (elasticityProductHierarchy.getCategories().get(ocData.getCategory())
										.getSubCategories().get(ocData.getTargetSubCategory()).getManufacturers()
										.get(ocData.getTargetManufacturer()).getBrands().get(ocData.getTargetBrand())
										.getSubBrands().get(ocData.getTargetSubBrand()).getTiers()
										.containsKey(ocData.getTargetTier())) {
									if (elasticityProductHierarchy.getCategories().get(ocData.getCategory())
											.getSubCategories().get(ocData.getTargetSubCategory()).getManufacturers()
											.get(ocData.getTargetManufacturer()).getBrands()
											.get(ocData.getTargetBrand()).getSubBrands().get(ocData.getTargetSubBrand())
											.getTiers().get(ocData.getTargetTier()).getPacks()
											.containsKey(ocData.getTargetPack())) {
										elasticityProductHierarchy.getCategories().get(ocData.getCategory())
												.getSubCategories().get(ocData.getTargetSubCategory())
												.getManufacturers().get(ocData.getTargetManufacturer()).getBrands()
												.get(ocData.getTargetBrand()).getSubBrands()
												.get(ocData.getTargetSubBrand()).getTiers().get(ocData.getTargetTier())
												.getPacks().get(ocData.getTargetPack()).add(EanUtility.formEanNumberDescriptionCombination(ocData.getEanTarget(), ocData.getEanDescriptionTarget()));
									} else {
										Set<String> eans = new HashSet<String>();
										eans.add(EanUtility.formEanNumberDescriptionCombination(ocData.getEanTarget(), ocData.getEanDescriptionTarget()));
										elasticityProductHierarchy.getCategories().get(ocData.getCategory())
												.getSubCategories().get(ocData.getTargetSubCategory())
												.getManufacturers().get(ocData.getTargetManufacturer()).getBrands()
												.get(ocData.getTargetBrand()).getSubBrands()
												.get(ocData.getTargetSubBrand()).getTiers().get(ocData.getTargetTier())
												.getPacks().put(ocData.getTargetPack(), eans);
									}
								} else {
									this.createNewTierDataTargetNode(elasticityProductHierarchy, ocData);
								}
							} else {
								this.createNewSubBrandTargetNode(elasticityProductHierarchy, ocData);
							}
						} else {
							this.createNewBrandTargetNode(elasticityProductHierarchy, ocData);
						}
					} else {
						this.createNewManufacturerTargetNode(elasticityProductHierarchy, ocData);
					}
				} else {
					this.createNewSubCategoryTargetNode(elasticityProductHierarchy, ocData);
				}
			} else {
				this.createNewCategoryTargetNode(elasticityProductHierarchy, ocData);
			}
		}
		return elasticityProductHierarchy;
	}

	// Creating TARGET NODES in a hierarchical tree
	private void createNewCategoryTargetNode(ElasticityProductHierarchy elasticityProductHierarchy,
											 CrossOwnView view) {
		elasticityProductHierarchy.getCategories().put(view.getCategory(),
				this.createTargetSubCategory(elasticityProductHierarchy, view));
	}

	private void createNewSubCategoryTargetNode(ElasticityProductHierarchy elasticityProductHierarchy,
												CrossOwnView view) {
		elasticityProductHierarchy.getCategories().get(view.getCategory()).getSubCategories()
				.put(view.getTargetSubCategory(), this.createTargetManufacturer(elasticityProductHierarchy, view));
	}

	private void createNewManufacturerTargetNode(ElasticityProductHierarchy elasticityProductHierarchy,
												 CrossOwnView view) {
		elasticityProductHierarchy.getCategories().get(view.getCategory()).getSubCategories()
				.get(view.getTargetSubCategory()).getManufacturers()
				.put(view.getTargetManufacturer(), this.createTargetBrand(elasticityProductHierarchy, view));
	}

	private void createNewBrandTargetNode(ElasticityProductHierarchy elasticityProductHierarchy, CrossOwnView view) {
		elasticityProductHierarchy.getCategories().get(view.getCategory()).getSubCategories()
				.get(view.getTargetSubCategory()).getManufacturers().get(view.getTargetManufacturer()).getBrands()
				.put(view.getTargetBrand(), this.createTargetSubBrand(elasticityProductHierarchy, view));
	}

	private void createNewSubBrandTargetNode(ElasticityProductHierarchy elasticityProductHierarchy,
											 CrossOwnView view) {
		elasticityProductHierarchy.getCategories().get(view.getCategory()).getSubCategories()
				.get(view.getTargetSubCategory()).getManufacturers().get(view.getTargetManufacturer()).getBrands()
				.get(view.getTargetBrand()).getSubBrands()
				.put(view.getTargetSubBrand(), this.createTargetTierData(elasticityProductHierarchy, view));
	}

	private void createNewTierDataTargetNode(ElasticityProductHierarchy elasticityProductHierarchy,
											 CrossOwnView view) {
		elasticityProductHierarchy.getCategories().get(view.getCategory()).getSubCategories()
				.get(view.getTargetSubCategory()).getManufacturers().get(view.getTargetManufacturer()).getBrands()
				.get(view.getTargetBrand()).getSubBrands().get(view.getTargetSubBrand()).getTiers()
				.put(view.getTargetTier(), this.createTargetElasticityPack(elasticityProductHierarchy, view));
	}

	// Creating TARGET Leaf Values in a tree
	private ElasticityPack createTargetElasticityPack(ElasticityProductHierarchy elasticityProductHierarchy,
			CrossOwnView ocData) {

		ElasticityPack elasticityPack = new ElasticityPack();
		elasticityPack.setPacks(new HashMap<String, Set<String>>());
		Set<String> eans = new HashSet<String>();
		eans.add(EanUtility.formEanNumberDescriptionCombination(ocData.getEanTarget(), ocData.getEanDescriptionTarget()));
		elasticityPack.getPacks().put(ocData.getTargetPack(), eans);
		return elasticityPack;
	}

	private TierData createTargetTierData(ElasticityProductHierarchy elasticityProductHierarchy, CrossOwnView ocData) {
		if(ocData.getTargetTier() == null) {
			return null;
		}
		TierData tierData = new TierData();
		tierData.setTiers(new HashMap<String, ElasticityPack>());
		tierData.getTiers().put(ocData.getTargetTier(),
				this.createTargetElasticityPack(elasticityProductHierarchy, ocData));
		return tierData;
	}

	private ElasticitySubBrand createTargetSubBrand(ElasticityProductHierarchy elasticityProductHierarchy,
			CrossOwnView ocData) {
		if(ocData.getTargetSubBrand() == null) {
			return null;
		}
		ElasticitySubBrand elasticitySubBrand = new ElasticitySubBrand();
		elasticitySubBrand.setSubBrands(new HashMap<String, TierData>());
		elasticitySubBrand.getSubBrands().put(ocData.getTargetSubBrand(), this.createTargetTierData(elasticityProductHierarchy, ocData));
		return elasticitySubBrand;
	}

	private ElasticityBrand createTargetBrand(ElasticityProductHierarchy elasticityProductHierarchy,
			CrossOwnView ocData) {

		ElasticityBrand elasticityBrand = new ElasticityBrand();
		elasticityBrand.setBrands(new HashMap<String, ElasticitySubBrand>());
		elasticityBrand.getBrands().put(ocData.getTargetBrand(),
				this.createTargetSubBrand(elasticityProductHierarchy, ocData));
		return elasticityBrand;
	}

	private Manufacturer createTargetManufacturer(ElasticityProductHierarchy elasticityProductHierarchy,
			CrossOwnView ocData) {
		if(ocData.targetManufacturer == null) {
			return null;
		}
		Manufacturer manufacturer = new Manufacturer();
		manufacturer.setManufacturers(new HashMap<String, ElasticityBrand>());
		manufacturer.getManufacturers().put(ocData.getTargetManufacturer(),
				this.createTargetBrand(elasticityProductHierarchy, ocData));
		return manufacturer;
	}

	private ElasticitySubCategory createTargetSubCategory(ElasticityProductHierarchy elasticityProductHierarchy,
			CrossOwnView ocData) {

		ElasticitySubCategory elasticitySubCategory = new ElasticitySubCategory();
		elasticitySubCategory.setSubCategories(new HashMap<String, Manufacturer>());
		elasticitySubCategory.getSubCategories().put(ocData.getTargetSubCategory(),
				this.createTargetManufacturer(elasticityProductHierarchy, ocData));
		return elasticitySubCategory;
	}
}
