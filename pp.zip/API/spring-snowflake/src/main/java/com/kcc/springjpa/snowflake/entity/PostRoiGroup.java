package com.kcc.springjpa.snowflake.entity;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class PostRoiGroup {
	
	public PostRoiGroup() {};

	public PostRoiGroup(String groupBy, double retailerMargin, double retailerMarginPercentage) {
		this.groupBy = groupBy;
		this.retailerMargin = retailerMargin;
		this.retailerMarginPercentage = retailerMarginPercentage;
	}

	public PostRoiGroup(Double netProfit, Double actualVolume, Double baselineVolume, Double promoInvestment) {
		this.netProfit = netProfit;
		this.totalVolume = actualVolume;
		this.baselineVolume = baselineVolume;
		this.promoInvestment = promoInvestment;
	}

	public PostRoiGroup(double promoProfit, double baselineProfit, double netProfit, double totalVolume,
						double baselineVolume, double promoInvestment, double retailerMargin) {
		super();
		this.promoProfit = promoProfit;
		this.baselineProfit = baselineProfit;
		this.netProfit = netProfit;
		this.totalVolume = totalVolume;
		this.baselineVolume = baselineVolume;
		this.promoInvestment = promoInvestment;
		this.retailerMargin = retailerMargin;
	}

	public PostRoiGroup(double retailerMarginPercentage) {
		super();
		this.retailerMarginPercentage = retailerMarginPercentage;
	}

	public PostRoiGroup(String groupBy,  double retailerMarginPercentage) {
		super();
		this.groupBy = groupBy;
		this.retailerMarginPercentage = retailerMarginPercentage;
	}

	public PostRoiGroup(String groupBy, int year,  double retailerMarginPercentage) {
		super();
		this.groupBy = groupBy;
		this.year = year;
		this.retailerMarginPercentage = retailerMarginPercentage;
	}
	
	public PostRoiGroup(String groupBy, double promoProfit, double baselineProfit, double netProfit, double totalVolume,
						double baselineVolume, double promoInvestment, double cogs, double npp, double groupByTotalVolume, double retailerMargin) {
		super();
		this.groupBy = groupBy;
		this.promoProfit = promoProfit;
		this.baselineProfit = baselineProfit;
		this.netProfit = netProfit;
		this.totalVolume = totalVolume;
		this.baselineVolume = baselineVolume;
		this.promoInvestment = promoInvestment;
		this.cogs = cogs;
		this.npp = npp;
		this.groupByTotalVolume = groupByTotalVolume;
		this.retailerMargin = retailerMargin;
	}

	public PostRoiGroup(String groupBy, double promoProfit, double baselineProfit, double netProfit, double totalVolume,
						double baselineVolume, double promoInvestment, double cogs, double npp, double groupByTotalVolume, double retailerMargin,
						long duration, double pricePoint) {
		super();
		this.groupBy = groupBy;
		this.promoProfit = promoProfit;
		this.baselineProfit = baselineProfit;
		this.netProfit = netProfit;
		this.totalVolume = totalVolume;
		this.baselineVolume = baselineVolume;
		this.promoInvestment = promoInvestment;
		this.cogs = cogs;
		this.npp = npp;
		this.groupByTotalVolume = groupByTotalVolume;
		this.retailerMargin = retailerMargin;
		this.duration = duration;
		this.pricePoint = pricePoint;
	}
	
	public PostRoiGroup(int groupByNum, double promoProfit, double baselineProfit, double netProfit, double totalVolume,
						double baselineVolume, double promoInvestment, double cogs, double npp, double groupByTotalVolume, double retailerMargin) {
		super();
		this.groupByNum = groupByNum;
		this.promoProfit = promoProfit;
		this.baselineProfit = baselineProfit;
		this.netProfit = netProfit;
		this.totalVolume = totalVolume;
		this.baselineVolume = baselineVolume;
		this.promoInvestment = promoInvestment;
		this.cogs = cogs;
		this.npp = npp;
		this.groupByTotalVolume = groupByTotalVolume;
		this.retailerMargin = retailerMargin;
	}

	/**
	 * @param groupByNum When Week is selected by user for group by
	 * */
	public PostRoiGroup(int groupByNum,  double retailerMarginPercentage) {
		super();
		this.groupByNum = groupByNum;
		this.retailerMarginPercentage = retailerMarginPercentage;
	}

	/**
	 * @param groupByNum When Month is selected by user for group by
	 * */
	public PostRoiGroup(int groupByNum,  int year,  double retailerMarginPercentage) {
		super();
		this.groupByNum = groupByNum;
		this.year = year;
		this.retailerMarginPercentage = retailerMarginPercentage;
	}

	/**
	 * @param month When Month is selected by user for group by
	 * */
	public PostRoiGroup(int month,  int year,  double retailerMargin, double retailerMarginPercentage) {
		super();
		this.groupByNum = month;
		this.year = year;
		this.retailerMargin = retailerMargin;
		this.retailerMarginPercentage = retailerMarginPercentage;
	}

	/**
	 * @param week When Month is selected by user for group by
	 * */
	public PostRoiGroup(int week,  double retailerMargin, double retailerMarginPercentage) {
		super();
		this.groupByNum = week;
		this.retailerMargin = retailerMargin;
		this.retailerMarginPercentage = retailerMarginPercentage;
	}

	/**
	 * @param duration When Duration is selected by user for group by
	 * */
	public PostRoiGroup(long duration,  double retailerMarginPercentage) {
		super();
		this.groupBy = String.valueOf(duration);
		this.retailerMarginPercentage = retailerMarginPercentage;
	}

	/**
	 * @param pricePoint When Price Point is selected by user for group by
	 * */
	public PostRoiGroup(double pricePoint,  double retailerMarginPercentage) {
		super();
		this.groupBy = String.valueOf(pricePoint);
		this.retailerMarginPercentage = retailerMarginPercentage;
	}

	public PostRoiGroup(int groupByNum, int year, double promoProfit, double baselineProfit, double netProfit, double totalVolume,
						double baselineVolume, double promoInvestment, double cogs, double npp, double groupByTotalVolume, double retailerMargin) {
		super();
		this.groupByNum = groupByNum;
		this.year = year;
		this.promoProfit = promoProfit;
		this.baselineProfit = baselineProfit;
		this.netProfit = netProfit;
		this.totalVolume = totalVolume;
		this.baselineVolume = baselineVolume;
		this.promoInvestment = promoInvestment;
		this.cogs = cogs;
		this.npp = npp;
		this.groupByTotalVolume = groupByTotalVolume;
		this.retailerMargin = retailerMargin;
	}

	private int groupByNum;
	
	private int year;
	
	private String groupBy;

	private double promoProfit;
	
	private double baselineProfit;
	
	private Double netProfit;
	
	private Double totalVolume;
	
	private Double baselineVolume;
	
	private Double promoInvestment;
	
	private double cogs;
	
	private double npp;
	
	private double groupByTotalVolume;

	private double retailerMargin;

	private double retailerMarginPercentage;

	private double pricePoint;

	private long duration;

	private List<Object> mechanic, feature;
}
