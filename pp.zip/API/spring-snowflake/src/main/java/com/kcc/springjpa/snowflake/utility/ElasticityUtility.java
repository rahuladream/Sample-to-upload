package com.kcc.springjpa.snowflake.utility;

public class ElasticityUtility {
	
	public static String getRange(boolean forOwn, Float elasticity, boolean forKorea) {
		if(forKorea) return getRangeForKR(elasticity, forOwn);
		if(elasticity < -4) {
			return "HIGH";				
		} else if(elasticity >= -4 && elasticity <= -2.5) {
			return "MEDIUM";
		}else {
			return "LOW";
		}
	}

	public static String getRangeForKR(Float elasticity, boolean forOwn) {
		String range = forOwn ? "HIGH" : "LOW";
		if (elasticity < -2.0) { range = forOwn ? "HIGH" : "LOW";
		} else if (elasticity <= -1.0) { range = "MEDIUM";
		} else if (elasticity <= 0.0 || elasticity >= 0.0) { range = forOwn ? "LOW" : "HIGH";
		}
		return range;
	}
}
