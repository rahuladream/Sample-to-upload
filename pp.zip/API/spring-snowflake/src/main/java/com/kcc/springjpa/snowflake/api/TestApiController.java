package com.kcc.springjpa.snowflake.api;

import com.kcc.springjpa.snowflake.model.BaseLineDataModel;
import com.kcc.springjpa.snowflake.model.TestData;
import com.kcc.springjpa.snowflake.service.BaseLineDataService;

import com.kcc.springjpa.snowflake.service.TestDataService;
import com.kcc.springjpa.snowflake.utility.ImpactorTests;
import com.kcc.springjpa.snowflake.utility.PreRoiTests;
import com.kcc.springjpa.snowflake.utility.StringResponse;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import java.util.ArrayList;
import java.util.List;

@Controller
public class TestApiController implements TestApi {
	
	private static final Logger logger = LogManager.getLogger(TestApiController.class);
	
	@Autowired
    BaseLineDataService baseLineDataService;

	@Autowired
	ImpactorTests impactorTests;

	@Autowired
	TestDataService testDataService;

	@Autowired
	PreRoiTests preRoiTests;

	@Override
	public ResponseEntity<StringResponse> initialTestRun() throws Exception {
		logger.info("Starting Initial Test Run ----------> " + java.time.LocalDateTime.now());
		
		StringResponse sr = new StringResponse();
		String message = "";
		List<Integer> years = new ArrayList<Integer>();
		years.add(2021);
		List<BaseLineDataModel> baseLineDataModels = baseLineDataService.getBaseLineData("XX", years, "weekly", null, null, null, null, null, null, null);
		for(BaseLineDataModel bdm : baseLineDataModels) {
			bdm.getStatisticalBaseLine().getTotalQuantity();
			if(bdm.getStatisticalBaseLine().getTotalQuantity().intValue() == bdm.getAdjustedBaseLine().getTotalQuantity().intValue()) {
				message = "Total Quantity is same for Statistical And Adjusted for XX Country :: Test Passed";
			} else {
				message = "Total Quantity is NOT same for Statistical And Adjusted for XX Country :: Test Failed";
			}
		}

		message += "<br/>";
		message += impactorTests.run();
		message += "<br/>----------------------------------------------<br/>";
		message += preRoiTests.run();

		sr.setResponse(message);

		return new ResponseEntity<>(sr, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<TestData>> dataTest() throws Exception {
		List<TestData> result =  testDataService.runDataTests();
		return new ResponseEntity<>(result, HttpStatus.OK);
	}
}
