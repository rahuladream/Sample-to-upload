package com.kcc.springjpa.snowflake.service;

import java.sql.SQLException;

import com.kcc.springjpa.snowflake.model.OktaApiAuthenticator;
import com.kcc.springjpa.snowflake.utility.StringResponse;

public interface OktaService {
	
	public StringResponse validateAccessToken(String accessToken) throws SQLException, Exception;

	public StringResponse validateIdToken(String idToken) throws Exception;
	
	public OktaApiAuthenticator generateAuthenticateToken(String accessToken, String idToken) throws Exception;

}
