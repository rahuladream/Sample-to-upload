package com.kcc.springjpa.snowflake.dao.impl;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.kcc.springjpa.snowflake.dtos.GetElasticitiesRequest;
import com.kcc.springjpa.snowflake.dtos.LineFittingDataPoint;
import com.kcc.springjpa.snowflake.entity.OwnCrossCategory;
import com.kcc.springjpa.snowflake.entity.OwnCrossCommonFields;
import com.kcc.springjpa.snowflake.model.CrossOwnView;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.kcc.springjpa.snowflake.configuration.DBConfig;
import com.kcc.springjpa.snowflake.dao.ElasticityDao;
import com.kcc.springjpa.snowflake.utility.HierarchyLevel;

import net.snowflake.client.jdbc.internal.amazonaws.util.StringUtils;

@Repository
public class ElasticityDaoImpl implements ElasticityDao {
	
	private static final Logger logger = LogManager.getLogger(ElasticityDaoImpl.class);

	@Autowired
	DBConfig dbConfig;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Map<String , Boolean> isViewMoreOwn(String country, List<String> initialLeafValues,
			String levelIndicator) throws Exception {
		
		logger.info("Database call to verify OWN view more Data from POWER BI table " + levelIndicator);
		Connection conn = dbConfig.getJdbcConnection();
		
		Map<String , Boolean> leafMap = new HashMap<>();
		String leafNode = "";	
		if (levelIndicator.equals(HierarchyLevel.SUB_CATEGORY)) {
			leafNode = "SUB_CATEGORY_INITIAL";
		} else if (levelIndicator.equals(HierarchyLevel.BRAND)) {
			leafNode = "BRAND_INITIAL";
		} else if (levelIndicator.equals(HierarchyLevel.SUB_BRAND)) {
			leafNode = "SUB_BRAND_INITIAL";
		} else if (levelIndicator.equals(HierarchyLevel.PACK)) {
			leafNode = "PACK_INITIAL";
		} else if (levelIndicator.equals(HierarchyLevel.EAN)) {
			leafNode = "EAN_INITIAL";
		} else {
			throw new Exception("Unexpected hierarchy level :: " + levelIndicator);
		}
		
		StringBuilder builder = new StringBuilder();
		for( int i = 0 ; i < initialLeafValues.size(); i++ ) {
		    builder.append("?,");
		}

		String viewName = "V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS";
		if(levelIndicator.equals(HierarchyLevel.SUB_BRAND)) {
			viewName = "V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS_SUB_BRAND";
		}
		String placeHolders =  builder.deleteCharAt( builder.length() -1 ).toString();		
		String sql = "SELECT " + leafNode + ", SUM(Price_PI) AS PRICE_PI, SUM(Volume_VI) AS VOLUME_VI from RGM_ADV_ANLTCS.REPORTING.viewName "
				+ "where country = ? and " + leafNode + " IN ("+ placeHolders + ") GROUP BY " + leafNode;
		sql = sql.replace("viewName", viewName);
		if (conn != null) {
			try {
				PreparedStatement stat = conn.prepareStatement(sql);
				stat.setString(1, country);
				int index = 2;
				for( String s : initialLeafValues ) {
					stat.setObject(  index++, s ); // or whatever it applies 
				}
				ResultSet res = stat.executeQuery();
									
				while (res.next()) {
					if(res.getString("PRICE_PI") != null || res.getString("VOLUME_VI") != null) {
						leafMap.put(res.getString(leafNode), true);
					} else {
						leafMap.put(res.getString(leafNode), false);
					}
				}
				logger.info("Own view more data verified with data size " + leafMap.size());
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				conn.close();
			}
		}
		return leafMap;
	}

	@Override
	public boolean isViewMoreCross(String country, String initialLeafValue, String targetLeafValue,
			String levelIndicator) throws Exception {

		logger.info("Database call to verify OWN view more Data from POWER BI table " + levelIndicator);
		
		boolean isViewMore = false;
		String initialLeafNode = "";
		String targetLeafNode = "";
		String tableName = "";
		if (levelIndicator.equals(HierarchyLevel.SUB_CATEGORY)) {
			initialLeafNode = "SUB_CATEGORY_INITIAL";
			targetLeafNode = "SUB_CATEGORY_TARGET";
			tableName = "RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS";
		} else if (levelIndicator.equals(HierarchyLevel.BRAND)) {
			initialLeafNode = "BRAND_INITIAL";
			targetLeafNode = "BRAND_TARGET";
			tableName = "RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS";
		} else if (levelIndicator.equals(HierarchyLevel.SUB_BRAND)) {
			initialLeafNode = "SUB_BRAND_INITIAL";
			targetLeafNode = "SUB_BRAND_TARGET";
			tableName = "RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS_SUB_BRAND";
		} else if (levelIndicator.equals(HierarchyLevel.PACK)) {
			initialLeafNode = "PACK_INITIAL";
			targetLeafNode = "PACK_TARGET";
			tableName = "RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS";
		} else if (levelIndicator.equals(HierarchyLevel.EAN)) {
			initialLeafNode = "EAN_INITIAL";
			targetLeafNode = "EAN_TARGET";
			tableName = "RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS";
		} else {
			throw new Exception("Unexpected hierarchy level :: " + levelIndicator);
		}
		
		Connection conn = dbConfig.getJdbcConnection();
		String sql = "SELECT SUM(Price_PI) AS PRICE_PI, SUM(Volume_VI) AS VOLUME_VI from " + tableName
				+ " where country = ? and " + initialLeafNode + " = ? and " + targetLeafNode + " = ?";
		if (conn != null) {
			try {
				PreparedStatement stat = conn.prepareStatement(sql);
				stat.setString(1, country);
				stat.setString(2, initialLeafValue);
				stat.setString(3, targetLeafValue);
				ResultSet res = stat.executeQuery();
									
				while (res.next()) {
					if(res.getString("PRICE_PI") != null || res.getString("VOLUME_VI") != null) {
						isViewMore = true;
					} else {
						isViewMore = false;
					}
				}
				logger.info("Cross view more data verified ");
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				conn.close();
			}
		}
		return isViewMore;
	}

	@Override
	public boolean scopeExists(String country, String category, String scope, String levelIndicator, String source) throws Exception {
		String tn = tableName(levelIndicator);
		boolean exists = false;
		try(Connection c = dbConfig.getJdbcConnection()) {
			String sql = "SELECT COUNT(type) ScopeCount " +
					"FROM RGM_ADV_ANLTCS.REPORTING.table_name " +
					"WHERE country = ? AND type = ? AND category = ? AND source = ?";
			sql = sql.replace("table_name", tn);
			PreparedStatement ps = c.prepareStatement(sql);
			ps.setString(1, country);
			ps.setString(2, scope);
			ps.setString(3, category);
			ps.setString(4, source);

			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				exists = rs.getInt("ScopeCount") > 0;
			}
		} catch (SQLException e) {
			logger.error(e.getMessage(), e);
		}
		return exists;
	}

	private String tableName(String levelIndicator) throws Exception {
		String t = null;
		switch (levelIndicator) {
			case HierarchyLevel.SUB_CATEGORY:
				t = "V_RGM_SLS_FCT_DATA_CROSS_OWN_SUB_CATEGORY";
				break;
			case HierarchyLevel.BRAND:
				 t = "V_RGM_SLS_FCT_DATA_CROSS_OWN_BRAND";
				break;
			case HierarchyLevel.SUB_BRAND:
				t = "V_RGM_SLS_FCT_DATA_CROSS_OWN_SUB_BRAND";
				break;
			case HierarchyLevel.PACK:
				t = "V_RGM_SLS_FCT_DATA_CROSS_OWN_PACK";
				break;
			case HierarchyLevel.EAN:
				t = "V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN";
				break;
		}
		if(t == null) {
			throw new Exception("Unexpected hierarchy level :: " + levelIndicator);
		}
		return t;
	}

	@Override
	public List<String> getAvailableSources(String country, String productLevel) throws Exception {
		String tn = tableName(productLevel);
		List<String> sources = new ArrayList<>();
		try (Connection c = dbConfig.getJdbcConnection()) {
			String sql = "select distinct source " +
					"from RGM_ADV_ANLTCS.REPORTING.tn where country = ?".replace("tn", tn);
			PreparedStatement s = c.prepareStatement(sql);
			s.setString(1, country);
			ResultSet rs = s.executeQuery();
			while (rs.next()) {
				sources.add(rs.getString(1));
			}
		} catch (SQLException e) {
			throw new Exception("Could not query for sources", e);
		}
		return sources;
	}

	@Override
	public String lastModelUpdateDate(String country) throws Exception {
		try(Connection c = dbConfig.getJdbcConnection()) {
			String sql = "SELECT top 1 MODEL_RUN " +
					"FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN " +
					"WHERE country = ? AND MODEL_RUN is not null";
			PreparedStatement ps = c.prepareStatement(sql);
			ps.setString(1, country);

			ResultSet rs = ps.executeQuery();
			String result = null;
			while(rs.next()) {
				result = rs.getString("MODEL_RUN");
			}
			return result;

		} catch (SQLException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	@Override
	public List<LineFittingDataPoint> getLineFittingDataPoints(String country, String initial, String target, String productLevel, String customer) {
		List<LineFittingDataPoint> data = new ArrayList<>();
		try (Connection c = dbConfig.getJdbcConnection()) {
			String viewName = "V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS";
			if(productLevel.equals(HierarchyLevel.SUB_BRAND)) {
				viewName = "V_RGM_SLS_FCT_DATA_PROFIT_PARABOLA_MS_SUB_BRAND";
			}
			String sql = "SELECT WEEK, columnsToSelect" +
					"FROM RGM_ADV_ANLTCS.REPORTING.viewName " +
					"WHERE " +
					"country = ? ";
			sql = sql.replace("viewName", viewName);

			boolean kr = country.equalsIgnoreCase("KR");
			if(kr) {
				sql = sql.replace("columnsToSelect", " LOG_PRICE_PI, LOG_VOLUME_VI ");
			} else {
				sql = sql.replace("columnsToSelect", " PRICE_PI, VOLUME_VI ");
			}
			switch (productLevel) {
				case "PACK":
					sql += " AND PACK_INITIAL = ?";
					break;
				case "SUB_BRAND":
					sql += " AND SUB_BRAND_INITIAL = ?";
					break;
				default:
					sql += " AND EAN_INITIAL = ?";
					break;
			}
			if (target != null) {
				switch (productLevel) {
					case "PACK":
						sql += " AND PACK_TARGET = ?";
						break;
					case "SUB_BRAND":
						sql += " AND SUB_BRAND_TARGET = ?";
						break;
					default:
						sql += " AND EAN_TARGET = ?";
						break;
				}
			}
			if(kr && customer != null && !customer.isEmpty()) {
				sql += " AND UPPER(customer) = ?";
			}
			PreparedStatement ps = c.prepareStatement(sql);
			ps.setString(1, country);
			ps.setString(2, initial);
			if (target != null) {
				ps.setString(3, target);
			}
			if(kr && customer != null && !customer.isEmpty()) {
				if(target == null) {
					ps.setString(3, customer);
				} else {
					ps.setString(4, customer);
				}
			}
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				String yearWeek = String.valueOf(rs.getInt(1));
				int year = Integer.parseInt(yearWeek.substring(0, 4));
				int week = Integer.parseInt(yearWeek.substring(4));

				LineFittingDataPoint d = new LineFittingDataPoint();
				d.year = year;
				d.week = week;
				d.price = rs.getFloat(2);
				d.volume = rs.getFloat(3);

				data.add(d);
			}
		} catch (SQLException e) {
			logger.error("", e);
		}
		return data;
	}
	
	@Override
	public List<CrossOwnView> findByInitials(String country, List<String> leafValues, String scope, String source, String flag, boolean initial) throws Exception {
		List<CrossOwnView> views = new ArrayList<>();
		try(Connection c = dbConfig.getJdbcConnection()) {
			
			String sql = "SELECT * FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_SUB_BRAND " +
			"WHERE COUNTRY = ? AND FLAG = ? AND TYPE = ? AND SOURCE = ?";
			if (!CollectionUtils.isEmpty(leafValues)) {
				StringBuilder builder = new StringBuilder();
				for (int i = 0; i < leafValues.size(); i++) {
					builder.append("?,");
				}
				String placeHolders = builder.deleteCharAt(builder.length() - 1).toString();
				sql = sql + " AND SUB_BRAND_INITIAL IN (" + placeHolders + ")";
			}
			
			PreparedStatement ps = c.prepareStatement(sql);
			ps.setString(1, country);
			ps.setString(2, flag);
			
			if (StringUtils.isNullOrEmpty(scope)) {
				scope = "WC";
			}
			if (StringUtils.isNullOrEmpty(source)) {
				source = "NIELSEN";
			}
			
			ps.setString(3, scope);
			ps.setString(4, source);
			int index =5;
			if (!CollectionUtils.isEmpty(leafValues)) {
				for (String o : leafValues) {
					ps.setString(index++, o);
				}
			}

			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				CrossOwnView v = new CrossOwnView();
				if(initial) {
					v.setCategory(rs.getString("CATEGORY"));
					v.setInitialSubCategory(rs.getString("SUB_CATEGORY_INITIAL"));
					v.setInitialManufacturer(rs.getString("MANUFACTURER_INITIAL"));
					v.setInitialBrand(rs.getString("BRAND_INITIAL"));
					v.setInitialSubBrand(rs.getString("SUB_BRAND_INITIAL"));
				} else {
					v.setCategory(rs.getString("CATEGORY"));
					v.setTargetSubCategory(rs.getString("SUB_CATEGORY_TARGET"));
					v.setTargetManufacturer(rs.getString("MANUFACTURER_TARGET"));
					v.setTargetBrand(rs.getString("BRAND_TARGET"));
					v.setTargetSubBrand(rs.getString("SUB_BRAND_TARGET"));
				}				
				views.add(v);
			}
			return views;
		} catch (SQLException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	@Override
	public <SnowT extends OwnCrossCommonFields> List<SnowT> products(String country,
																					 String flag,
																					 String type,
																					 List<String> initialLeafValues,
																					 List<String> targetLeafValues,
																					 String source,
																					 String category,
																					 List<String> initialSubCategories,
																					 List<String> targetSubCategories,
																					 List<String> initialManufacturers,
																					 List<String> targetManufacturers,
																					 List<String> initialBrands,
																					 List<String> targetBrands,
																					 List<String> initialSubBrands,
																					 List<String> targetSubBrands,
																					 List<String> initialPacks,
																					 List<String> targetPacks,
																					 String productLevel,
																				     Class<SnowT> clazz) throws Exception {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<SnowT> cq = cb.createQuery(clazz);
		Root<SnowT> root = cq.from(clazz);

		Predicate predicate = cb.equal(root.get("country"), country);
		predicate = cb.and(predicate, cb.equal(root.get("flag"), flag));
		predicate = cb.and(predicate, cb.equal(root.get("type"), type));
		predicate = cb.and(predicate, cb.equal(root.get("source"), source));
		if (!StringUtils.isNullOrEmpty(category)) {
			predicate = cb.and(predicate, cb.equal(root.get("category"), category));
		}

		if (!CollectionUtils.isEmpty(initialManufacturers)) {
			predicate = cb.and(predicate, root.get("initialManufacturer").in(initialManufacturers));
		}
		if (!CollectionUtils.isEmpty(targetManufacturers)) {
			predicate = cb.and(predicate, root.get("targetManufacturer").in(targetManufacturers));
		}
		if (!CollectionUtils.isEmpty(initialSubCategories)) {
			predicate = cb.and(predicate, root.get("initialSubCategory").in(initialSubCategories));
		}
		if (!CollectionUtils.isEmpty(targetSubCategories)) {
			predicate = cb.and(predicate, root.get("targetSubCategory").in(targetSubCategories));
		}
		if (!CollectionUtils.isEmpty(initialBrands)) {
			predicate = cb.and(predicate, root.get("initialBrand").in(initialBrands));
		}
		if (!CollectionUtils.isEmpty(targetBrands)) {
			predicate = cb.and(predicate, root.get("targetBrand").in(targetBrands));
		}
		if (productLevel.equalsIgnoreCase("ean") ||
				productLevel.equalsIgnoreCase("pack")) {
			if (!CollectionUtils.isEmpty(initialSubBrands)) {
				predicate = cb.and(predicate, root.get("initialSubBrand").in(initialSubBrands));
			}
			if (!CollectionUtils.isEmpty(targetSubBrands)) {
				predicate = cb.and(predicate, root.get("targetSubBrand").in(targetSubBrands));
			}
		}
		if (productLevel.equalsIgnoreCase("ean")) {
			if (!CollectionUtils.isEmpty(initialLeafValues)) {
				predicate = cb.and(predicate, root.get("eanInitial").in(initialLeafValues));
			}
			if (!CollectionUtils.isEmpty(targetLeafValues)) {
				predicate = cb.and(predicate, root.get("eanTarget").in(targetLeafValues));
			}
		} else if (productLevel.equalsIgnoreCase("pack")) {
			if (!CollectionUtils.isEmpty(initialLeafValues)) {
				predicate = cb.and(predicate, root.get("initialPack").in(initialLeafValues));
			}
			if (!CollectionUtils.isEmpty(targetLeafValues)) {
				predicate = cb.and(predicate, root.get("targetPack").in(targetLeafValues));
			}
		} else if (productLevel.equalsIgnoreCase("sub_brand")) {
			if (!CollectionUtils.isEmpty(initialLeafValues)) {
				predicate = cb.and(predicate, root.get("initialSubBrand").in(initialLeafValues));
			}
			if (!CollectionUtils.isEmpty(targetLeafValues)) {
				predicate = cb.and(predicate, root.get("targetSubBrand").in(targetLeafValues));
			}
		}
		cq.where(predicate);

		return entityManager.createQuery(cq).getResultList();
	}

	@Override
	public List<OwnCrossCategory> categories(String country, String flag, String type, String source, String category) {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<OwnCrossCategory> cq = cb.createQuery(OwnCrossCategory.class);
		Root<OwnCrossCategory> root = cq.from(OwnCrossCategory.class);

		Predicate predicate = cb.equal(root.get("country"), country);
		predicate = cb.and(predicate, cb.equal(root.get("flag"), flag));
		predicate = cb.and(predicate, cb.equal(root.get("type"), type));
		predicate = cb.and(predicate, cb.equal(root.get("source"), source));
		if (!StringUtils.isNullOrEmpty(category)) {
			predicate = cb.and(predicate, cb.equal(root.get("category"), category));
		}
		cq.where(predicate);

		return entityManager.createQuery(cq).getResultList();
	}

	@Override
	public <SnowT extends OwnCrossCommonFields> List<SnowT> elasticitiesForDownload(GetElasticitiesRequest r, Class<SnowT> clazz) throws Exception {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<SnowT> cq = cb.createQuery(clazz);
		Root<SnowT> root = cq.from(clazz);

		Predicate predicate = cb.equal(root.get("country"), r.country);
		predicate = cb.and(predicate, cb.equal(root.get("flag"), r.forOwn ? HierarchyLevel.OWN : HierarchyLevel.CROSS));
		predicate = cb.and(predicate, cb.equal(root.get("type"), r.scope));
		predicate = cb.and(predicate, cb.equal(root.get("source"), r.source));

		if (!StringUtils.isNullOrEmpty(r.category)) {
			predicate = cb.and(predicate, cb.equal(root.get("category"), r.category));
		}
		if (!CollectionUtils.isEmpty(r.initialManufacturers)) {
			predicate = cb.and(predicate, root.get("initialManufacturer").in(r.initialManufacturers));
		}
		if (!CollectionUtils.isEmpty(r.targetManufacturers)) {
			predicate = cb.and(predicate, root.get("targetManufacturer").in(r.targetManufacturers));
		}
		if (!CollectionUtils.isEmpty(r.subCategories)) {
			predicate = cb.and(predicate, root.get("initialSubCategory").in(r.subCategories));
		}
		if (!CollectionUtils.isEmpty(r.initialBrands)) {
			predicate = cb.and(predicate, root.get("initialBrand").in(r.initialBrands));
		}
		if (!CollectionUtils.isEmpty(r.targetBrands)) {
			predicate = cb.and(predicate, root.get("targetBrand").in(r.targetBrands));
		}
		if (!CollectionUtils.isEmpty(r.initialSubBrands)) {
			predicate = cb.and(predicate, root.get("initialSubBrand").in(r.initialSubBrands));
		}
		if (!CollectionUtils.isEmpty(r.targetSubBrands)) {
			predicate = cb.and(predicate, root.get("targetSubBrand").in(r.targetSubBrands));
		}
		if (!CollectionUtils.isEmpty(r.initialPacks)) {
			predicate = cb.and(predicate, root.get("initialPack").in(r.initialPacks));
		}
		if (!CollectionUtils.isEmpty(r.targetPacks)) {
			predicate = cb.and(predicate, root.get("targetPack").in(r.targetPacks));
		}
		String initialNode = null, targetNode = null;
		switch (r.hierarchyLevel) {
			case HierarchyLevel.BRAND:
				initialNode = "initialBrand";
				targetNode = "targetBrand";
				break;
			case HierarchyLevel.SUB_BRAND:
				initialNode = "initialSubBrand";
				targetNode = "targetSubBrand";
				break;
			case HierarchyLevel.PACK:
				initialNode = "initialPack";
				targetNode = "targetPack";
				break;
			case HierarchyLevel.EAN:
				initialNode = "eanInitial";
				targetNode = "eanTarget";
				break;
		}
		if(initialNode != null && !CollectionUtils.isEmpty(r.initialNodeValues)) {
			predicate = cb.and(predicate, root.get(initialNode).in(r.initialNodeValues));
		}
		if(!r.forOwn && targetNode != null && !CollectionUtils.isEmpty(r.targetNodeValues)) {
			predicate = cb.and(predicate, root.get(targetNode).in(r.targetNodeValues));
		}
		cq.where(predicate);

		return entityManager.createQuery(cq).getResultList();
	}
}
