package com.kcc.springjpa.snowflake.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.kcc.springjpa.snowflake.model.BaseLineDataModel;
import com.kcc.springjpa.snowflake.model.CustomerHierarchy;
import com.kcc.springjpa.snowflake.model.ProductHierarchy;


public interface BaseLineDataService {
	
	public CustomerHierarchy getCustomerHierarchy(String country, List<String> source, String feature) throws Exception;
	
	public ProductHierarchy getProductHierarchy(String country) throws SQLException;
	
	public List<String> getCountriesList() throws SQLException;
	
	public List<BaseLineDataModel> getBaseLineData(String country, List<Integer> years, String granularity, List<String> planLevels, List<String> customers, List<String> categories,
			List<String> subCategories, List<String> brands, List<String> subBrands, List<String> eans) throws SQLException;

	Map<String, Boolean> dailyAvailable(String country);
}
