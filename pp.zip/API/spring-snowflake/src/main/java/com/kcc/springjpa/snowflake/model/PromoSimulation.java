package com.kcc.springjpa.snowflake.model;

import java.util.List;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class PromoSimulation {
	
	private String country;

	private String name;

	private List<String> categories;
	
	private List<String> subCategories;
	
	private List<String> brands;
	
	private List<String> subBrands;
	
	private List<String> eans;
	
	private List<String> planLevels;
	
	private List<String> customers;

	private String fromDate;

	private String toDate;

	private Float baseline;

	private Integer incrementalVolume;

	private Integer totalVolume;

	private Float totalInvestment;

	private List<String> promoInvestmentAbsValues;
	
	private List<String> promoInvestmentNonAbsValues;
	
	private Float npp;
	
	private Float cogs;

	private Float targetRoi;

	private Float roiPercent;

	private Float netProfit;

}
