package com.kcc.springjpa.snowflake.model;

import java.util.Date;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class ImpactorInfoModel {
	
	public String createdBy;
	
	public Date createdOn;
	
	public String deletedBy;
	
	public Date deletedOn;
	
	public String country;
	
	public String planLevels;
	
	public String soldTo;
	
	public String categories;
	
	public String subCategories;
	
	public String brands;
	
	public String subBrands;
	
	public String eans;
	
	public float absValue;
	
	public boolean isAbs;

}
