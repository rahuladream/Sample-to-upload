package com.kcc.springjpa.snowflake.model;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class BaseLineCustomerModel {
	
    private String distrChannelDesc;
    
    private String salesOffice;
    
    private String planLevel;
    
    private String soldToDesc;

}
