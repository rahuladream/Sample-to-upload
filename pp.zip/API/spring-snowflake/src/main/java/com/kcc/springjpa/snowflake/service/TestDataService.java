package com.kcc.springjpa.snowflake.service;

import com.kcc.springjpa.snowflake.model.TestData;

import java.util.List;

public interface TestDataService {
    public List<TestData> runDataTests();
}
