package com.kcc.springjpa.snowflake.dtos;

import java.util.List;

public class CountryMaster {

    public String country;
    public List<ProductLocator> productLocators;
}
