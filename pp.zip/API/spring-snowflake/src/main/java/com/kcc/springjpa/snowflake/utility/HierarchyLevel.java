package com.kcc.springjpa.snowflake.utility;

public class HierarchyLevel {
	
	public static final String CATEGORY = "CATEGORY";
	
	public static final String SUB_CATEGORY = "SUB_CATEGORY";
	
	public static final String MANUFACTURER = "MANUFACTURER";
	
	public static final String BRAND = "BRAND";
	
	public static final String SUB_BRAND = "SUB_BRAND";
	
	public static final String TIER = "TIER";
	
	public static final String PACK = "PACK";
	
	public static final String EAN = "EAN";
	
	public static final String OWN = "OWN";
	
	public static final String CROSS = "CROSS";
	
	public static final String WC = "WC";
	
	public static final String CUSTOMER = "CUSTOMER";
	
	public static final String CHANNEL = "CHANNEL";

	public static final String PCUST = "PCUST";

}
