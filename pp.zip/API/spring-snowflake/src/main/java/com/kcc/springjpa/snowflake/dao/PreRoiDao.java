package com.kcc.springjpa.snowflake.dao;

import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.kcc.springjpa.snowflake.entity.Scenario;
import com.kcc.springjpa.snowflake.model.BaseLineCustomerModel;
import com.kcc.springjpa.snowflake.model.PreRoiBaseLineModel;
import com.kcc.springjpa.snowflake.model.PreRoiSimulatedROIAndNPLModel;
import com.kcc.springjpa.snowflake.model.Simulation;

public interface PreRoiDao {
	
	public Map<String, Boolean> getPromoTypes(String country) throws SQLException;
	
	public Map<String, Boolean> getValidPromoTypes(String country) throws SQLException;
	
	public List<PreRoiBaseLineModel> getBaseLineValueByFilters(String country, int year, List<String> planLevels,
			List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
			List<String> subBrands, List<String> eans, int fromDate, int toDate) throws SQLException;

	public PreRoiSimulatedROIAndNPLModel getCogsAndNppByFilters(String country, List<String> planLevels,
                                                                List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
                                                                List<String> subBrands, List<String> eans);
	
	public PreRoiSimulatedROIAndNPLModel getCogsAndNppByFiltersForUK(String country, List<String> planLevels,
			List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
			List<String> subBrands, List<String> eans, int fromDate, int toDate);

	public PreRoiSimulatedROIAndNPLModel getCogsAndNppByFiltersForKR(String country, List<String> planLevels,
			List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
			List<String> subBrands, List<String> eans);

	List<Simulation> findSimulations(String country, String fromDate, String toDate, String name) throws ParseException;

	long deleteSimulations(String country, String createdBy, List<String> simulationsNames) throws SQLException;

	void createScenario(String scenarioName, String createdBy, LocalDateTime createdAt, List<String> simulationNames) throws Exception;

	boolean scenarioExists(String scenarioName, String createdBy) throws Exception;

	void updateScenario(String newName, String previousName, String createdBy) throws Exception;

	void deleteScenario(String name, String createdBy) throws Exception;

	List<Scenario> scenarios(String createdBy) throws Exception;

	List<Simulation> findSimulations(String scenario, String createdBy, String country) throws Exception;

	List<BaseLineCustomerModel> getCustomerHierarchy(String country);
}
