package com.kcc.springjpa.snowflake.service.impl;

import com.kcc.springjpa.snowflake.dao.ElasticityDao;
import com.kcc.springjpa.snowflake.entity.*;
import com.kcc.springjpa.snowflake.model.CrossOwnView;
import com.kcc.springjpa.snowflake.model.ElasticityProductHierarchy;
import com.kcc.springjpa.snowflake.model.OwnElasticityModel;
import com.kcc.springjpa.snowflake.repository.*;
import com.kcc.springjpa.snowflake.service.CrossDataService;
import com.kcc.springjpa.snowflake.utility.EanUtility;
import com.kcc.springjpa.snowflake.utility.ElasticityUtility;
import com.kcc.springjpa.snowflake.utility.HierarchyLevel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.*;

import static com.kcc.springjpa.snowflake.utility.NumberFormatUtility.roundedPValue;

@Service
public class CrossDataServiceImpl implements CrossDataService {

	private static final Logger logger = LogManager.getLogger(CrossDataServiceImpl.class);

	@Autowired
	OwnCrossEanRepository ownCrossEanRepository;
	
	@Autowired
	OwnCrossPackRepository ownCrossPackRepository;
	
	@Autowired
	OwnCrossSubbrandRepository ownCrossSubbrandRepository;
	
	@Autowired
	OwnCrossBrandRepository ownCrossBrandRepository;
	
	@Autowired
	OwnCrossSubCategoryRepository ownCrossSubCategoryRepository;

	@Autowired
	ElasticityHelperServiceImpl elasticityHelper;
	
	@Autowired
	ElasticityDao elasticityDao;

	@Override
	public ElasticityProductHierarchy getKCProductHierarchy(String country, String scope, String source, String levelIndicator) throws Exception {
		// Category --> SubCategory --> Manufacturer --> Brand --> SubBrand --> Tier --> Pack --> EAN - Description
		logger.info("Snowflake call to find CrossKCProducts by country initial: " + country);

		if(levelIndicator == null || levelIndicator.isEmpty()) {
			levelIndicator = "EAN";
		}
		String theSource = source;
		if(source == null) {
			List<String> sources = elasticityDao.getAvailableSources(country, levelIndicator);
			if (sources.contains("POS")) {
				theSource = "POS";
			} else if (sources.contains("NIELSEN")) {
				theSource = "NIELSEN";
			}
		}

		List<CrossOwnView> views;
		List<String> leafValues = null;
		switch (levelIndicator) {
			case "SUB_CATEGORY":
				views = ownCrossSubCategoryRepository.findByInitials(country, leafValues, scope, theSource, HierarchyLevel.CROSS, true);
				break;
			case "BRAND":
				views = ownCrossBrandRepository.findByInitials(country, leafValues, scope, theSource, HierarchyLevel.CROSS, true);
				break;
			case "SUB_BRAND":
				views = ownCrossSubbrandRepository.findByInitials(country, leafValues, scope, theSource, HierarchyLevel.CROSS, true);
				break;
			case "PACK":
				views = ownCrossPackRepository.findByInitials(country, leafValues, scope, theSource, HierarchyLevel.CROSS, true);
				break;
			default:
				views = ownCrossEanRepository.findByInitials(country, leafValues, scope, theSource, HierarchyLevel.CROSS, true);
				break;
		}
		logger.info("Number of CrossKCProducts by country initial " + country + "----------" + views.size());

		return elasticityHelper.getInitialProductHierarchy(views);
	}

	@Override
	public ElasticityProductHierarchy getTargetProductHierarchy(String country, List<String> leafValues,
																String levelIndicator, String scope, String source) throws Exception {
		// Category --> SubCategory --> Manufacturer --> Brand --> SubBrand --> Tier --> Pack --> EAN - Description
		logger.info("Snowflake call to find CrossTargetProducts by country initial and KC Products: " + country);

		if(levelIndicator == null || levelIndicator.isEmpty()) {
			levelIndicator = "EAN";
		}
		String theSource = source;
		if(source == null) {
			List<String> sources = elasticityDao.getAvailableSources(country, levelIndicator);
			if (sources.contains("POS")) {
				theSource = "POS";
			} else if (sources.contains("NIELSEN")) {
				theSource = "NIELSEN";
			}
		}

		List<CrossOwnView> views = new ArrayList<>();
		switch (levelIndicator) {
			case "SUB_CATEGORY":
				views = ownCrossSubCategoryRepository.findByInitials(country, leafValues, scope, theSource, HierarchyLevel.CROSS, false);
				break;
			case "BRAND":
				views = ownCrossBrandRepository.findByInitials(country, leafValues, scope, theSource, HierarchyLevel.CROSS, false);
				break;
			case "SUB_BRAND":
				views = ownCrossSubbrandRepository.findByInitials(country, leafValues, scope, theSource, HierarchyLevel.CROSS, false);
				break;
			case "PACK":
				views = ownCrossPackRepository.findByInitials(country, leafValues, scope, theSource, HierarchyLevel.CROSS, false);
				break;
			case "EAN":
				views = ownCrossEanRepository.findByInitials(country, leafValues, scope, theSource, HierarchyLevel.CROSS, false);
				break;
		}

		logger.info("Number of CrossTargetProducts by country initial " + country + "----------" + views.size());

		return elasticityHelper.getTargetProductHierarchy(views);
	}

	private void populateElasticityModel(OwnElasticityModel ownElasticityModel, OwnCrossCommonFields entityObj, String country, String initialKey,
										 String targetlKey, String levelIndicator, boolean forKorea) throws Exception {
		ownElasticityModel.setPriceIndex(entityObj.getPriceIndexAvg());
		ownElasticityModel.setRange(ElasticityUtility.getRange(false, entityObj.getElasticityAvgPrice(), forKorea));
		ownElasticityModel.setRsquared(entityObj.getRSquaredAvg());
		ownElasticityModel.setAveragePrice(entityObj.getElasticityAvgPrice());
		ownElasticityModel.setPromoPrice(entityObj.getElasticityPromoPrice());
		ownElasticityModel.setBasePrice(entityObj.getElasticityBasePrice());
		ownElasticityModel.setModelRun(entityObj.getModelRun());
		ownElasticityModel.setNWeeks(entityObj.getNWeeks());
		ownElasticityModel.setPeriodBegin(entityObj.getPeriodBegin());
		ownElasticityModel.setPeriodEnd(entityObj.getPeriodEnd());
		ownElasticityModel.setInitial(initialKey);
		ownElasticityModel.setTarget(targetlKey);
		ownElasticityModel.setCategory(entityObj.getCategory());
		ownElasticityModel.setSubCategoryInitial(entityObj.getInitialSubCategory());
		ownElasticityModel.setSubCategoryTarget(entityObj.getTargetSubCategory());
		ownElasticityModel.setPValue(roundedPValue(entityObj.getPValue()));
		ownElasticityModel.setAverageVolume(entityObj.getAvgQty());

		if(entityObj instanceof OwnCrossSubbrandData) {
			OwnCrossSubbrandData d = (OwnCrossSubbrandData) entityObj;
			ownElasticityModel.setManufacturerInitial(d.getInitialManufacturer());
			ownElasticityModel.setManufacturerTarget(d.getTargetManufacturer());
			ownElasticityModel.setBrandInitial(d.getInitialBrand());
			ownElasticityModel.setBrandTarget(d.getTargetBrand());
		}

		if(levelIndicator.equals(HierarchyLevel.EAN)){
			ownElasticityModel.setViewMore(elasticityDao.isViewMoreCross(country, EanUtility.getEanNumber(initialKey), EanUtility.getEanNumber(targetlKey), levelIndicator));
		}else{
			ownElasticityModel.setViewMore(elasticityDao.isViewMoreCross(country, initialKey, targetlKey, levelIndicator));
		}

	}

	@Override
	public List<OwnElasticityModel> getCrossElasticityAnalysis(String country,
															   List<String> initialLeafValues,
															   List<String> targetLeafValues,
															   String levelIndicator,
															   String source,
															   String category,
															   List<String> initialSubCategories,
															   List<String> targetSubCategories,
															   List<String> initialManufacturers,
															   List<String> targetManufacturers,
															   List<String> initialBrands,
															   List<String> targetBrands,
															   List<String> initialSubBrands,
															   List<String> targetSubBrands,
															   List<String> initialPacks,
															   List<String> targetPacks) throws Exception {

		logger.info("Snowflake Call to get the Cross Elasticity Values from given Initial and Target Products");
		List<OwnElasticityModel> ownElasticityModels = new ArrayList<>();
		//boolean isViewMore = elasticityDao.isViewMoreCross(country, initialLeafValues, targetLeafValues, levelIndicator);

		boolean forKorea = country.equalsIgnoreCase("KR");

		if (levelIndicator.equals(HierarchyLevel.CATEGORY)) {
			// Not expected to get this Hierarchy Level
		} else if (levelIndicator.equals(HierarchyLevel.SUB_CATEGORY)) {
			List<OwnCrossSubCategoryData> ownCrossSubCategoryData = ownCrossSubCategoryRepository
					.findAllByCountryAndFlagAndTypeAndSourceAndInitialSubCategoryInAndTargetSubCategoryIn(country, HierarchyLevel.CROSS, HierarchyLevel.WC, source, initialLeafValues, targetLeafValues);
			logger.info("FIND CROSS ELASTICITY ANALYSIS BY SUB_CATEGORY INTIAL AND SUB_CATEGORY TARGET---------------" + ownCrossSubCategoryData.size());
			for (OwnCrossSubCategoryData ocData : ownCrossSubCategoryData) {
				String initialKey = ocData.getInitialSubCategory();
				String targetKey = ocData.getTargetSubCategory();
				OwnElasticityModel ownElasticityModel = new OwnElasticityModel();
				populateElasticityModel(ownElasticityModel, ocData, country, initialKey, targetKey, levelIndicator, forKorea);
				ownElasticityModels.add(ownElasticityModel);
			}
		} else if (levelIndicator.equals(HierarchyLevel.MANUFACTURER)) {
			// Not expected to get this Hierarchy Level
		} else if (levelIndicator.equals(HierarchyLevel.BRAND)) {
			List<OwnCrossBrandData> ownCrossBrandData = ownCrossBrandRepository
					.findAllByCountryAndFlagAndTypeAndSourceAndInitialBrandInAndTargetBrandIn(country, HierarchyLevel.CROSS, HierarchyLevel.WC, source, initialLeafValues, targetLeafValues);
			logger.info("FIND CROSS ELASTICITY ANALYSIS BY BRAND INTIAL AND BRAND TARGET---------------"
					+ ownCrossBrandData.size());
			for (OwnCrossBrandData ocData : ownCrossBrandData) {
				String initialKey = ocData.getInitialBrand();
				String targetKey = ocData.getTargetBrand();
				OwnElasticityModel ownElasticityModel = new OwnElasticityModel();
				populateElasticityModel(ownElasticityModel, ocData, country, initialKey, targetKey, levelIndicator, forKorea);
				ownElasticityModels.add(ownElasticityModel);
			}
		} else if (levelIndicator.equals(HierarchyLevel.SUB_BRAND)) {
			List<OwnCrossSubbrandData> ownCrossSubbrandData = elasticityDao.products(country,
					HierarchyLevel.CROSS, HierarchyLevel.WC, initialLeafValues, targetLeafValues, source, category,
					initialSubCategories, targetSubCategories, initialManufacturers, targetManufacturers,
					initialBrands, targetBrands, initialSubBrands, targetSubBrands, initialPacks, targetPacks, levelIndicator, OwnCrossSubbrandData.class);
			logger.info("FIND CROSS ELASTICITY ANALYSIS BY SUB_BRAND INTIAL AND SUB_BRAND TARGET---------------"
					+ ownCrossSubbrandData.size());
			for (OwnCrossSubbrandData ocData : ownCrossSubbrandData) {
				String initialKey = ocData.getInitialSubBrand();
				String targetKey = ocData.getTargetSubBrand();
				OwnElasticityModel ownElasticityModel = new OwnElasticityModel();
				populateElasticityModel(ownElasticityModel, ocData, country, initialKey, targetKey, levelIndicator, forKorea);
				ownElasticityModels.add(ownElasticityModel);
			}
		} else if (levelIndicator.equals(HierarchyLevel.TIER)) {
			// Not expected to get this Hierarchy Level
		} else if (levelIndicator.equals(HierarchyLevel.PACK)) {
			List<OwnCrossPackData> ownCrossPackData = ownCrossPackRepository
					.findAllByCountryAndFlagAndTypeAndSourceAndInitialPackInAndTargetPackIn(country, HierarchyLevel.CROSS, HierarchyLevel.WC, source, initialLeafValues, targetLeafValues);
			logger.info("FIND CROSS ELASTICITY ANALYSIS BY PACK INTIAL AND PACK TARGET---------------"
					+ ownCrossPackData.size());
			for (OwnCrossPackData ocData : ownCrossPackData) {
				String initialKey = ocData.getInitialPack();
				String targetKey = ocData.getTargetPack();
				OwnElasticityModel ownElasticityModel = new OwnElasticityModel();
				populateElasticityModel(ownElasticityModel, ocData, country, initialKey, targetKey, levelIndicator, forKorea);
				ownElasticityModels.add(ownElasticityModel);
			}
		} else if (levelIndicator.equals(HierarchyLevel.EAN)) {
			List<OwnCrossData> ownCrossData = elasticityDao.products(country,
					HierarchyLevel.CROSS,
					HierarchyLevel.WC,
					EanUtility.getEanNumbersFromDescriptions(initialLeafValues),
					EanUtility.getEanNumbersFromDescriptions(targetLeafValues),
					source,
					category,
					initialSubCategories,
					targetSubCategories,
					initialManufacturers,
					targetManufacturers,
					initialBrands,
					targetBrands,
					initialSubBrands,
					targetSubBrands,
					initialPacks,
					targetPacks,
					levelIndicator,
					OwnCrossData.class);
			ownCrossEanRepository
					.findAllByCountryAndFlagAndTypeAndSourceAndEanInitialInAndEanTargetIn(country, HierarchyLevel.CROSS, HierarchyLevel.WC,
							source, EanUtility.getEanNumbersFromDescriptions(initialLeafValues), EanUtility.getEanNumbersFromDescriptions(targetLeafValues));
			logger.info(
					"FIND CROSS ELASTICITY ANALYSIS BY EAN INTIAL AND EAN TARGET---------------" + ownCrossData.size());
			for (OwnCrossData ocData : ownCrossData) {
				OwnElasticityModel ownElasticityModel = new OwnElasticityModel();

				Optional<String> initial = initialLeafValues.stream().filter(x -> x.contains(ocData.getEanInitial())).findFirst();
				Optional<String> target  = targetLeafValues.stream().filter(x -> x.contains(ocData.getEanTarget())).findFirst();
				populateElasticityModel(ownElasticityModel, ocData, country, initial.orElse(null), target.orElse(null), levelIndicator, forKorea);

				ownElasticityModels.add(ownElasticityModel);

			}
		}
		return ownElasticityModels;
	}

	private void addOrUpdateSCopedResults( Map<String, List<OwnElasticityModel>> crossElasticityMap, String typeDesc, OwnElasticityModel model){
		if (crossElasticityMap.containsKey(typeDesc)) {
			List<OwnElasticityModel> existingResult = crossElasticityMap.get(typeDesc);
			existingResult.add(model);
			crossElasticityMap.put(typeDesc, existingResult);
		}else{
			List<OwnElasticityModel> newResult = new ArrayList();
			newResult.add(model);
			crossElasticityMap.put(typeDesc, newResult);

		}
	}
	@Override
	public Map<String, List<OwnElasticityModel>> getCrossElasticityAnalysisPerScope(String country, List<String> initialLeafValues,
																					List<String> targetLeafValues, String levelIndicator, String scope, List<String> initialSubCategories, List<String> targetSubCategories, String source, String category, List<String> initialManufacturers, List<String> targetManufacturers, List<String> initialBrands, List<String> targetBrands, List<String> initialSubBrands, List<String> targetSubBrands, List<String> initialPacks, List<String> targetPacks) throws SQLException, Exception {
		
		logger.info("Snowflake Call to get the Cross Elasticity Values Per Scope from given Initial and Target Products");
		Map<String, List<OwnElasticityModel>> crossElasticityMap = new HashMap<String, List<OwnElasticityModel>>();

		boolean forKorea = country.equalsIgnoreCase("KR");

		if (levelIndicator.equals(HierarchyLevel.CATEGORY)) {
			// Not expected to get this Hierarchy Level
		} else if (levelIndicator.equals(HierarchyLevel.SUB_CATEGORY)) {
			List<OwnCrossSubCategoryData> ownCrossSubCategoryData = ownCrossSubCategoryRepository
					.findAllByCountryAndFlagAndTypeAndSourceAndInitialSubCategoryInAndTargetSubCategoryIn(country, HierarchyLevel.CROSS, scope.toUpperCase(), source, initialLeafValues, targetLeafValues);
			logger.info("FIND CROSS ELASTICITY ANALYSIS BY SUB_CATEGORY INTIAL AND SUB_CATEGORY TARGET PER SCOPE---------------" + ownCrossSubCategoryData.size());
			for (OwnCrossSubCategoryData ocData : ownCrossSubCategoryData) {
				OwnElasticityModel ownElasticityModel = new OwnElasticityModel();
				String initialKey = ocData.getInitialSubCategory();
				String targetKey = ocData.getTargetSubCategory();
				populateElasticityModel(ownElasticityModel, ocData, country, initialKey, targetKey, levelIndicator, forKorea);
				String typeDesc = ocData.getTypeDescription();
				addOrUpdateSCopedResults(crossElasticityMap, typeDesc, ownElasticityModel);
			}

		} else if (levelIndicator.equals(HierarchyLevel.MANUFACTURER)) {
			// Not expected to get this Hierarchy Level
		} else if (levelIndicator.equals(HierarchyLevel.BRAND)) {
			List<OwnCrossBrandData> ownCrossBrandData = ownCrossBrandRepository
					.findAllByCountryAndFlagAndTypeAndSourceAndInitialBrandInAndTargetBrandIn(country, HierarchyLevel.CROSS, scope.toUpperCase(), source, initialLeafValues, targetLeafValues);
			logger.info("FIND CROSS ELASTICITY ANALYSIS BY BRAND INTIAL AND BRAND TARGET PER SCOPE---------------"
					+ ownCrossBrandData.size());
			for (OwnCrossBrandData ocData : ownCrossBrandData) {
				OwnElasticityModel ownElasticityModel = new OwnElasticityModel();
				String initialKey = ocData.getInitialBrand();
				String targetKey = ocData.getTargetBrand();
				populateElasticityModel(ownElasticityModel, ocData, country, initialKey, targetKey, levelIndicator, forKorea);
				String typeDesc = ocData.getTypeDescription();
				addOrUpdateSCopedResults(crossElasticityMap, typeDesc, ownElasticityModel);
			}
		} else if (levelIndicator.equals(HierarchyLevel.SUB_BRAND)) {
			List<OwnCrossSubbrandData> ownCrossSubbrandData = elasticityDao.products(country, HierarchyLevel.CROSS, scope.toUpperCase(), initialLeafValues, targetLeafValues, source, category, initialSubCategories, targetSubCategories, initialManufacturers, targetManufacturers, initialBrands, targetBrands, initialSubBrands, targetSubBrands, initialPacks, targetPacks, levelIndicator, OwnCrossSubbrandData.class);
			logger.info("FIND CROSS ELASTICITY ANALYSIS BY SUB_BRAND INTIAL AND SUB_BRAND TARGET PER SCOPE---------------"
					+ ownCrossSubbrandData.size());
			for (OwnCrossSubbrandData ocData : ownCrossSubbrandData) {
				OwnElasticityModel ownElasticityModel = new OwnElasticityModel();
				String initialKey = ocData.getInitialSubBrand();
				String targetKey = ocData.getTargetSubBrand();
				populateElasticityModel(ownElasticityModel, ocData, country, initialKey, targetKey, levelIndicator, forKorea);
				String typeDesc = ocData.getTypeDescription();
				addOrUpdateSCopedResults(crossElasticityMap, typeDesc, ownElasticityModel);
			}
		} else if (levelIndicator.equals(HierarchyLevel.TIER)) {
			// Not expected to get this Hierarchy Level
		} else if (levelIndicator.equals(HierarchyLevel.PACK)) {
			List<OwnCrossPackData> ownCrossPackData = ownCrossPackRepository
					.findAllByCountryAndFlagAndTypeAndSourceAndInitialPackInAndTargetPackIn(country, HierarchyLevel.CROSS, scope.toUpperCase(), source, initialLeafValues, targetLeafValues);
			logger.info("FIND CROSS ELASTICITY ANALYSIS BY PACK INTIAL AND PACK TARGET PER SCOPE---------------"
					+ ownCrossPackData.size());
			for (OwnCrossPackData ocData : ownCrossPackData) {
				OwnElasticityModel ownElasticityModel = new OwnElasticityModel();
				String initialKey = ocData.getInitialPack();
				String targetKey = ocData.getTargetPack();
				populateElasticityModel(ownElasticityModel, ocData, country, initialKey, targetKey, levelIndicator, forKorea);
				String typeDesc = ocData.getTypeDescription();
				addOrUpdateSCopedResults(crossElasticityMap, typeDesc, ownElasticityModel);
			}
		} else if (levelIndicator.equals(HierarchyLevel.EAN)) {
			List<OwnCrossData> ownCrossData = elasticityDao.products(country, HierarchyLevel.CROSS, scope.toUpperCase(), EanUtility.getEanNumbersFromDescriptions(initialLeafValues), EanUtility.getEanNumbersFromDescriptions(targetLeafValues), source, category, initialSubCategories, targetSubCategories, initialManufacturers, targetManufacturers, initialBrands, targetBrands, initialSubBrands, targetSubBrands, initialPacks, targetPacks, levelIndicator, OwnCrossData.class);
			logger.info(
					"FIND CROSS ELASTICITY ANALYSIS BY EAN INTIAL AND EAN TARGET PER SCOPE---------------" + ownCrossData.size());
			for (OwnCrossData ocData : ownCrossData) {
				OwnElasticityModel ownElasticityModel = new OwnElasticityModel();

				Optional<String> initial = initialLeafValues.stream().filter(x -> x.contains(ocData.getEanInitial())).findFirst();
				Optional<String> target  = targetLeafValues.stream().filter(x -> x.contains(ocData.getEanTarget())).findFirst();
				populateElasticityModel(ownElasticityModel, ocData, country, initial.orElse(null), target.orElse(null), levelIndicator, forKorea);

				String typeDesc = ocData.getTypeDescription();
				addOrUpdateSCopedResults(crossElasticityMap, typeDesc, ownElasticityModel);
			}
		}
		return crossElasticityMap;
	}

}
