package com.kcc.springjpa.snowflake.exception;

import java.util.Date;

public class CustomerExceptionResponse extends ExceptionResponse{
    String cusomerName;

    public CustomerExceptionResponse(Date timestamp, String message, String details, String cusomerName) {
        super(timestamp, message, details);
        this.cusomerName = cusomerName;
    }
}
