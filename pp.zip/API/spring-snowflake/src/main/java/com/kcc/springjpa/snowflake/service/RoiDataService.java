package com.kcc.springjpa.snowflake.service;

import java.io.ByteArrayInputStream;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.kcc.springjpa.snowflake.model.PostRoiModel;
import com.kcc.springjpa.snowflake.model.PostRoiTpQuadrant;

public interface RoiDataService {

	public List<PostRoiModel> getPostRoiData(String country, List<String> planLevels,
                                             List<String> customers, List<String> source, List<String> categories, List<String> subCategories, List<String> brands,
                                             List<String> subBrands, List<String> eans, List<String> eventIds, String fromDate, String toDate, String groupBy, String kpiType, List<Integer> quadrants) throws Exception;

	public PostRoiModel getPostRoiQuadrantData(String country, List<String> planLevels,
											   List<String> customers, List<String> source, List<String> categories, List<String> subCategories, List<String> brands,
											   List<String> subBrands, List<String> eans, List<String> eventIds, String fromDate, String toDate, String kpiType) throws Exception;

	public List<String> getPostRoiEventIds(String country, List<String> planLevels,
			List<String> customers, List<String> source,  List<String> categories, List<String> subCategories, List<String> brands,
			List<String> subBrands, List<String> eans, String fromDate, String toDate) throws ParseException;

	public PostRoiTpQuadrant getPostRoiTpQuadrant(String country, List<String> planLevels, List<String> customers,
												  List<String> source, List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands,
												  List<String> eans, List<String> eventIds, String fromDate, String toDate, String kpiType) throws ParseException;

	public ByteArrayInputStream getPostRoiFile(String trim, List<String> planLevels, List<String> customers,
                                               List<String> source, List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands,
                                               List<String> eans, List<String> eventIds, String fromDate, String toDate, String kpiType) throws ParseException;

	public Map<String, Boolean> hasSellInSelloutData(String country) throws ParseException;

}
