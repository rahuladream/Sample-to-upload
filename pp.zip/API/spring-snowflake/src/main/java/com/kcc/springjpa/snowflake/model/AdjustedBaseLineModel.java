package com.kcc.springjpa.snowflake.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class AdjustedBaseLineModel {

	private Integer totalQuantity;
	
	private Integer averageQuantity;
	
	private Map<String, Integer> january;
	
	private Map<String, Integer> february;
	
	private Map<String, Integer> march;
	
	private Map<String, Integer> april;
	
	private Map<String, Integer> may;
	
	private Map<String, Integer> june;
	
	private Map<String, Integer> july;
	
	private Map<String, Integer> august;
	
	private Map<String, Integer> september;
	
	private Map<String, Integer> october;
	
	private Map<String, Integer> november;
	
	private Map<String, Integer> december;
	
	
}
