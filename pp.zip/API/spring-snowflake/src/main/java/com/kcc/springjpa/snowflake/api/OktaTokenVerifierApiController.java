package com.kcc.springjpa.snowflake.api;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import com.kcc.springjpa.snowflake.model.OktaApiAuthenticator;
import com.kcc.springjpa.snowflake.model.OktaForm;
import com.kcc.springjpa.snowflake.service.OktaService;
import com.kcc.springjpa.snowflake.utility.StringResponse;

@Controller
public class OktaTokenVerifierApiController implements OktaTokenVerifierApi {
	
	private static final Logger logger = LogManager.getLogger(OktaTokenVerifierApiController.class);
	
	@Autowired
	OktaService oktaService;

	@Override
	public ResponseEntity<StringResponse> validateAccessToken(String accessToken) throws Exception {
		logger.info("API Call to validate Access Token");
		return new ResponseEntity<>(oktaService.validateAccessToken(accessToken), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<StringResponse> validateIdToken(String idToken) throws Exception {
		logger.info("API Call to validate Id Token");
		return new ResponseEntity<>(oktaService.validateIdToken(idToken), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<OktaApiAuthenticator> generateAuthenticateToken(OktaForm oktaForm) throws Exception {
		logger.info("API Call to validate Okta Tokens and generate new Token");
		
		OktaApiAuthenticator oktaValidator = oktaService.generateAuthenticateToken(oktaForm.getAccessToken(), oktaForm.getIdToken());

		if(oktaValidator.getGroups() != null && oktaValidator.getJwtToken() != null) {
			return new ResponseEntity<>(oktaService.generateAuthenticateToken(oktaForm.getAccessToken(), oktaForm.getIdToken()), HttpStatus.OK);
		}else {
			return new ResponseEntity<>(oktaService.generateAuthenticateToken(oktaForm.getAccessToken(), oktaForm.getIdToken()), HttpStatus.FORBIDDEN);
		}
		//return new ResponseEntity<>(oktaService.generateAuthenticateToken(oktaForm.getAccessToken(), oktaForm.getIdToken()), HttpStatus..OK);
	}

}
