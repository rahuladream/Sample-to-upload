package com.kcc.springjpa.snowflake.dtos;

public class UpdateScenarioRequest {

    public String previousName;
    public String newName;
}
