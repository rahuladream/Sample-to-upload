package com.kcc.springjpa.snowflake.exception;

public class InvalidCustomerNameException extends Exception{
    String customerName;
    public InvalidCustomerNameException(String message, String customerName){
        super(message);
        this.customerName = customerName;
    }
}
