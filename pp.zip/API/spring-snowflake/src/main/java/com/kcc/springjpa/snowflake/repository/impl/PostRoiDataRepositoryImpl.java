package com.kcc.springjpa.snowflake.repository.impl;

import com.kcc.springjpa.snowflake.configuration.DBConfig;
import com.kcc.springjpa.snowflake.dtos.PostRoiQueryResult;
import com.kcc.springjpa.snowflake.entity.PostRoiData;
import com.kcc.springjpa.snowflake.entity.PostRoiGroup;
import com.kcc.springjpa.snowflake.model.BaseLineCustomerModel;
import com.kcc.springjpa.snowflake.repository.PostRoiDataRepository;
import com.kcc.springjpa.snowflake.utility.ExcelHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.io.ByteArrayInputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

@Repository
public class PostRoiDataRepositoryImpl implements PostRoiDataRepository {

    private static final Logger logger = LogManager.getLogger(PostRoiDataRepositoryImpl.class);

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    DBConfig dbConfig;

    @Override
    public List<PostRoiData> findAll(Sort sort) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<PostRoiData> findAllById(Iterable<Integer> ids) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public <S extends PostRoiData> List<S> saveAll(Iterable<S> entities) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void flush() {
        // TODO Auto-generated method stub

    }

    @Override
    public <S extends PostRoiData> S saveAndFlush(S entity) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void deleteInBatch(Iterable<PostRoiData> entities) {
        // TODO Auto-generated method stub

    }

    @Override
    public void deleteAllInBatch() {
        // TODO Auto-generated method stub

    }

    @Override
    public PostRoiData getOne(Integer id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public <S extends PostRoiData> List<S> findAll(Example<S> example) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public <S extends PostRoiData> List<S> findAll(Example<S> example, Sort sort) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Page<PostRoiData> findAll(Pageable pageable) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public <S extends PostRoiData> S save(S entity) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Optional<PostRoiData> findById(Integer id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean existsById(Integer id) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public long count() {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public void deleteById(Integer id) {
        // TODO Auto-generated method stub

    }

    @Override
    public void delete(PostRoiData entity) {
        // TODO Auto-generated method stub

    }

    @Override
    public void deleteAll(Iterable<? extends PostRoiData> entities) {
        // TODO Auto-generated method stub

    }

    @Override
    public void deleteAll() {
        // TODO Auto-generated method stub

    }

    @Override
    public <S extends PostRoiData> Optional<S> findOne(Example<S> example) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public <S extends PostRoiData> Page<S> findAll(Example<S> example, Pageable pageable) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public <S extends PostRoiData> long count(Example<S> example) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public <S extends PostRoiData> boolean exists(Example<S> example) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public List<PostRoiData> findAll() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<String> findEventIds(String country, List<String> planLevels,
                                     List<String> customers, List<String> source, List<String> categories, List<String> subCategories, List<String> brands,
                                     List<String> subBrands, List<String> eans, int fromDate, int toDate, boolean dayData) {

        logger.info("Get ROI Event Ids List based on filters :: ");
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<String> cq = cb.createQuery(String.class);
        Root<PostRoiData> root = cq.from(PostRoiData.class);

        List<Selection<?>> s = new LinkedList<Selection<?>>();
        s.add(root.get("eventId"));
        cq.multiselect(s);

        Predicate result = getPredicateUsingJpaExpression(country, planLevels, customers, source, categories, subCategories,
                brands, subBrands, eans, null, fromDate, toDate, cb, root, dayData, false, false);
        cq.where(result);

        TypedQuery<String> q = entityManager.createQuery(cq);
        logger.info("QUERY TO GET ROI QUADRANT ****************" + q.toString());
        return q.getResultList();
    }

    @Override
    public boolean hasDayData(String country) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<String> cq = cb.createQuery(String.class);
        Root<PostRoiData> root = cq.from(PostRoiData.class);

        List<Selection<?>> s = new LinkedList<Selection<?>>();
        s.add(root.get("ean"));
        cq.multiselect(s);

        Predicate predicate = cb.and(cb.equal(root.get("country"), country), cb.gt(root.get("day"), 0));
        cq.where(predicate);

        TypedQuery<String> q = entityManager.createQuery(cq).setMaxResults(1);
        List<String> result = q.getResultList();
        System.out.println(result.size());

        return result.size() > 0;
    }

    private Predicate getPredicateUsingJpaExpression(String country, List<String> planLevels, List<String> customers,
                                                     List<String> source, List<String> categories, List<String> subCategories,
                                                     List<String> brands, List<String> subBrands, List<String> oskus,
                                                     List<String> eventIds, int fromDate, int toDate, CriteriaBuilder cb,
                                                     Root<PostRoiData> root, boolean dayData, boolean forRetailerMargin, boolean forSU) {
        Predicate result = cb.equal(root.get("country"), country);
        if (!CollectionUtils.isEmpty(planLevels)) {
            result = cb.and(result, root.get("planLevel").in(planLevels));
        }
        if (!CollectionUtils.isEmpty(customers)) {
            result = cb.and(result, root.get("soldToDesc").in(customers));
        }
        if (!CollectionUtils.isEmpty(source)) {
            result = cb.and(result, root.get("dataSource").in(source));
        }
        if (!CollectionUtils.isEmpty(categories)) {
            result = cb.and(result, root.get("category").in(categories));
        }
        if (!CollectionUtils.isEmpty(subCategories)) {
            result = cb.and(result, root.get("subCategory").in(subCategories));
        }
        if (!CollectionUtils.isEmpty(brands)) {
            result = cb.and(result, root.get("brand").in(brands));
        }
        if (!CollectionUtils.isEmpty(subBrands)) {
            result = cb.and(result, root.get("subBrand").in(subBrands));
        }
        if (!CollectionUtils.isEmpty(oskus)) {
            result = cb.and(result, root.get("ean").in(oskus));
        }
        if (!CollectionUtils.isEmpty(eventIds)) {
            result = cb.and(result, root.get("eventId").in(eventIds));
        }
        result = cb.and(result, cb.between(getTimestampExpression(source, dayData, cb, root), fromDate, toDate));

        if (forRetailerMargin) {
            if (forSU) {
                result = cb.and(result, root.get("retailerMarginPercentSU").isNotNull());
                result = cb.and(result, cb.greaterThan(root.get("retailerMarginPercentSU"), 0));
            } else {
                result = cb.and(result, root.get("retailerMarginPercentCase").isNotNull());
                result = cb.and(result, cb.greaterThan(root.get("retailerMarginPercentCase"), 0));
            }
        }
        return result;
    }

    private Expression<Integer> getTimestampExpression(List<String> source, boolean dayData, CriteriaBuilder cb, Root<PostRoiData> root) {
        Expression<Integer> timestampExpression;
        if (!CollectionUtils.isEmpty(source) && source.contains("SELL IN")) {
            Expression<Integer> monthCol = root.get("month");
            Expression<Integer> length = cb.literal(2);
            Expression<String> fillText = cb.literal("0");
            Expression<String> monthPadded = cb.function(
                    "LPAD",
                    String.class,
                    monthCol, length, fillText);
            timestampExpression = cb.concat(root.get("year"), monthPadded).as(Integer.class);
        } else {
            if (!dayData) {
                timestampExpression = root.get("week");
            } else {
                Expression<Integer> monthCol = root.get("month");
                Expression<Integer> length = cb.literal(2);
                Expression<String> fillText = cb.literal("0");
                Expression<String> monthPadded = cb.function(
                        "LPAD",
                        String.class,
                        monthCol, length, fillText);
                Expression<Integer> dayCol = root.get("day");
                Expression<String> dayPadded = cb.function(
                        "LPAD",
                        String.class,
                        dayCol, length, fillText);
                Expression<String> yearAndMonth = cb.concat(root.get("year"), monthPadded);
                timestampExpression = cb.concat(yearAndMonth, dayPadded).as(Integer.class);
            }
        }
        return timestampExpression;
    }

    private List<Selection<?>> columnsToSelectForRetailerMargin(CriteriaBuilder cb, Root<PostRoiData> root, String groupBy, boolean forSU) {
        List<Selection<?>> s = new LinkedList<>();
        switch (groupBy) {
            case "Category":
                s.add(root.get("category"));
                break;
            case "Month":
                s.add(root.get("month"));
                s.add(root.get("year"));
                break;
            case "Week":
                s.add(root.get("week"));
                break;
            case "PlanningCustomer":
                s.add(root.get("planLevel"));
                break;
            case "Customer":
                s.add(root.get("soldToDesc"));
                break;
            case "SubCategory":
                s.add(root.get("subCategory"));
                break;
            case "Brand":
                s.add(root.get("brand"));
                break;
            case "SubBrand":
                s.add(root.get("subBrand"));
                break;
            case "OSKU":
                s.add(root.get("ean"));
                break;
            case "EventId":
                s.add(root.get("eventId"));
                break;
            case "Tier":
                s.add(root.get("tier"));
                break;
            case "PromoType":
                s.add(root.get("promoType"));
                break;
            case "Roll":
                s.add(root.get("roll"));
                break;
            case "Pack":
                s.add(root.get("pack"));
                break;
            case "Size":
                s.add(root.get("size"));
                break;
            case "Feature":
                s.add(root.get("feature"));
                break;
            case "Duration":
                s.add(root.get("duration"));
                break;
            case "PricePoint":
                s.add(root.get("pricePoint"));
                break;
            case "Mechanic":
                s.add(root.get("mechanic"));
                break;
            default:
                s.add(root.get("soldToDesc"));
                break;
        }
        if (forSU) {
            s.add(cb.sum(root.get("retailerMarginSU")));
            s.add(cb.sum(root.get("retailerMarginPercentSU")));
        } else {
            s.add(cb.sum(root.get("retailerMarginCase")));
            s.add(cb.sum(root.get("retailerMarginPercentCase")));
        }
        return s;
    }

    private void setGroupBy(CriteriaBuilder cb, CriteriaQuery<PostRoiGroup> cq, Root<PostRoiData> root, String groupBy, boolean forSU) {
        switch (groupBy) {
            case "Category":
                cq.groupBy(root.get("category"));
                break;
            case "Month":
                //Need to add 2 Group bys because month and year are in 2 different columns
                cq.groupBy(root.get("month"), root.get("year"));
                cq.orderBy(cb.asc(root.get("month")));
                break;
            case "Week":
                cq.groupBy(root.get("week"));
                cq.orderBy(cb.asc(root.get("week")));
                break;
            case "PlanningCustomer":
                cq.groupBy(root.get("planLevel"));
                break;
            case "Customer":
                cq.groupBy(root.get("soldToDesc"));
                break;
            case "SubCategory":
                cq.groupBy(root.get("subCategory"));
                break;
            case "Brand":
                cq.groupBy(root.get("brand"));
                break;
            case "SubBrand":
                cq.groupBy(root.get("subBrand"));
                break;
            case "osku":
            case "Ean":
                cq.groupBy(root.get("ean"));
                break;
            case "EventId":
                cq.groupBy(root.get("eventId"));
                break;
            case "Tier":
                cq.groupBy(root.get("tier"));
                break;
            case "PromoType":
                cq.groupBy(root.get("promoType"));
                break;
            case "Roll":
                cq.groupBy(root.get("roll"));
                break;
            case "Pack":
                cq.groupBy(root.get("pack"));
                break;
            case "Size":
                cq.groupBy(root.get("size"));
                break;
            case "Feature":
                cq.groupBy(root.get("feature"));
                break;
            case "Duration":
                cq.groupBy(root.get("duration"));
                break;
            case "PricePoint":
                if (forSU) {
                    cq.groupBy(root.get("pricePointSU"));
                } else {
                    cq.groupBy(root.get("pricePointCase"));
                }
                break;
            case "Mechanic":
                cq.groupBy(root.get("mechanic"));
                break;
            default:
                cq.groupBy(root.get("soldToDesc"));
                break;
        }
    }

    public List<PostRoiGroup> findRetailerMargin(String country, List<String> planLevels, List<String> customers,
                                                 List<String> source, List<String> categories,
                                                 List<String> subCategories, List<String> brands,
                                                 List<String> subBrands, List<String> eans, List<String> eventIds,
                                                 int fromDate, int toDate, String groupBy, boolean dayData, boolean forSU, int quadrant) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<PostRoiGroup> cq = cb.createQuery(PostRoiGroup.class);
        Root<PostRoiData> root = cq.from(PostRoiData.class);

        List<Selection<?>> s = columnsToSelectForRetailerMargin(cb, root, groupBy, forSU);
        cq.multiselect(s);

        Predicate result = getPredicateUsingJpaExpression(country, planLevels, customers, source, categories, subCategories,
                brands, subBrands, eans, eventIds, fromDate, toDate, cb, root, dayData, true, forSU);
        result = getQuadrantCondition(quadrant, forSU, result, cb, root);
        cq.where(result);

        setGroupBy(cb, cq, root, groupBy, forSU);

        TypedQuery<PostRoiGroup> q = entityManager.createQuery(cq);
        return q.getResultList();
    }

    private Predicate getQuadrantCondition(int quadrant, boolean forSU, Predicate result, CriteriaBuilder cb, Root<PostRoiData> root) {
        switch (quadrant) {
            case 1:
                if(forSU) result = cb.and(cb.ge(root.get("netProfitSU"), 0), cb.ge(root.get("actualVolumeSU"), root.get("baselineVolume")));
                else result = cb.and(cb.ge(root.get("netProfitCase"), 0), cb.ge(root.get("actualVolumeCase"), root.get("baselineVolume")));
                break;
            case 2:
                if(forSU) result = cb.and(cb.lessThan(root.get("netProfitSU"), 0), cb.ge(root.get("actualVolumeSU"), root.get("baselineVolume")));
                else result = cb.and(cb.lessThan(root.get("netProfitCase"), 0), cb.ge(root.get("actualVolumeCase"), root.get("baselineVolume")));
                break;
            case 3:
                if(forSU) result = cb.and(cb.lessThan(root.get("netProfitSU"), 0), cb.lessThan(root.get("actualVolumeSU"), root.get("baselineVolume")));
                else result = cb.and(cb.lessThan(root.get("netProfitCase"), 0), cb.lessThan(root.get("actualVolumeCase"), root.get("baselineVolume")));
                break;
            case 4:
                if(forSU) result = cb.and(cb.ge(root.get("netProfitSU"), 0), cb.lessThan(root.get("actualVolumeSU"), root.get("baselineVolume")));
                else result = cb.and(cb.ge(root.get("netProfitCase"), 0), cb.lessThan(root.get("actualVolumeCase"), root.get("baselineVolume")));
                break;
        }
        return result;
    }

    @Override
    public PostRoiGroup findPostRoiQuadrant(String country, List<String> planLevels, List<String> customers, List<String> source, List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands, List<String> eans, List<String> eventIds, int fromDate, int toDate, boolean dayData, boolean forSU) throws Exception {
        String sql = "SELECT select_list " +
                "FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_POST_ROI " +
                "WHERE predicate ";
        StringBuilder selectListBuilder = new StringBuilder();
        if (forSU) {
            selectListBuilder.append("SUM(").append("promo_profit_su").append(")").append(",");
            selectListBuilder.append("SUM(").append("baseline_profit_su").append(")").append(",");
            selectListBuilder.append("SUM(").append("net_profit_su").append(")").append(",");
            selectListBuilder.append("SUM(").append("actual_volume_su").append(")").append(",");
            selectListBuilder.append("SUM(").append("baseline_volume").append(")").append(",");
            selectListBuilder.append("SUM(").append("promo_investment").append(")").append(",");
            selectListBuilder.append("AVG(").append("retailer_margin_su").append(")").append(",");
            selectListBuilder.append("AVG(").append("RETAILER_MARGIN_PCT_su").append(")");
        } else {
            selectListBuilder.append("SUM(").append("promo_profit").append(")").append(",");
            selectListBuilder.append("SUM(").append("baseline_profit").append(")").append(",");
            selectListBuilder.append("SUM(").append("net_profit").append(")").append(",");
            selectListBuilder.append("SUM(").append("actual_volume").append(")").append(",");
            selectListBuilder.append("SUM(").append("baseline_volume").append(")").append(",");
            selectListBuilder.append("SUM(").append("promo_investment").append(")").append(",");
            selectListBuilder.append("AVG(").append("retailer_margin").append(")").append(",");
            selectListBuilder.append("AVG(").append("RETAILER_MARGIN_PCT").append(")");
        }
        sql = sql.replace("select_list", selectListBuilder.toString());
        sql = sql.replace("predicate", getPredicateUsingStringBuilder(country, planLevels, customers, source, categories,
                subCategories, brands, subBrands, eans, eventIds, fromDate, toDate, dayData, forSU));
        logger.info("QUERY TO GET ROI QUADRANT ****************   " + sql);
        PostRoiGroup r = new PostRoiGroup();
        try (Connection c = dbConfig.getJdbcConnection()) {
            Statement s = c.createStatement();
            ResultSet rs = s.executeQuery(sql);
            while (rs.next()) {
                r.setPromoProfit(rs.getDouble(1));
                r.setBaselineProfit(rs.getDouble(2));
                r.setNetProfit(rs.getDouble(3));
                r.setTotalVolume(rs.getDouble(4));
                r.setBaselineVolume(rs.getDouble(5));
                r.setPromoInvestment(rs.getDouble(6));
                r.setRetailerMargin(rs.getDouble(7));
                r.setRetailerMarginPercentage(rs.getDouble(8));
            }
        } catch (SQLException e) {
            throw new Exception("Could not retrieve records from V_RGM_SLS_FCT_DATA_POST_ROI", e);
        }
        return r;
    }

    @Override
    public List<PostRoiGroup> findTpQuadrant(String country, List<String> planLevels, List<String> customers, List<String> source, List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands, List<String> eans, List<String> eventIds, int fromDate, int toDate, boolean dayData, boolean forSU) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<PostRoiGroup> cq = cb.createQuery(PostRoiGroup.class);
        Root<PostRoiData> root = cq.from(PostRoiData.class);
        List<Selection<?>> s = new LinkedList<>();
        if (forSU) {
            s.add(root.get("netProfitSU"));
            s.add(root.get("actualVolumeSU"));
        } else {
            s.add(root.get("netProfitCase"));
            s.add(root.get("actualVolumeCase"));
        }
        s.add(root.get("baselineVolume"));
        s.add(root.get("promoInvestment"));
        cq.multiselect(s);

        Predicate result = getPredicateUsingJpaExpression(country, planLevels, customers, source, categories, subCategories,
                brands, subBrands, eans, eventIds, fromDate, toDate, cb, root, dayData, false, forSU);
        cq.where(result);

        TypedQuery<PostRoiGroup> q = entityManager.createQuery(cq);
        logger.info("QUERY TO GET ROI QUADRANT ****************" + q.toString());
        return q.getResultList();
    }

    @Override
    public ByteArrayInputStream findTpQuadrantForExport(String country, List<String> planLevels, List<String> customers,
                                                        List<String> source, List<String> categories,
                                                        List<String> subCategories, List<String> brands,
                                                        List<String> subBrands, List<String> eans,
                                                        List<String> eventIds, int fromDate, int toDate,
                                                        boolean dayData, boolean forSU) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<PostRoiData> cq = cb.createQuery(PostRoiData.class);
        Root<PostRoiData> root = cq.from(PostRoiData.class);

        Predicate result = getPredicateUsingJpaExpression(country, planLevels, customers, source, categories, subCategories,
                brands, subBrands, eans, eventIds, fromDate, toDate, cb, root, dayData, false, forSU);

        cq.where(result);

        TypedQuery<PostRoiData> q = entityManager.createQuery(cq);
        logger.info("QUERY TO GET ROI QUADRANT ****************" + q.toString());
        return ExcelHelper.postROIDataToExcel(q.getResultStream(), forSU);
    }

    @Override
    public List<String> findDistinctDataSource(String country) {
        return null;
    }

    @Override
    public void deleteAllByIdInBatch(Iterable<Integer> ids) {
        // TODO Auto-generated method stub

    }

    @Override
    public void deleteAllInBatch(Iterable<PostRoiData> entities) {
        // TODO Auto-generated method stub

    }

    @Override
    public PostRoiData getById(Integer id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public <S extends PostRoiData> List<S> saveAllAndFlush(Iterable<S> entities) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void deleteAllById(Iterable<? extends Integer> ids) {
        // TODO Auto-generated method stub

    }

    @Override
    public List<PostRoiQueryResult> findPostRoi(String country,
                                                List<String> planLevels,
                                                List<String> customers,
                                                List<String> source,
                                                List<String> categories,
                                                List<String> subCategories,
                                                List<String> brands,
                                                List<String> subBrands,
                                                List<String> eans,
                                                List<String> eventIds,
                                                int fromDate,
                                                int toDate,
                                                String groupBy,
                                                boolean dayData,
                                                List<Integer> monthNumbers,
                                                boolean forSU, List<Integer> quadrants) throws Exception {
        try (Connection c = dbConfig.getJdbcConnection()) {
            List<PostRoiQueryResult> results = new ArrayList<>();
            if(quadrants == null || quadrants.isEmpty() || quadrants.contains(0)) {
                results.add(new PostRoiQueryResult(getPostRoiGroups(c, country, planLevels, customers, source, categories, subCategories, brands, subBrands, eans, eventIds, fromDate, toDate, groupBy, dayData, forSU, 0),
                        findRetailerMargin(country, planLevels, customers, source, categories, subCategories, brands, subBrands, eans, eventIds, fromDate, toDate, groupBy, dayData, forSU, 0)));
                return results;
            }
            for(int q : quadrants) {
                results.add(new PostRoiQueryResult(getPostRoiGroups(c, country, planLevels, customers, source, categories, subCategories, brands, subBrands, eans, eventIds, fromDate, toDate, groupBy, dayData, forSU, q),
                        findRetailerMargin(country, planLevels, customers, source, categories, subCategories, brands, subBrands, eans, eventIds, fromDate, toDate, groupBy, dayData, forSU, q)));
                entityManager.clear();
            }
            return results;
        } catch (SQLException e) {
            throw new Exception("Could not retrieve records from V_RGM_SLS_FCT_DATA_POST_ROI", e);
        }
    }

    private List<PostRoiGroup> getPostRoiGroups(Connection c,
                                                String country,
                                                List<String> planLevels,
                                                List<String> customers,
                                                List<String> source,
                                                List<String> categories,
                                                List<String> subCategories,
                                                List<String> brands,
                                                List<String> subBrands,
                                                List<String> eans,
                                                List<String> eventIds,
                                                int fromDate,
                                                int toDate,
                                                String groupBy,
                                                boolean dayData,
                                                boolean forSU,
                                                int quadrant) throws SQLException {
        String sql = "SELECT select_list, group_by_column " +
                "FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_POST_ROI " +
                "WHERE predicate " +
                "quadrantCondition " +
                "GROUP BY group_by_column ";
        String groupByColumn = getGroupByColumn(groupBy);
        sql = sql.replace("group_by_column", groupByColumn);
        sql = sql.replace("select_list", selectList(forSU));
        sql = sql.replace("predicate", getPredicateUsingStringBuilder(country, planLevels, customers, source, categories,
                subCategories, brands, subBrands, eans, eventIds, fromDate, toDate, dayData, forSU));
        sql = sql.replace("quadrantCondition", getQuadrantCondition(quadrant, forSU));
        sql = sql.replace("group_by_column", groupByColumn);

        boolean groupByMonth = groupBy.equalsIgnoreCase("Month");
        List<PostRoiGroup> records = new ArrayList<>();
        Statement s = c.createStatement();
        ResultSet rs = s.executeQuery(sql);
        while (rs.next()) {
            PostRoiGroup r = new PostRoiGroup();
            r.setPromoProfit(rs.getDouble(1));
            r.setBaselineProfit(rs.getDouble(2));
            r.setNetProfit(rs.getDouble(3));
            r.setTotalVolume(rs.getDouble(4));
            r.setBaselineVolume(rs.getDouble(5));
            r.setPromoInvestment(rs.getDouble(6));
            r.setCogs(rs.getDouble(7));
            r.setNpp(rs.getDouble(8));
            r.setRetailerMargin(rs.getDouble(9));
            r.setRetailerMarginPercentage(rs.getDouble(10));
            r.setDuration(rs.getInt(11));
            r.setPricePoint(rs.getDouble(12));
            JSONArray mechanicArray = new JSONArray(rs.getString(13));
            r.setMechanic(mechanicArray.toList());
            JSONArray featureArray = new JSONArray(rs.getString(14));
            r.setFeature(featureArray.toList());
            r.setGroupBy(rs.getString(15));
            if(groupByMonth) {
                r.setGroupByNum(Integer.parseInt(rs.getString(15)));
                r.setYear(Integer.parseInt(rs.getString(16)));
            }

            records.add(r);
        }
        return records;
    }

    private String getQuadrantCondition(int quadrant, boolean forSU) {
        String c = "";
        switch (quadrant) {
            case 1:
                if(forSU) c = " net_profit_su >= 0 AND actual_volume_su >= baseline_volume";
                else c = " net_profit >= 0 AND actual_volume >= baseline_volume ";
                break;
            case 2:
                if(forSU) c = " net_profit_su < 0 AND actual_volume_su >= baseline_volume ";
                else c = " net_profit < 0 AND actual_volume >= baseline_volume ";
                break;
            case 3:
                if(forSU) c = " net_profit_su < 0 AND actual_volume_su < baseline_volume ";
                else c = " net_profit < 0 AND actual_volume < baseline_volume ";
                break;
            case 4:
                if(forSU) c = " net_profit_su >= 0 AND actual_volume_su < baseline_volume";
                else c = " net_profit >= 0 AND actual_volume < baseline_volume ";
                break;
        }
        if(!c.isEmpty()) c = " AND " + c;
        return c;
    }

    private String selectList(boolean forSU) {
        StringBuilder selectListBuilder = new StringBuilder();
        if (forSU) {
            selectListBuilder.append("sum(promo_profit_su)").append(",");
            selectListBuilder.append("sum(baseline_profit_su)").append(",");
            selectListBuilder.append("sum(net_profit_su)").append(",");
            selectListBuilder.append("sum(actual_volume_su)").append(",");
            selectListBuilder.append("sum(baseline_volume)").append(",");
            selectListBuilder.append("sum(promo_investment)").append(",");
            selectListBuilder.append("avg(cogs_per_su)").append(",");
            selectListBuilder.append("avg(npp_per_su)").append(",");
            selectListBuilder.append("sum(retailer_margin_su)").append(",");
            selectListBuilder.append("sum(RETAILER_MARGIN_PCT_su)").append(",");
        } else {
            selectListBuilder.append("sum(promo_profit)").append(",");
            selectListBuilder.append("sum(baseline_profit)").append(",");
            selectListBuilder.append("sum(net_profit)").append(",");
            selectListBuilder.append("sum(actual_volume)").append(",");
            selectListBuilder.append("sum(baseline_volume)").append(",");
            selectListBuilder.append("sum(promo_investment)").append(",");
            selectListBuilder.append("avg(cogs_per_case)").append(",");
            selectListBuilder.append("avg(npp_per_case)").append(",");
            selectListBuilder.append("sum(retailer_margin)").append(",");
            selectListBuilder.append("sum(RETAILER_MARGIN_PCT)").append(",");
        }
        selectListBuilder.append("sum(duration)").append(",");
        selectListBuilder.append("sum(").append(forSU ? "price_point_su" : "price_point").append(")").append(",");
        selectListBuilder.append("array_agg(distinct mechanic)").append(",");
        selectListBuilder.append("array_agg(distinct feature)");

        return selectListBuilder.toString();
    }

    private String getGroupByColumn(String groupBy) {
        String col;
        switch (groupBy) {
            case "Category":
                col = "category";
                break;
            case "Month":
                //Need to add 2 Group bys because month and year are in 2 different columns
                col = "month, year";
                break;
            case "Week":
                col = "week";
                break;
            case "PlanningCustomer":
                col = "plan_level";
                break;
            case "SubCategory":
                col = "sub_category";
                break;
            case "Brand":
                col = "brand";
                break;
            case "SubBrand":
                col = "sub_brand";
                break;
            case "osku":
            case "Ean":
                col = "ean";
                break;
            case "EventId":
                col = "event_id";
                break;
            case "Tier":
                col = "tier";
                break;
            case "PromoType":
                col = "promo_type";
                break;
            case "Roll":
                col = "roll";
                break;
            case "Pack":
                col = "pack";
                break;
            case "Size":
                col = "size";
                break;
            case "Feature":
                col = "feature";
                break;
            case "Duration":
                col = "duration";
                break;
            case "PricePoint":
                col = "price_point";
                break;
            case "Mechanic":
                col = "mechanic";
                break;
            default:
                col = "sold_to_desc";
                break;
        }
        return col;
    }

    private String getOrderBy(String groupBy) {
        String expression = "";
        switch (groupBy) {
            case "Month":
                //Need to add 2 Group bys because month and year are in 2 different columns
                expression = "ORDER BY month ASC";
                break;
            case "Week":
                expression = "ORDER BY week ASC";
                break;
        }
        return expression;
    }

    private String getPredicateUsingStringBuilder(String country, List<String> planLevels, List<String> customers,
                                                  List<String> source, List<String> categories, List<String> subCategories,
                                                  List<String> brands, List<String> subBrands, List<String> oskus,
                                                  List<String> eventIds, int fromDate, int toDate, boolean dayData,
                                                  boolean forSU) {
        String where = "";
        where += "country = '" + country + "'";
        if (!CollectionUtils.isEmpty(planLevels)) {
            where += " and plan_level in " + buildInExpression(planLevels);
        }
        if (!CollectionUtils.isEmpty(customers)) {
            where += " and sold_to_desc in " + buildInExpression(customers);
        }
        if (!CollectionUtils.isEmpty(source)) {
            where += " and data_source in " + buildInExpression(source);
        }
        if (!CollectionUtils.isEmpty(categories)) {
            where += " and category in " + buildInExpression(categories);
        }
        if (!CollectionUtils.isEmpty(subCategories)) {
            where += " and sub_category in " + buildInExpression(subCategories);
        }
        if (!CollectionUtils.isEmpty(brands)) {
            where += " and brand in " + buildInExpression(brands);
        }
        if (!CollectionUtils.isEmpty(subBrands)) {
            where += " and sub_brand in " + buildInExpression(subBrands);
        }
        if (!CollectionUtils.isEmpty(oskus)) {
            where += " and ean in " + buildInExpression(oskus);
        }
        if (!CollectionUtils.isEmpty(eventIds)) {
            where += " and event_id in " + buildInExpression(eventIds);
        }

        if (!CollectionUtils.isEmpty(source) && source.contains("SELL IN")) {
            where += " and concat(year, lpad(month, 2, 0)) between " + fromDate + " and " + toDate;
        } else {
            if (!dayData) {
                where += " and week between " + fromDate + " and " + toDate;
            } else {
                where += " and concat(concat(year, lpad(month, 2, 0)), lpad(cast(day as decimal(2, 0)), 2, 0)) between " + fromDate + " and " + toDate;
            }
        }
        return where;
    }

    private String buildInExpression(List<String> userSelectedValues) {
        StringBuilder in = new StringBuilder();
        for (String s : userSelectedValues) {
            in.append("'").append(s).append("', ");
        }
        String x = in.toString();
        if (x.lastIndexOf(",") != -1) {
            x = x.substring(0, x.lastIndexOf(","));
            x = "(" + x + ")";
        }
        return x;
    }

    @Override
    public List<BaseLineCustomerModel> getCustomerHierarchy(String country, List<String> sources) {
        List<BaseLineCustomerModel> baseLineCustomerModels = new ArrayList<>();
        try(Connection conn = dbConfig.getJdbcConnection()) {
            String sql = "SELECT DISTRIBUTION_CHANNEL, SALES_ORG, SOLD_TO_DESC, PLAN_LEVEL " +
                    "FROM rgm_adv_anltcs.reporting.v_rgm_sls_fct_data_post_roi " +
                    "WHERE COUNTRY = ? ";
            if(sources != null && !sources.isEmpty()) {
                StringBuilder s = new StringBuilder(" AND data_source IN (");
                for(String x : sources) {
                    s.append("?,");
                }
                s = new StringBuilder(s.substring(0, s.lastIndexOf(",")));
                s.append(")");
                sql += s;
            }
            sql += " GROUP BY DISTRIBUTION_CHANNEL, SALES_ORG, SOLD_TO_DESC, PLAN_LEVEL";
            PreparedStatement stat = conn.prepareStatement(sql);
            stat.setString(1, country);
            int y = 2;
            if(sources != null && !sources.isEmpty()) {
                for(String s : sources) {
                    stat.setString(y, s);
                    y++;
                }
            }
            ResultSet res = stat.executeQuery();
            while (res.next()) {
                BaseLineCustomerModel baseLineCustomerModel = new BaseLineCustomerModel();
                baseLineCustomerModel.setDistrChannelDesc(res.getString(1));
                baseLineCustomerModel.setSalesOffice(res.getString(2));
                baseLineCustomerModel.setSoldToDesc(res.getString(3));
                baseLineCustomerModel.setPlanLevel(res.getString(4));
                baseLineCustomerModels.add(baseLineCustomerModel);
            }
        } catch (SQLException e) {
            logger.error("Could not select customer hierarchy", e);
        }
        return baseLineCustomerModels;
    }
}
