package com.kcc.springjpa.snowflake.dao.impl;

import com.kcc.springjpa.snowflake.configuration.DBConfig;
import com.kcc.springjpa.snowflake.dao.BaseLineDao;
import com.kcc.springjpa.snowflake.entity.BaseLineData;
import com.kcc.springjpa.snowflake.model.BaseLineCustomerModel;
import com.kcc.springjpa.snowflake.model.BaseLineProductModel;
import com.kcc.springjpa.snowflake.model.BaseLineResultsModel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@Repository
public class BaseLineDaoImpl implements BaseLineDao {

	private static final Logger logger = LogManager.getLogger(BaseLineDaoImpl.class);

	@Autowired
	DBConfig dbConfig;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public List<String> getCountriesList() throws SQLException {
		List<String> countriesList = new ArrayList<String>();
		Connection conn = dbConfig.getJdbcConnection();
		if (conn != null) {
			try {
				Statement stat = conn.createStatement();
				ResultSet res = stat.executeQuery(
						"select COUNTRY " +
								"from rgm_adv_anltcs.reporting.v_rgm_sls_fct_data_baseline " +
								"where active = true " +
								"group by country");
				while (res.next()) {
					countriesList.add(res.getString("COUNTRY"));
				}
				logger.info("Number of Countries " + countriesList.size());
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				conn.close();
			}
		}
		return countriesList;
	}

	@Override
	public List<BaseLineProductModel> getProductHierarchy(String country) throws SQLException {
		List<BaseLineProductModel> baseLineProductModels = new ArrayList<BaseLineProductModel>();
		Connection conn = dbConfig.getJdbcConnection();
		if (conn != null) {
			try {
				PreparedStatement stat = conn.prepareStatement("SELECT COUNTRY, CATEGORY, SUB_CATEGORY, BRAND, SUB_BRAND, ltrim(EAN, '0') as EAN " +
						"FROM rgm_adv_anltcs.reporting.v_rgm_sls_fct_data_baseline " +
						"WHERE ACTIVE = true AND COUNTRY = ? " +
						"group by COUNTRY, CATEGORY, SUB_CATEGORY, BRAND, SUB_BRAND, EAN");
				stat.setString(1, country);
				ResultSet res = stat.executeQuery();
				logger.info("Number of BaseLine Product Hierarchy Records " + res.getFetchSize());
				while (res.next()) {
					BaseLineProductModel baseLineProductModel = new BaseLineProductModel();
					baseLineProductModel.setCountry(res.getString("COUNTRY"));
					baseLineProductModel.setCategory(res.getString("CATEGORY"));
					baseLineProductModel.setSubCategory(res.getString("SUB_CATEGORY"));
					baseLineProductModel.setBrand(res.getString("BRAND"));
					baseLineProductModel.setSubBrand(res.getString("SUB_BRAND"));
					baseLineProductModel.setEan(res.getString("EAN"));
					baseLineProductModels.add(baseLineProductModel);
				}
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				conn.close();
			}
		}
		return baseLineProductModels;
	}

	@Override
	public List<BaseLineCustomerModel> getCustomerHierarchy(String country) throws SQLException {
		List<BaseLineCustomerModel> baseLineCustomerModels = new ArrayList<>();
		Connection conn = dbConfig.getJdbcConnection();
		String sql = "select DISTR_CHANNEL, SALES_ORG, SOLD_TO_DESC, PLAN_LEVEL " +
				"from rgm_adv_anltcs.reporting.v_rgm_sls_fct_data_baseline " +
				"WHERE ACTIVE = true AND COUNTRY = ? " +
				"group by DISTR_CHANNEL, SALES_ORG, SOLD_TO_DESC, PLAN_LEVEL";
		if (conn != null) {
			try {
				PreparedStatement stat = conn.prepareStatement(sql);
				stat.setString(1, country);
				ResultSet res = stat.executeQuery();
				logger.info("Number of BaseLine Product Hierarchy Records " + res.getFetchSize());
				while (res.next()) {
					BaseLineCustomerModel baseLineCustomerModel = new BaseLineCustomerModel();
					baseLineCustomerModel.setDistrChannelDesc(res.getString(1));
					baseLineCustomerModel.setSalesOffice(res.getString(2));
					baseLineCustomerModel.setSoldToDesc(res.getString(3));
					baseLineCustomerModel.setPlanLevel(res.getString(4));
					baseLineCustomerModels.add(baseLineCustomerModel);
				}
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				conn.close();
			}
		}
		return baseLineCustomerModels;
	}

	@Override
	public List<BaseLineResultsModel> findByFilter(String country, int year, List<String> planLevels,
												   List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
												   List<String> subBrands, List<String> eans, String granularity) throws SQLException {
		
		logger.info("BaseLine Results Custom Query Execution#######################################");
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<BaseLineResultsModel> cq = cb.createQuery(BaseLineResultsModel.class);
		Root<BaseLineData> root = cq.from(BaseLineData.class);
		
		List<Selection<?>> s = new LinkedList<Selection<?>>();		
		s.add(root.get("year"));
		s.add(root.get("month"));
		s.add(root.get("week"));
		if(granularity.equals("daily")) {
			s.add(root.get("day"));
		}
		s.add(cb.sum(root.get("baseLineTotalQuantity")));
		s.add(cb.sum(root.get("baseLineAdjustedQuantity")));
		cq.multiselect(s);

//		cq.multiselect(cb.sum(root.get("promoProfit")), cb.sum(root.get("baselineProfit")),
//				cb.sum(root.get("netProfit")), cb.sum(root.get("totalVolume")), cb.sum(root.get("baselineVolume")), cb.sum(root.get("promoInvestment")));
		
		Predicate result = cb.equal(root.get("country"), country);
		result = cb.and(result, cb.equal(root.get("year"), year));
		result = cb.and(result, cb.equal(root.get("active"), true));
//		result = cb.and(result, cb.greaterThan(root.get("totalQuantity"), -1));
		if (!CollectionUtils.isEmpty(planLevels)) {
			result = cb.and(result, root.get("planLevel").in(planLevels));
		}
		if (!CollectionUtils.isEmpty(customers)) {
			result = cb.and(result, root.get("soldToDesc").in(customers));
		}
		if (!CollectionUtils.isEmpty(categories)) {
			result = cb.and(result, root.get("category").in(categories));
		}
		if (!CollectionUtils.isEmpty(subCategories)) {
			result = cb.and(result, root.get("subCategory").in(subCategories));
		}
		if (!CollectionUtils.isEmpty(brands)) {
			result = cb.and(result, root.get("brand").in(brands));
		}
		if (!CollectionUtils.isEmpty(subBrands)) {
			result = cb.and(result, root.get("subBrand").in(subBrands));
		}
		if (!CollectionUtils.isEmpty(eans)) {
			result = cb.and(result, root.get("ean").in(eans));
		}
		cq.where(result);
		if(granularity.equals("daily")) {
			cq.groupBy(root.get("year"), root.get("month"), root.get("week"), root.get("day"));
		} else {
			cq.groupBy(root.get("year"), root.get("month"), root.get("week"));
		}

		TypedQuery<BaseLineResultsModel> q = entityManager.createQuery(cq);		
		logger.info("BASELINE RESULTS QUERY********************************************" + q.toString());
		return q.getResultList();
	}

	@Override
	public boolean dailyAvailable(String country) {
		boolean a = false;
		try(Connection c = dbConfig.getJdbcConnection()) {
			PreparedStatement p = c.prepareStatement("SELECT COUNT(1) dailyCount FROM " +
					"RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_BASELINE WHERE ACTIVE = true AND COUNTRY = ? " +
					"AND DAY > 0");
			p.setString(1, country);
			ResultSet rs = p.executeQuery();
			while(rs.next()) {
				a = rs.getInt("dailyCount") > 0;
			}
		} catch (SQLException e) {
			logger.error("Query for dailyAvailable failed", e);
		}
		return a;
	}
}
