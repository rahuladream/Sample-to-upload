package com.kcc.springjpa.snowflake.dao;

import com.kcc.springjpa.snowflake.dtos.GetElasticitiesRequest;
import com.kcc.springjpa.snowflake.dtos.LineFittingDataPoint;
import com.kcc.springjpa.snowflake.entity.OwnCrossCategory;
import com.kcc.springjpa.snowflake.entity.OwnCrossCommonFields;
import com.kcc.springjpa.snowflake.model.CrossOwnView;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface ElasticityDao {
	
	public Map<String, Boolean> isViewMoreOwn(String country, List<String> initialLeafValues,
			String levelIndicator) throws SQLException, Exception;
	
	public boolean isViewMoreCross(String country, String initialLeafValue,
	String targetLeafValue, String levelIndicator) throws SQLException, Exception;

	boolean scopeExists(String country, String category, String scope, String levelIndicator, String source) throws Exception;

	List<String> getAvailableSources(String country, String productLevel) throws Exception;

	String lastModelUpdateDate(String country) throws Exception;

	List<LineFittingDataPoint> getLineFittingDataPoints(String country, String initial, String target, String productLevel, String customer);

	List<CrossOwnView> findByInitials(String country, List<String> leafValues, String scope, String source, String flag, boolean initial)
			throws Exception;

	<SnowT extends OwnCrossCommonFields> List<SnowT> products(String country, String flag, String type,
															  List<String> initialLeafValues,
															  List<String> targetLeafValues,
															  String source,
															  String category,
															  List<String> initialSubCategories,
															  List<String> targetSubCategories,
															  List<String> initialManufacturers,
															  List<String> targetManufacturers,
															  List<String> initialBrands,
															  List<String> targetBrands,
															  List<String> initialSubBrands,
															  List<String> targetSubBrands,
															  List<String> initialPacks,
															  List<String> targetPacks,
															  String productLevel,
															  Class<SnowT> clazz) throws Exception;

	List<OwnCrossCategory> categories(String country,
									  String flag,
									  String type, String source,
									  String category);

	<SnowT extends OwnCrossCommonFields> List<SnowT> elasticitiesForDownload(GetElasticitiesRequest r, Class<SnowT> clazz) throws Exception;
}
