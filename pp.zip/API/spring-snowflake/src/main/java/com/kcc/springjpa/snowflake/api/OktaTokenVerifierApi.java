package com.kcc.springjpa.snowflake.api;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kcc.springjpa.snowflake.entity.Customer;
import com.kcc.springjpa.snowflake.model.OktaApiAuthenticator;
import com.kcc.springjpa.snowflake.model.OktaForm;
import com.kcc.springjpa.snowflake.utility.StringResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "okta", description = "OKTA API")
public interface OktaTokenVerifierApi {
	
	@ApiOperation(value = "", response = Customer.class, tags = { "Okta", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "A successful Access Token Verified", response = StringResponse.class) })
	@RequestMapping(value = "/validateAccessToken", produces = { "application/json" }, method = RequestMethod.POST)
	ResponseEntity<StringResponse> validateAccessToken(@RequestParam(value = "accessToken", required = true) String accessToken) throws Exception;
	
	@ApiOperation(value = "", response = Customer.class, tags = { "Okta", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "A successful ID Token Verified", response = StringResponse.class) })
	@RequestMapping(value = "/validateIdToken", produces = { "application/json" }, method = RequestMethod.POST)
	ResponseEntity<StringResponse> validateIdToken(@RequestParam(value = "idToken", required = true) String idToken) throws Exception;
	
	@ApiOperation(value = "", response = OktaApiAuthenticator.class, tags = { "Okta", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "A successful API Token Generated", response = OktaApiAuthenticator.class) })
	@RequestMapping(value = "/generateApiToken", produces = { "application/json" }, method = RequestMethod.POST)
	ResponseEntity<OktaApiAuthenticator> generateAuthenticateToken(@RequestBody OktaForm oktaForm) throws Exception;

}
