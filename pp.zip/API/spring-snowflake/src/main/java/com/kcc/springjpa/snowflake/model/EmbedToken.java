package com.kcc.springjpa.snowflake.model;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class EmbedToken {

	public String token;

	// token id
	public String tokenId;

	// token expiration time
	public String expiration;

}
