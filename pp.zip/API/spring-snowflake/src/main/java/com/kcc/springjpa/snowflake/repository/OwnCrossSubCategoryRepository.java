package com.kcc.springjpa.snowflake.repository;

import java.util.ArrayList;
import java.util.List;

import com.kcc.springjpa.snowflake.model.CrossOwnView;
import net.snowflake.client.jdbc.internal.amazonaws.util.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.kcc.springjpa.snowflake.entity.OwnCrossSubCategoryData;
import org.springframework.util.CollectionUtils;

import javax.persistence.criteria.Predicate;

@Repository
@Transactional
public interface OwnCrossSubCategoryRepository extends JpaRepository<OwnCrossSubCategoryData, Integer> {
	
	// Query to get OWN Elasticity Data
	public List<OwnCrossSubCategoryData> findAllByCountryAndFlagAndTypeAndSourceAndInitialSubCategoryIn(String country, String flag, String type, String source, List<String> subCategories);

	//Query to get CROSS Elasticity Data
	public List<OwnCrossSubCategoryData> findAllByCountryAndFlagAndTypeAndSourceAndInitialSubCategoryInAndTargetSubCategoryIn(
			String country, String flag, String type, String source, List<String> initialLeafValues, List<String> targetLeafValues);

	public List<OwnCrossSubCategoryData> findAllByCountryAndFlagAndTypeAndInitialSubCategoryInAndTargetSubCategoryIn(
			String country, String flag, String type, List<String> initialLeafValues, List<String> targetLeafValues);

	public List<OwnCrossSubCategoryData> findAllByCountry(String country);

	@Query(value = "SELECT * FROM REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_SUB_CATEGORY s " +
			"WHERE s.COUNTRY = :country AND s.FLAG = :flag AND s.TYPE = :type AND s.CATEGORY = :category AND s.SOURCE = :source " +
			"ORDER BY s.ELASTICITY_AVG_PRICE DESC " +
			"LIMIT :limit", nativeQuery = true)
	List<OwnCrossSubCategoryData> findTopN(@Param("country") String country,
										   @Param("flag") String flag,
										   @Param("type") String type,
										   @Param("limit") int limit,
										   @Param("category") String category,
										   @Param("source") String source);

	@Query(value = "SELECT * FROM REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_SUB_CATEGORY s " +
			"WHERE s.COUNTRY = :country AND s.FLAG = :flag AND s.TYPE = :type AND s.CATEGORY = :category AND s.SOURCE = :source " +
			"ORDER BY s.ELASTICITY_AVG_PRICE ASC " +
			"LIMIT :limit", nativeQuery = true)
	List<OwnCrossSubCategoryData> findBottomN(@Param("country") String country,
											  @Param("flag") String flag,
											  @Param("type") String type,
											  @Param("limit") int limit,
											  @Param("category") String category,
											  @Param("source") String source);

	default List<CrossOwnView> findByInitials(String country, List<String> leafValues, String scope, String source, String flag, boolean initial) {
		List<CrossOwnView> views = new ArrayList<>();
		Specification<OwnCrossSubCategoryData> spec = InitialSpecs.findBySubCategoryFilter(country, leafValues, scope, source, flag);
		List<OwnCrossSubCategoryData> items = findAll(spec);
		for(OwnCrossSubCategoryData d : items) {
			CrossOwnView v = new CrossOwnView();
			if(initial) {
				v.category = d.getCategory();
				v.initialSubCategory = d.getInitialSubCategory();
			} else {
				v.category = d.getCategory();
				v.targetSubCategory = d.getTargetSubCategory();
			}
			views.add(v);
		}
		return views;
	}

	class InitialSpecs {

		public static Specification<OwnCrossSubCategoryData> findBySubCategoryFilter(String country, List<String> leafValues, String scope, String source, String flag) {
			return (root, query, builder) -> {
				Predicate result = builder.equal(root.get("country"), country);
				result = builder.and(result, root.get("flag").in(flag));
				if (StringUtils.isNullOrEmpty(scope)) {
					if (source != null) {
						result = builder.and(result, root.get("source").in(source));
					}
				} else if (StringUtils.isNullOrEmpty(source)) {
					result = builder.and(result, root.get("type").in(scope));
				} else {
					result = builder.and(result, root.get("type").in(scope));
					result = builder.and(result, root.get("source").in(source));
				}
				if (!CollectionUtils.isEmpty(leafValues)) {
					result = builder.and(result, root.get("initialSubCategory").in(leafValues));
				}
				return result;
			};
		}
	}

	List<OwnCrossSubCategoryData> findAll(Specification<OwnCrossSubCategoryData> s);
}
