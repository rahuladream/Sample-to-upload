package com.kcc.springjpa.snowflake.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Predicate;

import com.kcc.springjpa.snowflake.entity.*;
import com.kcc.springjpa.snowflake.model.CrossOwnView;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import com.kcc.springjpa.snowflake.utility.EanUtility;

import net.snowflake.client.jdbc.internal.amazonaws.util.StringUtils;

@Repository
@Transactional
public interface OwnCrossEanRepository extends JpaRepository<OwnCrossData, Integer> {

	public List<OwnCrossData> findAll();

	public List<OwnCrossData> findAllByCountry(String country);


	// Query to get OWN Elasticity Data
	public List<OwnCrossData> findAllByCountryAndFlagAndTypeAndSourceAndEanInitialIn(String country, String flag, String type, String source, List<String> eans);

	// Query to get OWN and CROSS_INITIAL Product Hierarchy
	@Query(nativeQuery = true, value = "SELECT * FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN WHERE COUNTRY = ? AND FLAG = ? AND TYPE = ? AND SOURCE = ?")
	public List<OwnCrossData> findHierarchy(String country, String flag, String type, String source);

	@Query(value = "SELECT DISTINCT SUB_CATEGORY_INITIAL from REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN WHERE COUNTRY = :country AND CATEGORY = :category", nativeQuery = true)
	List<String> findSubCategoriesForCategory(String country, String category);

	//Query to get Target Product Hierarchy
	default List<CrossOwnView> findByInitials(String country, List<String> leafValues, String scope, String source, String flag, boolean initial){
		List<CrossOwnView> views = new ArrayList<>();
		Specification<OwnCrossData> spec4 = InitialSpecs.findByEANFilter(country, leafValues, scope, source, flag);
		List<OwnCrossData> items4 = findAll(spec4);
		for(OwnCrossData d : items4) {
			CrossOwnView v = new CrossOwnView();
			if(initial) {
				v.category = d.getCategory();
				v.initialSubCategory = d.getInitialSubCategory();
				v.initialManufacturer = d.getInitialManufacturer();
				v.initialBrand = d.getInitialBrand();
				v.initialSubBrand = d.getInitialSubBrand();
				v.initialPack = d.getInitialPack();
				v.eanInitial = d.getEanInitial();
				v.eanDescriptionInitial = d.getEanDescriptionInitial();
				v.initialTier = d.getInitialTier();
			} else {
				v.category = d.getCategory();
				v.targetSubCategory = d.getTargetSubCategory();
				v.targetManufacturer = d.getTargetManufacturer();
				v.targetBrand = d.getTargetBrand();
				v.targetSubBrand = d.getTargetSubBrand();
				v.targetPack = d.getTargetPack();
				v.eanTarget = d.getEanTarget();
				v.eanDescriptionTarget = d.getEanDescriptionTarget();
				v.targetTier = d.getTargetTier();
			}
			views.add(v);
		}
		return views;
	}
	
	List<OwnCrossData> findAll(Specification<OwnCrossData> specification);
	
	class InitialSpecs	{
	   public static Specification<OwnCrossData> findByEANFilter(String country, List<String> leafValues, String scope, String source, String flag)	   {
			return (root, query, builder) -> {
				Predicate result = builder.equal(root.get("country"), country);
				result = builder.and(result, root.get("flag").in(flag));
				if(StringUtils.isNullOrEmpty(scope)) {
					if(source != null) {
						result = builder.and(result, root.get("source").in(source));
					}
				} else if(StringUtils.isNullOrEmpty(source)) {
					result = builder.and(result, root.get("type").in(scope));
				} else {
					result = builder.and(result, root.get("type").in(scope));
					result = builder.and(result, root.get("source").in(source));
				}
				if (!CollectionUtils.isEmpty(leafValues)) {
					List<String> eanNumbers = EanUtility.getEanNumbersFromDescriptions(leafValues);
					result = builder.and(result, root.get("eanInitial").in(eanNumbers));
				}
				return result;
			};
		}
	}

	//Query to get CROSS Elasticity Data
	public List<OwnCrossData> findAllByCountryAndFlagAndTypeAndSourceAndEanInitialInAndEanTargetIn(String country, String cross, String type,
																								   String source, List<String> initialLeafValues, List<String> targetLeafValues);

	public List<OwnCrossData> findAllByCountryAndFlagAndTypeAndEanInitialInAndEanTargetIn(String country, String cross, String type,
																								   List<String> initialLeafValues, List<String> targetLeafValues);

	@Query(value = "SELECT * FROM REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN s " +
			"WHERE s.COUNTRY = :country AND s.FLAG = :flag AND s.TYPE = :type AND s.CATEGORY = :category AND s.SOURCE = :source " +
			"ORDER BY s.ELASTICITY_AVG_PRICE DESC " +
			"LIMIT :limit", nativeQuery = true)
	List<OwnCrossData> findTopN(@Param("country") String country,
								@Param("flag") String flag,
								@Param("type") String type,
								@Param("limit") int limit,
								@Param("category") String category,
								@Param("source") String source);

	@Query(value = "SELECT * FROM REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN s " +
			"WHERE s.COUNTRY = :country AND s.FLAG = :flag AND s.TYPE = :type AND s.CATEGORY = :category AND s.SOURCE = :source " +
			"ORDER BY s.ELASTICITY_AVG_PRICE ASC " +
			"LIMIT :limit", nativeQuery = true)
	List<OwnCrossData> findBottomN(@Param("country") String country,
								   @Param("flag") String flag,
								   @Param("type") String type,
								   @Param("limit") int limit,
								   @Param("category") String category,
								   @Param("source") String source);

	List<OwnCrossData> findByCountryAndFlagAndTypeAndSource(String country, String flag, String type, String source);

	List<OwnCrossData> findByCountryAndFlag(String country, String flag);

	List<OwnCrossData> findByCountryAndFlagAndType(String country, String flag, String scope);

	List<OwnCrossData> findByCountryAndFlagAndSource(String country, String flag, String source);

	@Query(value = "SELECT DISTINCT SOURCE FROM REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN WHERE COUNTRY = :country AND FLAG = :flag", nativeQuery = true)
	List<String> distinctSources(@Param(value = "country") String country, @Param("flag") String flag);

	@Query(value = "SELECT DISTINCT SOURCE FROM REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN WHERE COUNTRY = :country", nativeQuery = true)
	List<String> distinctSources(@Param(value = "country") String country);

}
