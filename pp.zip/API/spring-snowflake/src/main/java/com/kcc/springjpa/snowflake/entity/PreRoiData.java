package com.kcc.springjpa.snowflake.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@IdClass(PreRoiKey.class)
@Table(name = "V_RGM_SLS_FCT_DATA_PRE_ROI", schema = "REPORTING")
@Getter
@Setter
public class PreRoiData {
	
	@Column(name = "COUNTRY")
	private String country;
	
	@Column(name = "DATA_SOURCE")
	private String dataSource;
	
//	@Column(name = "CREATE_DATE")
//	private Timestamp startingDate;

	@Column(name = "CATEGORY")
	private String category;

	@Column(name = "SUB_CATEGORY")
	private String subCategory;
	
	@Column(name = "BRAND")
	private String brand;
	
	@Id
	@Column(name = "SUB_BRAND")
	private String subBrand;
	
	@Column(name = "TIER")
	private String tier;
	
	@Column(name = "SIZE")
	private String size;
	
	@Column(name = "ROLL")
	private String roll;
	
	@Column(name = "PACK")
	private String pack;
	
	@Column(name = "PACK_COUNT")
	private String packCount;
	
	@Column(name = "PLAN_LEVEL")
	private String planLevel;
	
	@Column(name = "DISTRIBUTION_CHANNEL")
	private String distributionChannel;
	
	@Id
	@Column(name = "SOLD_TO")
	private String soldTo;
	
	@Column(name = "SOLD_TO_DESC")
	private String customerName;
	
	@Id
	@Column(name = "EAN")
	private String ean;
	
	@Column(name = "EAN_DESCRIPTION")
	private String eanDescription;
	
	@Column(name = "WEEK")
	private Integer week;
	
	@Column(name = "MONTH")
	private Integer month;
	
	@Column(name = "YEAR")
	private Integer year;
	
	@Column(name = "SALES_VALUE")
	private Float avgSalesValue;
	
	@Column(name = "SALES_VOLUME")
	private Float avgSalesVolume;
	
	@Column(name = "TRADE_ALLOWANCE_ON_INV")
	private Float avgTradeAllowanceOnInv;
	
	@Column(name = "FIN_DISC")
	private Float avgFinDisc;
	
	@Column(name = "CASH_DISCOUNT")
	private Float avgCashDiscount;
	
	@Column(name = "TRADE_ALLOWANCE")
	private Float avgTradeAllowance;
	
	@Column(name = "TOT_DISTR")
	private Float avgDistribution;
	
	@Column(name = "TRADE_PROMOTION_ON_INV")
	private Float avgTradePromotionsOnInv;
	
//	@Column(name = "CONSUMER_PROMOTIONS_ON_INV")
//	private Float avgCustomerPromotionsOnInv;
//	
//	@Column(name = "TRADE_PROMOTIONS_RIR")
//	private Float avgTradePromotionsRir;
	
	@Column(name = "CONSUMER_PROMOTIONS_RIR")
	private Float avgConsumerPromotionsRir;
	
	@Column(name = "TOT_COST_SALE")
	private Float avgTotCostSale;
	
	@Column(name = "DA_ON_INVOICE")
	private Float avgDAOnInv; // United Kingdom
	
	@Column(name = "ON_INVOICE_PROMO_DISCOUNT")
	private Float avgOnInvPromoDisc; // United Kingdom
	
	@Column(name = "NET_INVOICE_VALUE")
	private Float avgNetInvValue; // United Kingdom
	
	@Column(name = "DA_OFF_INVOICE")
	private Float avgDAOffInv; // United Kingdom
	
	@Column(name = "OFF_INVOICE_PROMO_DISCOUNT")
	private Float avgOffInvPromoDisc; // United Kingdom
	
	@Column(name = "GROSS_PROFIT")
	private Float avgGrossProfit; // United Kingdom
	
	@Column(name = "COST_OF_SALES_TOTAL")
	private Float costOfSalesTotal; // United Kingdom
	
	@Column(name = "GROSS_SALES_AFTER_DISC")
	private Float grossSalesAfterDisc; // United Kingdom
	
	@Column(name = "VOLUME_CASES")
	private Float volumeCases; // United Kingdom
	
	@Column(name = "SALES_VOLUME_PACKS")
	private Float salesVolumePacks; // South Korea
	
	@Column(name = "NON_PROMOTED_PRICE")
	private Float nonPromotedPrice; // ???
	
	@Column(name = "NON_PROMOTION_RIR")
	private Float nonPromotionRir; // South Korea

	@Column(name = "PROMOTION_RIR")
	private Float promotionRir; // South Korea
	
	@Column(name = "VARIABLE_COGS")
	private Float variableCogs; // ???
	
	@Column(name = "DISTRIBUTION_EXPENSE")
	private Float distributionExpense; // South Korea
	
	@Column(name = "GROSS_SALES_TESTING")
	private Float grossSalesTesting; // ???

	@Column(name = "NET_SALES_TESTING")
	private Float netSalesTesting; // ???
	
	@Column(name = "TOTAL_RIR_TESTING")
	private Float totalRirTesting; // ???
	
	@Column(name = "PROMOTION_RIR_TESTING")
	private Float promotionRirTesting; // ???
	
	@Column(name = "NON_PROMOTION_RIR_TESTING")
	private Float nonPromotionRirTesting; // ???
	
	@Column(name = "VOLUME_PACKS_TESTING")
	private Float volumePacksTesting; // ???
	
	@Column(name = "MIN_GMR_MONTH_TESTING")
	private Float minGmrMonthTesting; // ???
	
	@Column(name = "MAX_GMR_MONTH_TESTING")
	private Float maxGmrMonthTesting; // ???
	
	@Column(name = "COGS_PER_CASE")
	private Float cogsPerCase;
	
	@Column(name = "NPP_PER_CASE")
	private Float nppPerCase;
	
	@Column(name = "RETAILER_MARGIN")
	private Float retailerMargin;
	
	@Column(name = "RETAILER_MARGIN_PCT")
	private Float retailerMarginPct;
	
	@Column(name = "TA_PCT")
	private Float taPct;
	
	@Column(name = "TP_PCT")
	private Float tpPct;
	
	@Column(name = "HISTORICAL_VOLUME")
	private Float historicalVolume;

}
