package com.kcc.springjpa.snowflake.model;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

@Component
@Getter
@Setter
public class BaseLineDataModel {
	
	public int year;
	
	public AdjustedBaseLineModel statisticalBaseLine;
	
	public AdjustedBaseLineModel adjustedBaseLine;
	
	public AdjustedBaseLineModel upperBand;
	
	public AdjustedBaseLineModel lowerBand;

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		BaseLineDataModel that = (BaseLineDataModel) o;
		return year == that.year;
	}

	@Override
	public int hashCode() {
		return Objects.hash(year);
	}
}
