package com.kcc.springjpa.snowflake.service;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.kcc.springjpa.snowflake.dtos.*;
import com.kcc.springjpa.snowflake.entity.PreRoiSim;
import com.kcc.springjpa.snowflake.entity.Scenario;
import com.kcc.springjpa.snowflake.model.PreRoiPromoSimulationModel;
import com.kcc.springjpa.snowflake.model.PreRoiSimulatedPAndLModel;
import com.kcc.springjpa.snowflake.model.PromoSimulation;
import com.kcc.springjpa.snowflake.model.Simulation;
import com.kcc.springjpa.snowflake.utility.StringResponse;

public interface PreRoiDataService {
	
	public Map<String, Boolean> getPromoType(String country) throws ParseException, SQLException;

	public StringResponse getBaselineValue(String country, List<String> planLevels, List<String> customers,
			List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands,
			List<String> eans, String fromDate, String toDate) throws SQLException, ParseException;

	public PreRoiPromoSimulationModel getSimulatedROIAndNPL(String country, List<String> planLevels, List<String> customers,
                                                            List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands,
                                                            List<String> eans, String fromDate, String toDate, Double baseLineVolume, Double incrementalVolume,
                                                            List<String> promoInvestmentAbsValues, List<String> promoInvestmentNonAbsValues, Double promotedPrice) throws SQLException;

	public List<PreRoiSimulatedPAndLModel> getSimulatedPAndL(String country, List<String> planLevels, List<String> customers,
															 List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands,
															 List<String> eans, String fromDate, String toDate, Double baseLineVolume, Double incrementalVolume,
															 List<String> promoInvestmentAbsValues, List<String> promoInvestmentNonAbsValues, Double netProfitOrLoss,
															 Double roiPercentage, Double totalPromoInvestment, Double npp, Double cogs, Double promotedPrice) throws ParseException;

	public Double getPromoInvMagicWand(String country, Double baseLineVolume, Double incrementalVolume,
			Double targetRoiPercentage, Double totalPromoInvestment, Double npp, Double cogs, Boolean isAbs);

	public Double getCalculatedIncrementalVolume(String country, Double promoInvestment, Double targetRoiPercentage,
			Double baseLineVolume, Double npp, Double cogs);

	public PreRoiSim savePromoSimulation(String name, PromoSimulation promoSimulation) throws SQLException, ParseException;

	List<Simulation> findSimulations(String country, String fromDate, String toDate, String name, String scenario, String createdBy) throws Exception;

	StringResponse deleteSimulations(DeleteSimulationsRequest r, String createdBy) throws Exception;

    GetSimulationsTallyResponse tally(GetSimulationsTallyRequest request) throws ParseException;

	void createScenario(CreateScenarioRequest r, String createdBy) throws Exception;

	void updateScenario(UpdateScenarioRequest r, String createdBy) throws Exception;

	void deleteScenario(String name, String createdBy) throws Exception;

	List<Scenario> scenarios(String createdBy) throws Exception;
}
