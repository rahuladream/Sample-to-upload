package com.kcc.springjpa.snowflake.service;

import java.util.List;
import java.util.Map;

public interface CorrelationDataService {

	public Map<String, Map<String, String>> getCorrelationAnalysis(String country, List<String> initialLeafValues,
                                                                   List<String> targetLeafValues, String levelIndicator, String scope);

}
