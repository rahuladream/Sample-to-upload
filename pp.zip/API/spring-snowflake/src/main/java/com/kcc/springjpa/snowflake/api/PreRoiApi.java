package com.kcc.springjpa.snowflake.api;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.kcc.springjpa.snowflake.dtos.*;
import com.kcc.springjpa.snowflake.entity.Scenario;
import com.kcc.springjpa.snowflake.model.Simulation;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.kcc.springjpa.snowflake.entity.PreRoiSim;
import com.kcc.springjpa.snowflake.model.PreRoiPromoSimulationModel;
import com.kcc.springjpa.snowflake.model.PreRoiSimulatedPAndLModel;
import com.kcc.springjpa.snowflake.model.PromoSimulation;
import com.kcc.springjpa.snowflake.utility.StringResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "preRoi", description = "PRE ROI API")
public interface PreRoiApi {

	@ApiOperation(value = "", response = Map.class, tags = { "PRE-ROI", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Pre ROI Promotype data", response = Map.class) })
	@RequestMapping(value = "/preRoiPromoTypes", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<Map<String, Boolean>> getPromoTypes(@RequestParam(value = "country", required = true) String country)
			throws Exception;

	@ApiOperation(value = "", response = StringResponse.class, tags = { "PRE-ROI", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "PreROI Baseline Value for the filters selected", response = StringResponse.class) })
	@RequestMapping(value = "/getBaseLineValue", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<StringResponse> getBaseLineValue(@RequestParam(value = "country", required = true) String country,
			@RequestParam(value = "planLevels", required = false) List<String> planLevels,
			@RequestParam(value = "customers", required = false) List<String> customers,
			@RequestParam(value = "categories", required = false) List<String> categories,
			@RequestParam(value = "subCategories", required = false) List<String> subCategories,
			@RequestParam(value = "brands", required = false) List<String> brands,
			@RequestParam(value = "subBrands", required = false) List<String> subBrands,
			@RequestParam(value = "eans", required = false) List<String> eans,
			@RequestParam(value = "fromDate", required = true) String fromDate,
			@RequestParam(value = "toDate", required = true) String toDate) throws Exception;

	@ApiOperation(value = "", response = PreRoiPromoSimulationModel.class, tags = { "PRE-ROI", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "PreROI Simulation Value for the filters selected", response = PreRoiPromoSimulationModel.class) })
	@RequestMapping(value = "/getSimulatedValues", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<PreRoiPromoSimulationModel> getSimulatedROIAndNPL(
			@RequestParam(value = "country", required = true) String country,
			@RequestParam(value = "planLevels", required = false) List<String> planLevels,
			@RequestParam(value = "customers", required = false) List<String> customers,
			@RequestParam(value = "categories", required = false) List<String> categories,
			@RequestParam(value = "subCategories", required = false) List<String> subCategories,
			@RequestParam(value = "brands", required = false) List<String> brands,
			@RequestParam(value = "subBrands", required = false) List<String> subBrands,
			@RequestParam(value = "eans", required = false) List<String> eans,
			@RequestParam(value = "fromDate", required = true) String fromDate,
			@RequestParam(value = "toDate", required = true) String toDate,
			@RequestParam(value = "baseLineVolume", required = true) Double baseLineVolume,
			@RequestParam(value = "incrementalVolume", required = true) Double incrementalVolume,
			@RequestParam(value = "promoInvestmentAbsValues", required = false) List<String> promoInvestmentAbsValues,
			@RequestParam(value = "promoInvestmentNonAbsValues", required = false) List<String> promoInvestmentNonAbsValues,
			@RequestParam(value = "promotedPrice", required = false) Double promotedPrice)
			throws Exception;

	@ApiOperation(value = "", response = PreRoiSimulatedPAndLModel.class, tags = { "PRE-ROI", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "PreROI P and L Chart for the filters selected", response = PreRoiSimulatedPAndLModel.class) })
	@RequestMapping(value = "/getSimulatedPAndL", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<List<PreRoiSimulatedPAndLModel>> getSimulatedPAndL(
			@RequestParam(value = "country", required = true) String country,
			@RequestParam(value = "planLevels", required = false) List<String> planLevels,
			@RequestParam(value = "customers", required = false) List<String> customers,
			@RequestParam(value = "categories", required = false) List<String> categories,
			@RequestParam(value = "subCategories", required = false) List<String> subCategories,
			@RequestParam(value = "brands", required = false) List<String> brands,
			@RequestParam(value = "subBrands", required = false) List<String> subBrands,
			@RequestParam(value = "eans", required = false) List<String> eans,
			@RequestParam(value = "fromDate", required = true) String fromDate,
			@RequestParam(value = "toDate", required = true) String toDate,
			@RequestParam(value = "baseLineVolume", required = true) Double baseLineVolume,
			@RequestParam(value = "incrementalVolume", required = true) Double incrementalVolume,
			@RequestParam(value = "promoInvestmentAbsValues", required = false) List<String> promoInvestmentAbsValues,
			@RequestParam(value = "promoInvestmentNonAbsValues", required = false) List<String> promoInvestmentNonAbsValues,
			@RequestParam(value = "netProfitOrLoss", required = true) Double netProfitOrLoss,
			@RequestParam(value = "roiPercentage", required = true) Double roiPercentage,
			@RequestParam(value = "totalPromoInvestment", required = true) Double totalPromoInvestment,
			@RequestParam(value = "npp", required = true) Double npp,
			@RequestParam(value = "cogs", required = true) Double cogs,
			@RequestParam(value = "promotedPrice", required = false) Double promotedPrice) throws Exception;

	@ApiOperation(value = "", response = Double.class, tags = { "PRE-ROI", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "PreROI Calculated Incremental for the filters selected", response = Double.class) })
	@RequestMapping(value = "/getCalculatedIncrementalVolume", produces = {
			"application/json" }, method = RequestMethod.GET)
	ResponseEntity<Double> getCalculatedIncrementalVolume(
			@RequestParam(value = "country", required = true) String country,
			@RequestParam(value = "promoInvestment", required = true) Double promoInvestment,
			@RequestParam(value = "targetRoiPercentage", required = true) Double targetRoiPercentage,
			@RequestParam(value = "baseLineVolume", required = true) Double baseLineVolume,
			@RequestParam(value = "npp", required = true) Double npp,
			@RequestParam(value = "cogs", required = true) Double cogs) throws Exception;

	@ApiOperation(value = "", response = Map.class, tags = { "PRE-ROI", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "PreROI Promo Investment for Magic Wand for the filters selected", response = Map.class) })
	@RequestMapping(value = "/getPromoInvMagicWand", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<Double> getPromoInvMagicWand(
			@RequestParam(value = "country", required = true) String country,
			@RequestParam(value = "baseLineVolume", required = true) Double baseLineVolume,
			@RequestParam(value = "incrementalVolume", required = true) Double incrementalVolume,
			@RequestParam(value = "targetRoiPercentage", required = true) Double targetRoiPercentage,
			@RequestParam(value = "totalPromoInvestment", required = true) Double totalPromoInvestment,
			@RequestParam(value = "npp", required = true) Double npp,
			@RequestParam(value = "cogs", required = true) Double cogs,
			@RequestParam(value = "isAbs", required = true) Boolean isAbs) throws Exception;

	@ApiOperation(value = "", response = PreRoiSim.class, tags = { "PRE-ROI", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Pre Roi Promo Saved Successfully", response = PreRoiSim.class) })
	@RequestMapping(value = "/admin/savePromoSim", produces = { "application/json" }, method = RequestMethod.POST)
	ResponseEntity<PreRoiSim> savePromo(HttpServletRequest request, @RequestBody PromoSimulation promoSimulation,
			@RequestParam(value = "country", required = true) String country) throws Exception;

	@ApiOperation(value = "", response = PreRoiSim.class, tags = { "PRE-ROI", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Pre Roi Simulations Listed Successfully", response = List.class) })
	@RequestMapping(value = "simulations", produces = {"application/json"}, method = {RequestMethod.GET})
	ResponseEntity<List<Simulation>> findSimulations(HttpServletRequest servletRequest, @RequestParam(value = "country") String country,
													 @RequestParam(value = "fromDate", required = false) String fromDate,
													 @RequestParam(value = "toDate", required = false) String toDate,
													 @RequestParam(value = "name", required = false) String name,
													 @RequestParam(value = "scenario", required = false) String scenario) throws Exception;

	@ApiOperation(value = "", response = StringResponse.class, tags = { "PRE-ROI", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Pre Roi Simulations Deleted Successfully", response = StringResponse.class) })
	@RequestMapping(value = "/deleteSimulations", produces = {"application/json"}, method = {RequestMethod.POST})
	ResponseEntity<StringResponse> deleteSimulations(HttpServletRequest request, @RequestBody DeleteSimulationsRequest r) throws Exception;

	@ApiOperation(value = "", response = GetSimulationsTallyResponse.class, tags = { "PRE-ROI", })
	@ApiResponse(code = 200, message = "Successful tally for simulations", response = GetSimulationsTallyResponse.class)
	@RequestMapping(value = "/simulationsForTally", produces = { "application/json" }, method = { RequestMethod.POST })
	ResponseEntity<GetSimulationsTallyResponse> tally(@RequestBody GetSimulationsTallyRequest request) throws ParseException;

	@ApiOperation(value = "", response = StringResponse.class, tags = {"PRE-ROI",})
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Scenario created successfully", response = StringResponse.class)})
	@RequestMapping(value = "/scenario", produces = {"application/json"}, method = {RequestMethod.POST})
	ResponseEntity<StringResponse> createScenario(HttpServletRequest servletRequest, @RequestBody CreateScenarioRequest request) throws Exception;

	@ApiOperation(value = "", response = StringResponse.class, tags = {"PRE-ROI",})
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Scenario updated successfully", response = StringResponse.class)})
	@RequestMapping(value = "/scenario", produces = {"application/json"}, method = {RequestMethod.PUT})
	ResponseEntity<StringResponse> renameScenario(HttpServletRequest servletRequest, @RequestBody UpdateScenarioRequest request) throws Exception;

	@ApiOperation(value = "", response = StringResponse.class, tags = {"PRE-ROI",})
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Scenario deleted successfully", response = StringResponse.class)})
	@RequestMapping(value = "/scenario/{name}", produces = {"application/json"}, method = {RequestMethod.DELETE})
	ResponseEntity<StringResponse> deleteScenario(HttpServletRequest servletRequest, @PathVariable(value = "name") String name) throws Exception;

	@ApiOperation(value = "", response = List.class, tags = {"PRE-ROI",})
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Retrieved scenarios successfully", response = List.class)})
	@RequestMapping(value = "/scenarios", produces = {"application/json"}, method = {RequestMethod.GET})
	ResponseEntity<List<Scenario>> scenarios(HttpServletRequest servletRequest) throws Exception;
}
