package com.kcc.springjpa.snowflake.api;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import com.kcc.springjpa.snowflake.model.PostRoiModel;
import com.kcc.springjpa.snowflake.model.PostRoiTpQuadrant;
import com.kcc.springjpa.snowflake.service.RoiDataService;

@Controller
public class RoiApiController implements RoiApi {

	private static final Logger logger = LogManager.getLogger(RoiApiController.class);

	@Autowired
	RoiDataService roiDataService;

	@Override
	public ResponseEntity<List<PostRoiModel>> getPostRoiData(String country, List<String> planLevels,
                                                             List<String> customers, List<String> source, List<String> categories, List<String> subCategories, List<String> brands,
                                                             List<String> subBrands, List<String> eans, List<String> eventIds, String fromDate, String toDate, String groupBy, String kpiType, List<Integer> quadrants) throws Exception {
		logger.info("API call to retrieve POST ROI Data for the filters selected: " + country);
		return new ResponseEntity<>(roiDataService.getPostRoiData(country.trim(), planLevels, customers, source, categories,
				subCategories, brands, subBrands, eans, eventIds, fromDate, toDate, groupBy, kpiType, quadrants), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<PostRoiModel> getPostRoiQuadrantData(String country, List<String> planLevels,
															   List<String> customers, List<String> source, List<String> categories, List<String> subCategories, List<String> brands,
															   List<String> subBrands, List<String> eans, List<String> eventIds, String fromDate, String toDate, String kpiType) throws Exception {
		logger.info("API call to retrieve POST ROI Quadrant Data for the filters selected: " + country);
		return new ResponseEntity<>(roiDataService.getPostRoiQuadrantData(country.trim(), planLevels, customers,
				source, categories, subCategories, brands, subBrands, eans, eventIds, fromDate, toDate, kpiType), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<String>> getPostRoiEventIds(String country, List<String> planLevels,
			List<String> customers, List<String> source, List<String> categories, List<String> subCategories, List<String> brands,
			List<String> subBrands, List<String> eans, String fromDate, String toDate) throws Exception {
		logger.info("API call to retrieve POST ROI Event Ids for the filters selected: " + country);
		return new ResponseEntity<>(roiDataService.getPostRoiEventIds(country.trim(), planLevels, customers,
				source, categories, subCategories, brands, subBrands, eans, fromDate, toDate), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<PostRoiTpQuadrant> getPostRoiTpQuadrant(String country, List<String> planLevels,
																  List<String> customers, List<String> source, List<String> categories, List<String> subCategories, List<String> brands,
																  List<String> subBrands, List<String> eans, List<String> eventIds, String fromDate, String toDate, String kpiType) throws Exception {
		logger.info("API call to retrieve POST ROI TP Quadrant for the filters selected: " + country);
		return new ResponseEntity<>(roiDataService.getPostRoiTpQuadrant(country.trim(), planLevels, customers,
				source, categories, subCategories, brands, subBrands, eans, eventIds, fromDate, toDate, kpiType), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Resource> downloadFile(String country, List<String> planLevels, List<String> customers,
												 List<String> source, List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands,
												 List<String> eans, List<String> eventIds, String fromDate, String toDate, String kpiType) throws Exception {
		String filename = "PromoPerformance.xlsx";
		InputStreamResource file = null;
		try {
			file = new InputStreamResource(roiDataService.getPostRoiFile(country.trim(), planLevels, customers, source, categories,
					subCategories, brands, subBrands, eans, eventIds, fromDate, toDate, kpiType));
		} catch (Exception e) {
			logger.error("Could not construct file", e);
			if (e.getCause() != null) {
				logger.error("Root cause", e.getCause());
			}
			throw new Exception(e);
		}
	    
	    HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");
	    return ResponseEntity.ok()
	            .headers(headers)
	            .contentType(MediaType.APPLICATION_OCTET_STREAM)
	            .body(file);
	}

	@Override
	public ResponseEntity<Map<String, Boolean>> hasSellInSelloutData(String country) throws Exception {
		Map<String, Boolean> result =  roiDataService.hasSellInSelloutData(country);
		return  ResponseEntity.ok().body(result);
	}

}
