package com.kcc.springjpa.snowflake.utility;

import com.kcc.springjpa.snowflake.entity.PostRoiData;
import com.kcc.springjpa.snowflake.model.OwnElasticityModelForDownload;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

public class ExcelHelper {

	public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	static String[] POST_ROI_HEADERS = { "Country", "Category", "SubCategory", "Brand", "SubBrand", "PlanLevel", "SoldTo",
			"SoldToDesc", "Ean", "Week", "Month", "Year", "EventId", "BaselineVolume", "ActualVolume", "CogsPerCase",
			"NppPerCase", "PromoInvestment", "BaselineProfit", "PromoProfit", "NetProfit", "RetailerMargin", "RetailerMargin %" };
	static String POST_ROI_SHEET = "PostROIData";

	public static ByteArrayInputStream ownElasticityDataToExcel(Map<String[], List<OwnElasticityModelForDownload>> data, boolean forOwn) {
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {

			for (Map.Entry<String[],List<OwnElasticityModelForDownload>> entry : data.entrySet()) {
				Sheet sheet = workbook.createSheet(entry.getKey()[0]);
				Row headerRow = sheet.createRow(0);
				String[] headers = headers(forOwn, entry.getKey()[1]);
				for (int col = 0; col < headers.length; col++) {
					Cell cell = headerRow.createCell(col);
					cell.setCellValue(headers[col]);
				}
				int rowIdx = 1;
				for (OwnElasticityModelForDownload ownData: entry.getValue()){
					Row row = sheet.createRow(rowIdx++);
					if(forOwn) {
						rowsWithInitialsOnly(row, ownData, entry.getKey()[1]);
					} else {
						rowsWithTargets(row, ownData, entry.getKey()[1]);
					}
				}
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		} catch (IOException e) {
			throw new RuntimeException("Failed to export Own Elasticity data to Excel file: " + e.getMessage());
		}
	}

	private static String[] headers(boolean forOwn, String productLevel) {
		String[] headers;
		if(forOwn) {
			headers = headersForOwn(productLevel);
		} else {
			headers = headersForCross(productLevel);
		}
		return headers;
	}

	private static String[] headersForOwn(String productLevel) {
		String[] headers;
		switch (productLevel) {
			case HierarchyLevel.CATEGORY:
				headers = new String[]{"Customer", "Category", "Price Index", "Average Price", "Average Volume", "Elasticity", "R-Squared", "P-Value", "Range", "# of weeks", "Slope", "Intercept", "Promo Price", "Base Price"};
				break;
			case HierarchyLevel.BRAND:
				headers = new String[]{"Customer", "Category", "SubCategory", "Manufacturer", "Brand", "Price Index", "Average Price", "Average Volume", "Elasticity", "R-Squared", "P-Value", "Range", "# of weeks", "Slope", "Intercept", "Promo Price", "Base Price"};
				break;
			case HierarchyLevel.SUB_BRAND:
				headers = new String[]{"Customer", "Category", "SubCategory", "Manufacturer", "Brand", "Sub-Brand", "Price Index", "Average Price", "Average Volume", "Elasticity", "R-Squared", "P-Value", "Range", "# of weeks", "Slope", "Intercept", "Promo Price", "Base Price"};
				break;
			case HierarchyLevel.PACK:
				headers = new String[]{"Customer", "Category", "SubCategory", "Manufacturer", "Brand", "Sub-Brand", "Pack", "Price Index", "Average Price", "Average Volume", "Elasticity", "R-Squared", "P-Value", "Range", "# of weeks", "Slope", "Intercept", "Promo Price", "Base Price"};
				break;
			default:
				headers = new String[]{"Customer", "Category", "SubCategory", "Manufacturer", "Brand", "Sub-Brand", "Pack", "Tier", "EAN", "EAN Description", "Price Index", "Average Price", "Average Volume", "Elasticity", "R-Squared", "P-Value", "Range", "# of weeks", "Slope", "Intercept", "Promo Price", "Base Price"};
		}
		return headers;
	}

	private static String[] headersForCross(String productLevel) {
		String[] headers;
		switch (productLevel) {
			case HierarchyLevel.CATEGORY:
				headers = new String[]{"Customer", "Category", "Price Index", "Average Price", "Average Volume", "Elasticity", "R-Squared", "P-Value", "Range", "# of weeks", "Slope", "Intercept", "Promo Price", "Base Price"};
				break;
			case HierarchyLevel.BRAND:
				headers = new String[]{"Customer", "Category", "Initial SubCategory", "Target SubCategory", "Initial Manufacturer", "Target Manufacturer", "Initial Brand", "Target Brand", "Price Index", "Average Price", "Average Volume", "Elasticity", "R-Squared", "P-Value", "Range", "# of weeks", "Slope", "Intercept", "Promo Price", "Base Price"};
				break;
			case HierarchyLevel.SUB_BRAND:
				headers = new String[]{"Customer", "Category", "Initial SubCategory", "Target SubCategory", "Initial Manufacturer", "Target Manufacturer", "Initial Brand", "Target Brand", "Initial Sub-Brand", "Target Sub-Brand", "Price Index", "Average Price", "Average Volume", "Elasticity", "R-Squared", "P-Value", "Range", "# of weeks", "Slope", "Intercept", "Promo Price", "Base Price"};
				break;
			case HierarchyLevel.PACK:
				headers = new String[]{"Customer", "Category", "Initial SubCategory", "Target SubCategory", "Initial Manufacturer", "Target Manufacturer", "Initial Brand", "Target Brand", "Initial Sub-Brand", "Target Sub-Brand", "Initial Pack", "Target Pack", "Price Index", "Average Price", "Average Volume", "Elasticity", "R-Squared", "P-Value", "Range", "# of weeks", "Slope", "Intercept", "Promo Price", "Base Price"};
				break;
			default:
				headers = new String[]{"Customer", "Category", "Initial SubCategory", "Target SubCategory", "Initial Manufacturer", "Target Manufacturer", "Initial Brand", "Target Brand", "Initial Sub-Brand", "Target Sub-Brand", "Initial Pack", "Target Pack", "Initial Tier", "Target Tier", "Initial EAN", "Initial EAN Description", "Target EAN", "Target EAN Description", "Price Index", "Average Price", "Average Volume", "Elasticity", "R-Squared", "P-Value", "Range", "# of weeks", "Slope", "Intercept", "Promo Price", "Base Price"};
		}
		return headers;
	}

	private static void rowsWithInitialsOnly(Row row, OwnElasticityModelForDownload ownData, String productLevel) {
		row.createCell(0).setCellValue(ownData.getCustomer());
		row.createCell(1).setCellValue(ownData.getCategory());
		int cell = 1;
		switch (productLevel) {
			case HierarchyLevel.CATEGORY:
				break;
			case HierarchyLevel.EAN:
				row.createCell(++cell).setCellValue(ownData.getSubCategoryInitial());
				row.createCell(++cell).setCellValue(ownData.getManufacturerInitial());
				row.createCell(++cell).setCellValue(ownData.getBrandInitial());
				row.createCell(++cell).setCellValue(ownData.getSubBrandInitial());
				row.createCell(++cell).setCellValue(ownData.getPackInitial());
				row.createCell(++cell).setCellValue(ownData.getTierInitial());
				row.createCell(++cell).setCellValue(ownData.getEanInitial());
				row.createCell(++cell).setCellValue(ownData.getEanDescriptionInitial());
				break;
			case HierarchyLevel.PACK:
				row.createCell(++cell).setCellValue(ownData.getSubCategoryInitial());
				row.createCell(++cell).setCellValue(ownData.getManufacturerInitial());
				row.createCell(++cell).setCellValue(ownData.getBrandInitial());
				row.createCell(++cell).setCellValue(ownData.getSubBrandInitial());
				row.createCell(++cell).setCellValue(ownData.getPackInitial());
				break;
			case HierarchyLevel.SUB_BRAND:
				row.createCell(++cell).setCellValue(ownData.getSubCategoryInitial());
				row.createCell(++cell).setCellValue(ownData.getManufacturerInitial());
				row.createCell(++cell).setCellValue(ownData.getBrandInitial());
				row.createCell(++cell).setCellValue(ownData.getSubBrandInitial());
				break;
			case HierarchyLevel.BRAND:
				row.createCell(++cell).setCellValue(ownData.getSubCategoryInitial());
				row.createCell(++cell).setCellValue(ownData.getManufacturerInitial());
				row.createCell(++cell).setCellValue(ownData.getBrandInitial());
				break;
		}
		row.createCell(++cell).setCellValue(ownData.getPriceIndex());
		row.createCell(++cell).setCellValue(ownData.getAveragePrice());
		row.createCell(++cell).setCellValue(ownData.getAverageQuantity());
		row.createCell(++cell).setCellValue(ownData.getElasticity());
		row.createCell(++cell).setCellValue(ownData.getRsquared());
		row.createCell(++cell).setCellValue(ownData.getPValue());
		row.createCell(++cell).setCellValue(ownData.getRange());
		row.createCell(++cell).setCellValue(ownData.getNWeeks());
		row.createCell(++cell).setCellValue(ownData.getSlope());
		row.createCell(++cell).setCellValue(ownData.getIntercept());
		row.createCell(++cell).setCellValue(ownData.getPromoPrice());
		row.createCell(++cell).setCellValue(ownData.getBasePrice());
	}

	private static void rowsWithTargets(Row row, OwnElasticityModelForDownload ownData, String productLevel) {
		row.createCell(0).setCellValue(ownData.getCustomer());
		row.createCell(1).setCellValue(ownData.getCategory());
		int cell = 1;
		switch (productLevel) {
			case HierarchyLevel.CATEGORY:
				break;
			case HierarchyLevel.EAN:
				row.createCell(++cell).setCellValue(ownData.getSubCategoryInitial());
				row.createCell(++cell).setCellValue(ownData.getSubCategoryTarget());
				row.createCell(++cell).setCellValue(ownData.getManufacturerInitial());
				row.createCell(++cell).setCellValue(ownData.getManufacturerTarget());
				row.createCell(++cell).setCellValue(ownData.getBrandInitial());
				row.createCell(++cell).setCellValue(ownData.getBrandTarget());
				row.createCell(++cell).setCellValue(ownData.getSubBrandInitial());
				row.createCell(++cell).setCellValue(ownData.getSubBrandTarget());
				row.createCell(++cell).setCellValue(ownData.getPackInitial());
				row.createCell(++cell).setCellValue(ownData.getPackTarget());
				row.createCell(++cell).setCellValue(ownData.getTierInitial());
				row.createCell(++cell).setCellValue(ownData.getTierTarget());
				row.createCell(++cell).setCellValue(ownData.getEanInitial());
				row.createCell(++cell).setCellValue(ownData.getEanDescriptionInitial());
				row.createCell(++cell).setCellValue(ownData.getEanTarget());
				row.createCell(++cell).setCellValue(ownData.getEanDescriptionTarget());
				break;
			case HierarchyLevel.PACK:
				row.createCell(++cell).setCellValue(ownData.getSubCategoryInitial());
				row.createCell(++cell).setCellValue(ownData.getSubCategoryTarget());
				row.createCell(++cell).setCellValue(ownData.getManufacturerInitial());
				row.createCell(++cell).setCellValue(ownData.getManufacturerTarget());
				row.createCell(++cell).setCellValue(ownData.getBrandInitial());
				row.createCell(++cell).setCellValue(ownData.getBrandTarget());
				row.createCell(++cell).setCellValue(ownData.getSubBrandInitial());
				row.createCell(++cell).setCellValue(ownData.getSubBrandTarget());
				row.createCell(++cell).setCellValue(ownData.getPackInitial());
				row.createCell(++cell).setCellValue(ownData.getPackTarget());
				break;
			case HierarchyLevel.SUB_BRAND:
				row.createCell(++cell).setCellValue(ownData.getSubCategoryInitial());
				row.createCell(++cell).setCellValue(ownData.getSubCategoryTarget());
				row.createCell(++cell).setCellValue(ownData.getManufacturerInitial());
				row.createCell(++cell).setCellValue(ownData.getManufacturerTarget());
				row.createCell(++cell).setCellValue(ownData.getBrandInitial());
				row.createCell(++cell).setCellValue(ownData.getBrandTarget());
				row.createCell(++cell).setCellValue(ownData.getSubBrandInitial());
				row.createCell(++cell).setCellValue(ownData.getSubBrandTarget());
				break;
			case HierarchyLevel.BRAND:
				row.createCell(++cell).setCellValue(ownData.getSubCategoryInitial());
				row.createCell(++cell).setCellValue(ownData.getSubCategoryTarget());
				row.createCell(++cell).setCellValue(ownData.getManufacturerInitial());
				row.createCell(++cell).setCellValue(ownData.getManufacturerTarget());
				row.createCell(++cell).setCellValue(ownData.getBrandInitial());
				row.createCell(++cell).setCellValue(ownData.getBrandTarget());
				break;
		}
		row.createCell(++cell).setCellValue(ownData.getPriceIndex());
		row.createCell(++cell).setCellValue(ownData.getAveragePrice());
		row.createCell(++cell).setCellValue(ownData.getAverageQuantity());
		row.createCell(++cell).setCellValue(ownData.getElasticity());
		row.createCell(++cell).setCellValue(ownData.getRsquared());
		row.createCell(++cell).setCellValue(ownData.getPValue());
		row.createCell(++cell).setCellValue(ownData.getRange());
		row.createCell(++cell).setCellValue(ownData.getNWeeks());
		row.createCell(++cell).setCellValue(ownData.getSlope());
		row.createCell(++cell).setCellValue(ownData.getIntercept());
		row.createCell(++cell).setCellValue(ownData.getPromoPrice());
		row.createCell(++cell).setCellValue(ownData.getBasePrice());
	}

	public static ByteArrayInputStream postROIDataToExcel(Stream<PostRoiData> postRoiStream, boolean forSU) {
		try (Workbook workbook = new XSSFWorkbook()) {
			Sheet sheet = workbook.createSheet(POST_ROI_SHEET);

			// Header
			Row headerRow = sheet.createRow(0);

			for (int col = 0; col < POST_ROI_HEADERS.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(POST_ROI_HEADERS[col]);
			}

			int[] arr = {1};
			postRoiStream.forEach(x -> {
				Row row = sheet.createRow(arr[0]++);

				row.createCell(0).setCellValue(x.getCountry());
				row.createCell(1).setCellValue(x.getCategory());
				row.createCell(2).setCellValue(x.getSubCategory());
				row.createCell(3).setCellValue(x.getBrand());
				row.createCell(4).setCellValue(x.getSubBrand());
				row.createCell(5).setCellValue(x.getPlanLevel());
				row.createCell(6).setCellValue(x.getSoldTo());
				row.createCell(7).setCellValue(x.getSoldToDesc());
				row.createCell(8).setCellValue(x.getEan());
				row.createCell(9).setCellValue(x.getWeek());
				row.createCell(10).setCellValue(x.getMonth());
				row.createCell(11).setCellValue(x.getYear());
				row.createCell(12).setCellValue(x.getEventId());
				row.createCell(13).setCellValue(x.getBaselineVolume());
				if(forSU) {
					row.createCell(14).setCellValue(x.getActualVolumeSU());
					row.createCell(15).setCellValue(x.getCogsPerSU());
					row.createCell(16).setCellValue(x.getNppPerSU());
				} else {
					row.createCell(14).setCellValue(x.getActualVolumeCase());
					row.createCell(15).setCellValue(x.getCogsPerCase());
					row.createCell(16).setCellValue(x.getNppPerCase());
				}
				row.createCell(17).setCellValue(x.getPromoInvestment());
				if(forSU) {
					row.createCell(18).setCellValue(x.getBaselineProfitSU());
					row.createCell(19).setCellValue(x.getPromoProfitSU());
					row.createCell(20).setCellValue(x.getNetProfitSU());
					row.createCell(21).setCellValue(x.getRetailerMarginSU());
					row.createCell(22).setCellValue(x.getRetailerMarginPercentSU());
				} else {
					row.createCell(18).setCellValue(x.getBaselineProfitCase());
					row.createCell(19).setCellValue(x.getPromoProfitCase());
					row.createCell(20).setCellValue(x.getNetProfitCase());
					row.createCell(21).setCellValue(x.getRetailerMarginCase());
					row.createCell(22).setCellValue(x.getRetailerMarginPercentCase());
				}
			});

			ByteArrayOutputStream out = new ByteArrayOutputStream();
			workbook.write(out);
			out.close();
			return new ByteArrayInputStream(out.toByteArray());
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}
