package com.kcc.springjpa.snowflake.dao.impl;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import javax.persistence.metamodel.EntityType;

import com.kcc.springjpa.snowflake.entity.*;
import com.kcc.springjpa.snowflake.model.BaseLineCustomerModel;
import com.kcc.springjpa.snowflake.model.Simulation;
import com.kcc.springjpa.snowflake.utility.EanUtility;

import net.snowflake.client.jdbc.internal.amazonaws.util.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.kcc.springjpa.snowflake.configuration.DBConfig;
import com.kcc.springjpa.snowflake.dao.PreRoiDao;
import com.kcc.springjpa.snowflake.model.PreRoiBaseLineModel;
import com.kcc.springjpa.snowflake.model.PreRoiSimulatedROIAndNPLModel;

@Repository
public class PreRoiDaoImpl implements PreRoiDao {

	private static final Logger logger = LogManager.getLogger(PreRoiDaoImpl.class);

	@Autowired
	DBConfig dbConfig;

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Map<String, Boolean> getPromoTypes(String country) throws SQLException {

		logger.info("PRE ROI Get PromoTypes Per Country Query Execution#######################################");
		Map<String, Boolean> promoTypes = new HashMap<String, Boolean>();
		Connection conn = dbConfig.getJdbcConnection();
		String sql = "SELECT * FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_MD_DIM_PROMO_TYPE WHERE COUNTRY = ?";
		if (conn != null) {
			try {
				PreparedStatement stat = conn.prepareStatement(sql);
				stat.setString(1, country);
				ResultSet res = stat.executeQuery();
				logger.info("Number of PromoTypes per country " + res.getFetchSize());
				while (res.next()) {
					promoTypes.put(res.getString("PROMO_TYPE"), res.getBoolean("IS_ABS"));
				}
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				conn.close();
			}
		}
		return promoTypes;
	}

	@Override
	public Map<String, Boolean> getValidPromoTypes(String country) throws SQLException {

		logger.info("PRE ROI Get PromoTypes Per Country Query Execution#######################################");
		Map<String, Boolean> promoTypes = new HashMap<String, Boolean>();
		Connection conn = dbConfig.getJdbcConnection();
		String sql = "SELECT * FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_MD_DIM_PROMO_TYPE WHERE COUNTRY = ?";
		if (conn != null) {
			try {
				PreparedStatement stat = conn.prepareStatement(sql);
				stat.setString(1, country);
				ResultSet res = stat.executeQuery();
				logger.info("Number of PromoTypes per country " + res.getFetchSize());
				while (res.next()) {
					promoTypes.put(res.getString("PROMO_TYPE"), res.getBoolean("CONSIDERED_FOR_ROI"));
				}
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				conn.close();
			}
		}
		return promoTypes;
	}

	@Override
	public List<PreRoiBaseLineModel> getBaseLineValueByFilters(String country, int year, List<String> planLevels,
			List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
			List<String> subBrands, List<String> eans, int fromDate, int toDate) throws SQLException {

		logger.info("PRE ROI BaseLine Calculation Custom Query Execution#######################################");
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<PreRoiBaseLineModel> cq = cb.createQuery(PreRoiBaseLineModel.class);
		Root<BaseLineData> root = cq.from(BaseLineData.class);

		List<Selection<?>> s = new LinkedList<Selection<?>>();
		s.add(root.get("week"));
		s.add(cb.sum(root.get("baseLineTotalQuantity")));
		s.add(cb.sum(root.get("baseLineAdjustedQuantity")));
		cq.multiselect(s);

//		cq.multiselect(cb.sum(root.get("promoProfit")), cb.sum(root.get("baselineProfit")),
//				cb.sum(root.get("netProfit")), cb.sum(root.get("totalVolume")), cb.sum(root.get("baselineVolume")), cb.sum(root.get("promoInvestment")));

		Predicate result = cb.equal(root.get("country"), country);
		result = cb.and(result, cb.equal(root.get("year"), year));
		result = cb.and(result, cb.equal(root.get("active"), true));
//		result = cb.and(result, cb.greaterThan(root.get("totalQuantity"), -1));
		if (!CollectionUtils.isEmpty(planLevels)) {
			result = cb.and(result, root.get("planLevel").in(planLevels));
		}
		if (!CollectionUtils.isEmpty(customers)) {
			result = cb.and(result, root.get("soldToDesc").in(customers));
		}
		if (!CollectionUtils.isEmpty(categories)) {
			result = cb.and(result, root.get("category").in(categories));
		}
		if (!CollectionUtils.isEmpty(subCategories)) {
			result = cb.and(result, root.get("subCategory").in(subCategories));
		}
		if (!CollectionUtils.isEmpty(brands)) {
			result = cb.and(result, root.get("brand").in(brands));
		}
		if (!CollectionUtils.isEmpty(subBrands)) {
			result = cb.and(result, root.get("subBrand").in(subBrands));
		}
		if (!CollectionUtils.isEmpty(eans)) {
			result = cb.and(result, root.get("ean").in(eans));
		}
		result = cb.and(result, cb.between(root.get("week"), fromDate, toDate));
		cq.where(result);
		cq.groupBy(root.get("week"));
		cq.orderBy(cb.asc(root.get("week")));

		TypedQuery<PreRoiBaseLineModel> q = entityManager.createQuery(cq);
		logger.info("PRE-ROI BASELINE RESULTS QUERY********************************************" + q.toString());
		return q.getResultList();
	}

	@Override
	public PreRoiSimulatedROIAndNPLModel getCogsAndNppByFilters(String country,
																List<String> planLevels,
																List<String> customers,
																List<String> categories,
																List<String> subCategories,
																List<String> brands,
																List<String> subBrands,
																List<String> eans) {

		logger.info("PRE ROI SimulatedROIAndNPL Calculation Custom Query Execution#######################################");
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<PreRoiSimulatedROIAndNPLModel> cq = cb.createQuery(PreRoiSimulatedROIAndNPLModel.class);
		Root<PreRoiData> root = cq.from(PreRoiData.class);

		List<Selection<?>> s = new LinkedList<Selection<?>>();
		s.add(cb.sum(root.get("avgTradeAllowanceOnInv")));
		s.add(cb.sum(root.get("avgFinDisc")));
		s.add(cb.sum(root.get("avgCashDiscount")));
		s.add(cb.sum(root.get("avgTradeAllowance")));
		s.add(cb.sum(root.get("avgTotCostSale")));
		s.add(cb.sum(root.get("avgDistribution")));
		s.add(cb.sum(root.get("avgSalesVolume")));
		s.add(cb.sum(root.get("avgSalesValue")));
		s.add(cb.sum(root.get("avgTradePromotionsOnInv")));
		s.add(cb.sum(root.get("avgConsumerPromotionsRir")));
		s.add(cb.avg(root.get("cogsPerCase")));
		s.add(cb.avg(root.get("nppPerCase")));
		s.add(cb.sum(root.get("retailerMargin")));
		s.add(cb.sum(root.get("retailerMarginPct")));
		s.add(cb.avg(root.get("taPct")));
		s.add(cb.avg(root.get("tpPct")));
		s.add(cb.avg(root.get("historicalVolume")));
		cq.multiselect(s);

		Predicate result = cb.equal(root.get("country"), country);
		if (!CollectionUtils.isEmpty(planLevels)) {
			result = cb.and(result, root.get("planLevel").in(planLevels));
		}
		if (!CollectionUtils.isEmpty(customers)) {
			result = cb.and(result, root.get("customerName").in(customers));
		}
		if (!CollectionUtils.isEmpty(categories)) {
			result = cb.and(result, root.get("category").in(categories));
		}
		if (!CollectionUtils.isEmpty(subCategories)) {
			result = cb.and(result, root.get("subCategory").in(subCategories));
		}
		if (!CollectionUtils.isEmpty(brands)) {
			result = cb.and(result, root.get("brand").in(brands));
		}
		if (!CollectionUtils.isEmpty(subBrands)) {
			result = cb.and(result, root.get("subBrand").in(subBrands));
		}
		if (!CollectionUtils.isEmpty(eans)) {
			result = cb.and(result, root.get("eanDescription").in(eans));
		}
		cq.where(result);

		TypedQuery<PreRoiSimulatedROIAndNPLModel> q = entityManager.createQuery(cq);
		logger.info("QUERY********************************************" + q.toString());
		return q.getSingleResult();
	}

	@Override
	public PreRoiSimulatedROIAndNPLModel getCogsAndNppByFiltersForUK(String country, List<String> planLevels,
			List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
			List<String> subBrands, List<String> eans, int fromDate, int toDate) {

		logger.info(
				"PRE ROI SimulatedROIAndNPL Calculation Custom Query Execution For UK #######################################");
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<PreRoiSimulatedROIAndNPLModel> cq = cb.createQuery(PreRoiSimulatedROIAndNPLModel.class);
		Root<PreRoiData> root = cq.from(PreRoiData.class);

		List<Selection<?>> s = new LinkedList<Selection<?>>();
		s.add(cb.sum(root.get("avgSalesVolume"))); // avgSalesCases
		s.add(cb.sum(root.get("avgDAOnInv")));
		s.add(cb.sum(root.get("avgOnInvPromoDisc")));
		s.add(cb.sum(root.get("avgNetInvValue")));
		s.add(cb.sum(root.get("avgDAOffInv")));
		s.add(cb.sum(root.get("avgOffInvPromoDisc")));
		s.add(cb.sum(root.get("avgSalesValue"))); // avgNetSalesValue
		s.add(cb.sum(root.get("avgGrossProfit")));
		s.add(cb.sum(root.get("costOfSalesTotal")));
		s.add(cb.sum(root.get("grossSalesAfterDisc")));
		s.add(cb.sum(root.get("volumeCases")));
		s.add(cb.avg(root.get("cogsPerCase")));
		s.add(cb.avg(root.get("nppPerCase")));
		s.add(cb.avg(root.get("retailerMargin")));
		s.add(cb.avg(root.get("retailerMarginPct"))); // retailerMarginPercent
		cq.multiselect(s);

		Predicate result = cb.equal(root.get("country"), country);
		if (!CollectionUtils.isEmpty(planLevels)) {
			result = cb.and(result, root.get("planLevel").in(planLevels));
		}
		if (!CollectionUtils.isEmpty(customers)) {
			result = cb.and(result, root.get("customerName").in(customers));
		}
		if (!CollectionUtils.isEmpty(categories)) {
			result = cb.and(result, root.get("category").in(categories));
		}
		if (!CollectionUtils.isEmpty(subCategories)) {
			result = cb.and(result, root.get("subCategory").in(subCategories));
		}
		if (!CollectionUtils.isEmpty(brands)) {
			result = cb.and(result, root.get("brand").in(brands));
		}
		if (!CollectionUtils.isEmpty(subBrands)) {
			result = cb.and(result, root.get("subBrand").in(subBrands));
		}
		if (!CollectionUtils.isEmpty(eans)) {
			result = cb.and(result, root.get("eanDescription").in(eans));
		}
		cq.where(result);

		TypedQuery<PreRoiSimulatedROIAndNPLModel> q = entityManager.createQuery(cq);
		logger.info("QUERY********************************************" + q.toString());
		return q.getSingleResult();
	}

	@Override
	public PreRoiSimulatedROIAndNPLModel getCogsAndNppByFiltersForKR(String country, List<String> planLevels,
			List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
			List<String> subBrands, List<String> eans) {

		logger.info(
				"PRE ROI SimulatedROIAndNPL Calculation Custom Query Execution For UK #######################################");
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<PreRoiSimulatedROIAndNPLModel> cq = cb.createQuery(PreRoiSimulatedROIAndNPLModel.class);
		Root<PreRoiData> root = cq.from(PreRoiData.class);

		List<Selection<?>> s = new LinkedList<Selection<?>>();
		s.add(cb.sum(root.get("salesVolumePacks")));
		s.add(cb.sum(root.get("distributionExpense")));
		s.add(cb.sum(root.get("nonPromotionRir")));
		s.add(cb.sum(root.get("promotionRir")));
		s.add(cb.avg(root.get("variableCogs")));
		s.add(cb.avg(root.get("nonPromotedPrice")));
		cq.multiselect(s);

		Predicate result = cb.equal(root.get("country"), country);
		if (!CollectionUtils.isEmpty(planLevels)) {
			result = cb.and(result, root.get("planLevel").in(planLevels));
		}
		if (!CollectionUtils.isEmpty(customers)) {
			result = cb.and(result, root.get("customerName").in(customers));
		}
		if (!CollectionUtils.isEmpty(categories)) {
			result = cb.and(result, root.get("category").in(categories));
		}
		if (!CollectionUtils.isEmpty(subCategories)) {
			result = cb.and(result, root.get("subCategory").in(subCategories));
		}
		if (!CollectionUtils.isEmpty(brands)) {
			result = cb.and(result, root.get("brand").in(brands));
		}
		if (!CollectionUtils.isEmpty(subBrands)) {
			result = cb.and(result, root.get("subBrand").in(subBrands));
		}
		if (!CollectionUtils.isEmpty(eans)) {
			List<String> eanNumbers = EanUtility.getEanNumbersFromDescriptions(eans);
			result = cb.and(result, root.get("ean").in(eanNumbers));
		}
		cq.where(result);

		TypedQuery<PreRoiSimulatedROIAndNPLModel> q = entityManager.createQuery(cq);
		logger.info("QUERY********************************************" + q.toString());
		return q.getSingleResult();
	}

	@Override
	public List<Simulation> findSimulations(String country, String fromDate, String toDate, String name)
			throws ParseException {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Simulation> cq = cb.createQuery(Simulation.class);
		Root<PreRoiSim> root = cq.from(PreRoiSim.class);
		EntityType<PreRoiSim> entity = entityManager.getMetamodel().entity(PreRoiSim.class);

		List<Selection<?>> selections = new ArrayList<>();
		selections.add(root.get("name"));
		selections.add(root.get("fromDate"));
		selections.add(root.get("toDate"));
		selections.add(root.get("baseline"));
		selections.add(root.get("incrementalVolume"));
		selections.add(root.get("totalVolume"));
		selections.add(root.get("targetRoi"));
		selections.add(root.get("roi"));
		selections.add(root.get("netProfit"));
		selections.add(root.get("totalInvestment"));
		selections.add(root.get("promoTypeSpec"));
		selections.add(root.get("createdBy"));
		selections.add(root.get("modifiedBy"));
		selections.add(root.get("productHierarchy"));

		cq.multiselect(selections);

		Predicate predicate = cb.equal(root.get("country"), country);

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		if (!StringUtils.isNullOrEmpty(fromDate) && !StringUtils.isNullOrEmpty(toDate)) {
			predicate = cb.and(predicate,
					cb.between(root.get("fromDate"), formatter.parse(fromDate), formatter.parse(toDate)));
		}
		if (!StringUtils.isNullOrEmpty(name)) {
			predicate = cb.and(predicate, cb.like(cb.lower(root.get(entity.getSingularAttribute("name", String.class))),
					"%" + name.toLowerCase() + "%"));
		}
		cq.where(predicate);

		TypedQuery<Simulation> query = entityManager.createQuery(cq);
		List<Simulation> s = query.getResultList();
		return s;
	}

	@Override
	public long deleteSimulations(String country, String createdBy, List<String> simulationsNames) throws SQLException {
		long rowsDeleted;
		StringBuilder sb = new StringBuilder();
		sb.append("(");
		for (int i = 0; i < simulationsNames.size(); i++) {
			sb.append("?").append(",");
		}
		if (sb.length() > 1) {
			sb.setCharAt(sb.lastIndexOf(","), ' ');
		}
		sb.append(")");
		String placeholders = sb.toString();
		String sql = "DELETE FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_PRE_ROI_SIM WHERE COUNTRY = ? AND CREATED_BY = ? AND NAME IN ph";
		sql = sql.replace("ph", placeholders);
		try (Connection c = dbConfig.getJdbcConnection()) {
			PreparedStatement ps = c.prepareStatement(sql);
			ps.setString(1, country);
			ps.setString(2, createdBy);
			int i = 3;
			for (String simulationsName : simulationsNames) {
				ps.setString(i, simulationsName);
				++i;
			}
			ps.execute();
			rowsDeleted = ps.getUpdateCount();
		}
		return rowsDeleted;
	}

	@Override
	public void createScenario(String scenarioName, String createdBy, LocalDateTime createdAt, List<String> simulationNames) throws Exception {
		Connection c = null;
		try {
			c = dbConfig.getJdbcConnection();
			c.setAutoCommit(false);
			PreparedStatement ps = c.prepareStatement("INSERT INTO RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_PROMO_SCENARIO " +
					"(NAME, CREATED_BY, CREATED_AT, SIMULATIONS) " +
					"VALUES (?, ?, ?, ?)");
			ps.setString(1, scenarioName);
			ps.setString(2, createdBy);
			ps.setTimestamp(3, Timestamp.valueOf(createdAt));
			for (String s : simulationNames) {
				ps.setString(4, s);
				ps.addBatch();
			}
			ps.executeBatch();
			c.commit();
		} catch (SQLException e) {
			c.rollback();
			throw new Exception("Could not create scenario", e);
		} finally {
			if (c != null) {
				c.setAutoCommit(true);
				c.close();
			}
		}
	}

	@Override
	public boolean scenarioExists(String scenarioName, String createdBy) throws Exception {
		Connection c = null;
		boolean exists = false;
		try {
			c = dbConfig.getJdbcConnection();
			PreparedStatement ps = c.prepareStatement("SELECT COUNT(1) " +
					"FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_PROMO_SCENARIO " +
					"WHERE name = ? " +
					"AND CREATED_BY = ?");
			ps.setString(1, scenarioName);
			ps.setString(2, createdBy);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int count = rs.getInt(1);
				if (count > 0) {
					exists = true;
				}
			}
		} finally {
			if (c != null) {
				c.close();
			}
		}
		return exists;
	}

	@Override
	public void updateScenario(String newName, String previousName, String createdBy) throws Exception {
		try (Connection c = dbConfig.getJdbcConnection()) {
			PreparedStatement ps = c.prepareStatement("UPDATE RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_PROMO_SCENARIO " +
					"SET name = ? " +
					"WHERE name = ? " +
					"AND CREATED_BY = ?");
			ps.setString(1, newName);
			ps.setString(2, previousName);
			ps.setString(3, createdBy);
			ps.executeUpdate();
		}
	}

	@Override
	public void deleteScenario(String name, String createdBy) throws Exception {
		try(Connection c = dbConfig.getJdbcConnection()) {
			PreparedStatement ps = c.prepareStatement("DELETE " +
					"FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_PROMO_SCENARIO " +
					"WHERE name = ? " +
					"AND CREATED_BY = ?");
			ps.setString(1, name);
			ps.setString(2, createdBy);
			ps.executeUpdate();
		}
	}

	@Override
	public List<Scenario> scenarios(String createdBy) throws Exception {
		List<Scenario> scenarios = new ArrayList<>();
		try (Connection c = dbConfig.getJdbcConnection()) {
			PreparedStatement ps = c.prepareStatement("SELECT NAME, CREATED_BY, CREATED_AT " +
					"FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_PROMO_SCENARIO " +
					"WHERE CREATED_BY = ?");
			ps.setString(1, createdBy);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Scenario r = new Scenario();
				r.name = rs.getString(1);
				r.createdBy = rs.getString(2);
				r.createdAt = rs.getString(3);

				scenarios.add(r);
			}
		}
		return scenarios;
	}

	@Override
	public List<Simulation> findSimulations(String scenario, String createdBy, String country) throws Exception {
		List<Simulation> simulations = new ArrayList<>();
		try (Connection c = dbConfig.getJdbcConnection()) {
			PreparedStatement ps = c.prepareStatement("SELECT sim.NAME, sim.FROM_DATE, sim.TO_DATE, sim.BASELINE, sim.INCREMENTAL_VOLUME, sim.TOTAL_VOLUME, " +
					"sim.TARGET_ROI, sim.ROI, sim.NET_PROFIT, sim.TOTAL_INVESTMENT, sim.PROMO_TYPE_SPEC, sim.CREATED_BY, sim.MODIFIED_BY, sim.PRODUCT_HIERARCHY_FILTER " +
					"FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_PROMO_SCENARIO se " +
					"INNER JOIN " +
					"RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_PRE_ROI_SIM sim " +
					"ON se.SIMULATIONS = sim.name " +
					"WHERE se.NAME = ? " +
					"AND " +
					"se.CREATED_BY = ? " +
					"AND " +
					"sim.COUNTRY = ?");
			ps.setString(1, scenario);
			ps.setString(2, createdBy);
			ps.setString(3, country);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Simulation s = new Simulation();
				s.name = rs.getString(1);
				s.fromDate = rs.getDate(2);
				s.toDate = rs.getDate(3);
				s.baseline = rs.getFloat(4);
				s.incrementalVolume = rs.getInt(5);
				s.totalVolume = rs.getInt(6);
				s.targetRoi = rs.getFloat(7);
				s.roi = rs.getFloat(8);
				s.netProfit = rs.getFloat(9);
				s.totalInvestment = rs.getFloat(10);
				s.tacticType = rs.getString(11);
				s.createdBy = rs.getString(12);
				s.modifiedBy = rs.getString(13);
				s.productHierarchy = rs.getString(14);

				simulations.add(s);
			}
		}
		return simulations;
	}

	@Override
	public List<BaseLineCustomerModel> getCustomerHierarchy(String country) {
		List<BaseLineCustomerModel> baseLineCustomerModels = new ArrayList<>();
		try(Connection conn = dbConfig.getJdbcConnection()) {
			PreparedStatement stat = conn.prepareStatement("SELECT DISTRIBUTION_CHANNEL, SALES_ORG, SOLD_TO_DESC, PLAN_LEVEL " +
					"FROM rgm_adv_anltcs.reporting.v_rgm_sls_fct_data_pre_roi " +
					"WHERE COUNTRY = ? " +
					"GROUP BY DISTRIBUTION_CHANNEL, SALES_ORG, SOLD_TO_DESC, PLAN_LEVEL");
			stat.setString(1, country);
			ResultSet res = stat.executeQuery();
			while (res.next()) {
				BaseLineCustomerModel baseLineCustomerModel = new BaseLineCustomerModel();
				baseLineCustomerModel.setDistrChannelDesc(res.getString(1));
				baseLineCustomerModel.setSalesOffice(res.getString(2));
				baseLineCustomerModel.setSoldToDesc(res.getString(3));
				baseLineCustomerModel.setPlanLevel(res.getString(4));
				baseLineCustomerModels.add(baseLineCustomerModel);
			}
		} catch (SQLException e) {
			logger.error("Could not select customer hierarchy", e);
		}
		return baseLineCustomerModels;
	}
}
