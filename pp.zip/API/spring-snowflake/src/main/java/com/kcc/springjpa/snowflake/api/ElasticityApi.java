package com.kcc.springjpa.snowflake.api;

import java.util.List;
import java.util.Map;

import com.kcc.springjpa.snowflake.dtos.*;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kcc.springjpa.snowflake.model.ElasticityProductHierarchy;
import com.kcc.springjpa.snowflake.model.OwnElasticityModel;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import org.springframework.core.io.Resource;

@Api(value = "elasticity", description = "the Elasticity API")
public interface ElasticityApi {

	@ApiOperation(value = "", response = ElasticityProductHierarchy.class, tags = { "Elasticity", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful OwnProduct Hierarchy data", response = ElasticityProductHierarchy.class) })
	@RequestMapping(value = "/ownProductHierarchy", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<ElasticityProductHierarchy> getOwnProductHierarchy(@RequestParam(value = "country", required = true) String country,
																	  @RequestParam(value = "scope", required = false) String scope,
																	  @RequestParam(value = "source", required = false) String source,
																	  @RequestParam(value = "hierarchyLevel", required = false) String levelIndicator)
			throws Exception;

	@ApiOperation(value = "", response = OwnElasticityModel.class, tags = { "Elasticity", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Own Elasticity Model data", response = ElasticityProductHierarchy.class) })
	@RequestMapping(value = "/ownElasticity", produces = { "application/json" }, method = RequestMethod.POST)
	ResponseEntity<List<Map<String, OwnElasticityModel>>> getOwnElasticity(@RequestBody GetElasticitiesRequest getElasticitiesRequest) throws Exception;

	@ApiOperation(value = "", response = OwnElasticityModel.class, tags = { "Elasticity", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Own Elasticity Model data Per Scope", response = ElasticityProductHierarchy.class) })
	@RequestMapping(value = "/ownElasticityPerScope", produces = { "application/json" }, method = RequestMethod.POST)
	ResponseEntity<Map<String, Map<String, OwnElasticityModel>>> getOwnElasticityPerScope(@RequestBody GetElasticitiesRequest getElasticitiesRequest) throws Exception;

	@ApiOperation(value = "", response = ElasticityProductHierarchy.class, tags = { "Elasticity", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful KCProduct Hierarchy data", response = ElasticityProductHierarchy.class) })
	@RequestMapping(value = "/kcproductHierarchy", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<ElasticityProductHierarchy> getKCProductHierarchy(@RequestParam(value = "country", required = true) String country,
																	 @RequestParam(value = "scope", required = false) String scope,
																	 @RequestParam(value = "source", required = false) String source,
																	 @RequestParam(value="hierarchyLevel", required=false) String levelIndicator) throws Exception;

	@ApiOperation(value = "", response = ElasticityProductHierarchy.class, tags = { "Elasticity", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful TargetProduct Hierarchy data", response = ElasticityProductHierarchy.class) })
	@RequestMapping(value = "/targetProductHierarchy", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<ElasticityProductHierarchy> getTargetProductHierarchy(@RequestParam(value = "country", required = true) String country,
																		 @RequestParam(value = "nodeValues", required = true) List<String> leafValues,
																		 @RequestParam(value = "hierarchyLevel", required = true) String levelIndicator,
																		 @RequestParam(value = "scope", required = false) String scope,
																		 @RequestParam(value = "source", required = false) String source) throws Exception;

	@ApiOperation(value = "", response = Map.class, tags = { "Elasticity", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Cross Elasticity Analysis data", response = Map.class) })
	@RequestMapping(value = "/crossElasticityAnalysis", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<List<OwnElasticityModel>> getCrossElasticityAnalysis(@RequestParam String country,
																		@RequestParam(value = "hierarchyLevel") String hierarchyLevel,
																		@RequestParam(value = "initialNodeValues") List<String> initialNodeValues,
																		@RequestParam(value = "targetNodeValues") List<String> targetNodeValues,
																		@RequestParam String source,
																		@RequestParam(required = false) String category,
																		@RequestParam(required = false) List<String> initialManufacturers,
																		@RequestParam(required = false) List<String> targetManufacturers,
																		@RequestParam(required = false) List<String> initialSubCategories,
																		@RequestParam(required = false) List<String> targetSubCategories,
																		@RequestParam(required = false) List<String> initialBrands,
																		@RequestParam(required = false) List<String> targetBrands,
																		@RequestParam(required = false) List<String> initialSubBrands,
																		@RequestParam(required = false) List<String> targetSubBrands,
																		@RequestParam(required = false) List<String> initialPacks,
																		@RequestParam(required = false) List<String> targetPacks) throws Exception;

	@ApiOperation(value = "", response = Map.class, tags = { "Elasticity", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Cross Elasticity Analysis data per Scope", response = Map.class) })
	@RequestMapping(value = "/crossElasticityAnalysisPerScope", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<Map<String, List<OwnElasticityModel>>> getCrossElasticityAnalysisPerScope(@RequestParam String country,
																							 @RequestParam(value = "hierarchyLevel") String hierarchyLevel,
																							 @RequestParam String scope,
																							 @RequestParam(value = "initialNodeValues") List<String> initialNodeValues,
																							 @RequestParam(value = "targetNodeValues") List<String> targetNodeValues,
																							 @RequestParam String source,
																							 @RequestParam(required = false) String category,
																							 @RequestParam(required = false) List<String> initialManufacturers,
																							 @RequestParam(required = false) List<String> targetManufacturers,
																							 @RequestParam(required = false) List<String> initialSubCategories,
																							 @RequestParam(required = false) List<String> targetSubCategories,
																							 @RequestParam(required = false) List<String> initialBrands,
																							 @RequestParam(required = false) List<String> targetBrands,
																							 @RequestParam(required = false) List<String> initialSubBrands,
																							 @RequestParam(required = false) List<String> targetSubBrands,
																							 @RequestParam(required = false) List<String> initialPacks,
																							 @RequestParam(required = false) List<String> targetPacks) throws Exception;

	@ApiOperation(value = "", response = Map.class, tags = { "Elasticity", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Correlation Analysis data", response = Map.class) })
	@RequestMapping(value = "/correlationAnalysis", produces = { "application/json" }, method = RequestMethod.POST)
	ResponseEntity<Map<String, Map<String, String>>> getCorrelationAnalysis(@RequestBody GetCorrelationRequest r) throws Exception;

	@ApiOperation(value = "", response = Map.class, tags = { "Elasticity", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Market Scope Toggles", response = Map.class) })
	@RequestMapping(value = "/marketScopeToggles", produces = {"application/json"}, method = {RequestMethod.GET})
	ResponseEntity<Map<String, Boolean>> getMarketScopeToggles(@RequestParam(value = "country", required = true) String country,
															   @RequestParam(value = "category", required = true) String category,
															   @RequestParam(value = "hierarchyLevel", required = true) String levelIndicator,
															   @RequestParam(value = "source", required = false) String source) throws Exception;

	@ApiOperation(value = "", response = Map.class, tags = { "Elasticity", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Source Toggles", response = Map.class) })
	@RequestMapping( value = "/availableSources", produces = { "application/json" }, method = {RequestMethod.GET})
	ResponseEntity<Map<String, Boolean>> getAvailableSources(@RequestParam(value = "country") String country,
															 @RequestParam(value = "productLevel", required = false) String productLevel) throws Exception;

	@ApiOperation(value = "", response = Resource.class, tags = { "Elasticity", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Own Elasticity Model data", response = Resource.class) })
	@RequestMapping(value = "/downloadElasticity", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE , method = RequestMethod.POST)
	ResponseEntity<Resource> downloadElasticity(@RequestBody GetElasticitiesRequest downloadRequest) throws Exception;


	@ApiOperation(value = "", response = Map.class, tags = { "Elasticity", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Own Elasticity Model data", response = Resource.class) })
	@RequestMapping(value = "/lastModelRunDate", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<Map<String, String>> getLastModelRunDate(@RequestParam(value="country", required=true) String country) throws Exception;

	// /weeksForLineFitting?country=&initialEan=&targetEan=

	@ApiOperation(value = "", response = List.class, tags = { "Elasticity", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Data Points for Line Fitting", response = List.class) })
	@RequestMapping(value = "/dataPointsForLineFitting", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<List<LineFittingDataPoint>> getLineFittingDataPoints(@RequestParam(value = "country") String country,
																		@RequestParam(value = "initial") String initial,
																		@RequestParam(value = "target", required = false) String target,
																		@RequestParam(value = "hierarchyLevel") String levelIndicator,
																		@RequestParam(value = "customer", required = false) String customer);

	@ApiOperation(value = "", response = RegressionStats.class, tags = { "Elasticity", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Data Points for Regression", response = RegressionStats.class) })
	@RequestMapping(value = "/dataPointsForRegression", produces = { "application/json" }, method = RequestMethod.POST)
	ResponseEntity<RegressionStats> dataPointsForRegression(@RequestBody GetRegressionStatsRequest r) throws Exception;

	@ApiOperation(value = "", response = RegressionStats.class, tags = { "Elasticity", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful sub categories for selected category", response = List.class) })
	@RequestMapping(value = "/getSubCategories", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<List<String>> getSubCategories(@RequestParam(value = "country") String country,
												  @RequestParam(value = "category") String category) throws Exception;
}
