package com.kcc.springjpa.snowflake.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class DateUtility {
	
	public static Date getDateFromString(String date) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dateObj = sdf.parse(date);

		return dateObj;
	}
	
	public static int getWeekNumber(String date) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dateObj = sdf.parse(date);

		Calendar calendar = Calendar.getInstance();
		calendar.setFirstDayOfWeek(Calendar.MONDAY);
		calendar.setMinimalDaysInFirstWeek(7);
		calendar.setTime(dateObj);
		
		if(calendar.get(Calendar.MONTH) == 0 && calendar.get(Calendar.WEEK_OF_YEAR) > 5) {
			return 0;
		}

		return calendar.get(Calendar.WEEK_OF_YEAR);
	}
	
	public static int getYearFromDate(String date) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dateObj = sdf.parse(date);

		Calendar calendar = Calendar.getInstance();
		calendar.setFirstDayOfWeek(Calendar.MONDAY);
		calendar.setTime(dateObj);
		
		return calendar.get(Calendar.YEAR);
	}
	
	public static int getDayFromDate(String date) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dateObj = sdf.parse(date);

		Calendar calendar = Calendar.getInstance();
		calendar.setFirstDayOfWeek(Calendar.MONDAY);
		calendar.setTime(dateObj);
		
		return calendar.get(Calendar.DAY_OF_WEEK);
	}
	
	public static long getNumberOfDaysBetweenDates(String fromDate, String toDate) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date fromdateObj = sdf.parse(fromDate);
		Date todateObj = sdf.parse(toDate);
		return Math.round((todateObj.getTime() - fromdateObj.getTime()) / (double) 86400000) + 1;
	}
	
	public static Integer getConcatenatedWeekAndYear(String date) throws ParseException {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dateObj = sdf.parse(date);

		Calendar calendar = Calendar.getInstance();
		calendar.setFirstDayOfWeek(Calendar.MONDAY);
		calendar.setMinimalDaysInFirstWeek(7);
		calendar.setTime(dateObj);
		
		int year = calendar.get(Calendar.YEAR);
		int week = calendar.get(Calendar.WEEK_OF_YEAR);
			
		if(calendar.get(Calendar.MONTH) == 0 && calendar.get(Calendar.WEEK_OF_YEAR) > 5) {
			week = 0;
		}

		String s1 = "";
		if (week < 10) {
			s1 = 0 + Integer.toString(week);
		} else {
			s1 = Integer.toString(week);
		}
		String s2 = Integer.toString(year);
		return Integer.valueOf(s2 + s1);
	}

	public static Integer getConcatenatedMonthAndYear(String date) throws ParseException {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dateObj = sdf.parse(date);

		Calendar calendar = Calendar.getInstance();
		calendar.setFirstDayOfWeek(Calendar.MONDAY);
		calendar.setMinimalDaysInFirstWeek(7);
		calendar.setTime(dateObj);

		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH) + 1;
		String monthStr = "";
		if (month < 10){
			monthStr = "0" + Integer.toString(month);
		}else{
			monthStr = Integer.toString(month);
		}
		return Integer.valueOf(Integer.toString(year) + monthStr);
	}
	
	public static List<Integer> getMonthNumbersBetweenDates(String fromDate, String toDate) throws ParseException {
		
		List<Integer> monthNumbers = new ArrayList<Integer>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Date fromDateObj = sdf.parse(fromDate);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fromDateObj);
		int fromMonth = calendar.get(Calendar.MONTH) + 1;
		
		Date todateObj = sdf.parse(toDate);
		Calendar calendarTo = Calendar.getInstance();
		calendarTo.setTime(todateObj);	
		int toMonth = calendarTo.get(Calendar.MONTH) + 1;
		
		if(calendar.get(Calendar.YEAR) != calendarTo.get(Calendar.YEAR)) {
			return monthNumbers;
		}
		
		while(fromMonth <= toMonth) {
			monthNumbers.add(fromMonth);
			fromMonth++;
		}		
		return monthNumbers;
	}

}
