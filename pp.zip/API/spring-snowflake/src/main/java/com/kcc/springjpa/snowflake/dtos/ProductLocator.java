package com.kcc.springjpa.snowflake.dtos;

public class ProductLocator {

    public String name;
    public String source;
    public String scope;
    public String flag;
}
