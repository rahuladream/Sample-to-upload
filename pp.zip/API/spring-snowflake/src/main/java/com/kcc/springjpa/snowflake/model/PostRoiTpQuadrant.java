package com.kcc.springjpa.snowflake.model;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class PostRoiTpQuadrant {

	public double q1PromoInvestment;

	public String q1PromoPercent;

	public double q2PromoInvestment;

	public String q2PromoPercent;

	public double q3PromoInvestment;

	public String q3PromoPercent;

	public double q4PromoInvestment;

	public String q4PromoPercent;

}
