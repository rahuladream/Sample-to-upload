package com.kcc.springjpa.snowflake.utility;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class StringResponse {

	public int code;
	private String response;

}
