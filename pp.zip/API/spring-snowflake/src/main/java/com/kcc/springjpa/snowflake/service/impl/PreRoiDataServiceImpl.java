package com.kcc.springjpa.snowflake.service.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.*;

import com.kcc.springjpa.snowflake.dtos.*;
import com.kcc.springjpa.snowflake.entity.Scenario;
import com.kcc.springjpa.snowflake.model.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kcc.springjpa.snowflake.dao.BaseLineDao;
import com.kcc.springjpa.snowflake.dao.PreRoiDao;
import com.kcc.springjpa.snowflake.entity.PreRoiSim;
import com.kcc.springjpa.snowflake.repository.PreRoiSimDataRepository;
import com.kcc.springjpa.snowflake.service.PreRoiDataService;
import com.kcc.springjpa.snowflake.utility.DateUtility;
import com.kcc.springjpa.snowflake.utility.StringResponse;
import com.kcc.springjpa.snowflake.utility.StringUtility;

@Service
public class PreRoiDataServiceImpl implements PreRoiDataService {

	private static final Logger logger = LogManager.getLogger(PreRoiDataServiceImpl.class);

	@Autowired
	PreRoiDao preRoiDao;

	@Autowired
	BaseLineDao baseLineDao;

	@Autowired
	PreRoiSimDataRepository preRoiSimDataRepository;

	@Override
	public Map<String, Boolean> getPromoType(String country) throws SQLException {
		logger.info("Snowflake call to get promoTypes Per Country :: " + country);
		return preRoiDao.getPromoTypes(country);
	}

	@Override
	public StringResponse getBaselineValue(String country, List<String> planLevels, List<String> customers,
			List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands,
			List<String> eans, String fromDate, String toDate) throws SQLException, ParseException {

		logger.info("Snowflake call to get baseline value for given filters :: ");
		double adjustedBaselineValue = 0;
		int fromWeekNumber = DateUtility.getWeekNumber(fromDate);
		int toWeekNumber = DateUtility.getWeekNumber(toDate);
		List<PreRoiBaseLineModel> baseLineData = preRoiDao.getBaseLineValueByFilters(country.toUpperCase(),
				DateUtility.getYearFromDate(fromDate), planLevels, customers, categories, subCategories, brands,
				subBrands, eans, DateUtility.getWeekNumber(fromDate), DateUtility.getWeekNumber(toDate));

		if (!CollectionUtils.isEmpty(baseLineData)) {
			if (fromWeekNumber == toWeekNumber) {
				adjustedBaselineValue = baseLineData.get(0).getBaseLineAdjustedQuantity().doubleValue()
						* DateUtility.getNumberOfDaysBetweenDates(fromDate, toDate) / 7;
			} else {
				for (PreRoiBaseLineModel preRoiBaseLineResultsModel : baseLineData) {
					if (preRoiBaseLineResultsModel.getWeek() == fromWeekNumber) {
						adjustedBaselineValue = adjustedBaselineValue + this.getPartialFromWeekValue(fromDate,
								preRoiBaseLineResultsModel.getBaseLineAdjustedQuantity());
					} else if (preRoiBaseLineResultsModel.getWeek() == toWeekNumber) {
						adjustedBaselineValue = adjustedBaselineValue + this.getPartialToWeekValue(toDate,
								preRoiBaseLineResultsModel.getBaseLineAdjustedQuantity());
					} else {
						adjustedBaselineValue = adjustedBaselineValue
								+ preRoiBaseLineResultsModel.getBaseLineAdjustedQuantity().doubleValue();
					}
				}
			}
		}
		logger.info("Number of rows returned for preRoiData ----------" + baseLineData.size());

		StringResponse sr = new StringResponse();
		sr.setResponse("Baseline Value for given filters : " + adjustedBaselineValue);
		return sr;
	}

	public double getPartialFromWeekValue(String fromDate, BigDecimal bigDecimal) throws ParseException {
		double value = 0;
		if (DateUtility.getDayFromDate(fromDate) == 2) {
			value = value + bigDecimal.doubleValue();
		} else if (DateUtility.getDayFromDate(fromDate) == 3) {
			value = value + (bigDecimal.doubleValue() * 6 / 7);
		} else if (DateUtility.getDayFromDate(fromDate) == 4) {
			value = value + (bigDecimal.doubleValue() * 5 / 7);
		} else if (DateUtility.getDayFromDate(fromDate) == 5) {
			value = value + (bigDecimal.doubleValue() * 4 / 7);
		} else if (DateUtility.getDayFromDate(fromDate) == 6) {
			value = value + (bigDecimal.doubleValue() * 3 / 7);
		} else if (DateUtility.getDayFromDate(fromDate) == 7) {
			value = value + (bigDecimal.doubleValue() * 2 / 7);
		} else if (DateUtility.getDayFromDate(fromDate) == 1) {
			value = value + (bigDecimal.doubleValue() * 1 / 7);
		}
		return value;
	}

	public double getPartialToWeekValue(String fromDate, BigDecimal bigDecimal) throws ParseException {
		double value = 0;
		if (DateUtility.getDayFromDate(fromDate) == 2) {
			value = value + (bigDecimal.doubleValue() * 1 / 7);
		} else if (DateUtility.getDayFromDate(fromDate) == 3) {
			value = value + (bigDecimal.doubleValue() * 2 / 7);
		} else if (DateUtility.getDayFromDate(fromDate) == 4) {
			value = value + (bigDecimal.doubleValue() * 3 / 7);
		} else if (DateUtility.getDayFromDate(fromDate) == 5) {
			value = value + (bigDecimal.doubleValue() * 4 / 7);
		} else if (DateUtility.getDayFromDate(fromDate) == 6) {
			value = value + (bigDecimal.doubleValue() * 5 / 7);
		} else if (DateUtility.getDayFromDate(fromDate) == 7) {
			value = value + (bigDecimal.doubleValue() * 6 / 7);
		} else if (DateUtility.getDayFromDate(fromDate) == 1) {
			value = value + bigDecimal.doubleValue();
		}
		return value;
	}

	/*
	* ROI% = NetProfitOrLoss / PromoInvestment
	* NetProfitOrLoss = TotalProfit - BaselineProfit
	* BaselineProfit = (BaselineVolume * (Unit NPP - Unit COGS))
	* TotalProfit = (TotalVolume * (Unit NPP - Unit COGS)) - PromoInvestment
	* TotalVolume = BaselineVolume + IncrementalVolume
	* PromoInvestment = If it is a lump sum: use exactly that amount
	* If it is a percentage: multiply that percentage x (total volume * Unit non
	* promoted price)
	* */
	@Override
	public PreRoiPromoSimulationModel getSimulatedROIAndNPL(String country, List<String> planLevels,
															List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
															List<String> subBrands, List<String> eans, String fromDate, String toDate, Double baseLineVolume,
															Double incrementalVolume, List<String> promoInvestmentAbsValues, List<String> promoInvestmentNonAbsValues,
															Double promotedPrice)
			throws SQLException {
		logger.info("Snowflake call to simulate PRE ROI promo ROI and NetProfit/Loss for the filters selected :: ");

		PreRoiSimulatedROIAndNPLModel preRoiSimulatedROIAndNPLModel = new PreRoiSimulatedROIAndNPLModel();
		if(country.equals("KR")) {
			preRoiSimulatedROIAndNPLModel = preRoiDao.getCogsAndNppByFiltersForKR(country,
					planLevels, customers, categories, subCategories, brands, subBrands, eans);
		} else {
			preRoiSimulatedROIAndNPLModel = preRoiDao.getCogsAndNppByFilters(country,
					planLevels, customers, categories, subCategories, brands, subBrands, eans);
		}
		
		Map<String, Boolean> validPromoTypes = preRoiDao.getValidPromoTypes(country);

		double totalVolume = baseLineVolume + incrementalVolume;
		double unitNPP = preRoiSimulatedROIAndNPLModel.getNppPerCase();
		double unitCOGS = preRoiSimulatedROIAndNPLModel.getCogsPerCase();
		double promoInvestment = 0;

		if (promoInvestmentAbsValues != null && !promoInvestmentAbsValues.isEmpty()) {
			Map<String, Double> promoInvestmentAbsValuesMap = StringUtility.getMapFromString(promoInvestmentAbsValues);
			for (String promoType : promoInvestmentAbsValuesMap.keySet()) {
				if (validPromoTypes.containsKey(promoType) && validPromoTypes.get(promoType)) {
					promoInvestment = promoInvestment + promoInvestmentAbsValuesMap.get(promoType);
				}
			}
		}

		if (promoInvestmentNonAbsValues != null && !promoInvestmentNonAbsValues.isEmpty()) {
			Map<String, Double> promoInvestmentNonAbsValuesMap = StringUtility
					.getMapFromString(promoInvestmentNonAbsValues);
			for (String promoType : promoInvestmentNonAbsValuesMap.keySet()) {
				if (validPromoTypes.containsKey(promoType) && validPromoTypes.get(promoType)) {
					promoInvestment = promoInvestment
							+ ((promoInvestmentNonAbsValuesMap.get(promoType) * totalVolume * unitNPP) / 100);
				}
			}
		}
		if (promotedPrice != null && promotedPrice != 0) {
			if (promotedPrice > unitNPP) {
				promoInvestment = (promotedPrice - unitNPP) * totalVolume;
			} else if (promotedPrice < unitNPP) {
				promoInvestment = (unitNPP - promotedPrice) * totalVolume;
			} else if (promotedPrice == unitNPP) {
				promoInvestment = (unitNPP - promotedPrice) * totalVolume;
			}
		}

		double totalProfit = (totalVolume * (unitNPP - unitCOGS)) - promoInvestment;
		double baseLineProfit = (baseLineVolume * (unitNPP - unitCOGS));
		double netProfitOrLoss = totalProfit - baseLineProfit;
		double roiPercentage = 0;
		if (promoInvestment != 0) {
			roiPercentage = (netProfitOrLoss / promoInvestment) * 100;
		}

		PreRoiPromoSimulationModel preRoiPromoSimulationModel = new PreRoiPromoSimulationModel();
		preRoiPromoSimulationModel.setNetProfitOrLoss(netProfitOrLoss);
		preRoiPromoSimulationModel.setRoiPercentage(roiPercentage);
		preRoiPromoSimulationModel.setTotalPromoInvestment(promoInvestment);
		preRoiPromoSimulationModel.setNpp(unitNPP);
		preRoiPromoSimulationModel.setCogs(unitCOGS);
		if(preRoiSimulatedROIAndNPLModel.getTpPct() != null && preRoiSimulatedROIAndNPLModel.getTaPct() != null) {
			preRoiPromoSimulationModel.setTaPct(preRoiSimulatedROIAndNPLModel.getTaPct());
			preRoiPromoSimulationModel.setTpPct(preRoiSimulatedROIAndNPLModel.getTpPct());
		}
		preRoiPromoSimulationModel.setHistoricalVolume(preRoiSimulatedROIAndNPLModel.getAvgSalesVolume());
		return preRoiPromoSimulationModel;
	}

	@Override
	public List<PreRoiSimulatedPAndLModel> getSimulatedPAndL(String country, List<String> planLevels,
                                                             List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
                                                             List<String> subBrands, List<String> eans, String fromDate, String toDate, Double baseLineVolume,
                                                             Double incrementalVolume, List<String> promoInvestmentAbsValues, List<String> promoInvestmentNonAbsValues,
                                                             Double netProfitOrLoss, Double roiPercentage, Double totalPromoInvestment, Double npp, Double cogs,
															 Double promotedPrice) throws ParseException {
		
		logger.info("Snowflake call to get Simulated P and L for the filters selected :: ");
		PreRoiSimulatedROIAndNPLModel preRoiSimulatedROIAndNPLModel;
		
		List<PreRoiSimulatedPAndLModel> ss = new ArrayList<>();
		if(country.equals("PE")) {
			preRoiSimulatedROIAndNPLModel = preRoiDao.getCogsAndNppByFilters(country,
					planLevels, customers, categories, subCategories, brands, subBrands, eans);
			ss = this.getPAndLForPE(preRoiSimulatedROIAndNPLModel, baseLineVolume, incrementalVolume, promoInvestmentAbsValues, promoInvestmentNonAbsValues,
					netProfitOrLoss, roiPercentage, totalPromoInvestment, npp, cogs);
		}else if(country.equals("UK")) {
			preRoiSimulatedROIAndNPLModel = preRoiDao.getCogsAndNppByFiltersForUK(country,
					planLevels, customers, categories, subCategories, brands, subBrands, eans, DateUtility.getWeekNumber(fromDate), DateUtility.getWeekNumber(toDate));
			ss = this.getPAndLForUK(preRoiSimulatedROIAndNPLModel, baseLineVolume, incrementalVolume, promoInvestmentAbsValues, promoInvestmentNonAbsValues, 
					netProfitOrLoss, roiPercentage, totalPromoInvestment, npp, cogs, promotedPrice);
		}else if(country.equals("KR")) {
			preRoiSimulatedROIAndNPLModel = preRoiDao.getCogsAndNppByFiltersForKR(country,
					planLevels, customers, categories, subCategories, brands, subBrands, eans);
			ss = this.getPAndLForKR(preRoiSimulatedROIAndNPLModel, baseLineVolume, incrementalVolume, promoInvestmentAbsValues, promoInvestmentNonAbsValues,
					netProfitOrLoss, roiPercentage, totalPromoInvestment, npp, cogs);
		}	
		return ss;
	}

	private List<PreRoiSimulatedPAndLModel> getPAndLForPE(PreRoiSimulatedROIAndNPLModel preRoiSimulatedROIAndNPLModel, Double baseLineVolume, Double incrementalVolume, 
			List<String> promoInvestmentAbsValues, List<String> promoInvestmentNonAbsValues, Double netProfitOrLoss, Double roiPercentage, Double totalPromoInvestment, Double npp, Double cogs) {
		
		logger.info("Formulating P and L Chart for country :: PE");
		List<PreRoiSimulatedPAndLModel> ss = new ArrayList<PreRoiSimulatedPAndLModel>();
		Map<String, Double> promoInvestmentAbsValuesMap = new HashMap<String, Double>();
		Map<String, Double> promoInvestmentNonAbsValuesMap = new HashMap<String, Double>();
		
		if (promoInvestmentAbsValues != null && !promoInvestmentAbsValues.isEmpty()) {
			promoInvestmentAbsValuesMap = StringUtility.getMapFromString(promoInvestmentAbsValues);
		}		
		if (promoInvestmentNonAbsValues != null && !promoInvestmentNonAbsValues.isEmpty()) {
			promoInvestmentNonAbsValuesMap = StringUtility.getMapFromString(promoInvestmentNonAbsValues);
		}
		
		PreRoiSimulatedPAndLModel salesCases = new PreRoiSimulatedPAndLModel();
		salesCases.setName("(-) Sales Cases");
		salesCases.setActuals(preRoiSimulatedROIAndNPLModel.getAvgSalesVolume());
		salesCases.setBaselineScenario(baseLineVolume);
		salesCases.setPromoScenario(baseLineVolume + incrementalVolume);
		salesCases.setLiftScenario(salesCases.getPromoScenario() - salesCases.getBaselineScenario());
		ss.add(salesCases);

		PreRoiSimulatedPAndLModel nonPromotedPrice = new PreRoiSimulatedPAndLModel();
		nonPromotedPrice.setName("Non-Promoted Price");
		nonPromotedPrice.setActuals(npp);
		nonPromotedPrice.setBaselineScenario(npp);
		nonPromotedPrice.setPromoScenario(npp);
		nonPromotedPrice.setLiftScenario(npp);
		ss.add(nonPromotedPrice);

		PreRoiSimulatedPAndLModel nonPromotedSales = new PreRoiSimulatedPAndLModel();
		nonPromotedSales.setName("Non-Promoted Sales");
		nonPromotedSales.setActuals(salesCases.getActuals() * nonPromotedPrice.getActuals());
		nonPromotedSales.setBaselineScenario(salesCases.getBaselineScenario() * nonPromotedPrice.getBaselineScenario());
		nonPromotedSales.setPromoScenario(salesCases.getPromoScenario() * nonPromotedPrice.getPromoScenario());
		nonPromotedSales.setLiftScenario(nonPromotedSales.getPromoScenario() - nonPromotedSales.getBaselineScenario());
		ss.add(nonPromotedSales);

		PreRoiSimulatedPAndLModel tpBasePercentOnInv = new PreRoiSimulatedPAndLModel();
		tpBasePercentOnInv.setName("(-) TP Base on invoice %");
		if(promoInvestmentNonAbsValuesMap.containsKey("TP_Base_%_On_Invoice")) {
			tpBasePercentOnInv.setActuals(0);
			tpBasePercentOnInv.setBaselineScenario(nonPromotedSales.getBaselineScenario() * promoInvestmentNonAbsValuesMap.get("TP_Base_%_On_Invoice") / 100);
			tpBasePercentOnInv.setPromoScenario(nonPromotedSales.getPromoScenario() * promoInvestmentNonAbsValuesMap.get("TP_Base_%_On_Invoice") / 100);
			tpBasePercentOnInv.setLiftScenario(tpBasePercentOnInv.getPromoScenario() - tpBasePercentOnInv.getBaselineScenario());
		}	
		ss.add(tpBasePercentOnInv);

		PreRoiSimulatedPAndLModel cpBasePercentOnInv = new PreRoiSimulatedPAndLModel();
		cpBasePercentOnInv.setName("(-) CP Base on invoice %");
		if(promoInvestmentNonAbsValuesMap.containsKey("CP_Base_%_On_Invoice")) {
			cpBasePercentOnInv.setActuals(0);
			cpBasePercentOnInv.setBaselineScenario(nonPromotedSales.getBaselineScenario() * promoInvestmentNonAbsValuesMap.get("CP_Base_%_On_Invoice") / 100);
			cpBasePercentOnInv.setPromoScenario(nonPromotedSales.getPromoScenario() * promoInvestmentNonAbsValuesMap.get("CP_Base_%_On_Invoice") / 100);
			cpBasePercentOnInv.setLiftScenario(cpBasePercentOnInv.getPromoScenario() - cpBasePercentOnInv.getBaselineScenario());
		}	
		ss.add(cpBasePercentOnInv);

		PreRoiSimulatedPAndLModel tradePromosOnInv = new PreRoiSimulatedPAndLModel();
		tradePromosOnInv.setName("(-) Trade Promotions on invoice");
		tradePromosOnInv.setActuals(preRoiSimulatedROIAndNPLModel.getAvgTradePromotionsOnInv());
		tradePromosOnInv.setBaselineScenario(0);
		if(promoInvestmentNonAbsValuesMap.containsKey("Discount_TP_%_On_Invoice")) {
			tradePromosOnInv.setPromoScenario(nonPromotedSales.getPromoScenario() * promoInvestmentNonAbsValuesMap.get("Discount_TP_%_On_Invoice") / 100);
			tradePromosOnInv.setLiftScenario(tradePromosOnInv.getPromoScenario() - tradePromosOnInv.getBaselineScenario());
		}	
		ss.add(tradePromosOnInv);

		PreRoiSimulatedPAndLModel consumerPromosRIROnInv = new PreRoiSimulatedPAndLModel();
		consumerPromosRIROnInv.setName("(-) Consumer Promotion RIR on invoice");
		consumerPromosRIROnInv.setActuals(preRoiSimulatedROIAndNPLModel.getAvgConsumerPromotionsRir());
		consumerPromosRIROnInv.setBaselineScenario(0);
		if(promoInvestmentNonAbsValuesMap.containsKey("Discount_CP_%_On_Invoice")) {
			consumerPromosRIROnInv.setPromoScenario(nonPromotedSales.getPromoScenario() * promoInvestmentNonAbsValuesMap.get("Discount_CP_%_On_Invoice") / 100);
			consumerPromosRIROnInv.setLiftScenario(consumerPromosRIROnInv.getPromoScenario() - consumerPromosRIROnInv.getBaselineScenario());
		}
		ss.add(consumerPromosRIROnInv);

		PreRoiSimulatedPAndLModel netInvoiceValue = new PreRoiSimulatedPAndLModel();
		netInvoiceValue.setName("Net Invoice Value");
		netInvoiceValue.setActuals(nonPromotedSales.getActuals() - (tradePromosOnInv.getActuals() + consumerPromosRIROnInv.getActuals()));
		netInvoiceValue.setBaselineScenario(nonPromotedSales.getBaselineScenario() - (tpBasePercentOnInv.getBaselineScenario() + cpBasePercentOnInv.getBaselineScenario()));
		netInvoiceValue.setPromoScenario(nonPromotedSales.getPromoScenario() - (tpBasePercentOnInv.getPromoScenario() + cpBasePercentOnInv.getPromoScenario() + 
				tradePromosOnInv.getPromoScenario() + consumerPromosRIROnInv.getPromoScenario()));
		netInvoiceValue.setLiftScenario(netInvoiceValue.getPromoScenario() - netInvoiceValue.getBaselineScenario());
		ss.add(netInvoiceValue);

		PreRoiSimulatedPAndLModel cashDiscount = new PreRoiSimulatedPAndLModel();
		cashDiscount.setName("(-) Cash Discount");
		cashDiscount.setActuals(preRoiSimulatedROIAndNPLModel.getAvgCashDiscount());
		if(salesCases.getActuals() != 0) {
			cashDiscount.setBaselineScenario(cashDiscount.getActuals() * (salesCases.getBaselineScenario() / salesCases.getActuals()));
			cashDiscount.setPromoScenario(salesCases.getPromoScenario() * (cashDiscount.getActuals() / salesCases.getActuals()));
			cashDiscount.setLiftScenario(cashDiscount.getPromoScenario() - cashDiscount.getBaselineScenario());
		}	
		ss.add(cashDiscount);

		PreRoiSimulatedPAndLModel tradeAllowance = new PreRoiSimulatedPAndLModel();
		tradeAllowance.setName("(-) Trade Allowance");
		tradeAllowance.setActuals(preRoiSimulatedROIAndNPLModel.getAvgTradeAllowance());
		if(promoInvestmentNonAbsValuesMap.containsKey("TA_%_Off_Invoice")) {
			tradeAllowance.setBaselineScenario(netInvoiceValue.getBaselineScenario() * promoInvestmentNonAbsValuesMap.get("TA_%_Off_Invoice") /100);
			tradeAllowance.setPromoScenario(netInvoiceValue.getPromoScenario() * promoInvestmentNonAbsValuesMap.get("TA_%_Off_Invoice") /100);
			tradeAllowance.setLiftScenario(tradeAllowance.getPromoScenario() - tradeAllowance.getBaselineScenario());
		}			
		ss.add(tradeAllowance);

		PreRoiSimulatedPAndLModel tpBasePercent = new PreRoiSimulatedPAndLModel();
		tpBasePercent.setName("(-) TP Base %");
		tpBasePercent.setActuals(0);
		if(promoInvestmentNonAbsValuesMap.containsKey("TP_Base_%_Off_Invoice")) {
			tpBasePercent.setBaselineScenario(netInvoiceValue.getBaselineScenario() * promoInvestmentNonAbsValuesMap.get("TP_Base_%_Off_Invoice")/100);
			tpBasePercent.setPromoScenario(netInvoiceValue.getPromoScenario() * promoInvestmentNonAbsValuesMap.get("TP_Base_%_Off_Invoice")/100);
			tpBasePercent.setLiftScenario(tpBasePercent.getPromoScenario() - tpBasePercent.getBaselineScenario());
		}
		ss.add(tpBasePercent);

		PreRoiSimulatedPAndLModel cpBasePercent = new PreRoiSimulatedPAndLModel();
		cpBasePercent.setName("(-) CP Base %");
		cpBasePercent.setActuals(0);
		if(promoInvestmentNonAbsValuesMap.containsKey("CP_Base_%_Off_Invoice")) {
			cpBasePercent.setBaselineScenario(netInvoiceValue.getBaselineScenario() * promoInvestmentNonAbsValuesMap.get("CP_Base_%_Off_Invoice")/100);
			cpBasePercent.setPromoScenario(netInvoiceValue.getPromoScenario() * promoInvestmentNonAbsValuesMap.get("CP_Base_%_Off_Invoice")/100);
			cpBasePercent.setLiftScenario(tpBasePercent.getPromoScenario() - tpBasePercent.getBaselineScenario());
		}
		ss.add(cpBasePercent);

		PreRoiSimulatedPAndLModel tradePromotionsRir = new PreRoiSimulatedPAndLModel();
		tradePromotionsRir.setName("(-) Trade Promotions RIR");
		tradePromotionsRir.setActuals(preRoiSimulatedROIAndNPLModel.getAvgTradePromotionsOnInv());
		double percentTPOffInv = 0;
		double fixedTPOffInv = 0;
		if(promoInvestmentNonAbsValuesMap.containsKey("Discount_TP_%_Off_Invoice")) {
			percentTPOffInv = promoInvestmentNonAbsValuesMap.get("Discount_TP_%_Off_Invoice")/100;
		}	
		if(promoInvestmentAbsValuesMap.containsKey("Fixed_TP_Off_Invoice")) {
			fixedTPOffInv = promoInvestmentAbsValuesMap.get("Fixed_TP_Off_Invoice");
		}
		tradePromotionsRir.setBaselineScenario(0);
		tradePromotionsRir.setPromoScenario(fixedTPOffInv + (netInvoiceValue.getPromoScenario() * percentTPOffInv));
		//tradePromotionsRir.setPromoScenario((percentTPOffInv + fixedTPOffInv) * netInvoiceValue.getPromoScenario());
		tradePromotionsRir.setLiftScenario(tradePromotionsRir.getPromoScenario() - tradePromotionsRir.getBaselineScenario());
		ss.add(tradePromotionsRir);

		PreRoiSimulatedPAndLModel consumerPromotionsRir = new PreRoiSimulatedPAndLModel();
		consumerPromotionsRir.setName("(-) Consumer Promotion RIR");
		consumerPromotionsRir.setActuals(preRoiSimulatedROIAndNPLModel.getAvgConsumerPromotionsRir());
		double percentCPOffInv = 0;
		double fixedCPOffInv = 0;
		if(promoInvestmentNonAbsValuesMap.containsKey("Discount_CP_%_Off_Invoice")) {
			percentTPOffInv = promoInvestmentNonAbsValuesMap.get("Discount_CP_%_Off_Invoice")/100;
		}	
		if(promoInvestmentAbsValuesMap.containsKey("Fixed_CP_Off_Invoice")) {
			fixedTPOffInv = promoInvestmentAbsValuesMap.get("Fixed_CP_Off_Invoice");
		}
		consumerPromotionsRir.setBaselineScenario(0);
		consumerPromotionsRir.setPromoScenario(fixedCPOffInv + (netInvoiceValue.getPromoScenario() * percentCPOffInv));
		consumerPromotionsRir.setLiftScenario(consumerPromotionsRir.getPromoScenario() - consumerPromotionsRir.getBaselineScenario());
		ss.add(consumerPromotionsRir);

		PreRoiSimulatedPAndLModel netSalesValue = new PreRoiSimulatedPAndLModel();
		netSalesValue.setName("Net Sales Value");
		netSalesValue.setActuals(netInvoiceValue.getActuals() - cashDiscount.getActuals() - tradeAllowance.getActuals() 
				- tradePromotionsRir.getActuals() - consumerPromotionsRir.getActuals());
		netSalesValue.setBaselineScenario(netInvoiceValue.getBaselineScenario() - cashDiscount.getBaselineScenario() - tradeAllowance.getBaselineScenario() - 
				tpBasePercent.getBaselineScenario() - cpBasePercent.getBaselineScenario());
		netSalesValue.setPromoScenario(netInvoiceValue.getPromoScenario() - cashDiscount.getPromoScenario() - tradeAllowance.getPromoScenario() - 
				tpBasePercent.getPromoScenario() - cpBasePercent.getPromoScenario() - tradePromotionsRir.getPromoScenario() - consumerPromotionsRir.getPromoScenario());
		netSalesValue.setLiftScenario(netSalesValue.getPromoScenario() - netSalesValue.getBaselineScenario());
		ss.add(netSalesValue);

		PreRoiSimulatedPAndLModel totalCostOfSale = new PreRoiSimulatedPAndLModel();
		totalCostOfSale.setName("(-) Total Cost of Sales (COGS)");
		totalCostOfSale.setActuals(salesCases.getActuals() * cogs);
		totalCostOfSale.setBaselineScenario(salesCases.getBaselineScenario() * cogs);
		totalCostOfSale.setPromoScenario(salesCases.getPromoScenario() * cogs);
		totalCostOfSale.setLiftScenario(totalCostOfSale.getPromoScenario() - totalCostOfSale.getBaselineScenario());
		ss.add(totalCostOfSale);

		PreRoiSimulatedPAndLModel totalDistribution = new PreRoiSimulatedPAndLModel();
		totalDistribution.setName("(-) Total Distribution");
		totalDistribution.setActuals(preRoiSimulatedROIAndNPLModel.getAvgDistribution());
		if(salesCases.getActuals() != 0) {
			totalDistribution.setBaselineScenario(salesCases.getBaselineScenario() * (totalDistribution.getActuals() / salesCases.getActuals()));
			totalDistribution.setPromoScenario(salesCases.getPromoScenario() * (totalDistribution.getActuals() / salesCases.getActuals()));
			totalDistribution.setLiftScenario(totalDistribution.getPromoScenario() - totalDistribution.getBaselineScenario());
		}	
		ss.add(totalDistribution);

		PreRoiSimulatedPAndLModel gp = new PreRoiSimulatedPAndLModel();
		gp.setName("GP");
		gp.setActuals(netSalesValue.getActuals() - totalCostOfSale.getActuals() - totalDistribution.getActuals()); 
		gp.setBaselineScenario(netSalesValue.getBaselineScenario() - totalCostOfSale.getBaselineScenario() - totalDistribution.getBaselineScenario());
		gp.setPromoScenario(netSalesValue.getPromoScenario() - totalCostOfSale.getPromoScenario() - totalDistribution.getPromoScenario());
		gp.setLiftScenario(gp.getPromoScenario() - gp.getBaselineScenario());
		ss.add(gp);

		PreRoiSimulatedPAndLModel gpPercent = new PreRoiSimulatedPAndLModel();
		gpPercent.setName("GP%");
		if(netSalesValue.getActuals() != 0) {
			gpPercent.setActuals((gp.getActuals()/netSalesValue.getActuals()) * 100);
		}
		if(netSalesValue.getBaselineScenario() != 0) {
			gpPercent.setBaselineScenario((gp.getBaselineScenario()/netSalesValue.getBaselineScenario()) * 100);
		}
		if(netSalesValue.getPromoScenario() != 0) {
			gpPercent.setPromoScenario((gp.getPromoScenario()/netSalesValue.getPromoScenario()) * 100);
		}
		gpPercent.setLiftScenario(gpPercent.getPromoScenario() - gpPercent.getBaselineScenario());
		ss.add(gpPercent);
		
		PreRoiSimulatedPAndLModel retailerProfit = new PreRoiSimulatedPAndLModel();
		retailerProfit.setName("Retailer Profit");
		retailerProfit.setActuals(salesCases.getActuals() * preRoiSimulatedROIAndNPLModel.getRetailerMargin()); 
		retailerProfit.setBaselineScenario(salesCases.getBaselineScenario() * preRoiSimulatedROIAndNPLModel.getRetailerMargin());
		retailerProfit.setPromoScenario(salesCases.getPromoScenario() * preRoiSimulatedROIAndNPLModel.getRetailerMargin());
		retailerProfit.setLiftScenario(retailerProfit.getPromoScenario() - retailerProfit.getBaselineScenario());
		ss.add(retailerProfit);
		
		PreRoiSimulatedPAndLModel retailerMarginPer = new PreRoiSimulatedPAndLModel();
		retailerMarginPer.setName("Retailer Margin %");
		retailerMarginPer.setActuals(salesCases.getActuals() * preRoiSimulatedROIAndNPLModel.getRetailerMarginPercent()); 
		retailerMarginPer.setBaselineScenario(salesCases.getBaselineScenario() * preRoiSimulatedROIAndNPLModel.getRetailerMarginPercent());
		retailerMarginPer.setPromoScenario(salesCases.getPromoScenario() * preRoiSimulatedROIAndNPLModel.getRetailerMarginPercent());
		retailerMarginPer.setLiftScenario(retailerMarginPer.getPromoScenario() - retailerMarginPer.getBaselineScenario());
		ss.add(retailerMarginPer);
		
		return ss;		
	}
	
	private List<PreRoiSimulatedPAndLModel> getPAndLForUK(PreRoiSimulatedROIAndNPLModel preRoiSimulatedROIAndNPLModel,
														  Double baseLineVolume, Double incrementalVolume, List<String> promoInvestmentAbsValues,
														  List<String> promoInvestmentNonAbsValues, Double netProfitOrLoss, Double roiPercentage,
														  Double totalPromoInvestment, Double npp, Double cogs, Double promotedPrice) {

		logger.info("Formulating P and L Chart for country :: UK");
		List<PreRoiSimulatedPAndLModel> ss = new ArrayList<PreRoiSimulatedPAndLModel>();
		Map<String, Double> promoInvestmentAbsValuesMap = new HashMap<String, Double>();
		Map<String, Double> promoInvestmentNonAbsValuesMap = new HashMap<String, Double>();
		
		if (promoInvestmentAbsValues != null && !promoInvestmentAbsValues.isEmpty()) {
			promoInvestmentAbsValuesMap = StringUtility.getMapFromString(promoInvestmentAbsValues);
		}		
		if (promoInvestmentNonAbsValues != null && !promoInvestmentNonAbsValues.isEmpty()) {
			promoInvestmentNonAbsValuesMap = StringUtility.getMapFromString(promoInvestmentNonAbsValues);
		}
		
		PreRoiSimulatedPAndLModel salesCases = new PreRoiSimulatedPAndLModel();
		salesCases.setName("(-) Sales Cases");
		salesCases.setActuals(preRoiSimulatedROIAndNPLModel.getAvgSalesVolume());
		salesCases.setBaselineScenario(baseLineVolume);
		salesCases.setPromoScenario(baseLineVolume + incrementalVolume);
		salesCases.setLiftScenario(salesCases.getPromoScenario() - salesCases.getBaselineScenario());
		ss.add(salesCases);

		PreRoiSimulatedPAndLModel nonPromotedPrice = new PreRoiSimulatedPAndLModel();
		nonPromotedPrice.setName("Non-Promoted Price");
		nonPromotedPrice.setActuals(npp);
		nonPromotedPrice.setBaselineScenario(npp);
		nonPromotedPrice.setPromoScenario(npp);
		nonPromotedPrice.setLiftScenario(npp);
		ss.add(nonPromotedPrice);

		PreRoiSimulatedPAndLModel grossSalesValue = new PreRoiSimulatedPAndLModel();
		grossSalesValue.setName("Gross Sales Value");
		grossSalesValue.setActuals(salesCases.getActuals() * nonPromotedPrice.getActuals());
		grossSalesValue.setBaselineScenario(salesCases.getBaselineScenario() * nonPromotedPrice.getBaselineScenario());
		grossSalesValue.setPromoScenario(salesCases.getPromoScenario() * nonPromotedPrice.getPromoScenario());
		grossSalesValue.setLiftScenario(grossSalesValue.getPromoScenario() - grossSalesValue.getBaselineScenario());
		ss.add(grossSalesValue);

		PreRoiSimulatedPAndLModel netSalesValue = new PreRoiSimulatedPAndLModel();
		if(promotedPrice == null || promotedPrice == 0) {
			PreRoiSimulatedPAndLModel dAndAOnInv = new PreRoiSimulatedPAndLModel();
			dAndAOnInv.setName("(-) D&A on invoice");
			dAndAOnInv.setActuals(0);
			if(promoInvestmentNonAbsValuesMap.containsKey("D&A_On_Invoice_%")) {
				dAndAOnInv.setBaselineScenario(grossSalesValue.getBaselineScenario() * promoInvestmentNonAbsValuesMap.get("D&A_On_Invoice_%") / 100);
				dAndAOnInv.setPromoScenario(grossSalesValue.getPromoScenario() * promoInvestmentNonAbsValuesMap.get("D&A_On_Invoice_%") / 100);
				dAndAOnInv.setLiftScenario(dAndAOnInv.getPromoScenario() - dAndAOnInv.getBaselineScenario());
			}
			ss.add(dAndAOnInv);

			PreRoiSimulatedPAndLModel onInvPromoDiscount = new PreRoiSimulatedPAndLModel();
			onInvPromoDiscount.setName("(-)On Invoice Promo Discount (Absolute)");
			onInvPromoDiscount.setActuals(0);
			onInvPromoDiscount.setBaselineScenario(0);
			if(promoInvestmentAbsValuesMap.containsKey("On_Invoice_Promo_Discount_Absolute")) {
				onInvPromoDiscount.setPromoScenario(promoInvestmentAbsValuesMap.get("On_Invoice_Promo_Discount_Absolute"));
				onInvPromoDiscount.setLiftScenario(onInvPromoDiscount.getPromoScenario() - onInvPromoDiscount.getBaselineScenario());
			}
			ss.add(onInvPromoDiscount);

			PreRoiSimulatedPAndLModel onInvPromoDiscountPercent = new PreRoiSimulatedPAndLModel();
			onInvPromoDiscountPercent.setName("(-)On Invoice Promo Discount (%)");
			onInvPromoDiscountPercent.setActuals(0);
			onInvPromoDiscountPercent.setBaselineScenario(0);
			if(promoInvestmentNonAbsValuesMap.containsKey("On_Invoice_Promo_Discount_%")) {
				onInvPromoDiscountPercent.setPromoScenario(grossSalesValue.getPromoScenario() * promoInvestmentNonAbsValuesMap.get("On_Invoice_Promo_Discount_%") /100);
				onInvPromoDiscountPercent.setLiftScenario(onInvPromoDiscountPercent.getPromoScenario() - onInvPromoDiscountPercent.getBaselineScenario());
			}
			ss.add(onInvPromoDiscountPercent);

			PreRoiSimulatedPAndLModel netInvoiceValue = new PreRoiSimulatedPAndLModel();
			netInvoiceValue.setName("Net Invoice Value");
			netInvoiceValue.setActuals(preRoiSimulatedROIAndNPLModel.getAvgNetInvValue());
			netInvoiceValue.setBaselineScenario(grossSalesValue.getBaselineScenario() - dAndAOnInv.getBaselineScenario());
			netInvoiceValue.setPromoScenario(grossSalesValue.getPromoScenario() - dAndAOnInv.getPromoScenario() - onInvPromoDiscount.getPromoScenario() - onInvPromoDiscountPercent.getPromoScenario());
			netInvoiceValue.setLiftScenario(netInvoiceValue.getPromoScenario() - netInvoiceValue.getBaselineScenario());
			ss.add(netInvoiceValue);

			PreRoiSimulatedPAndLModel dAndAOffInvoice = new PreRoiSimulatedPAndLModel();
			dAndAOffInvoice.setName("(-) D&A Off Invoice");
			dAndAOffInvoice.setActuals(0);
			if(promoInvestmentNonAbsValuesMap.containsKey("D&A_Off_Invoice_%")) {
				dAndAOffInvoice.setBaselineScenario(grossSalesValue.getBaselineScenario() * promoInvestmentNonAbsValuesMap.get("D&A_Off_Invoice_%") / 100);
				dAndAOffInvoice.setPromoScenario(grossSalesValue.getPromoScenario() * promoInvestmentNonAbsValuesMap.get("D&A_Off_Invoice_%") / 100);
				dAndAOffInvoice.setLiftScenario(dAndAOffInvoice.getPromoScenario() - dAndAOffInvoice.getBaselineScenario());
			}
			ss.add(dAndAOffInvoice);

			PreRoiSimulatedPAndLModel offInvDiscAbs = new PreRoiSimulatedPAndLModel();
			offInvDiscAbs.setName("(-) Off Invoice Discount Absolute");
			offInvDiscAbs.setActuals(0);
			offInvDiscAbs.setBaselineScenario(0);
			if(promoInvestmentAbsValuesMap.containsKey("Off_Invoice_Discount_Absolute")) {
				offInvDiscAbs.setPromoScenario(promoInvestmentAbsValuesMap.get("Off_Invoice_Discount_Absolute"));
				offInvDiscAbs.setLiftScenario(offInvDiscAbs.getPromoScenario() - offInvDiscAbs.getBaselineScenario());
			}
			ss.add(offInvDiscAbs);

			PreRoiSimulatedPAndLModel offInvDiscPercent = new PreRoiSimulatedPAndLModel();
			offInvDiscPercent.setName("(-) Off Invoice Discount %");
			offInvDiscPercent.setActuals(0);
			offInvDiscPercent.setBaselineScenario(0);
			if(promoInvestmentNonAbsValuesMap.containsKey("Off_Invoice_Discount_%")) {
				offInvDiscPercent.setPromoScenario(grossSalesValue.getPromoScenario() * promoInvestmentNonAbsValuesMap.get("Off_Invoice_Discount_%") /100);
				offInvDiscPercent.setLiftScenario(offInvDiscPercent.getPromoScenario() - offInvDiscPercent.getBaselineScenario());
			}
			ss.add(offInvDiscPercent);

			netSalesValue.setName("Net Sales Value");
			netSalesValue.setActuals(preRoiSimulatedROIAndNPLModel.getAvgNetSalesValue());
			netSalesValue.setBaselineScenario(netInvoiceValue.getBaselineScenario() - dAndAOffInvoice.getBaselineScenario());
			netSalesValue.setPromoScenario(netInvoiceValue.getPromoScenario() - dAndAOffInvoice.getPromoScenario() - offInvDiscAbs.getPromoScenario() - offInvDiscPercent.getPromoScenario());
			netSalesValue.setLiftScenario(netSalesValue.getPromoScenario() - netSalesValue.getBaselineScenario());
			ss.add(netSalesValue);
		} else {
			PreRoiSimulatedPAndLModel promotedPriceModel = new PreRoiSimulatedPAndLModel();
			promotedPriceModel.setName("Promoted Price");
			promotedPriceModel.setActuals(promotedPrice);
			promotedPriceModel.setBaselineScenario(promotedPrice);
			promotedPriceModel.setPromoScenario(promotedPrice);
			promotedPriceModel.setLiftScenario(promotedPrice);
			ss.add(promotedPriceModel);

			netSalesValue.setName("Net Sales Value");
			netSalesValue.setActuals(promotedPrice * preRoiSimulatedROIAndNPLModel.getAvgSalesVolume());
			netSalesValue.setBaselineScenario(promotedPrice * baseLineVolume);
			netSalesValue.setPromoScenario(promotedPrice * (baseLineVolume + incrementalVolume));
			netSalesValue.setLiftScenario(netSalesValue.getPromoScenario() - netSalesValue.getBaselineScenario());
			ss.add(netSalesValue);
		}

		PreRoiSimulatedPAndLModel avgTotalCost = new PreRoiSimulatedPAndLModel();
		avgTotalCost.setName("(-) Average Total Cost");
		avgTotalCost.setActuals(preRoiSimulatedROIAndNPLModel.getCostOfSalesTotal());
		if(salesCases.getActuals() != 0) {
			avgTotalCost.setBaselineScenario(salesCases.getBaselineScenario() * (preRoiSimulatedROIAndNPLModel.getCostOfSalesTotal() / salesCases.getActuals()));
			avgTotalCost.setPromoScenario(preRoiSimulatedROIAndNPLModel.getCostOfSalesTotal() * (salesCases.getPromoScenario() / salesCases.getActuals()));
		}	
		avgTotalCost.setLiftScenario(avgTotalCost.getPromoScenario() - avgTotalCost.getBaselineScenario());
		ss.add(avgTotalCost);

		PreRoiSimulatedPAndLModel gp = new PreRoiSimulatedPAndLModel();
		gp.setName("GP");
		gp.setActuals(netSalesValue.getActuals() - avgTotalCost.getActuals()); 
		gp.setBaselineScenario(netSalesValue.getBaselineScenario() - avgTotalCost.getBaselineScenario());
		gp.setPromoScenario(netSalesValue.getPromoScenario() - avgTotalCost.getPromoScenario());
		gp.setLiftScenario(gp.getPromoScenario() - gp.getBaselineScenario());
		ss.add(gp);

		PreRoiSimulatedPAndLModel gpPercent = new PreRoiSimulatedPAndLModel();
		gpPercent.setName("GP%");	
		if(netSalesValue.getActuals() != 0) {
			gpPercent.setActuals((gp.getActuals()/netSalesValue.getActuals()) * 100);
		}
		if(netSalesValue.getBaselineScenario() != 0) {
			gpPercent.setBaselineScenario((gp.getBaselineScenario()/netSalesValue.getBaselineScenario()) * 100);
		}
		if(netSalesValue.getPromoScenario() != 0) {
			gpPercent.setPromoScenario((gp.getPromoScenario()/netSalesValue.getPromoScenario()) * 100);
		}
		gpPercent.setLiftScenario(gpPercent.getPromoScenario() - gpPercent.getBaselineScenario());
		ss.add(gpPercent);
		
		//Retailer Margin = Sell out volume * (Sell out price * (1-VAT) - Sell in price * (1-VAT))
		//Retailer Margin % =  (1 - ((Sell in price * (1-VAT)) / (Sell out price * (1-VAT)))) * 100VAT/TAX = 20%
		
		PreRoiSimulatedPAndLModel retailerProfit = new PreRoiSimulatedPAndLModel();
		retailerProfit.setName("Retailer Profit");
		retailerProfit.setActuals(salesCases.getActuals() * preRoiSimulatedROIAndNPLModel.getRetailerMargin()); 
		retailerProfit.setBaselineScenario(salesCases.getBaselineScenario() * preRoiSimulatedROIAndNPLModel.getRetailerMargin());
		retailerProfit.setPromoScenario(salesCases.getPromoScenario() * preRoiSimulatedROIAndNPLModel.getRetailerMargin());
		retailerProfit.setLiftScenario(retailerProfit.getPromoScenario() - retailerProfit.getBaselineScenario());
		ss.add(retailerProfit);
		
		PreRoiSimulatedPAndLModel retailerMarginPer = new PreRoiSimulatedPAndLModel();
		retailerMarginPer.setName("Retailer Margin %");
		retailerMarginPer.setActuals(salesCases.getActuals() * preRoiSimulatedROIAndNPLModel.getRetailerMarginPercent()); 
		retailerMarginPer.setBaselineScenario(salesCases.getBaselineScenario() * preRoiSimulatedROIAndNPLModel.getRetailerMarginPercent());
		retailerMarginPer.setPromoScenario(salesCases.getPromoScenario() * preRoiSimulatedROIAndNPLModel.getRetailerMarginPercent());
		retailerMarginPer.setLiftScenario(retailerMarginPer.getPromoScenario() - retailerMarginPer.getBaselineScenario());
		ss.add(retailerMarginPer);
		
		return ss;
	}

	private List<PreRoiSimulatedPAndLModel> getPAndLForKR(PreRoiSimulatedROIAndNPLModel preRoiSimulatedROIAndNPLModel,
			Double baseLineVolume, Double incrementalVolume, List<String> promoInvestmentAbsValues,
			List<String> promoInvestmentNonAbsValues, Double netProfitOrLoss, Double roiPercentage,
			Double totalPromoInvestment, Double npp, Double cogs) {

		logger.info("Formulating P and L Chart for country :: KR");
		List<PreRoiSimulatedPAndLModel> ss = new ArrayList<PreRoiSimulatedPAndLModel>();
		Map<String, Double> promoInvestmentAbsValuesMap = new HashMap<String, Double>();
		Map<String, Double> promoInvestmentNonAbsValuesMap = new HashMap<String, Double>();
		
		if (promoInvestmentAbsValues != null && !promoInvestmentAbsValues.isEmpty()) {
			promoInvestmentAbsValuesMap = StringUtility.getMapFromString(promoInvestmentAbsValues);
		}		
		if (promoInvestmentNonAbsValues != null && !promoInvestmentNonAbsValues.isEmpty()) {
			promoInvestmentNonAbsValuesMap = StringUtility.getMapFromString(promoInvestmentNonAbsValues);
		}
		
		PreRoiSimulatedPAndLModel salesCases = new PreRoiSimulatedPAndLModel();
		salesCases.setName("(-) Sales Cases");
		salesCases.setActuals(preRoiSimulatedROIAndNPLModel.getAvgSalesVolume());
		salesCases.setBaselineScenario(baseLineVolume);
		salesCases.setPromoScenario(baseLineVolume + incrementalVolume);
		salesCases.setLiftScenario(salesCases.getPromoScenario() - salesCases.getBaselineScenario());
		ss.add(salesCases);

		PreRoiSimulatedPAndLModel nonPromotedPrice = new PreRoiSimulatedPAndLModel();
		nonPromotedPrice.setName("Non-Promoted Price");
		nonPromotedPrice.setActuals(npp);
		nonPromotedPrice.setBaselineScenario(npp);
		nonPromotedPrice.setPromoScenario(npp);
		nonPromotedPrice.setLiftScenario(npp);
		ss.add(nonPromotedPrice);

		PreRoiSimulatedPAndLModel grossSalesValue = new PreRoiSimulatedPAndLModel();
		grossSalesValue.setName("Gross Sales Value");
		grossSalesValue.setActuals(salesCases.getActuals() * nonPromotedPrice.getActuals());
		grossSalesValue.setBaselineScenario(salesCases.getBaselineScenario() * nonPromotedPrice.getBaselineScenario());
		grossSalesValue.setPromoScenario(salesCases.getPromoScenario() * nonPromotedPrice.getPromoScenario());
		grossSalesValue.setLiftScenario(grossSalesValue.getPromoScenario() - grossSalesValue.getBaselineScenario());
		ss.add(grossSalesValue);
		
		PreRoiSimulatedPAndLModel nonPromotionRIR = new PreRoiSimulatedPAndLModel();
		nonPromotionRIR.setName("Non-Promotion RIR");
		nonPromotionRIR.setActuals(preRoiSimulatedROIAndNPLModel.getNonPromotionRir());
		if(salesCases.getActuals() != 0) {
			nonPromotionRIR.setBaselineScenario((nonPromotionRIR.getActuals()*salesCases.baselineScenario)/salesCases.getActuals());
			nonPromotionRIR.setPromoScenario((nonPromotionRIR.getActuals()*salesCases.promoScenario)/salesCases.getActuals());
		}	
		nonPromotionRIR.setLiftScenario(nonPromotionRIR.getPromoScenario() - nonPromotionRIR.getBaselineScenario());		
		ss.add(nonPromotionRIR);
		
		PreRoiSimulatedPAndLModel promotionRIR = new PreRoiSimulatedPAndLModel();
		promotionRIR.setName("Promotion RIR");
		promotionRIR.setActuals(preRoiSimulatedROIAndNPLModel.getPromotionRir());
		promotionRIR.setBaselineScenario(0);
		double rirFixed = 0;
		if(promoInvestmentAbsValuesMap.containsKey("Discount_RIR_Fix_Amount")) {
			rirFixed = promoInvestmentAbsValuesMap.get("Discount_RIR_Fix_Amount");
		}
		if(promoInvestmentNonAbsValuesMap.containsKey("Discount_RIR_%")) {
			promotionRIR.setPromoScenario((salesCases.getPromoScenario() * npp * promoInvestmentNonAbsValuesMap.get("Discount_RIR_%")/100) + rirFixed);
		}else {
			promotionRIR.setPromoScenario(rirFixed);
		}
		promotionRIR.setLiftScenario(promotionRIR.getPromoScenario() - promotionRIR.getBaselineScenario());		
		ss.add(promotionRIR);

		PreRoiSimulatedPAndLModel netSalesValue = new PreRoiSimulatedPAndLModel();
		netSalesValue.setName("Net Sales Value");
		netSalesValue.setActuals(grossSalesValue.getActuals() - nonPromotionRIR.getActuals() - promotionRIR.getActuals());
		netSalesValue.setBaselineScenario(grossSalesValue.getBaselineScenario() - nonPromotionRIR.getBaselineScenario() - promotionRIR.getBaselineScenario());
		netSalesValue.setPromoScenario(grossSalesValue.getPromoScenario() - nonPromotionRIR.getPromoScenario() - promotionRIR.getPromoScenario());
		netSalesValue.setLiftScenario(netSalesValue.getPromoScenario() - netSalesValue.getBaselineScenario());
		ss.add(netSalesValue);
		
		PreRoiSimulatedPAndLModel avgFixedCost = new PreRoiSimulatedPAndLModel();
		avgFixedCost.setName("(-) Cost - Fixed Cost");
		avgFixedCost.setActuals(salesCases.getActuals() * npp);
		avgFixedCost.setBaselineScenario(salesCases.getBaselineScenario() * npp);
		avgFixedCost.setPromoScenario(salesCases.getPromoScenario() * npp);
		avgFixedCost.setLiftScenario(avgFixedCost.getPromoScenario() - avgFixedCost.getBaselineScenario());
		ss.add(avgFixedCost);

		PreRoiSimulatedPAndLModel avgTotalCost = new PreRoiSimulatedPAndLModel();
		avgTotalCost.setName("(-) Cost - Variable Cost");
		avgTotalCost.setActuals(salesCases.getActuals() * cogs);
		avgTotalCost.setBaselineScenario(salesCases.getBaselineScenario() * cogs);
		avgTotalCost.setPromoScenario(salesCases.getPromoScenario() * cogs);
		avgTotalCost.setLiftScenario(avgTotalCost.getPromoScenario() - avgTotalCost.getBaselineScenario());
		ss.add(avgTotalCost);
		
		PreRoiSimulatedPAndLModel distribution = new PreRoiSimulatedPAndLModel();
		distribution.setName("(-) Distribution");
		distribution.setActuals(preRoiSimulatedROIAndNPLModel.getDistributionExpense());
		if(salesCases.getActuals() != 0) {
			distribution.setBaselineScenario(salesCases.getBaselineScenario() * (preRoiSimulatedROIAndNPLModel.getDistributionExpense() / salesCases.getActuals()));
			distribution.setPromoScenario(salesCases.getPromoScenario() * (preRoiSimulatedROIAndNPLModel.getDistributionExpense() / salesCases.getActuals()));
		}
		distribution.setLiftScenario(distribution.getPromoScenario() - distribution.getBaselineScenario());
		ss.add(distribution);

		PreRoiSimulatedPAndLModel gp = new PreRoiSimulatedPAndLModel();
		gp.setName("GP");
		gp.setActuals(netSalesValue.getActuals() - avgTotalCost.getActuals() - distribution.getActuals()); 
		gp.setBaselineScenario(netSalesValue.getBaselineScenario() - avgTotalCost.getBaselineScenario() - distribution.getBaselineScenario());
		gp.setPromoScenario(netSalesValue.getPromoScenario() - avgTotalCost.getPromoScenario() - distribution.getPromoScenario());
		gp.setLiftScenario(gp.getPromoScenario() - gp.getBaselineScenario());
		ss.add(gp);

		PreRoiSimulatedPAndLModel gpPercent = new PreRoiSimulatedPAndLModel();
		gpPercent.setName("GP%");	
		if(netSalesValue.getActuals() != 0) {
			gpPercent.setActuals((gp.getActuals()/netSalesValue.getActuals()) * 100);
		}
		if(netSalesValue.getBaselineScenario() != 0) {
			gpPercent.setBaselineScenario((gp.getBaselineScenario()/netSalesValue.getBaselineScenario()) * 100);
		}
		if(netSalesValue.getPromoScenario() != 0) {
			gpPercent.setPromoScenario((gp.getPromoScenario()/netSalesValue.getPromoScenario()) * 100);
		}
		gpPercent.setLiftScenario(gpPercent.getPromoScenario() - gpPercent.getBaselineScenario());
		ss.add(gpPercent);
		
		return ss;
	}

	@Override
	public Double getPromoInvMagicWand(String country, Double baseLineVolume, Double incrementalVolume,
			Double targetRoiPercentage, Double totalPromoInvestment, Double npp, Double cogs, Boolean isAbs) {

		logger.info("Calculating Promo Investment Magic Wand value");
		double totalVolume = baseLineVolume + incrementalVolume;
		double baseLineProfit = baseLineVolume * (npp - cogs);
		double promoInvMagicWand = 0;
		if(isAbs) {
			promoInvMagicWand = (((npp - cogs) * totalVolume) - baseLineProfit - 0)/(1 + (targetRoiPercentage/100));
		}else {
			promoInvMagicWand = //((totalVolume * npp)/(((npp - cogs) * totalVolume) - baseLineProfit - totalPromoInvestment))/(1 + (targetRoiPercentage/100));
					(totalVolume * npp)/((((npp - cogs) * totalVolume) - baseLineProfit - 0)/(1 + (targetRoiPercentage/100)));
		}
		return promoInvMagicWand;		
	}

	@Override
	public Double getCalculatedIncrementalVolume(String country, Double promoInvestment, Double targetRoiPercentage,
			Double baseLineVolume, Double npp, Double cogs) {
		
		logger.info("Calculating Incremental Volume Magic Wand value");
		double baseLineProfit = baseLineVolume * (npp - cogs);
		return (((promoInvestment * (targetRoiPercentage/100)) + baseLineProfit + promoInvestment) / (npp - cogs)) - baseLineVolume;
	}

	@Override
	public PreRoiSim savePromoSimulation(String name, PromoSimulation promoSimulation) throws SQLException, ParseException {
		
		logger.info("Saving Pre Roi Sim to DB");
		PreRoiSim preRoiSim = new PreRoiSim();
		preRoiSim.setName(promoSimulation.getName());
		preRoiSim.setBaseline(promoSimulation.getBaseline());
		preRoiSim.setCountry(promoSimulation.getCountry());
		preRoiSim.setCreated(Timestamp.valueOf(LocalDateTime.now()));
		preRoiSim.setCreatedBy(name);
		preRoiSim.setFromDate(DateUtility.getDateFromString(promoSimulation.getFromDate()));
		preRoiSim.setIncrementalVolume(promoSimulation.getIncrementalVolume());
		preRoiSim.setModified(Timestamp.valueOf(LocalDateTime.now()));
		preRoiSim.setModifiedBy(name);
		preRoiSim.setName(promoSimulation.getName());
		preRoiSim.setNetProfit(promoSimulation.getNetProfit());
		preRoiSim.setProductHierarchy(this.formDescription(promoSimulation));
		preRoiSim.setPromoTypeSpec(StringUtility.getCommaSeparatedStringFromList(promoSimulation.getPromoInvestmentAbsValues()) + "," + StringUtility.getCommaSeparatedStringFromList(promoSimulation.getPromoInvestmentNonAbsValues()));
		preRoiSim.setRoi(promoSimulation.getRoiPercent());
		preRoiSim.setTargetRoi(promoSimulation.getTargetRoi());
		preRoiSim.setToDate(DateUtility.getDateFromString(promoSimulation.getToDate()));
		preRoiSim.setTotalInvestment(promoSimulation.getTotalInvestment());
		preRoiSim.setTotalVolume(promoSimulation.getTotalVolume());
		preRoiSim.setBaseline(promoSimulation.getBaseline());
		
		preRoiSimDataRepository.save(preRoiSim);	
		return preRoiSim;
	}

	private String formDescription(PromoSimulation promoSimulation) {
		
		StringBuilder builder = new StringBuilder();
		if (!CollectionUtils.isEmpty(promoSimulation.getPlanLevels())) {
			builder.append(":PlanLevels=");
			builder.append(String.join(", ", promoSimulation.getPlanLevels()));
		}
		if (!CollectionUtils.isEmpty(promoSimulation.getCustomers())) {
			builder.append(":Customers=");
			builder.append(String.join(", ", promoSimulation.getCustomers()));
		}
		if (!CollectionUtils.isEmpty(promoSimulation.getCategories())) {
			builder.append(":Categories=");
			builder.append(String.join(", ", promoSimulation.getCategories()));
		}
		if (!CollectionUtils.isEmpty(promoSimulation.getSubCategories())) {
			builder.append(":SubCategories=");
			builder.append(String.join(", ", promoSimulation.getSubCategories()));
		}
		if (!CollectionUtils.isEmpty(promoSimulation.getBrands())) {
			builder.append(":Brands=");
			builder.append(String.join(", ", promoSimulation.getBrands()));
		}
		if (!CollectionUtils.isEmpty(promoSimulation.getSubBrands())) {
			builder.append(":SubBrands=");
			builder.append(String.join(", ", promoSimulation.getSubBrands()));
		}
		if (!CollectionUtils.isEmpty(promoSimulation.getEans())) {
			builder.append(":Eans=");
			builder.append(String.join(", ", promoSimulation.getEans()));
		}

		String str = builder.toString();
		if (str.length() > 7999)
			str = builder.substring(0, 7999).toString();
		
		return str;
	}

	@Override
	public List<Simulation> findSimulations(String country, String fromDate, String toDate, String name, String scenario, String createdBy) throws Exception {
		if(scenario == null || scenario.isEmpty()) {
			return preRoiDao.findSimulations(country, fromDate, toDate, name);
		} else {
			return preRoiDao.findSimulations(scenario, createdBy, country);
		}
	}

	@Override
	public StringResponse deleteSimulations(DeleteSimulationsRequest r, String createdBy) {
		StringResponse response = new StringResponse();
		try {
			long rowsDeleted = preRoiDao.deleteSimulations(r.country, createdBy, r.names);
			response.setResponse(String.format("Deleted %d simulation(s)", rowsDeleted));
		} catch (SQLException e) {
			response.setResponse("Could not delete simulations :: Reason - " + e.getMessage());
		}
		return response;
	}

	@Override
	public GetSimulationsTallyResponse tally(GetSimulationsTallyRequest request) throws ParseException {
		
		GetSimulationsTallyResponse res = new GetSimulationsTallyResponse();
		double overallProfitLoss = 0;
		double overallTotalInvestment = 0;
		
		for(double d : request.profitLoss) {
			overallProfitLoss = overallProfitLoss + d;
		}
		
		for(double e : request.totalInvestment) {
			overallTotalInvestment = overallTotalInvestment + e;
		}
		
		res.currentTotalProfit = overallProfitLoss;
		if (overallTotalInvestment != 0) {
			res.currentTotalROI = (res.currentTotalProfit / overallTotalInvestment) * 100;
		}
		return res;
	}

	@Override
	public void createScenario(CreateScenarioRequest r, String createdBy) throws Exception {
		if (r.name == null || r.name.isEmpty()) {
			throw new Exception("Invalid input, scenario name cannot be empty.");
		}
		if (r.simulations == null || r.simulations.isEmpty()) {
			throw new Exception("Invalid input, simulations list cannot be empty.");
		}
		boolean scenarioWithNameExists = preRoiDao.scenarioExists(r.name, createdBy);
		if (scenarioWithNameExists) {
			throw new Exception("Scenario not created, given name already exists. Provide a different name.");
		}
		preRoiDao.createScenario(r.name, createdBy, LocalDateTime.now(), r.simulations);
	}

	@Override
	public void updateScenario(UpdateScenarioRequest r, String createdBy) throws Exception {
		if (r.previousName == null || r.previousName.isEmpty()) {
			throw new Exception("Invalid input, previousName cannot be empty");
		}
		if (r.newName == null || r.newName.isEmpty()) {
			throw new Exception("Invalid input, newName cannot be empty");
		}
		boolean scenarioWithNameExists = preRoiDao.scenarioExists(r.newName, createdBy);
		if (scenarioWithNameExists) {
			throw new Exception("Cannot rename scenario, you already have a scenario with given name.");
		}
		preRoiDao.updateScenario(r.newName, r.previousName, createdBy);
	}

	@Override
	public void deleteScenario(String name, String createdBy) throws Exception {
		if (name == null || name.isEmpty()) {
			throw new Exception("Invalid input, path parameter name cannot be empty");
		}
		preRoiDao.deleteScenario(name, createdBy);
	}

	@Override
	public List<Scenario> scenarios(String createdBy) throws Exception {
		return preRoiDao.scenarios(createdBy);
	}
}
