package com.kcc.springjpa.snowflake.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormatSymbols;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.kcc.springjpa.snowflake.configuration.DBConfig;
import com.kcc.springjpa.snowflake.dao.ImpactorDao;
import com.kcc.springjpa.snowflake.model.ImpactorHistoryModel;
import com.kcc.springjpa.snowflake.model.ImpactorInfoModel;

@Repository
public class ImpactorDaoImpl implements ImpactorDao {

	private static final Logger logger = LogManager.getLogger(ImpactorDaoImpl.class);

	@Autowired
	DBConfig dbConfig;

	@Override
	public String findImpactorByName(String name) throws SQLException {

		String impactorName = "";
		Connection conn = dbConfig.getJdbcConnection();
		String sql = "SELECT * FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_META WHERE IMPACTOR_NAME = ?";
		if (conn != null) {
			PreparedStatement stat = conn.prepareStatement(sql);
			try {
				stat.setString(1, name);
				ResultSet res = stat.executeQuery();
				logger.info("Number of Impactors " + res.getFetchSize());
				while (res.next()) {
					impactorName = res.getString("IMPACTOR_NAME");
				}
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				stat.close();
				conn.close();
			}
		}
		return impactorName;
	}

	@Override
	public List<String> getImpactorNamesInOrder(String country, boolean deleted) throws SQLException {

		List<String> impactorNames = new ArrayList<String>();
		String sql = "SELECT IMPACTOR_NAME, RECENT_APPLY_DATE FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_META " +
				"whereExpression group by IMPACTOR_NAME, RECENT_APPLY_DATE";
		StringBuilder whereExpression = new StringBuilder();
		whereExpression.append("WHERE");
		if(country != null) {
			whereExpression.append(" country = ?").append(" AND ");
		}
		whereExpression.append(" is_deleted = ? ");
		sql = sql.replace("whereExpression", whereExpression.toString());

		Connection conn = dbConfig.getJdbcConnection();
		if (conn != null) {
			PreparedStatement stat = conn.prepareStatement(sql);
			try {
				if(country != null) {
					stat.setString(1, country);
				}
				stat.setBoolean(2, deleted);
				ResultSet res = stat.executeQuery();
				while (res.next()) {
					impactorNames.add(res.getString("IMPACTOR_NAME"));
				}
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				stat.close();
				conn.close();
			}
		}
		return impactorNames;
	}

	@Override
	public Map<String, ImpactorHistoryModel> getImpactorHistory(String country, boolean deleted, String granularity)
			throws SQLException {

		logger.info("DB Call to get Impactor History");
		List<String> orderedImpactorNames = this.getImpactorNamesInOrder(country, deleted);

		Map<String, ImpactorHistoryModel> impactorHistory = new HashMap<String, ImpactorHistoryModel>();
		Map<String, ImpactorHistoryModel> orderedImpactorHistory = new LinkedHashMap<String, ImpactorHistoryModel>();

		Connection conn = dbConfig.getJdbcConnection();
		if (conn != null) {
			Statement stat = conn.createStatement();
			String sql = "SELECT DISTINCT IDATA.YEAR, IDATA.MONTH, IDATA.WEEK, IDATA.DAY, IDATA.IMPACTOR_NAME, IMETA.VALUE, IMETA.IS_ABS "
					+ "FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_DATA IDATA "
					+ "INNER JOIN "
					+ "RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_META IMETA "
					+ "ON IDATA.IMPACTOR_NAME = IMETA.IMPACTOR_NAME "
					+ "WHERE IMETA.COUNTRY = '" + country + "' "
					+ "AND IMETA.IS_DELETED = " + deleted
					+ " ORDER BY IDATA.WEEK ASC";
			try {
				ResultSet res = stat.executeQuery(sql);
				while (res.next()) {
					if (impactorHistory.containsKey(res.getString("IMPACTOR_NAME"))) {
						if (res.getInt("MONTH") == 1) {
							this.setQuantity(res, impactorHistory.get(res.getString("IMPACTOR_NAME")).getJanuary(),
									granularity);
						} else if (res.getInt("MONTH") == 2) {
							this.setQuantity(res, impactorHistory.get(res.getString("IMPACTOR_NAME")).getFebruary(),
									granularity);
						} else if (res.getInt("MONTH") == 3) {
							this.setQuantity(res, impactorHistory.get(res.getString("IMPACTOR_NAME")).getMarch(),
									granularity);
						} else if (res.getInt("MONTH") == 4) {
							this.setQuantity(res, impactorHistory.get(res.getString("IMPACTOR_NAME")).getApril(),
									granularity);
						} else if (res.getInt("MONTH") == 5) {
							this.setQuantity(res, impactorHistory.get(res.getString("IMPACTOR_NAME")).getMay(),
									granularity);
						} else if (res.getInt("MONTH") == 6) {
							this.setQuantity(res, impactorHistory.get(res.getString("IMPACTOR_NAME")).getJune(),
									granularity);
						} else if (res.getInt("MONTH") == 7) {
							this.setQuantity(res, impactorHistory.get(res.getString("IMPACTOR_NAME")).getJuly(),
									granularity);
						} else if (res.getInt("MONTH") == 8) {
							this.setQuantity(res, impactorHistory.get(res.getString("IMPACTOR_NAME")).getAugust(),
									granularity);
						} else if (res.getInt("MONTH") == 9) {
							this.setQuantity(res, impactorHistory.get(res.getString("IMPACTOR_NAME")).getSeptember(),
									granularity);
						} else if (res.getInt("MONTH") == 10) {
							this.setQuantity(res, impactorHistory.get(res.getString("IMPACTOR_NAME")).getOctober(),
									granularity);
						} else if (res.getInt("MONTH") == 11) {
							this.setQuantity(res, impactorHistory.get(res.getString("IMPACTOR_NAME")).getNovember(),
									granularity);
						} else if (res.getInt("MONTH") == 12) {
							this.setQuantity(res, impactorHistory.get(res.getString("IMPACTOR_NAME")).getDecember(),
									granularity);
						}
					} else {
						ImpactorHistoryModel statisticalBaseLine = new ImpactorHistoryModel();
						Map<String, Integer> januaryMonth = new TreeMap<String, Integer>();
						Map<String, Integer> februaryMonth = new TreeMap<String, Integer>();
						Map<String, Integer> marchMonth = new TreeMap<String, Integer>();
						Map<String, Integer> aprilMonth = new TreeMap<String, Integer>();
						Map<String, Integer> mayMonth = new TreeMap<String, Integer>();
						Map<String, Integer> juneMonth = new TreeMap<String, Integer>();
						Map<String, Integer> julyMonth = new TreeMap<String, Integer>();
						Map<String, Integer> augustMonth = new TreeMap<String, Integer>();
						Map<String, Integer> septemberMonth = new TreeMap<String, Integer>();
						Map<String, Integer> octoberMonth = new TreeMap<String, Integer>();
						Map<String, Integer> novemberMonth = new TreeMap<String, Integer>();
						Map<String, Integer> decemberMonth = new TreeMap<String, Integer>();

						if (res.getInt("MONTH") == 1) {
							this.setQuantity(res, januaryMonth, granularity);
						} else if (res.getInt("MONTH") == 2) {
							this.setQuantity(res, februaryMonth, granularity);
						} else if (res.getInt("MONTH") == 3) {
							this.setQuantity(res, marchMonth, granularity);
						} else if (res.getInt("MONTH") == 4) {
							this.setQuantity(res, aprilMonth, granularity);
						} else if (res.getInt("MONTH") == 5) {
							this.setQuantity(res, mayMonth, granularity);
						} else if (res.getInt("MONTH") == 6) {
							this.setQuantity(res, juneMonth, granularity);
						} else if (res.getInt("MONTH") == 7) {
							this.setQuantity(res, julyMonth, granularity);
						} else if (res.getInt("MONTH") == 8) {
							this.setQuantity(res, augustMonth, granularity);
						} else if (res.getInt("MONTH") == 9) {
							this.setQuantity(res, septemberMonth, granularity);
						} else if (res.getInt("MONTH") == 10) {
							this.setQuantity(res, octoberMonth, granularity);
						} else if (res.getInt("MONTH") == 11) {
							this.setQuantity(res, novemberMonth, granularity);
						} else if (res.getInt("MONTH") == 12) {
							this.setQuantity(res, decemberMonth, granularity);
						}
						statisticalBaseLine.setJanuary(januaryMonth);
						statisticalBaseLine.setFebruary(februaryMonth);
						statisticalBaseLine.setMarch(marchMonth);
						statisticalBaseLine.setApril(aprilMonth);
						statisticalBaseLine.setMay(mayMonth);
						statisticalBaseLine.setJune(juneMonth);
						statisticalBaseLine.setJuly(julyMonth);
						statisticalBaseLine.setAugust(augustMonth);
						statisticalBaseLine.setSeptember(septemberMonth);
						statisticalBaseLine.setOctober(octoberMonth);
						statisticalBaseLine.setNovember(novemberMonth);
						statisticalBaseLine.setDecember(decemberMonth);
						statisticalBaseLine.setIsAbs(res.getString("IS_ABS"));

						impactorHistory.put(res.getString("IMPACTOR_NAME"), statisticalBaseLine);
					}
				}
			} catch (SQLException e) {
				logger.error("Could not retrieve impactor history :: ", e);
			} finally {
				stat.close();
				conn.close();
			}
		}

		for (String impactorName : orderedImpactorNames) {
			if (impactorHistory.containsKey(impactorName)) {
				orderedImpactorHistory.put(impactorName, impactorHistory.get(impactorName));
			}
		}
		impactorHistory.clear();
		return orderedImpactorHistory;
	}

	private void setQuantity(ResultSet res, Map<String, Integer> month, String granularity) throws SQLException {
		if (granularity == null || granularity.equalsIgnoreCase("weekly")) {
			setWeekQuantity(res, month);
		} else if (granularity.equalsIgnoreCase("daily")) {
			setDailyQuantity(res, month);
		}
	}

	private void setWeekQuantity(ResultSet res, Map<String, Integer> month) throws SQLException {
		if (month.get("W" + res.getInt("WEEK")) != null) {
			month.put("W" + res.getInt("WEEK"),
					// month.get("W" + res.getInt("WEEK")) +
					Math.round(res.getFloat("VALUE")));
		} else {
			month.put("W" + res.getInt("WEEK"), Math.round(res.getFloat("VALUE")));
		}
	}

	private void setDailyQuantity(ResultSet res, Map<String, Integer> month) throws SQLException {
		month.put("" + res.getInt("DAY"), Math.round(res.getFloat("VALUE")));
	}

	public String formMonthWeek(int week, int month) {
		return new DateFormatSymbols().getMonths()[month - 1] + ":" + String.valueOf(week);
	}

	@Override
	public ImpactorInfoModel getImpactorInfo(String impactorName) throws SQLException {

		ImpactorInfoModel impactorInfoModel = new ImpactorInfoModel();
		Connection conn = dbConfig.getJdbcConnection();
		String sql = "SELECT * FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_META WHERE IMPACTOR_NAME = ?";
		if (conn != null) {
			PreparedStatement stat = conn.prepareStatement(sql);
			try {
				stat.setString(1, impactorName);
				ResultSet res = stat.executeQuery();
				logger.info("Number of Impactors " + res.getFetchSize());
				while (res.next()) {
					impactorInfoModel.setCreatedBy(res.getString("CREATED_BY"));
					impactorInfoModel.setCreatedOn(res.getDate("CREATED_DATE"));
					impactorInfoModel.setDeletedBy(res.getString("DELETED_BY"));
					impactorInfoModel.setDeletedOn(res.getDate("DELETED_DATE"));
					impactorInfoModel.setCountry(res.getString("COUNTRY"));

					String description = res.getString("DESCRIPTION");
					if (StringUtils.isNotEmpty(description)) {
						String[] filters = description.trim().split(":");
						for (String filter : filters) {
							if(filter.isEmpty()) {
								continue;
							}
							String[] pairs = filter.split("=");
							String filterName = pairs[0];
							String filterValue = pairs[1];
							switch (filterName) {
								case "PlanLevels":
									impactorInfoModel.setPlanLevels(filterValue);
									break;
								case "Customers":
									impactorInfoModel.setSoldTo(filterValue);
									break;
								case "Categories":
									impactorInfoModel.setCategories(filterValue);
									break;
								case "SubCategories":
									impactorInfoModel.setSubCategories(filterValue);
									break;
								case "Brands":
									impactorInfoModel.setBrands(filterValue);
									break;
								case "SubBrands":
									impactorInfoModel.setSubBrands(filterValue);
									break;
								case "Eans":
									impactorInfoModel.setEans(filterValue);
									break;
							}
						}
					}
					impactorInfoModel.setAbsValue(res.getFloat("VALUE"));
					impactorInfoModel.setAbs(res.getBoolean("IS_ABS"));
				}
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				stat.close();
				conn.close();
			}
		}
		return impactorInfoModel;
	}

	@Override
	public int deleteImpactor(String deletedBy, String impactorName) throws SQLException {
		logger.info("JDBC Call to delete Impactor:: " + impactorName);
		Connection conn = dbConfig.getJdbcConnection();
		String sql = "UPDATE RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_META SET DELETED_BY = ?, DELETED_DATE = ?, IS_DELETED = ? WHERE IMPACTOR_NAME = ?";
		int impactorsDeleted = 0;
		if (conn != null) {
			PreparedStatement stat = conn.prepareStatement(sql);
			try {
				stat.setString(1, deletedBy);
				stat.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
				stat.setString(3, "TRUE");
				stat.setString(4, impactorName);
				impactorsDeleted = stat.executeUpdate();
				logger.info("Number of Impactors Deleted:: " + impactorsDeleted);
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				stat.close();
				conn.close();
			}
		}
		return impactorsDeleted;
	}

	@Override
	public int undoImpactorAfterDelete(float absValue, String impactorName, String country, boolean isAbs)
			throws SQLException {
		logger.info("JDBC Call to undo Impactor after delete :: " + impactorName);
		Connection conn = dbConfig.getJdbcConnection();
		String sql = "";
		if (isAbs) {
			sql = "UPDATE RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_ADJUSTED_BASELINE A SET A.trace = A.trace || 'UNDO:\"' || B.impactor_name || '\":[' || A.baseline_adjusted_quantity || ',' || "
					+ "A.BASELINE_SAVED_QUANTITY || '];', A.baseline_adjusted_quantity = A.BASELINE_SAVED_QUANTITY, A.modified_date=CURRENT_TIMESTAMP() FROM "
					+ "RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_DATA B WHERE  B.impactor_name=? AND A.sold_to=B.sold_to AND A.EAN=B.EAN AND A.year=B.year "
					+ "AND A.week=B.week AND A.DAY=B.DAY AND B.country=? AND A.country=?";
		} else {
			sql = "UPDATE RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_ADJUSTED_BASELINE A SET A.trace = A.trace || 'UNDO:\"' || B.impactor_name || '\":[' || A.baseline_adjusted_quantity || ',' "
					+ "|| ROUND(A.baseline_adjusted_quantity * (1./(1+(?/100.)))) || '];', A.baseline_adjusted_quantity = A.baseline_adjusted_quantity * (1/(1+(?/100.))), "
					+ "A.modified_date=CURRENT_TIMESTAMP() FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_DATA B WHERE  B.impactor_name=? AND A.sold_to=B.sold_to "
					+ "AND A.EAN=B.EAN AND A.year=B.year AND A.week=B.week AND A.DAY=B.DAY AND B.country=? AND A.country=?";
		}

		int impactorsReverted = 0;
		if (conn != null) {
			PreparedStatement stat = conn.prepareStatement(sql);
			try {
				if (isAbs) {
					stat.setString(1, impactorName);
					stat.setString(2, country);
					stat.setString(3, country);
				} else {
					stat.setFloat(1, absValue);
					stat.setFloat(2, absValue);
					stat.setString(3, impactorName);
					stat.setString(4, country);
					stat.setString(5, country);
				}
				impactorsReverted = stat.executeUpdate();
				logger.info("Number of Impactors Reverted:: " + impactorsReverted);
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				stat.close();
				conn.close();
			}
		}
		return impactorsReverted;
	}

	@Override
	public int createImpactorMeta(String createdBy, String impactorName, boolean isAbs, float impactorValue,
			String country, String description) throws SQLException {
		logger.info("JDBC Call to create Impactor Meta Record :: " + impactorName);
		Connection conn = dbConfig.getJdbcConnection();
		String sql = "INSERT INTO RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_META (IMPACTOR_NAME, CREATED_BY, DELETED_BY, CREATED_DATE, DELETED_DATE, DESCRIPTION, "
				+ "IS_DELETED, RECENT_APPLY_DATE, COUNTRY, BEGIN_DATE, END_DATE, VALUE, IS_ABS, WHERE_CLAUSE) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		int impactorsMetaCreated = 0;
		if (conn != null) {
			PreparedStatement stat = conn.prepareStatement(sql);
			try {
				stat.setString(1, impactorName);
				stat.setString(2, createdBy);
				stat.setString(3, "");
				stat.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
				stat.setTimestamp(5, null);
				stat.setString(6, description);
				stat.setString(7, "FALSE");
				stat.setTimestamp(8, Timestamp.valueOf(LocalDateTime.now()));
				stat.setString(9, country);
				stat.setTimestamp(10, Timestamp.valueOf(LocalDateTime.now()));
				stat.setTimestamp(11, Timestamp.valueOf(LocalDateTime.now()));
				stat.setFloat(12, impactorValue);
				stat.setString(13, String.valueOf(isAbs));
				stat.setString(14, "where clause");
				impactorsMetaCreated = stat.executeUpdate();
				logger.info("Number of Impactors Meta Created:: " + impactorsMetaCreated);
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				stat.close();
				conn.close();
			}
		}
		return impactorsMetaCreated;
	}

	@Override
	public int createImpactorData(String country, Integer year, List<String> planLevels, List<String> customers,
								  List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands,
								  List<String> eans, String impactorName, List<Integer> weeks, boolean forDaily, Map<Integer, List<Integer>> daysForMonth)
			throws SQLException {

		int i = 0;
		if (forDaily) {
			for (Map.Entry<Integer, List<Integer>> e : daysForMonth.entrySet()) {
				String sql = "INSERT INTO RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_DATA (COUNTRY, SOLD_TO, EAN, YEAR, MONTH, WEEK, DAY, IMPACTOR_NAME) "
						+ "SELECT DISTINCT COUNTRY, SOLD_TO, EAN, YEAR, MONTH, WEEK, DAY, ? FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_BASELINE "
						+ "WHERE COUNTRY = ? AND ACTIVE = TRUE AND YEAR = ? AND MONTH = ? ";
				sql = this.getPreparedSql(sql, planLevels, customers, categories, subCategories, brands, subBrands,
						eans, weeks, forDaily, e.getValue());
				i = executeCreateImpactor(sql, impactorName, country, year, planLevels, customers, categories,
						subCategories, brands, subBrands, eans, forDaily, e.getKey(), e.getValue(), weeks);
			}
		} else {
			String sql = "INSERT INTO RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_DATA (COUNTRY, SOLD_TO, EAN, YEAR, MONTH, WEEK, DAY, IMPACTOR_NAME) "
					+ "SELECT DISTINCT COUNTRY, SOLD_TO, EAN, YEAR, MONTH, WEEK, DAY, ? FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_BASELINE WHERE COUNTRY = ? AND ACTIVE = TRUE AND YEAR = ? ";
			sql = this.getPreparedSql(sql, planLevels, customers, categories, subCategories, brands, subBrands, eans,
					weeks, false, null);
			i = executeCreateImpactor(sql, impactorName, country, year, planLevels, customers, categories,
					subCategories, brands, subBrands, eans, forDaily, 0, null, weeks);
		}
		return i;
	}

	private int executeCreateImpactor(String sql, String impactorName, String country, int year,
			List<String> planLevels, List<String> customers, List<String> categories, List<String> subCategories,
			List<String> brands, List<String> subBrands, List<String> eans, boolean forDaily, int month,
			List<Integer> days, List<Integer> weeks) throws SQLException {
		int i = 0;
		logger.info("JDBC Call to create Impactor Data Records :: ");

		Connection conn = dbConfig.getJdbcConnection();
		if (conn != null) {
			try {
				PreparedStatement stat = conn.prepareStatement(sql);
				stat.setString(1, impactorName);
				stat.setString(2, country);
				stat.setInt(3, year);
				int index = 4;
				if (forDaily) {
					stat.setInt(4, month);
					index = 5;
				}

				if (!CollectionUtils.isEmpty(planLevels)) {
					for (String o : planLevels) {
						stat.setString(index++, o);
					}
				}
				if (!CollectionUtils.isEmpty(customers)) {
					for (String o : customers) {
						stat.setString(index++, o);
					}
				}
				if (!CollectionUtils.isEmpty(categories)) {
					for (String o : categories) {
						stat.setString(index++, o);
					}
				}
				if (!CollectionUtils.isEmpty(subCategories)) {
					for (String o : subCategories) {
						stat.setString(index++, o);
					}
				}
				if (!CollectionUtils.isEmpty(brands)) {
					for (String o : brands) {
						stat.setString(index++, o);
					}
				}
				if (!CollectionUtils.isEmpty(subBrands)) {
					for (String o : subBrands) {
						stat.setString(index++, o);
					}
				}
				if (!CollectionUtils.isEmpty(eans)) {
					for (String o : eans) {
						stat.setString(index++, o);
					}
				}
				if (forDaily) {
					if (!CollectionUtils.isEmpty(days)) {
						for (int o : days) {
							stat.setInt(index++, o);
						}
					}
				} else {
					if (!CollectionUtils.isEmpty(weeks)) {
						for (int o : weeks) {
							stat.setInt(index++, o);
						}
					}
				}
				i = stat.executeUpdate();
				logger.info("Number of Impactor Data Records Created:: " + i);
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				conn.close();
			}
		}
		return i;
	}

	private String getPreparedSql(String sql, List<String> planLevels, List<String> customers, List<String> categories,
			List<String> subCategories, List<String> brands, List<String> subBrands, List<String> eans,
			List<Integer> weeks, boolean forDaily, List<Integer> days) throws SQLException {

		if (!CollectionUtils.isEmpty(planLevels)) {
			StringBuilder builder = new StringBuilder();
			for (int i = 0; i < planLevels.size(); i++) {
				builder.append("?,");
			}
			String placeHolders = builder.deleteCharAt(builder.length() - 1).toString();
			sql = sql + " AND PLAN_LEVEL IN (" + placeHolders + ")";
		}
		if (!CollectionUtils.isEmpty(customers)) {
			StringBuilder builder = new StringBuilder();
			for (int i = 0; i < customers.size(); i++) {
				builder.append("?,");
			}
			String placeHolders = builder.deleteCharAt(builder.length() - 1).toString();
			sql = sql + " AND SOLD_TO_DESC IN (" + placeHolders + ")";
		}
		if (!CollectionUtils.isEmpty(categories)) {
			StringBuilder builder = new StringBuilder();
			for (int i = 0; i < categories.size(); i++) {
				builder.append("?,");
			}
			String placeHolders = builder.deleteCharAt(builder.length() - 1).toString();
			sql = sql + " AND CATEGORY IN (" + placeHolders + ")";
		}
		if (!CollectionUtils.isEmpty(subCategories)) {
			StringBuilder builder = new StringBuilder();
			for (int i = 0; i < subCategories.size(); i++) {
				builder.append("?,");
			}
			String placeHolders = builder.deleteCharAt(builder.length() - 1).toString();
			sql = sql + " AND SUB_CATEGORY IN (" + placeHolders + ")";
		}
		if (!CollectionUtils.isEmpty(brands)) {
			StringBuilder builder = new StringBuilder();
			for (int i = 0; i < brands.size(); i++) {
				builder.append("?,");
			}
			String placeHolders = builder.deleteCharAt(builder.length() - 1).toString();
			sql = sql + " AND BRAND IN (" + placeHolders + ")";
		}
		if (!CollectionUtils.isEmpty(subBrands)) {
			StringBuilder builder = new StringBuilder();
			for (int i = 0; i < subBrands.size(); i++) {
				builder.append("?,");
			}
			String placeHolders = builder.deleteCharAt(builder.length() - 1).toString();
			sql = sql + " AND SUB_BRAND IN (" + placeHolders + ")";
		}
		if (!CollectionUtils.isEmpty(eans)) {
			StringBuilder builder = new StringBuilder();
			for (int i = 0; i < eans.size(); i++) {
				builder.append("?,");
			}
			String placeHolders = builder.deleteCharAt(builder.length() - 1).toString();
			sql = sql + " AND EAN IN (" + placeHolders + ")";
		}
		if (forDaily) {
			if (!CollectionUtils.isEmpty(days)) {
				StringBuilder builder = new StringBuilder();
				for (int i = 0; i < days.size(); i++) {
					builder.append("?,");
				}
				String placeHolders = builder.deleteCharAt(builder.length() - 1).toString();
				sql = sql + " AND DAY IN (" + placeHolders + ")";
			}
		} else {
			if (!CollectionUtils.isEmpty(weeks)) {
				StringBuilder builder = new StringBuilder();
				for (int i = 0; i < weeks.size(); i++) {
					builder.append("?,");
				}
				String placeHolders = builder.deleteCharAt(builder.length() - 1).toString();
				sql = sql + " AND WEEK IN (" + placeHolders + ")";
			}
		}
		return sql;
	}

	@Override
	public int applyImpactorNotAbs(String impactorName, float value, String country, boolean forDaily) throws SQLException {
		logger.info("JDBC Call to Apply Impactor :: ");
		Connection conn = dbConfig.getJdbcConnection();
		String sql = "UPDATE RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_ADJUSTED_BASELINE A SET A.trace = A.trace || '\"' || B.impactor_name || '\":[' || A.baseline_adjusted_quantity || ',' || "
				+ "A.baseline_adjusted_quantity * (1+(?/100)) || '];', A.baseline_adjusted_quantity = A.baseline_adjusted_quantity * (1+(?/100.)), A.modified_date=? "
				+ "FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_DATA B WHERE  B.impactor_name=? AND A.sold_to=B.sold_to AND A.EAN=B.EAN AND A.year=B.year "
				+ "AND B.country=? AND A.country=?";
		if(forDaily) {
			sql += " AND A.month = B.month AND A.day = B.day";
		} else {
			sql += " AND A.week = B.week ";
		}
		int i = 0;
		if (conn != null) {
			try {
				PreparedStatement stat = conn.prepareStatement(sql);
				stat.setFloat(1, value);
				stat.setFloat(2, value);
				stat.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
				stat.setString(4, impactorName);
				stat.setString(5, country);
				stat.setString(6, country);
				i = stat.executeUpdate();
				logger.info("Number of Impactors Applied :: " + i);
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				conn.close();
			}
		}
		return i;
	}

	@Override
	public int applyImpactorAbs(int numberOfRecords, int numberOfWeeksOrDays, String impactorName, float value,
								String country, boolean forDaily) throws SQLException {
		logger.info("JDBC Call to Apply Impactor :: ");
		Connection conn = dbConfig.getJdbcConnection();
//		String sql = "UPDATE RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_ADJUSTED_BASELINE A SET A.trace = A.trace || '\"' || B.impactor_name || '\":[' || A.baseline_adjusted_quantity || ',' || "
//				+ "? || '];', A.baseline_saved_quantity = A.baseline_adjusted_quantity, A.baseline_adjusted_quantity = ?, A.modified_date=? FROM "
//				+ "RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_DATA B WHERE  B.impactor_name=? AND A.sold_to=B.sold_to AND A.EAN=B.EAN AND A.year=B.year "
//				+ "AND A.week=B.week AND B.country=? AND A.country=?";

		String sql = "UPDATE RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_ADJUSTED_BASELINE A SET A.trace = A.trace || '\"' || B.impactor_name || '\":[' || A.baseline_adjusted_quantity || ',' || "
				+ "? || '];', A.baseline_saved_quantity = A.baseline_adjusted_quantity, A.baseline_adjusted_quantity = A.baseline_adjusted_quantity + ((?*?)/?), A.modified_date=? FROM "
				+ "RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_DATA B WHERE  B.impactor_name=? AND A.sold_to=B.sold_to AND A.EAN=B.EAN AND A.year=B.year "
				+ "AND B.country=? AND A.country=?";
		if(forDaily) {
			sql += " AND A.month = B.month AND A.day = B.day";
		} else {
			sql += " AND A.week = B.week ";
		}

		int i = 0;
		if (conn != null) {
			try {
				PreparedStatement stat = conn.prepareStatement(sql);
				stat.setFloat(1, value);
				stat.setFloat(2, value);
				stat.setInt(3, numberOfWeeksOrDays);
				stat.setInt(4, numberOfRecords);
				stat.setTimestamp(5, Timestamp.valueOf(LocalDateTime.now()));
				stat.setString(6, impactorName);
				stat.setString(7, country);
				stat.setString(8, country);
				i = stat.executeUpdate();
				logger.info("Number of Impactors Applied :: " + i);
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				conn.close();
			}
		}
		return i;
	}

	@Override
	public Map<String, Float> minimumAdjustmentValue(String country, Integer year, List<String> planLevels,
			List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
			List<String> subBrands, List<String> eans, List<Integer> weeks) throws SQLException {

		logger.info("JDBC Call to find out Minimum Adjustment Value :: ");

		Connection conn = dbConfig.getJdbcConnection();
		String sql = "SELECT BASELINE_ADJUSTED_QUANTITY FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_BASELINE WHERE COUNTRY = ? AND ACTIVE = TRUE AND YEAR = ? ";
		sql = this.getPreparedSql(sql, planLevels, customers, categories, subCategories, brands, subBrands, eans, weeks,
				false, null);

		Map<String, Float> minimumMap = new HashMap<String, Float>();
		List<Float> list = new ArrayList<Float>();
		if (conn != null) {
			try {
				PreparedStatement stat = conn.prepareStatement(sql);
				stat.setString(1, country);
				stat.setInt(2, year);
				int index = 3;
				if (!CollectionUtils.isEmpty(planLevels)) {
					for (String o : planLevels) {
						stat.setString(index++, o);
					}
				}
				if (!CollectionUtils.isEmpty(customers)) {
					for (String o : customers) {
						stat.setString(index++, o);
					}
				}
				if (!CollectionUtils.isEmpty(categories)) {
					for (String o : categories) {
						stat.setString(index++, o);
					}
				}
				if (!CollectionUtils.isEmpty(subCategories)) {
					for (String o : subCategories) {
						stat.setString(index++, o);
					}
				}
				if (!CollectionUtils.isEmpty(brands)) {
					for (String o : brands) {
						stat.setString(index++, o);
					}
				}
				if (!CollectionUtils.isEmpty(subBrands)) {
					for (String o : subBrands) {
						stat.setString(index++, o);
					}
				}
				if (!CollectionUtils.isEmpty(eans)) {
					for (String o : eans) {
						stat.setString(index++, o);
					}
				}
				if (!CollectionUtils.isEmpty(weeks)) {
					for (int o : weeks) {
						stat.setInt(index++, o);
					}
				}
				ResultSet rs = stat.executeQuery();
				while (rs.next()) {
					list.add(rs.getFloat("BASELINE_ADJUSTED_QUANTITY"));
				}
				minimumMap.put("Number of Records", (float) list.size());
				minimumMap.put("Minimum Adjustment Value", Collections.min(list));
				logger.info("Number of Records : " + list.size() + " and Minimum Adjustment Value : "
						+ Collections.min(list));
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				conn.close();
			}
		}
		return minimumMap;
	}

	@Override
	public void clearTestImpactors(String country) throws Exception {
		try (Connection c = dbConfig.getJdbcConnection()) {
			updateAdjustedBaseline(country, c);

			deleteFromImpactorData(country, c);

			deleteFromImpactorMeta(country, c);
		} catch (SQLException e) {
			throw new Exception("Could not complete test impactor clean up", e);
		}
	}

	private void updateAdjustedBaseline(String country, Connection c) throws SQLException {
		PreparedStatement ps = c.prepareStatement("UPDATE RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_ADJUSTED_BASELINE A"
				+ " SET"
						+ " A.BASELINE_ADJUSTED_QUANTITY = B.BASELINE_TOTAL_QUANTITY,"
						+ " A.BASELINE_SAVED_QUANTITY = B.BASELINE_TOTAL_QUANTITY,"
						+ " A.modified_date = CURRENT_TIMESTAMP(),"
						+ " A.trace = ''"
				+ " FROM"
						+ " RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_BASELINE B"
				+ " WHERE"
						+ " A.country = ?"
						+ " AND B.country = ?"
						+ " AND B.active = true"
						+ " AND A.sold_to = B.sold_to"
						+ " AND A.EAN = B.EAN"
						+ " AND A.year = B.year"
						+ " AND A.week = B.week "
						+ " AND A.month = B.month"
						+ " AND A.day = B.day");
		ps.setString(1, country);
		ps.setString(2, country);
		ps.executeUpdate();
	}

	private void deleteFromImpactorData(String country, Connection c) throws SQLException {
		PreparedStatement ps = c
				.prepareStatement("DELETE FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_DATA WHERE country = ?");
		ps.setString(1, country);
		ps.execute();
	}

	private void deleteFromImpactorMeta(String country, Connection c) throws SQLException {
		PreparedStatement ps = c
				.prepareStatement("DELETE FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_IMPACTOR_META WHERE country = ?");
		ps.setString(1, country);
		ps.execute();
	}

	@Override
	public Set<String> getNewBaselineLoads() throws SQLException {

		logger.info("JDBC Call to get new Baseline Data Loads :: ");
		Set<String> countries = new HashSet<String>();
		Connection conn = dbConfig.getJdbcConnection();	
		String updateSql = "UPDATE RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_BASELINE_ADJUSTMENT_LOG SET IN_PROGRESS = 'TRUE' WHERE IN_PROGRESS = 'FALSE' AND COMPLETED = 'FALSE'";
		String selectSql = "SELECT * FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_BASELINE_ADJUSTMENT_LOG WHERE IN_PROGRESS = 'TRUE' AND COMPLETED = 'FALSE'";

		if (conn != null) {
			try {
				PreparedStatement updateStat = conn.prepareStatement(updateSql);
				int i = updateStat.executeUpdate();
				logger.info("Number of New Baseline Adjustment Log records Updated :: " + i);

				PreparedStatement selectStat = conn.prepareStatement(selectSql);
				ResultSet rs = selectStat.executeQuery();
				while (rs.next()) {
					countries.add(rs.getString("COUNTRY"));
				}
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				conn.close();
			}
		}
		return countries;
	}

	@Override
	public void loadNewBaselineDataLoads(String country) throws SQLException {

		logger.info("JDBC Call to get new Baseline Data Loads :: ");
		Connection conn = dbConfig.getJdbcConnection();
		
		//UPDATE ADJUSTED_BASELINE FROM BASELINE for baseline recs that did Not have adjustments in ADJUSTED_BASELINE assuming vars: $country
		String updateSql = "UPDATE RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_ADJUSTED_BASELINE A"
				+ "	SET A.BASELINE_ADJUSTED_QUANTITY=B.BASELINE_TOTAL_QUANTITY,"
				+ "	 A.BASELINE_SAVED_QUANTITY=B.BASELINE_TOTAL_QUANTITY,"
				+ "	 A.modified_date=CURRENT_TIMESTAMP(), A.trace=''"
				+ "	FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_BASELINE B"
				+ "	WHERE A.country=? AND B.country=? AND B.active=true"
				+ "	AND len(A.trace)=0 AND A.sold_to=B.sold_to AND A.EAN=B.EAN AND A.year=B.year AND A.week=B.week and A.month=B.month AND A.day=B.day";
		
		//INSERT INTO ADJUSTED_BASELINE FROM BASELINE for new baseline recs not already in ADJUSTED_BASELINE assume vars: $country
		String insertSql = "INSERT INTO RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_ADJUSTED_BASELINE"
				+ "	(country, sold_to, EAN, year, month, week, day, BASELINE_ADJUSTED_QUANTITY, BASELINE_SAVED_QUANTITY, modified_date, trace)"
				+ "	SELECT TRIM(A.country), TRIM(A.sold_to), TRIM(A.EAN), A.year, A.month, A.week, A.day, BASELINE_TOTAL_QUANTITY,BASELINE_TOTAL_QUANTITY,CURRENT_TIMESTAMP, ''"
				+ "	FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_BASELINE A"
				+ "	WHERE A.country=? AND A.active=true"
				+ "	AND NOT EXISTS (SELECT"
				+ "	  TRIM(B.country), TRIM(B.sold_to), TRIM(B.EAN), B.year, B.month, B.week, B.day"
				+ "	  FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_ADJUSTED_BASELINE B"
				+ "	  WHERE A.country=? AND B.country=? AND"
				+ "	  A.sold_to=B.sold_to AND A.EAN=B.EAN AND A.year=B.year AND"
				+ "	  A.month=B.month AND A.week=B.week AND A.day=B.day)";

		if (conn != null) {
			try {
				PreparedStatement updateStat = conn.prepareStatement(updateSql);
				updateStat.setString(1, country);
				updateStat.setString(2, country);
				int updatedRecords = updateStat.executeUpdate();
				logger.info("Number of Baseline Adjustment records Updated :: " + updatedRecords);

				PreparedStatement insertStat = conn.prepareStatement(insertSql);
				insertStat.setString(1, country);
				insertStat.setString(2, country);
				insertStat.setString(3, country);
				int insertedRecords = insertStat.executeUpdate();
				logger.info("Number of New Baseline Adjustment records Inserted :: " + insertedRecords);
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				conn.close();
			}
		}
	}
	
	@Override
	public void updateAdjustmentLogRecords() throws SQLException {

		logger.info("JDBC Call to Set completed as TRUE after load job :: ");
		Connection conn = dbConfig.getJdbcConnection();	
		String updateSql = "UPDATE RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_BASELINE_ADJUSTMENT_LOG SET COMPLETED = 'TRUE', "
				+ "IN_PROGRESS = 'FALSE', DATE_COMPLETED = CURRENT_TIMESTAMP() WHERE IN_PROGRESS = 'TRUE' AND COMPLETED = 'FALSE'";

		if (conn != null) {
			try {
				PreparedStatement updateStat = conn.prepareStatement(updateSql);
				int i = updateStat.executeUpdate();
				logger.info("Number of Adjustment Log records set to completed :: " + i);
			} catch (SQLException e) {
				logger.error("Exception occured while creating a JDBC connection to Database :: ");
				logger.info(e.getMessage());
				e.printStackTrace();
			} finally {
				conn.close();
			}
		}
	}
}
