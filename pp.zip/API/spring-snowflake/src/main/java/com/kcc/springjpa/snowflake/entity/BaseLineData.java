package com.kcc.springjpa.snowflake.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@Table(name = "V_RGM_SLS_FCT_DATA_BASELINE", schema = "REPORTING")
@Getter
@Setter
public class BaseLineData {

	@Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "DAY")
    private Integer day;

    @Column(name = "WEEK")
    private Integer week;

    @Column(name = "MONTH")
    private Integer month;

    @Column(name = "YEAR")
    private Integer year;
    
    @Column(name = "ACTUAL_QUANTITY")
    private BigDecimal totalQuantity;
    
    @Column(name = "PRICE_PER_CASE", precision=16, scale=3)
    private BigDecimal pricePerCase;
    
    @Column(name = "PROMO_PRICE", precision=16, scale=3)
    private BigDecimal promoPrice;
    
    @Column(name = "BASE_PRICE", precision=16, scale=3)
    private BigDecimal basePrice;
    
    @Column(name = "NET_INVOICE_LC", precision=16, scale=3)
    private BigDecimal netInvoiceLc;
    
    @Column(name = "NET_INVOICE_USD", precision=16, scale=3)
    private BigDecimal netInvoiceUsd;
    
    @Column(name = "LOWER_LIMIT", precision=16, scale=3)
    private BigDecimal lowerLimit;
    
    @Column(name = "UPPER_LIMIT", precision=16, scale=3)
    private BigDecimal upperLimit;
    
    @Column(name = "ACCURACY_10", precision=16, scale=3)
    private BigDecimal accuracy10;
    
    @Column(name = "ACCURACY_50", precision=16, scale=3)
    private BigDecimal accuracy50;
    
    @Column(name = "ACCURACY_90", precision=16, scale=3)
    private BigDecimal accuracy90;
    
    @Column(name = "PREDICTED_QUANTITY")
    private BigDecimal predictedQuantity;
    
    @Column(name = "BASELINE_TOTAL_QUANTITY")
    private BigDecimal baseLineTotalQuantity;
    
    @Column(name = "EAN")
    private String ean;
    
    @Column(name = "MODEL_CREATED")
    private String modelCreated;
    
    @Column(name = "MODEL_RUN")
    private String modelRun;
    
    @Column(name = "MODEL_NAME")
    private String modelName;
    
    @Column(name = "MODEL_VER")
    private String modelVer;
    
    @Column(name = "USER")
    private String user;
    
    @Column(name = "DATA_VER")
    private String dataVer;
    
    @Column(name = "SELL_IN_OUT")
    private String sellInOut;
    
    @Column(name = "PERIODICITY")
    private String periodicity;
    
    @Column(name = "COMMENTS")
    private String comments;
    
    @Column(name = "SECTOR")
    private String sector;
    
    @Column(name = "CATEGORY")
    private String category;
    
    @Column(name = "BRAND")
    private String brand;
    
    @Column(name = "SUB_BRAND")
    private String subBrand;
    
    @Column(name = "PRODUCT_DESC")
    private String productDesc;
    
    @Column(name = "SALES_ORG")
    private String salesOrg;
    
    @Column(name = "SOLD_TO")
    private String soldTo;
    
    @Column(name = "SOLD_TO_DESC")
    private String soldToDesc;
    
    @Column(name = "DISTR_CHANNEL")
    private String distrChannel;
    
//    @Column(name = "DISTR_CHANNEL_DESC")
//    private String distrChannelDesc;
//    
//    @Column(name = "SALES_OFFICE")
//    private String salesOffice;
    
    @Column(name = "COUNTRY")
    private String country;
    
    @Column(name = "ACTIVE")
    private Boolean active;
    
    @Column(name = "SCORE")
    private Integer score;
    
    @Column(name = "SUB_CATEGORY")
    private String subCategory;
    
    @Column(name = "PLAN_LEVEL")
    private String planLevel;
    
    @Column(name = "BASELINE_ADJUSTED_QUANTITY")
    private BigDecimal baseLineAdjustedQuantity;
    
    @Column(name = "TRACE")
    private String trace;
    
    @Column(name = "MODIFIED_DATE")
    private Timestamp modifiedDate;
}