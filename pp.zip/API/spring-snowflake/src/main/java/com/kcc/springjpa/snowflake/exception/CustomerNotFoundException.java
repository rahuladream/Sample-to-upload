package com.kcc.springjpa.snowflake.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerNotFoundException extends Exception{
    String customerId;
    public CustomerNotFoundException(String message, String customerId){
        super(message);
        this.customerId = customerId;
    }
}
