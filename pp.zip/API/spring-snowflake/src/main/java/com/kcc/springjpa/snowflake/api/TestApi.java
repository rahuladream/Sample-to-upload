package com.kcc.springjpa.snowflake.api;

import com.kcc.springjpa.snowflake.model.TestData;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.kcc.springjpa.snowflake.utility.StringResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.List;
import java.util.Map;

@Api(value = "test", description = "TEST API")
public interface TestApi {

	@ApiOperation(value = "", response = StringResponse.class, tags = { "Test Run", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "A successful Initial Test Run completed", response = StringResponse.class) })
	@RequestMapping(value = "/api-docs/testrun", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<StringResponse> initialTestRun() throws Exception;

	@ApiOperation(value = "", response = StringResponse.class, tags = { "Test Run", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "A successful Data Test Run completed", response = TestData.class) })
	@RequestMapping(value = "/api-docs/data-test", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<List<TestData>> dataTest() throws Exception;
}
