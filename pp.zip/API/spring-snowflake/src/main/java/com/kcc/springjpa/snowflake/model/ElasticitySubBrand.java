package com.kcc.springjpa.snowflake.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class ElasticitySubBrand {
	
	//Category --> SubCategory --> Manufacturer --> Brand --> SubBrand --> Tier --> Pack --> EAN - Description
	Map<String, TierData> subBrands;

}
