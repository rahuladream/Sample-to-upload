package com.kcc.springjpa.snowflake.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@IdClass(OwnCrossSubbrandKey.class)
@Table(name = "V_RGM_SLS_FCT_DATA_CROSS_OWN_SUB_BRAND", schema = "REPORTING")
@Getter
@Setter
public class OwnCrossSubbrandData extends OwnCrossCommonFields {

	@Column(name = "MANUFACTURER_INITIAL")
	private String initialManufacturer;

	@Column(name = "MANUFACTURER_TARGET")
	private String targetManufacturer;

	@Id
	@Column(name = "BRAND_INITIAL")
	private String initialBrand;


	@Id
	@Column(name = "BRAND_TARGET")
	private String targetBrand;

	@Id
	@Column(name = "SUB_BRAND_INITIAL")
	private String initialSubBrand;

	@Id
	@Column(name = "SUB_BRAND_TARGET")
	private String targetSubBrand;

}
