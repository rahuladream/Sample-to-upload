package com.kcc.springjpa.snowflake.repository;

import java.util.List;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.kcc.springjpa.snowflake.entity.BaseLineData;

@Transactional
public interface BaseLineDataRepository extends JpaRepository<BaseLineData, Integer> {

	@Query(value = "SELECT DISTINCT ID as \"id\", WEEK as \"week\", MONTH as \"month\", YEAR as \"year\", TOTAL_QUANTITY as \"total_quantity\", PRICE_PER_CASE as \"price_per_case\", "
			+ "PROMO_PRICE as \"promo_price\", BASE_PRICE as \"base_price\", NET_INVOICE_LC as \"net_invoice_lc\", NET_INVOICE_USD as \"net_invoice_usd\", "
			+ "LOWER_LIMIT as \"lower_limit\", UPPER_LIMIT as \"upper_limit\", ACCURACY_10 as \"accuracy_10\", ACCURACY_50 as \"accuracy_50\", ACCURACY_90 as \"accuracy_90\", "
			+ "IS_PREDICTION as \"is_prediction\", BASELINE_TOTAL_QUANTITY as \"baseline_total_quantity\", EAN as \"ean\", MODEL_CREATED as \"model_created\", "
			+ "MODEL_RUN as \"model_run\", MODEL_NAME as \"model_name\", MODEL_VER as \"model_ver\", USER as \"user\", DATA_VER as \"data_ver\", SELL_IN_OUT as \"sell_in_out\", "
			+ "PERIODICITY as \"periodicity\", COMMENTS as \"comments\", SECTOR as \"sector\", CATEGORY as \"category\", BRAND as \"brand\", "
			+ "SUB_BRAND as \"sub_brand\", PRODUCT_DESC as \"product_desc\", SALES_ORG as \"sales_org\", SOLD_TO as \"sold_to\", SOLD_TO_DESC as \"sold_to_desc\", "
			+ "DISTR_CHANNEL as \"distr_channel\", COUNTRY as \"country\", ACTIVE as \"active\", SCORE as \"score\", SUB_CATEGORY as \"sub_category\", PLAN_LEVEL as \"plan_level\" "
			+ "from RGM_SLS_FCT_DATA_BASELINE", nativeQuery=true)
	public List<BaseLineData> getAllData();
	
	@Query
	public BaseLineData findById(int id);
	
//	@Query
//	public List<BaseLineData> findByCountry(String country);
	
	public List<BaseLineData> findAll(Specification<BaseLineData> specification);
	
//	@Query(nativeQuery =true,value = "SELECT * FROM RGM_ADV_ANLTCS.STAGING.RGM_SLS_FCT_DATA_BASELINE WHERE COUNTRY = :country "
//			+ "AND (COALESCE(:categories, null) IS EMPTY OR (CATEGORY IN :categories)) "
//			+ "AND (COALESCE(:subCategories, null) IS EMPTY OR (SUB_CATEGORY IN :subCategories)) "
//			+ "AND (COALESCE(:brands, null) IS EMPTY OR (BRAND IN :brands)) "
//			+ "AND (COALESCE(:subBrands, null) IS EMPTY OR (SUB_BRAND IN :subBrands)) "
//			+ "AND (COALESCE(:eans, null) IS EMPTY OR (EAN IN :eans))")   // 3. Spring JPA In cause using native query
//    public List<BaseLineData> filterBaseLineTableData(String country, List<String> categories, List<String> subCategories, List<String> brands, 
//    		List<String> subBrands, List<String> eans);
	
	
	default List<BaseLineData> findByFilter(String country, int year, List<String> planLevels, List<String> customers, List<String> categories, List<String> subCategories, List<String> brands, 
    		List<String> subBrands, List<String> eans){
		{
			return findAll(TableSpecs.findByFilter(country, year, planLevels, customers, categories, subCategories, brands, subBrands, eans));
		}
	}
	
	public class TableSpecs	{
	   public static Specification<BaseLineData> findByFilter(String country, int year, List<String> planLevels, List<String> customers, List<String> categories, List<String> subCategories, List<String> brands, 
	    		List<String> subBrands, List<String> eans)	   {
	      return (root, query, builder) -> {
	    	 //Integer year = 2021;
	         Predicate result = builder.equal(root.get("country"), country);
	         result = builder.and(result, root.get("year").in(year));
	         if (!CollectionUtils.isEmpty(planLevels)) {
		            result = builder.and(result, root.get("planLevel").in(planLevels));
		     }
	         if (!CollectionUtils.isEmpty(customers)) {
		            result = builder.and(result, root.get("soldToDesc").in(customers));
		     }
	         if (!CollectionUtils.isEmpty(categories)) {
	            result = builder.and(result, root.get("category").in(categories));
	         }
	         if (!CollectionUtils.isEmpty(subCategories)) {
		            result = builder.and(result, root.get("subCategory").in(subCategories));
		     }
	         if (!CollectionUtils.isEmpty(brands)) {
		            result = builder.and(result, root.get("brand").in(brands));
		     }
	         if (!CollectionUtils.isEmpty(subBrands)) {
		            result = builder.and(result, root.get("subBrand").in(subBrands));
		     }
	         if (!CollectionUtils.isEmpty(eans)) {
		            result = builder.and(result, root.get("ean").in(eans));
		     }
	         return result;
	      };
	   }
	}
	
}
