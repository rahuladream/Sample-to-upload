package com.kcc.springjpa.snowflake.dtos;

public class LineFittingDataPoint {

    public int year;
    public int week;
    public float price;
    public float volume;
}
