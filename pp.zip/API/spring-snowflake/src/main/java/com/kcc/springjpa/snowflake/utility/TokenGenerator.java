package com.kcc.springjpa.snowflake.utility;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.stereotype.Component;

import java.security.Key;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.UUID;
import java.util.function.Function;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Prudhvi Kodali
 * 
 */

@Component
public class TokenGenerator {

	public static String secret = "asdfSFS34wfsdfsdfSDSD32dfsddDDerQSNCK34SOWEK5354fdgdf4";

	public static String jwtToken(String name, String email, List<String> groups) {

		Key hmacKey = new SecretKeySpec(Base64.getDecoder().decode(secret), SignatureAlgorithm.HS256.getJcaName());

		Instant now = Instant.now();
		String jwtToken = Jwts.builder().claim("name", name).claim("email", email).claim("groups", groups)
				.setId(UUID.randomUUID().toString()).setIssuedAt(Date.from(now))
				.setExpiration(Date.from(now.plus(30, ChronoUnit.DAYS))).signWith(hmacKey).compact();

		return jwtToken;
	}

	public static Jws<Claims> parseJwt(String jwtString) {
		Key hmacKey = new SecretKeySpec(Base64.getDecoder().decode(secret), SignatureAlgorithm.HS256.getJcaName());

		Jws<Claims> jwt = Jwts.parserBuilder().setSigningKey(hmacKey).build().parseClaimsJws(jwtString);

		return jwt;
	}

//	public <T> boolean isTokenExpired(String jwtString) {
//		
//		Key hmacKey = new SecretKeySpec(Base64.getDecoder().decode(secret), SignatureAlgorithm.HS256.getJcaName());
//		Function<Claims, T> claimResolver = Claims::getExpiration;
//				//(Function<Claims, T>) claimResolver.apply((Claims) Jwts.parserBuilder().setSigningKey(hmacKey).build().parseClaimsJws(jwtString));
//		
//		return extractExpiration(token).before(new Date());
//	}
//
//	public Date extractExpiration(String token) {
//		return extractClaim(token, Claims::getExpiration);
//	}
//
//	public <T> T extractClaim(String token, Function<Claims, T> claimResolver) {
//		// Jws<Claims> jwt = TokenGenerator.parseJwt(jwtString);
//		final Claims claim = extractAllClaims(token);
//		return claimResolver.apply(claim);
//	}
//
//	private Claims extractAllClaims(String token) {
//		return Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
//	}

}