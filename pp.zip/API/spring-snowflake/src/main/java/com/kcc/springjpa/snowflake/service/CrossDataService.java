package com.kcc.springjpa.snowflake.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.kcc.springjpa.snowflake.model.ElasticityProductHierarchy;
import com.kcc.springjpa.snowflake.model.OwnElasticityModel;

public interface CrossDataService {
	
	public ElasticityProductHierarchy getKCProductHierarchy(String country, String scope, String source, String levelIndicator) throws Exception;
	
	public ElasticityProductHierarchy getTargetProductHierarchy(String country, List<String> leafValues, String levelIndicator, String scope, String source) throws Exception;
	
	public List<OwnElasticityModel> getCrossElasticityAnalysis(String country, List<String> initialLeafValues,
                                                               List<String> targetLeafValues, String levelIndicator, String source, String category, List<String> initialSubCategories, List<String> targetSubCategories, List<String> initialManufacturers, List<String> targetManufacturers, List<String> initialBrands, List<String> targetBrands, List<String> initialSubBrands, List<String> targetSubBrands, List<String> initialPacks, List<String> targetPacks) throws SQLException, Exception;

	public Map<String, List<OwnElasticityModel>> getCrossElasticityAnalysisPerScope(String country, List<String> initialLeafValues,
																					List<String> targetLeafValues, String levelIndicator, String scope, List<String> initialSubCategories, List<String> targetSubCategories, String source, String category, List<String> initialManufacturers, List<String> targetManufacturers, List<String> initialBrands, List<String> targetBrands, List<String> initialSubBrands, List<String> targetSubBrands, List<String> initialPacks, List<String> targetPacks) throws SQLException, Exception;

}
