package com.kcc.springjpa.snowflake.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.kcc.springjpa.snowflake.dtos.CreateImpactorRequest;
import com.kcc.springjpa.snowflake.model.ImpactorHistoryModel;
import com.kcc.springjpa.snowflake.model.ImpactorInfoModel;
import com.kcc.springjpa.snowflake.utility.StringResponse;

public interface ImpactorService {
	
	public List<String> getImactorNames() throws SQLException;
	
	public Map<String, ImpactorHistoryModel> getImpactorHistory(String country, String granularity) throws SQLException;
	
	public Map<String, ImpactorHistoryModel> getDeletedImpactorHistory(String country, String granularity) throws SQLException;
	
	public ImpactorInfoModel getImpactorInfo(String impactorName) throws SQLException;

	public StringResponse deleteImpactor(String deletedBy, String impactorName) throws SQLException, Exception;

	public StringResponse createImpactor(String createdBy, CreateImpactorRequest r) throws SQLException, Exception;
	
	public Map<String, Float> getMinimumAdjustmentValue(String country, Integer year, List<String> planLevels,
			List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
			List<String> subBrands, List<String> eans, List<Integer> weeks) throws SQLException, Exception;

}
