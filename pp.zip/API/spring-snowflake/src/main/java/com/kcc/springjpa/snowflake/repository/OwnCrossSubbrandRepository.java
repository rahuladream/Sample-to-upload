package com.kcc.springjpa.snowflake.repository;

import java.util.ArrayList;
import java.util.List;

import com.kcc.springjpa.snowflake.model.CrossOwnView;
import net.snowflake.client.jdbc.internal.amazonaws.util.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.kcc.springjpa.snowflake.entity.OwnCrossSubbrandData;
import org.springframework.util.CollectionUtils;

import javax.persistence.criteria.Predicate;

@Repository
@Transactional
public interface OwnCrossSubbrandRepository extends JpaRepository<OwnCrossSubbrandData, Integer> {
	
	// Query to get OWN Elasticity Data
	public List<OwnCrossSubbrandData> findAllByCountryAndFlagAndTypeAndSourceAndInitialSubBrandIn(String country, String flag, String type, String source, List<String> subBrands);

	//Query to get CROSS Elasticity Data
	public List<OwnCrossSubbrandData> findAllByCountryAndFlagAndTypeAndSourceAndInitialSubBrandInAndTargetSubBrandIn(String country,
																													 String flag, String type, String source, List<String> initialLeafValues, List<String> targetLeafValues);

	public List<OwnCrossSubbrandData> findAllByCountryAndFlagAndTypeAndInitialSubBrandInAndTargetSubBrandIn(String country,
																													 String flag, String type, List<String> initialLeafValues, List<String> targetLeafValues);

	public List<OwnCrossSubbrandData> findAllByCountry(String country);

	@Query(value = "SELECT * FROM REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_SUB_BRAND s " +
			"WHERE s.COUNTRY = :country AND s.FLAG = :flag AND s.TYPE = :type AND s.CATEGORY = :category AND s.SOURCE = :source " +
			"ORDER BY s.ELASTICITY_AVG_PRICE DESC " +
			"LIMIT :limit", nativeQuery = true)
	List<OwnCrossSubbrandData> findTopN(@Param("country") String country,
										@Param("flag") String flag,
										@Param("type") String type,
										@Param("limit") int limit,
										@Param("category") String category,
										@Param("source") String source);

	@Query(value = "SELECT * FROM REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_SUB_BRAND s " +
			"WHERE s.COUNTRY = :country AND s.FLAG = :flag AND s.TYPE = :type AND s.CATEGORY = :category AND s.SOURCE = :source " +
			"ORDER BY s.ELASTICITY_AVG_PRICE ASC " +
			"LIMIT :limit", nativeQuery = true)
	List<OwnCrossSubbrandData> findBottomN(@Param("country") String country,
										   @Param("flag") String flag,
										   @Param("type") String type,
										   @Param("limit") int limit,
										   @Param("category") String category,
										   @Param("source") String source);

	default List<CrossOwnView> findByInitials(String country, List<String> leafValues, String scope, String source, String flag, boolean initial){
		List<CrossOwnView> views = new ArrayList<>();
		Specification<OwnCrossSubbrandData> spec2 = InitialSpecs.findBySubBrandFilter(country, leafValues, scope, source, flag);
		List<OwnCrossSubbrandData> items2 = findAll(spec2);
		for (OwnCrossSubbrandData d : items2) {
			CrossOwnView v = new CrossOwnView();
			if(initial) {
				v.category = d.getCategory();
				v.initialSubCategory = d.getInitialSubCategory();
				v.initialManufacturer = d.getInitialManufacturer();
				v.initialBrand = d.getInitialBrand();
				v.initialSubBrand = d.getInitialSubBrand();
			} else {
				v.category = d.getCategory();
				v.targetSubCategory = d.getTargetSubCategory();
				v.targetManufacturer = d.getTargetManufacturer();
				v.targetBrand = d.getTargetBrand();
				v.targetSubBrand = d.getTargetSubBrand();
			}
			views.add(v);
		}
		return views;
	}

	class InitialSpecs {
		public static Specification<OwnCrossSubbrandData> findBySubBrandFilter(String country, List<String> leafValues, String scope, String source, String flag) {
			return (root, query, builder) -> {
				Predicate result = builder.equal(root.get("country"), country);
				result = builder.and(result, root.get("flag").in(flag));
				if (StringUtils.isNullOrEmpty(scope)) {
					if (source != null) {
						result = builder.and(result, root.get("source").in(source));
					}
				} else if (StringUtils.isNullOrEmpty(source)) {
					result = builder.and(result, root.get("type").in(scope));
				} else {
					result = builder.and(result, root.get("type").in(scope));
					result = builder.and(result, root.get("source").in(source));
				}
				if (!CollectionUtils.isEmpty(leafValues)) {
					result = builder.and(result, root.get("initialSubBrand").in(leafValues));
				}
				return result;
			};
		}
	}

	List<OwnCrossSubbrandData> findAll(Specification<OwnCrossSubbrandData> s);

	List<OwnCrossSubbrandData> findAllByCountryAndFlagAndTypeAndSourceAndInitialSubBrandInAndTargetSubBrandInAndInitialSubCategoryIn(String country,
																																	 String flag, String type,
																																	 String source,
																																	 List<String> initialLeafValues,
																																	 List<String> targetLeafValues,
																																	 List<String> subCategories);
}
