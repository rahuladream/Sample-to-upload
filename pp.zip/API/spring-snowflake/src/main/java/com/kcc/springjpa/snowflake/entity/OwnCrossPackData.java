package com.kcc.springjpa.snowflake.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@IdClass(OwnCrossPackKey.class)
@Table(name = "V_RGM_SLS_FCT_DATA_CROSS_OWN_PACK", schema = "REPORTING")
@Getter
@Setter
public class OwnCrossPackData extends OwnCrossCommonFields {

	@Column(name = "MANUFACTURER_INITIAL")
	private String initialManufacturer;

	@Column(name = "MANUFACTURER_TARGET")
	private String targetManufacturer;

	@Column(name = "BRAND_INITIAL")
	private String initialBrand;

	@Column(name = "BRAND_TARGET")
	private String targetBrand;

	@Column(name = "SUB_BRAND_INITIAL")
	private String initialSubBrand;

	@Column(name = "SUB_BRAND_TARGET")
	private String targetSubBrand;

	@Column(name = "TIER_INITIAL")
	private String initialTier;

	@Column(name = "TIER_TARGET")
	private String targetTier;

	@Id
	@Column(name = "PACK_INITIAL")
	private String initialPack;

	@Id
	@Column(name = "PACK_TARGET")
	private String targetPack;

}
