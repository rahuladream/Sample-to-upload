package com.kcc.springjpa.snowflake.dao;

import java.sql.SQLException;
import java.util.List;

import com.kcc.springjpa.snowflake.model.BaseLineCustomerModel;
import com.kcc.springjpa.snowflake.model.BaseLineProductModel;
import com.kcc.springjpa.snowflake.model.BaseLineResultsModel;

public interface BaseLineDao {
	
	public List<String> getCountriesList() throws SQLException;

	public List<BaseLineProductModel> getProductHierarchy(String country) throws SQLException;
	
	public List<BaseLineCustomerModel> getCustomerHierarchy(String country) throws SQLException;
	
	public List<BaseLineResultsModel> findByFilter(String country, int year, List<String> planLevels, List<String> customers, List<String> categories, List<String> subCategories, List<String> brands, 
    		List<String> subBrands, List<String> eans, String granularity) throws SQLException;

	boolean dailyAvailable(String country);
}
