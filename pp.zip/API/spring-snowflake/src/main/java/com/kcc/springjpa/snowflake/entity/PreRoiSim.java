package com.kcc.springjpa.snowflake.entity;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.*;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@Table(name = "RGM_SLS_FCT_DATA_PRE_ROI_SIM", schema = "INT")
@Getter
@Setter
public class PreRoiSim {
	
	@Column(name = "COUNTRY")
	private String country;
	
	@Id
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "PRODUCT_HIERARCHY_FILTER")
	private String productHierarchy;
	
	@Column(name = "FROM_DATE")
	@Temporal(TemporalType.DATE)
	private Date fromDate;
	
	@Column(name = "TO_DATE")
	@Temporal(TemporalType.DATE)
	private Date toDate;
	
	@Column(name = "BASELINE")
	private Float baseline;
	
	@Column(name = "INCREMENTAL_VOLUME")
	private Integer incrementalVolume;
	
	@Column(name = "TOTAL_VOLUME")
	private Integer totalVolume;
	
	@Column(name = "TOTAL_INVESTMENT")
	private Float totalInvestment;

	@Column(name = "PROMO_TYPE_SPEC")
	private String promoTypeSpec;
	
	@Column(name = "TARGET_ROI")
	private Float targetRoi;
	
	@Column(name = "ROI")
	private Float roi;
	
	@Column(name = "NET_PROFIT")
	private Float netProfit;

	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "CREATED")
	private Timestamp created;
	
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	
	@Column(name = "modified")
	private Timestamp modified;
}
