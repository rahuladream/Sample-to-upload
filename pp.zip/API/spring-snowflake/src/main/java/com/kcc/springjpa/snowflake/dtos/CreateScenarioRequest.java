package com.kcc.springjpa.snowflake.dtos;

import java.util.List;

public class CreateScenarioRequest {

    public String name;
    public List<String> simulations;
}
