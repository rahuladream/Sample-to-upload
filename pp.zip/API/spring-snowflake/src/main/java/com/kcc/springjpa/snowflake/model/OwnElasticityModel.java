package com.kcc.springjpa.snowflake.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Component
@Getter
@Setter
public class OwnElasticityModel {
	
	private float priceIndex;
	
	private String range;
	
	private float rsquared;
	
	private float averagePrice;
	
	private float promoPrice;
	
	private float basePrice;
	
	private boolean isViewMore;

	private int nWeeks;

	private String periodBegin;

	private String periodEnd;

	private String modelRun;

	private String initial;

	private String target;

	private String category;

	private String subCategoryInitial;

	private String subCategoryTarget;

	private String manufacturerInitial;

	private String manufacturerTarget;

	private String brandInitial;

	private String brandTarget;

	private String pValue;

	private float averageVolume;
}
