package com.kcc.springjpa.snowflake.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@IdClass(OwnCrossSubCategoryKey.class)
@Table(name = "V_RGM_SLS_FCT_DATA_CROSS_OWN_SUB_CATEGORY", schema = "REPORTING")
@Getter
@Setter
public class OwnCrossSubCategoryData extends OwnCrossCommonFields {

}
