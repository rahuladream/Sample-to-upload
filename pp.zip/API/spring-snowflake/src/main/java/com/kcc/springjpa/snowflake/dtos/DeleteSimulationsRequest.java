package com.kcc.springjpa.snowflake.dtos;

import java.util.List;

public class DeleteSimulationsRequest {

    public String country;
    public List<String> names;
}
