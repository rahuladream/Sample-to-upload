package com.kcc.springjpa.snowflake.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class SalesOfficeModel {

	// Distribution Channel --> Sales Office --> Plan Levels --> Sold to
	Map<String, PlanLevelModel> salesOffice;
}
