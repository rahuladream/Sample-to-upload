package com.kcc.springjpa.snowflake.dtos;

import java.util.List;

public class GetElasticitiesRequest {

    public String country;
    public String source;
    public String scope;
    public String hierarchyLevel;
    public String category;
    public boolean forOwn;
    public List<String> initialNodeValues;
    public List<String> targetNodeValues;
    public List<String> subCategories;
    public List<String> initialManufacturers;
    public List<String> targetManufacturers;
    public List<String> initialBrands;
    public List<String> targetBrands;
    public List<String> initialSubBrands;
    public List<String> targetSubBrands;
    public List<String> initialPacks;
    public List<String> targetPacks;
    public int topNBottomN;
}
