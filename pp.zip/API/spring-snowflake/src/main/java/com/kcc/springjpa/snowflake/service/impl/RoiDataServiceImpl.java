package com.kcc.springjpa.snowflake.service.impl;

import com.kcc.springjpa.snowflake.dtos.PostRoiQueryResult;
import com.kcc.springjpa.snowflake.entity.PostRoiGroup;
import com.kcc.springjpa.snowflake.model.PostRoiModel;
import com.kcc.springjpa.snowflake.model.PostRoiTpQuadrant;
import com.kcc.springjpa.snowflake.repository.PostRoiDataRepository;
import com.kcc.springjpa.snowflake.service.RoiDataService;
import com.kcc.springjpa.snowflake.utility.DateUtility;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.*;

@Service
public class RoiDataServiceImpl implements RoiDataService {

    private static final Logger logger = LogManager.getLogger(RoiDataServiceImpl.class);

    @Autowired
    PostRoiDataRepository postRoiDataRepository;

    private int[] getDatesBasedOnSource(List<String> source, String fromDate, String toDate, boolean hasDayData) throws ParseException {
        int dateFrom;
        int dateTo;

        if (!CollectionUtils.isEmpty(source) && source.contains("SELL IN")) {
            dateFrom = DateUtility.getConcatenatedMonthAndYear(fromDate);
            dateTo = DateUtility.getConcatenatedMonthAndYear(toDate);
        } else {
            if (!hasDayData) {
                dateFrom = DateUtility.getConcatenatedWeekAndYear(fromDate);
                dateTo = DateUtility.getConcatenatedWeekAndYear(toDate);
            } else {
                dateFrom = Integer.parseInt(fromDate.replaceAll("-", ""));
                dateTo = Integer.parseInt(toDate.replaceAll("-", ""));
            }

        }
        int[] result = {dateFrom, dateTo};
        return result;
    }

    @Override
    public List<PostRoiModel> getPostRoiData(String country, List<String> planLevels, List<String> customers,
                                             List<String> source, List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands,
                                             List<String> eans, List<String> eventIds, String fromDate, String toDate, String groupBy, String kpiType, List<Integer> quadrants) throws Exception {
        logger.info("Snowflake call to get postRoiData");

        boolean hasDayData = postRoiDataRepository.hasDayData(country);

        int[] parsedDates = getDatesBasedOnSource(source, fromDate, toDate, hasDayData);

        boolean forSU = kpiType != null && kpiType.equalsIgnoreCase("osku");

        List<PostRoiQueryResult> results = postRoiDataRepository.findPostRoi(country.toUpperCase(), planLevels,
                customers, source, categories, subCategories, brands, subBrands, eans, eventIds, parsedDates[0],
                parsedDates[1], groupBy, hasDayData, DateUtility.getMonthNumbersBetweenDates(fromDate, toDate), forSU, quadrants);
        List<PostRoiModel> models = new ArrayList<>();
        for(PostRoiQueryResult r : results) {
            models.addAll(buildModels(r.postRoiGroups, r.retailerMarginPercentages, country, groupBy));
        }
        return models;
    }

    private List<PostRoiModel> buildModels(List<PostRoiGroup> postRoiData, List<PostRoiGroup> retailerMarginPercentages, String country, String groupBy) {
        List<PostRoiModel> postRoiModelData = new ArrayList<>();
        for (PostRoiGroup postRoiGroup : postRoiData) {
            PostRoiModel postRoiModel = new PostRoiModel();
            if (groupBy.equals("Month")) {
                postRoiModel.setGroupBy(String.format("%d%02d", postRoiGroup.getYear(), postRoiGroup.getGroupByNum()));
            } else if (groupBy.equals("Week")) {
                postRoiModel.setGroupBy(postRoiGroup.getGroupBy());
            } else {
                postRoiModel.setGroupBy(postRoiGroup.getGroupBy());
            }
            postRoiModel.setPromoProfit(postRoiGroup.getPromoProfit());
            postRoiModel.setBaseLineProfit(postRoiGroup.getBaselineProfit());
            postRoiModel.setNetProfit(postRoiGroup.getNetProfit());
            postRoiModel.setTotalVolume(postRoiGroup.getTotalVolume());
            postRoiModel.setBaseLineVolume(postRoiGroup.getBaselineVolume());
            postRoiModel.setLift(postRoiModel.getTotalVolume() - postRoiModel.getBaseLineVolume());
            postRoiModel.setPromoInvestment(postRoiGroup.getPromoInvestment());
            if(postRoiGroup.getNetProfit() != 0 && postRoiGroup.getPromoInvestment() != 0) {
                postRoiModel.setRoi(BigDecimal.valueOf((postRoiGroup.getNetProfit() / postRoiGroup.getPromoInvestment()) * 100)
                        .setScale(2, RoundingMode.HALF_EVEN).doubleValue());
            } else {
                postRoiModel.setRoi(0);
            }
            postRoiModel.setCogsPerCase(postRoiGroup.getCogs());
            postRoiModel.setNppPerCase(postRoiGroup.getNpp());
            postRoiModel.setRetailerMargin(postRoiGroup.getRetailerMargin());

            applyRetailerMarginPercentage(postRoiModel, postRoiGroup, retailerMarginPercentages, country, groupBy);

            postRoiModelData.add(postRoiModel);
        }
        return postRoiModelData;
    }

    private void applyRetailerMarginPercentage(PostRoiModel postRoiModel, PostRoiGroup postRoiGroup, List<PostRoiGroup> retailerMarginPercentages, String country, String groupBy) {
        if (retailerMarginPercentages != null){
            PostRoiGroup retailMarginGroup = retailerMarginPercentages.stream().filter((retailRow) -> {
                String groupByVal;
                if (groupBy.equals("Month")) {
                    groupByVal = retailRow.getYear() + String.format("%02d", retailRow.getGroupByNum());
                } else if (groupBy.equals("Week")) {
                    groupByVal = String.valueOf(retailRow.getGroupByNum());
                } else {
                    groupByVal = retailRow.getGroupBy();
                }
                return postRoiModel.groupBy.equals(groupByVal);
            }).findFirst().orElse(null);;
            if (retailMarginGroup == null){
                postRoiModel.setRetailerMarginPercentage(0);
            }else{
                postRoiModel.setRetailerMarginPercentage(retailMarginGroup.getRetailerMarginPercentage());
            }
        }
        if(country.equalsIgnoreCase("UK")) {
            postRoiModel.setMechanic(postRoiGroup.getMechanic());
            postRoiModel.setFeature(postRoiGroup.getFeature());
            postRoiModel.setPricePoint(postRoiGroup.getPricePoint());
            postRoiModel.setDuration(postRoiGroup.getDuration());
        }
    }

    @Override
    public PostRoiModel getPostRoiQuadrantData(String country, List<String> planLevels, List<String> customers,
                                               List<String> source, List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands,
                                               List<String> eans, List<String> eventIds, String fromDate, String toDate, String kpiType) throws Exception {

        boolean hasDayData = postRoiDataRepository.hasDayData(country);

        int[] parsedDates = getDatesBasedOnSource(source, fromDate, toDate, hasDayData);

        logger.info("Snowflake call to get Post ROI Quadrant Data");

        boolean forSU = kpiType != null && kpiType.equalsIgnoreCase("osku");
        PostRoiGroup postRoiData = postRoiDataRepository.findPostRoiQuadrant(country.toUpperCase(), planLevels,
                customers, source, categories, subCategories, brands, subBrands, eans, eventIds, parsedDates[0],
                parsedDates[1], hasDayData, forSU);

        logger.info("Number of rows returned for Post ROI Quadrant Data ----------" + postRoiData);

        PostRoiModel postRoiModel = new PostRoiModel();
        postRoiModel.setPromoProfit(postRoiData.getPromoProfit());
        postRoiModel.setBaseLineProfit(postRoiData.getBaselineProfit());
        postRoiModel.setPromoInvestment(postRoiData.getPromoInvestment());
        postRoiModel.setNetProfit(postRoiData.getNetProfit());
        if(postRoiData.getNetProfit() != 0 && postRoiData.getPromoInvestment() != 0) {
            postRoiModel.setRoi(BigDecimal.valueOf((postRoiData.getNetProfit() / postRoiData.getPromoInvestment()) * 100).setScale(2, RoundingMode.HALF_EVEN).doubleValue());
        } else {
            postRoiModel.setRoi(0);
        }
        postRoiModel.setBaseLineVolume(postRoiData.getBaselineVolume());
        postRoiModel.setRetailerMargin(postRoiData.getRetailerMargin());
        postRoiModel.setRetailerMarginPercentage(postRoiData.getRetailerMarginPercentage());
        return postRoiModel;
    }

    private String formattedNumber(double number) {
        NumberFormat defaultFormat = NumberFormat.getPercentInstance();
        defaultFormat.setMinimumFractionDigits(2);
        String s = defaultFormat.format(number);
        return Optional.ofNullable(s)
                .filter(str -> str.length() != 0)
                .map(str -> str.substring(0, str.length() - 1))
                .orElse(s);
        //return defaultFormat.format(number);
    }

    @Override
    public List<String> getPostRoiEventIds(String country, List<String> planLevels, List<String> customers,
                                           List<String> source, List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands,
                                           List<String> eans, String fromDate, String toDate) throws ParseException {

        boolean hasDayData = postRoiDataRepository.hasDayData(country);
        int[] parsedDates = getDatesBasedOnSource(source, fromDate, toDate, hasDayData);

        logger.info("Snowflake call to get Post ROI Event Ids List");
        List<String> eventIds = postRoiDataRepository.findEventIds(country.toUpperCase(), planLevels, customers,
                source, categories, subCategories, brands, subBrands, eans, parsedDates[0], parsedDates[1], hasDayData);
        logger.info("Number of rows returned for Post ROI Event Ids ----------" + eventIds.size());
        return new ArrayList<>(new LinkedHashSet<>(eventIds));
    }

    @Override
    public PostRoiTpQuadrant getPostRoiTpQuadrant(String country, List<String> planLevels, List<String> customers,
                                                  List<String> source, List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands,
                                                  List<String> eans, List<String> eventIds, String fromDate, String toDate, String kpiType) throws ParseException {

        boolean hasDayData = postRoiDataRepository.hasDayData(country);

        int[] parsedDates = getDatesBasedOnSource(source, fromDate, toDate, hasDayData);

        logger.info("Snowflake call to get Post ROI Quadrant TP");

        boolean forSU = kpiType != null && kpiType.equalsIgnoreCase("osku");
        List<PostRoiGroup> postRoiDataList = postRoiDataRepository.findTpQuadrant(country.toUpperCase(),
                planLevels, customers, source, categories, subCategories, brands, subBrands, eans, eventIds,
                parsedDates[0], parsedDates[1], hasDayData, forSU);;

        logger.info("Number of rows returned for postRoiData ----------" + postRoiDataList.size());

        double q1PromoInvestment = 0;
        double q2PromoInvestment = 0;
        double q3PromoInvestment = 0;
        double q4PromoInvestment = 0;

        for (PostRoiGroup postRoiData : postRoiDataList) {
            double netProfit = postRoiData.getNetProfit() == null ? 0 : postRoiData.getNetProfit();
            double totalVolume = postRoiData.getTotalVolume() == null ? 0 : postRoiData.getTotalVolume();
            double baselineVolume = postRoiData.getBaselineVolume() == null ? 0 : postRoiData.getBaselineVolume();
            double promoInvestment = postRoiData.getPromoInvestment() == null ? 0 : postRoiData.getPromoInvestment();

            if (netProfit >= 0 && totalVolume >= baselineVolume) {
                q1PromoInvestment = q1PromoInvestment + promoInvestment;
            } else if (netProfit >= 0) {
                q4PromoInvestment = q4PromoInvestment + promoInvestment;
            } else if (netProfit < 0 && totalVolume >= baselineVolume) {
                q2PromoInvestment = q2PromoInvestment + promoInvestment;
            } else if (netProfit < 0) {
                q3PromoInvestment = q3PromoInvestment + promoInvestment;
            }
        }

        double totalPromoInvestment = q1PromoInvestment + q2PromoInvestment + q3PromoInvestment + q4PromoInvestment;

        PostRoiTpQuadrant postRoiTpQuadrant = new PostRoiTpQuadrant();
        postRoiTpQuadrant.setQ1PromoInvestment(roundedValue(q1PromoInvestment));
        postRoiTpQuadrant.setQ2PromoInvestment(roundedValue(q2PromoInvestment));
        postRoiTpQuadrant.setQ3PromoInvestment(roundedValue(q3PromoInvestment));
        postRoiTpQuadrant.setQ4PromoInvestment(roundedValue(q4PromoInvestment));
        postRoiTpQuadrant.setQ1PromoPercent(this.formattedNumber(q1PromoInvestment / totalPromoInvestment));
        postRoiTpQuadrant.setQ2PromoPercent(this.formattedNumber(q2PromoInvestment / totalPromoInvestment));
        postRoiTpQuadrant.setQ3PromoPercent(this.formattedNumber(q3PromoInvestment / totalPromoInvestment));
        postRoiTpQuadrant.setQ4PromoPercent(this.formattedNumber(q4PromoInvestment / totalPromoInvestment));
        return postRoiTpQuadrant;
    }

    public double roundedValue(double number) {
        return new BigDecimal(number).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    @Override
    public ByteArrayInputStream getPostRoiFile(String country, List<String> planLevels, List<String> customers,
                                               List<String> source, List<String> categories, List<String> subCategories, List<String> brands, List<String> subBrands,
                                               List<String> eans, List<String> eventIds, String fromDate, String toDate, String kpiType) throws ParseException {
        boolean hasDayData = postRoiDataRepository.hasDayData(country);

        int[] parsedDates = getDatesBasedOnSource(source, fromDate, toDate, hasDayData);

        logger.info("Snowflake call to get Post ROI Download Excel File");

        boolean forSU = kpiType != null && kpiType.equalsIgnoreCase("osku");
        return postRoiDataRepository.findTpQuadrantForExport(country.toUpperCase(),
                planLevels, customers, source, categories, subCategories, brands, subBrands, eans, eventIds,
                parsedDates[0], parsedDates[1], hasDayData, forSU);
    }

    @Override
    public Map<String, Boolean> hasSellInSelloutData(String country) throws ParseException {
        Map<String, Boolean> result = new HashMap<>();
        List<String> dataSources = postRoiDataRepository.findDistinctDataSource(country);
        if (dataSources != null && dataSources.size() > 0) {
            if (dataSources.contains("SELL IN") || dataSources.contains("SELL OUT")) {
                result.put("available", true);
                return result;
            }
        }
        result.put("available", false);
        return result;
    }

    public int getRandomNumber() {
        Random r = new Random();
        int low = 1;
        int high = 100;
        return r.nextInt(high - low) + low;
    }
}
