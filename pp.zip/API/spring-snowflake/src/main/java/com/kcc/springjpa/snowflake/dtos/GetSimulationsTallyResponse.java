package com.kcc.springjpa.snowflake.dtos;

public class GetSimulationsTallyResponse {

    public double currentTotalProfit;
    public double currentTotalROI;
}
