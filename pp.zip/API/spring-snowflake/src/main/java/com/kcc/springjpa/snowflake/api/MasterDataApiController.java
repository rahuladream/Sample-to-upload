package com.kcc.springjpa.snowflake.api;

import com.kcc.springjpa.snowflake.dtos.CountryMaster;
import com.kcc.springjpa.snowflake.service.MasterApiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

@Controller
public class MasterDataApiController implements MasterDataApi {

    @Autowired
    MasterApiService masterApiService;

    @Override
    public ResponseEntity<CountryMaster> getCountryMaster(String country) throws Exception {
        return new ResponseEntity<>(masterApiService.getCountryMaster(country), HttpStatus.OK);
    }
}
