package com.kcc.springjpa.snowflake.service.impl;

import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import javax.naming.ServiceUnavailableException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.kcc.springjpa.snowflake.model.EmbedConfig;
import com.kcc.springjpa.snowflake.model.EmbedInfo;
import com.kcc.springjpa.snowflake.model.EmbedToken;
import com.kcc.springjpa.snowflake.service.PowerBIService;
import com.microsoft.aad.msal4j.ClientCredentialFactory;
import com.microsoft.aad.msal4j.ClientCredentialParameters;
import com.microsoft.aad.msal4j.ConfidentialClientApplication;
import com.microsoft.aad.msal4j.IAuthenticationResult;

@Service
public class PowerBIServiceImpl implements PowerBIService {

	private static final Logger logger = LogManager.getLogger(PowerBIServiceImpl.class);

	@Value("${powerbi.client.id}")
	private String clientId;

	@Value("${powerbi.client.secret}")
	private String clientSecret;

	@Value("${powerbi.tenant.id}")
	private String tenantId;

	@Value("${powerbi.authority.url}")
	private String authorityUrl;

	@Value("${powerbi.resource.url}")
	private String scopeUrl;
	
//	@Value("${powerbi.report.id}")
//	private String reportId;
	
	@Value("${powerbi.group.id}")
	private String groupId;

	private ReadWriteLock tokenLock = new ReentrantReadWriteLock();
	private String cachedToken;

	@Override
	public EmbedInfo getPowerBIEmbedDetails(String reportId) throws MalformedURLException, ServiceUnavailableException, InterruptedException, ExecutionException {
				
		logger.info("Power BI API call initiated to get the access token");
		String accessToken = getAccessTokenUsingServicePrincipal();
		
		EmbedConfig reportEmbedConfig = getReportEmbedDetails(reportId, groupId, accessToken);	
		// Get embed token
		reportEmbedConfig.embedToken = getMultiResourceEmbedToken(reportEmbedConfig.reportId, reportEmbedConfig.datasetId, accessToken);		
		
		EmbedInfo embedInfo = new EmbedInfo();
		embedInfo.setAccessToken(reportEmbedConfig.embedToken.token);
		embedInfo.setTokenExpiry(reportEmbedConfig.embedToken.expiration);
		embedInfo.setUrl(reportEmbedConfig.embedUrl);	
		
		logger.info(embedInfo);
		return embedInfo;	
	}
	
	@Override
	public String getAccessTokenUsingServicePrincipal() throws MalformedURLException, InterruptedException, ExecutionException {

		// Build ConfidentialClientApp
		ConfidentialClientApplication app = ConfidentialClientApplication
				.builder(clientId, ClientCredentialFactory.createFromSecret(clientSecret))
				.authority(authorityUrl + tenantId).build();

		ClientCredentialParameters clientCreds = ClientCredentialParameters.builder(Collections.singleton(scopeUrl))
				.build();

		// Acquire new AAD token
		IAuthenticationResult result = app.acquireToken(clientCreds).get();

		// Return access token if token is acquired successfully
		if (result != null && result.accessToken() != null && !result.accessToken().isEmpty()) {
			logger.info("Authenticated with Service Principal mode");
			logger.info("Access Token::::::: " + result.accessToken());
			return result.accessToken();
		} else {
			logger.info("Failed to authenticate with Service Principal mode");
			return null;
		}
	}

	@Override
	public EmbedToken getMultiResourceEmbedToken(String reportId, String datasetId, String accessToken) {

		// Embed Token - Generate Token REST API
		String uri = "https://api.powerbi.com/v1.0/myorg/GenerateToken";
		RestTemplate restTemplate = new RestTemplate();

		// Create request header
		HttpHeaders headers = new HttpHeaders();
		headers.put("Content-Type", Arrays.asList("application/json"));
		headers.put("Authorization", Arrays.asList("Bearer " + accessToken));
		headers.put("Accept", Arrays.asList(""));

		// Request body
		JSONObject requestBody = new JSONObject();

		// Add dataset id in body
		JSONArray jsonDatasets = new JSONArray();
		jsonDatasets.put(new JSONObject().put("id", datasetId));

		// Add report id in body
		JSONArray jsonReports = new JSONArray();
		jsonReports.put(new JSONObject().put("id", reportId));
		requestBody.put("datasets", jsonDatasets);
		requestBody.put("reports", jsonReports);

		// Add (body, header) to HTTP entity
		HttpEntity<String> httpEntity = new HttpEntity<>(requestBody.toString(), headers);

		// Call the API
		ResponseEntity<String> response = restTemplate.postForEntity(uri, httpEntity, String.class);
		String responseBody = response.getBody();

		// Parse responseBody
		org.json.JSONObject jsonResponse = new org.json.JSONObject(responseBody);
		String token = jsonResponse.getString("token");
		String tokenId = jsonResponse.getString("tokenId");
		String expiration = jsonResponse.getString("expiration");

		EmbedToken embedToken = new EmbedToken();
		embedToken.setToken(token);
		embedToken.setTokenId(tokenId);
		embedToken.setExpiration(expiration);
		logger.info("Embed Token ::::::::::::::::::::::::::::::::::::::::::::::;; " + token);
		return embedToken;
	}

	@Override
	public EmbedConfig getReportEmbedDetails(String reportId, String groupId, String accessToken) {

		if (StringUtils.isEmpty(reportId)) {
			throw new RuntimeException("Empty Report Id");
		}

		if (StringUtils.isEmpty(groupId)) {
			throw new RuntimeException("Empty Group(Workspace) Id");
		}

		// Get Report In Group API:
		// https://api.powerbi.com/v1.0/myorg/groups/{groupId}/reports/{reportId}
		StringBuilder urlStringBuilder = new StringBuilder("https://api.powerbi.com/v1.0/myorg/groups/");
		urlStringBuilder.append(groupId);
		urlStringBuilder.append("/reports/");
		urlStringBuilder.append(reportId);

		// REST API URL to get report details
		String endPointUrl = urlStringBuilder.toString();

		// Request header
		HttpHeaders reqHeader = new HttpHeaders();
		reqHeader.put("Content-Type", Arrays.asList("application/json"));
		reqHeader.put("Authorization", Arrays.asList("Bearer " + accessToken));

		// HTTP entity object - holds header and body
		HttpEntity<String> reqEntity = new HttpEntity<>(reqHeader);

		// Rest API get report's details
		RestTemplate getReportRestTemplate = new RestTemplate();
		ResponseEntity<String> response = getReportRestTemplate.exchange(endPointUrl,
				org.springframework.http.HttpMethod.GET, reqEntity, String.class);

		String responseBody = response.getBody();
		// Create embedding configuration object
		EmbedConfig reportEmbedConfig = new EmbedConfig();

		// Parse JSON and get Report details
		org.json.JSONObject responseObj = new org.json.JSONObject(responseBody);
		reportEmbedConfig.embedUrl = responseObj.getString("embedUrl");
		reportEmbedConfig.datasetId = responseObj.getString("datasetId");
		reportEmbedConfig.reportId = responseObj.getString("id");

		logger.info(
				"Dataset ID ::::::::::::::::::::::::::::::::::::::::::::::;; " + responseObj.getString("datasetId"));
		logger.info("EMBED URL:::::::::::::::::::::::::::::::::::::::::::::::::: " + responseObj.getString("embedUrl"));
		logger.info("REPORT ID :::::::::::::::::::::::::::::::::::::::::::::::::: " + responseObj.getString("id"));
		return reportEmbedConfig;
	}

}
