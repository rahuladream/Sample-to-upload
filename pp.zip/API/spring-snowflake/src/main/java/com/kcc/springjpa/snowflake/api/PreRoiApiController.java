package com.kcc.springjpa.snowflake.api;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.kcc.springjpa.snowflake.dtos.*;
import com.kcc.springjpa.snowflake.entity.Scenario;
import com.kcc.springjpa.snowflake.model.Simulation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import com.kcc.springjpa.snowflake.entity.PreRoiSim;
import com.kcc.springjpa.snowflake.model.PreRoiPromoSimulationModel;
import com.kcc.springjpa.snowflake.model.PreRoiSimulatedPAndLModel;
import com.kcc.springjpa.snowflake.model.PromoSimulation;
import com.kcc.springjpa.snowflake.service.PreRoiDataService;
import com.kcc.springjpa.snowflake.utility.StringResponse;

@Controller
public class PreRoiApiController implements PreRoiApi {

	private static final Logger logger = LogManager.getLogger(PreRoiApiController.class);

	@Autowired
	PreRoiDataService preRoiDataService;

	@Override
	public ResponseEntity<Map<String, Boolean>> getPromoTypes(String country) throws Exception {
		logger.info("API call to retrieve PRE ROI Promo Types for the country : " + country);
		return new ResponseEntity<>(preRoiDataService.getPromoType(country.trim()), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<StringResponse> getBaseLineValue(String country, List<String> planLevels,
			List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
			List<String> subBrands, List<String> eans, String fromDate, String toDate) throws Exception {
		logger.info("API call to retrieve PRE ROI baseline value for the filters selected");
		return new ResponseEntity<>(preRoiDataService.getBaselineValue(country, planLevels, customers, categories,
				subCategories, brands, subBrands, eans, fromDate, toDate), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<PreRoiPromoSimulationModel> getSimulatedROIAndNPL(String country, List<String> planLevels,
																			List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
																			List<String> subBrands, List<String> eans, String fromDate, String toDate, Double baseLineVolume,
																			Double incrementalVolume, List<String> promoInvestmentAbsValues, List<String> promoInvestmentNonAbsValues,
																			Double promotedPrice) throws Exception {
		logger.info("API call to simulate PRE ROI promo ROI and NetProfit/Loss for the filters selected");
		return new ResponseEntity<>(preRoiDataService.getSimulatedROIAndNPL(country, planLevels, customers, categories,
				subCategories, brands, subBrands, eans, fromDate, toDate, baseLineVolume, incrementalVolume, promoInvestmentAbsValues, promoInvestmentNonAbsValues,
				promotedPrice), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<PreRoiSimulatedPAndLModel>> getSimulatedPAndL(String country, List<String> planLevels,
                                                                             List<String> customers, List<String> categories, List<String> subCategories, List<String> brands,
                                                                             List<String> subBrands, List<String> eans, String fromDate, String toDate, Double baseLineVolume,
                                                                             Double incrementalVolume, List<String> promoInvestmentAbsValues, List<String> promoInvestmentNonAbsValues,
                                                                             Double netProfitOrLoss, Double roiPercentage, Double totalPromoInvestment, Double npp, Double cogs,
																			 Double promotedPrice)
			throws Exception {
		logger.info("API call to get Simulated P And L Chart for the filters selected");
		return new ResponseEntity<>(preRoiDataService.getSimulatedPAndL(country, planLevels, customers, categories,
				subCategories, brands, subBrands, eans, fromDate, toDate, baseLineVolume, incrementalVolume, promoInvestmentAbsValues, promoInvestmentNonAbsValues, 
				netProfitOrLoss, roiPercentage, totalPromoInvestment, npp, cogs, promotedPrice), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Double> getCalculatedIncrementalVolume(String country, Double promoInvestment,
			Double targetRoiPercentage, Double baseLineVolume, Double npp, Double cogs)
			throws Exception {
		logger.info("API call to calculate Incremental Volume for the filters selected");
		return new ResponseEntity<>(preRoiDataService.getCalculatedIncrementalVolume(country, promoInvestment, targetRoiPercentage, 
				baseLineVolume, npp, cogs), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Double> getPromoInvMagicWand(String country, Double baseLineVolume, Double incrementalVolume,
			Double targetRoiPercentage, Double totalPromoInvestment, Double npp, Double cogs, Boolean isAbs)
			throws Exception {
		logger.info("API call to get Promo Investment Magic Wand value for the filters selected");
		return new ResponseEntity<>(preRoiDataService.getPromoInvMagicWand(country, baseLineVolume, 
				incrementalVolume, targetRoiPercentage, totalPromoInvestment, npp, cogs, isAbs), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<PreRoiSim> savePromo(HttpServletRequest request, PromoSimulation promoSimulation, String country) throws Exception {
		logger.info("API call to save Promo Simulation");
		String name = (String) request.getAttribute("createdBy");
		return new ResponseEntity<>(preRoiDataService.savePromoSimulation(name, promoSimulation), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<Simulation>> findSimulations(HttpServletRequest servletRequest, String country, String fromDate, String toDate, String name, String scenario)
			throws Exception {
		String createdBy = (String) servletRequest.getAttribute("createdBy");
		return new ResponseEntity<>(preRoiDataService.findSimulations(country, fromDate, toDate, name, scenario, createdBy), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<StringResponse> deleteSimulations(HttpServletRequest request, DeleteSimulationsRequest r) throws Exception {
		String name = (String) request.getAttribute("createdBy");
		return new ResponseEntity<>(preRoiDataService.deleteSimulations(r, name), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<GetSimulationsTallyResponse> tally(GetSimulationsTallyRequest request) throws ParseException {
		return new ResponseEntity<>(preRoiDataService.tally(request), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<StringResponse> createScenario(HttpServletRequest servletRequest, CreateScenarioRequest request) {
		StringResponse s = new StringResponse();
		try {
			preRoiDataService.createScenario(request, (String) servletRequest.getAttribute("createdBy"));
			s.setResponse("Scenario created successfully");
		} catch (Exception e) {
			s.setResponse(e.getMessage());
		}
		return new ResponseEntity<>(s, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<StringResponse> renameScenario(HttpServletRequest servletRequest, UpdateScenarioRequest request) throws Exception {
		StringResponse r = new StringResponse();
		try {
			preRoiDataService.updateScenario(request, (String) servletRequest.getAttribute("createdBy"));
			r.setResponse("Scenario updated successfully");
		} catch (Exception e) {
			r.setResponse(e.getMessage());
			if(e.getMessage().contains("Cannot rename")) {
				r.code = 1001;
			}
		}
		return new ResponseEntity<>(r, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<StringResponse> deleteScenario(HttpServletRequest servletRequest, String name) throws Exception {
		StringResponse r = new StringResponse();
		try {
			preRoiDataService.deleteScenario(name, (String) servletRequest.getAttribute("createdBy"));
			r.setResponse("Scenario deleted successfully");
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return new ResponseEntity<>(r, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<Scenario>> scenarios(HttpServletRequest servletRequest) throws Exception {
		List<Scenario> scenarios = preRoiDataService.scenarios((String) servletRequest.getAttribute("createdBy"));
		return new ResponseEntity<>(scenarios, HttpStatus.OK);
	}
}
