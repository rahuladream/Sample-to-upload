package com.kcc.springjpa.snowflake.configuration;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

@Configuration
public class SwaggerDocumentationConfig {

    ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("Spring Data Jpa Snowflake Service API")
                .description("Spring Data Jpa Snowflake Service API")
                .license("")
                .termsOfServiceUrl("")
                .version("1.0.0")
                .contact(new Contact("", "", ""))
                .build();
    }

    @Bean
    public Docket customImplementation() {
    	 ParameterBuilder aParameterBuilder = new ParameterBuilder();
    	    aParameterBuilder.name("Authorization")                 // name of header
    	                     .modelRef(new ModelRef("string"))
    	                     .parameterType("header")               // type - header
    	                     .description("JWT Authorization token")        // based64 of - zone:mypassword
    	                     .required(false)                // for compulsory
    	                     .build();
    	    java.util.List<Parameter> aParameters = new ArrayList<>();
    	    aParameters.add(aParameterBuilder.build());
    	    
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.kcc.springjpa.snowflake.api"))
                .build()
                .apiInfo(apiInfo())
                .globalOperationParameters(aParameters);
    }

}
