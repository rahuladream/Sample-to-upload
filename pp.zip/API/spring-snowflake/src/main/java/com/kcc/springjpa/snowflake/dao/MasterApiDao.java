package com.kcc.springjpa.snowflake.dao;

import com.kcc.springjpa.snowflake.dtos.CountryMaster;

public interface MasterApiDao {

    CountryMaster getCountryMaster(String country) throws Exception;
}
