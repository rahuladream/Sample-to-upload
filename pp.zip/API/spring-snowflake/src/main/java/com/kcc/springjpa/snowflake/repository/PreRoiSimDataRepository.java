package com.kcc.springjpa.snowflake.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.kcc.springjpa.snowflake.entity.PreRoiSim;

@Repository
@Transactional
public interface PreRoiSimDataRepository extends JpaRepository<PreRoiSim, Integer> {

}
