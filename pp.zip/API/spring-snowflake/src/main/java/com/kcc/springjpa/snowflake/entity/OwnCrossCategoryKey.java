package com.kcc.springjpa.snowflake.entity;

import java.io.Serializable;
import java.util.Objects;

public class OwnCrossCategoryKey implements Serializable {

    public String typeDescription, category;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OwnCrossCategoryKey that = (OwnCrossCategoryKey) o;
        return typeDescription.equals(that.typeDescription) && category.equals(that.category);
    }

    @Override
    public int hashCode() {
        return Objects.hash(typeDescription, category);
    }
}
