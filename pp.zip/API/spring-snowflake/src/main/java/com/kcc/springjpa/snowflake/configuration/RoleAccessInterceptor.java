package com.kcc.springjpa.snowflake.configuration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.kcc.springjpa.snowflake.utility.TokenGenerator;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;


public class RoleAccessInterceptor implements HandlerInterceptor {
	
	private static final Logger logger = LogManager.getLogger(RoleAccessInterceptor.class);

	private String accessLevel;
	
	public String contributor = "Contributor";
	public String admin = "_Admin";
	public String read = "_Read_Users";
	
	RoleAccessInterceptor(String accessLevel){
		this.accessLevel = accessLevel;
	}
	
	@SuppressWarnings("unchecked")
	@Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception
    {
//		logger.info("INTERCEPTOR PREHANDLE CALLED");
		
		// Initial call to obtain the new Token. Any request should be able to access this API
		String requestUrl = request.getRequestURL().toString();
		logger.info("REQUEST URL ::::::: " + request.getRequestURL().toString());
		if(requestUrl.contains("generateApiToken") || requestUrl.contains("swagger") || requestUrl.contains("api-docs")) {
			return true;
		}
			
		String header = request.getHeader("Authorization");
        if (header == null || !header.startsWith("Bearer ")) {
            response.getWriter().write("No JWT token found in request headers");
	        response.setStatus(401);
	        return false;
        }

        String name = "";
        String jwtToken = header.substring(7);
        logger.info("JWT TOKEN ::::::: " + jwtToken);
        try {
			Jws<Claims> jwt = TokenGenerator.parseJwt(jwtToken);
			List<String> groups = new ArrayList<String>();
			if(jwt.getBody().get("groups") != null) {
				groups = (List<String>) jwt.getBody().get("groups");
				logger.info("Groups ::::::: " + groups);
			} else {
				response.getWriter().write("User is not in any of the Security Groups");
		        response.setStatus(401);
				return false;
			}
			
			if(jwt.getBody().get("name") != null) {
				name = (String) jwt.getBody().get("name");
				logger.info("User Name ::::::: " + name);
			} else {
				name = "UserName";
			}
			request.setAttribute("createdBy", name);
			
			if(groups.contains(accessLevel + contributor) || !request.getParameterMap().containsKey("country")) {
				return true;
			} else {
				String country = request.getParameter("country").toUpperCase();
				logger.info("COUNTRY ::::::: " + country);				
				return this.validateAcess(country, groups, requestUrl, response);			
			}			
		} catch (ExpiredJwtException ex) {
			logger.error("Invalid access token", ex);
			response.getWriter().write("JWT Token Expired");
	        response.setStatus(401);
	        return false;
		} catch (Exception e) {
			logger.error("Could not validate token", e);
			response.getWriter().write(e.getMessage());
	        response.setStatus(401);
	        return false;
		}	
		
//		return true;
    }

    private boolean validateAcess(String country, List<String> groups, String requestUrl, HttpServletResponse response) throws IOException {
		
    	String readAccess = accessLevel + country + read;
		String adminAccess = accessLevel + country + admin;
		
		if(requestUrl.contains("admin")) {
			for(String group : groups) {
				if(group.contains(adminAccess)) {
					return true;
				}
			}
		} else {
			for(String group : groups) {
				if(group.contains(readAccess) || group.contains(adminAccess)) {
					return true;
				}
			}
		}
		
		response.getWriter().write("User not Authorized to access this functionality");
        response.setStatus(401);

        return false;
	}

	@Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception
    {
    	//logger.info("MINIMAL: INTERCEPTOR POSTHANDLE CALLED");
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception exception) throws Exception
    {
    	//logger.info("MINIMAL: INTERCEPTOR AFTERCOMPLETION CALLED");
    }
    
   

}
