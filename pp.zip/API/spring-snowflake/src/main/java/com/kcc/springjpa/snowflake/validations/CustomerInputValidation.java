package com.kcc.springjpa.snowflake.validations;

import com.kcc.springjpa.snowflake.entity.Customer;
import com.kcc.springjpa.snowflake.exception.InvalidCustomerNameException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CustomerInputValidation  implements InputValidation {
    @Override
    public boolean validate(Object object) throws InvalidCustomerNameException {
        Customer customer = null;
        if(object instanceof Customer)
            customer = (Customer) object;

        Pattern pattern = Pattern.compile("[^a-zA-Z]");
        Matcher matcher = pattern.matcher(customer.getCName());
        boolean isStringContainsSpecialCharacter = matcher.find();
        if(isStringContainsSpecialCharacter)
            throw new InvalidCustomerNameException("Invalid Customer Name.", customer.getCName());
        return true;
    }
}
