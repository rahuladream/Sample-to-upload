package com.kcc.springjpa.snowflake.dtos;

import java.util.List;

public class GetCorrelationRequest {

    public String country;
    public String scope;
    public List<String> initialNodeValues;
    public List<String> targetNodeValues;
    public String hierarchyLevel;
}
