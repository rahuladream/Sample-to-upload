package com.kcc.springjpa.snowflake.model;

import org.json.JSONObject;

import java.util.List;
import java.util.Map;

public class TestData {
    public String title;
    public String query;
    public List<Map<String,Object>> result;
    public String error;

    public TestData(String _title, String _query){
        this.title = _title;
        this.query = _query;
    }
}
