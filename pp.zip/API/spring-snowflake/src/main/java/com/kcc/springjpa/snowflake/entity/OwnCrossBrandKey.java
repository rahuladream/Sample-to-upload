package com.kcc.springjpa.snowflake.entity;

import java.io.Serializable;
import java.util.Objects;

public class OwnCrossBrandKey implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public int hashCode() {
		return Objects.hash(initialBrand, targetBrand, type, typeDescription);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OwnCrossBrandKey other = (OwnCrossBrandKey) obj;
		return Objects.equals(initialBrand, other.initialBrand) && Objects.equals(targetBrand, other.targetBrand)
				&& Objects.equals(type, other.type) && Objects.equals(typeDescription, other.typeDescription);
	}

	private String initialBrand;
	
	private String targetBrand;
	
	private String type;
	
	private String typeDescription;

}
