package com.kcc.springjpa.snowflake.repository;

import java.io.ByteArrayInputStream;
import java.util.List;

import com.kcc.springjpa.snowflake.dtos.PostRoiQueryResult;
import com.kcc.springjpa.snowflake.entity.PostRoiData;
import com.kcc.springjpa.snowflake.model.BaseLineCustomerModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.kcc.springjpa.snowflake.entity.PostRoiGroup;

@Repository
@Transactional
public
interface PostRoiDataRepository extends JpaRepository<PostRoiData, Integer> {

	List<PostRoiData> findAll();

	List<String> findEventIds(String country, List<String> planLevels,
			List<String> customers, List<String> source, List<String> categories, List<String> subCategories, List<String> brands,
			List<String> subBrands, List<String> eans, int fromDate, int toDate,  boolean dayData);

	@Query(nativeQuery = true, value = "SELECT DISTINCT DATA_SOURCE from  RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_POST_ROI where country = ? ")
	List<String> findDistinctDataSource(String country);

	boolean hasDayData(String country);

	List<PostRoiQueryResult> findPostRoi(String country, List<String> planLevels,
										 List<String> customers, List<String> source, List<String> categories, List<String> subCategories, List<String> brands,
										 List<String> subBrands, List<String> eans, List<String> eventIds, int fromDate, int toDate, String groupBy, boolean dayData, List<Integer> monthNumbers, boolean forSU, List<Integer> quadrants) throws Exception;

	PostRoiGroup findPostRoiQuadrant(String country, List<String> planLevels,
									 List<String> customers, List<String> source, List<String> categories, List<String> subCategories, List<String> brands,
									 List<String> subBrands, List<String> eans, List<String> eventIds, int fromDate, int toDate, boolean dayData, boolean forSU) throws Exception;

	List<PostRoiGroup> findTpQuadrant(String country, List<String> planLevels,
									  List<String> customers, List<String> source, List<String> categories, List<String> subCategories, List<String> brands,
									  List<String> subBrands, List<String> eans, List<String> eventIds, int fromDate, int toDate, boolean dayData,
									  boolean forSU);

	ByteArrayInputStream findTpQuadrantForExport(String country, List<String> planLevels,
                                                 List<String> customers, List<String> source, List<String> categories, List<String> subCategories, List<String> brands,
                                                 List<String> subBrands, List<String> eans, List<String> eventIds, int fromDate, int toDate, boolean dayData, boolean forSU);

    List<BaseLineCustomerModel> getCustomerHierarchy(String country, List<String> sources);
}
