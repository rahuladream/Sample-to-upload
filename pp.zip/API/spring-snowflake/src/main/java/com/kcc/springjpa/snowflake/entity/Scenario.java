package com.kcc.springjpa.snowflake.entity;

import java.util.List;

public class Scenario {

    public String name;
    public String createdBy;
    public String createdAt;
    public List<String> simulations;

}
