package com.kcc.springjpa.snowflake.model;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class BaseLineResultsModel {
	
	public BaseLineResultsModel() {	}

	public BaseLineResultsModel(Integer year, Integer month, Integer week, BigDecimal baseLineTotalQuantity, BigDecimal baseLineAdjustedQuantity) {
		super();
		this.year = year;
		this.month = month;
		this.week = week;
		this.baseLineTotalQuantity = baseLineTotalQuantity;
		this.baseLineAdjustedQuantity = baseLineAdjustedQuantity;
	}

	public BaseLineResultsModel(Integer year, Integer month, Integer week, Integer day, BigDecimal baseLineTotalQuantity, BigDecimal baseLineAdjustedQuantity) {
		super();
		this.year = year;
		this.month = month;
		this.week = week;
		this.day = day;
		this.baseLineTotalQuantity = baseLineTotalQuantity;
		this.baseLineAdjustedQuantity = baseLineAdjustedQuantity;
	}

	private Integer year;
	
	private Integer month;
	
	private Integer week;

	private Integer day;
	
	private BigDecimal baseLineTotalQuantity;
	
	private BigDecimal baseLineAdjustedQuantity;

}
