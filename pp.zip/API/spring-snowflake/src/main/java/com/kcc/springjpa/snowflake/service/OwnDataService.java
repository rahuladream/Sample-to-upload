package com.kcc.springjpa.snowflake.service;

import java.io.ByteArrayInputStream;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.kcc.springjpa.snowflake.dtos.GetElasticitiesRequest;
import com.kcc.springjpa.snowflake.dtos.GetRegressionStatsRequest;
import com.kcc.springjpa.snowflake.dtos.LineFittingDataPoint;
import com.kcc.springjpa.snowflake.dtos.RegressionStats;
import com.kcc.springjpa.snowflake.model.ElasticityProductHierarchy;
import com.kcc.springjpa.snowflake.model.OwnElasticityModel;

public interface OwnDataService {
	
	ElasticityProductHierarchy getOwnProductHierarchy(String country, String scope, String source, String levelIndicator) throws Exception;

	List<Map<String, OwnElasticityModel>> getOwnElasticityModels(String country, List<String> leafValues, String levelIndicator, int topNBottomN, String category, String source, List<String> subCategories, List<String> manufacturers, List<String> brands, List<String> subBrands, List<String> packs) throws Exception;

	Map<String, Map<String, OwnElasticityModel>> getOwnElasticityModelsPerScope(String country, List<String> leafValues, String levelIndicator, String scope, int topNBottomN, String category, String source, List<String> subCategories, List<String> manufacturers, List<String> brands, List<String> subBrands, List<String> packs) throws Exception;

	Map<String, Boolean> getMarketScopeToggles(String country, String category, String levelIndicator, String source) throws Exception;

	Map<String, Boolean> getAvailableSources(String country, String productLevel) throws Exception;

	ByteArrayInputStream getOwnElasticityFile(GetElasticitiesRequest req) throws Exception;

	String lastModelUpdateDate(String country) throws Exception;

	List<LineFittingDataPoint> getLineFittingDataPoints(String country, String initial, String target, String levelIndicator, String customer);

    RegressionStats runRegression(GetRegressionStatsRequest r);

	List<String> getSubCategories(String countru, String category);
}
