package com.kcc.springjpa.snowflake.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerAlreadyExistsException extends Exception{
    String customerId;
    public CustomerAlreadyExistsException(String message, String customerId){
        super(message);
        this.customerId = customerId;
    }
}
