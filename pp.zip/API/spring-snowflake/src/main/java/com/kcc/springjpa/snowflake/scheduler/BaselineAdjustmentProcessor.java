package com.kcc.springjpa.snowflake.scheduler;

import java.sql.SQLException;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.kcc.springjpa.snowflake.dao.ImpactorDao;

@Component
public class BaselineAdjustmentProcessor {
	
	private static final Logger logger = LogManager.getLogger(BaselineAdjustmentProcessor.class);
	
	@Autowired
	ImpactorDao impactorDao;

	@Scheduled(cron = "${baseline.adjustment.schedule}")
	public void cronJobSch() throws SQLException {
		
		logger.info("Cron job checking for new baseline records :::");
		Set<String> countries = impactorDao.getNewBaselineLoads();
		try {
			for(String country : countries) {
				impactorDao.loadNewBaselineDataLoads(country.trim());
			}
			impactorDao.updateAdjustmentLogRecords();
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
	}

}
