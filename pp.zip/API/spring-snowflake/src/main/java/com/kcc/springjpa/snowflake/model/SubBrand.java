package com.kcc.springjpa.snowflake.model;

import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class SubBrand {
	
	//Map<String, String> subBrands;
	
	Map<String, Set<String>> subBrands;
}
