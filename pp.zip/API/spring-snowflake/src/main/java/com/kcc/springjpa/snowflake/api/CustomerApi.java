package com.kcc.springjpa.snowflake.api;

import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kcc.springjpa.snowflake.model.BaseLineDataModel;
import com.kcc.springjpa.snowflake.model.CustomerHierarchy;
import com.kcc.springjpa.snowflake.model.EmbedInfo;
import com.kcc.springjpa.snowflake.model.ProductHierarchy;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "customer", description = "the Customer API")
public interface CustomerApi {

	@ApiOperation(value = "", response = ProductHierarchy.class, tags = { "BaseLineData", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful baseline data", response = ProductHierarchy.class) })
	@RequestMapping(value = "/productHierarchy", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<ProductHierarchy> getProductHierarchy(@RequestParam(value = "country") String country) throws Exception;

	@ApiOperation(value = "", response = ProductHierarchy.class, tags = { "BaseLineData", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful baseline data", response = ProductHierarchy.class) })
	@RequestMapping(value = "/customerHierarchy", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<CustomerHierarchy> getCustomerHierarchy(
			@RequestParam(value = "country", required = true) String country,
			@RequestParam(value = "source", required = false) List<String> source,
			@RequestParam(value = "feature", required = false) String feature) throws Exception;

	@ApiOperation(value = "", response = ProductHierarchy.class, tags = { "BaseLineData", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Countries List", response = ProductHierarchy.class) })
	@RequestMapping(value = "/getCountriesList", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<List<String>> getCountriesList() throws Exception;
	
	@ApiOperation(value = "", response = BaseLineDataModel.class, tags = { "BaseLineData", })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful BaseLine Data", response = BaseLineDataModel.class) })
	@RequestMapping(value = "/baseLineData", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<List<BaseLineDataModel>> getBaseLineData(@RequestParam(value = "country", required = true) String country,
			@RequestParam(value = "years", required = true) List<Integer> years,
			@RequestParam(value = "granularity", required = true) String granularity,
			@RequestParam(value = "planLevels", required = false) List<String> planLevels,
			@RequestParam(value = "customers", required = false) List<String> customers,
			@RequestParam(value = "categories", required = false) List<String> categories,
			@RequestParam(value = "subCategories", required = false) List<String> subCategories,
			@RequestParam(value = "brands", required = false) List<String> brands,
			@RequestParam(value = "subBrands", required = false) List<String> subBrands,
			@RequestParam(value = "eans", required = false) List<String> eans) throws Exception;

	@ApiOperation(value = "", response = JSONObject.class, tags = { "PowerBiToken", })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Powr BI Token", response = String.class) })
	@RequestMapping(value = "/powerBiToken", produces = { "application/json" }, method = RequestMethod.GET)
	ResponseEntity<EmbedInfo> getPowerBIToken(@RequestParam(value = "reportId", required = true) String reportId) throws Exception;

	@ApiOperation(value = "", response = Map.class, tags = {"BaseLineData", })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Available Datasets", response = Map.class)})
	@RequestMapping(value = "/dailyAvailable", produces = {"application/json"}, method = {RequestMethod.GET})
	ResponseEntity<Map<String, Boolean>> dailyAvailable(@RequestParam(value = "country") String country);

}
