package com.kcc.springjpa.snowflake.api;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.kcc.springjpa.snowflake.dtos.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import com.kcc.springjpa.snowflake.model.ElasticityProductHierarchy;
import com.kcc.springjpa.snowflake.model.OwnElasticityModel;
import com.kcc.springjpa.snowflake.service.CorrelationDataService;
import com.kcc.springjpa.snowflake.service.CrossDataService;
import com.kcc.springjpa.snowflake.service.OwnDataService;

@Controller
public class ElasticityAPIController implements ElasticityApi {

	private static final Logger logger = LogManager.getLogger(ElasticityAPIController.class);

	@Autowired
	CorrelationDataService correlationDataService;

	@Autowired
	OwnDataService ownDataService;

	@Autowired
	CrossDataService crossDataService;

	@Override
	public ResponseEntity<ElasticityProductHierarchy> getOwnProductHierarchy(String country, String scope, String source, String levelIndicator) throws Exception {
		logger.info("API call to retrieve OwnProduct Hierarchy for the country: " + country);
		return new ResponseEntity<>(ownDataService.getOwnProductHierarchy(country.trim(), scope, source, levelIndicator), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<Map<String, OwnElasticityModel>>> getOwnElasticity(GetElasticitiesRequest r) throws Exception {
		logger.info("API call to retrieve Own Elasticity for the given OwnProducts: " + r.hierarchyLevel);
		return new ResponseEntity<>(ownDataService.getOwnElasticityModels(r.country, r.initialNodeValues,
				r.hierarchyLevel, r.topNBottomN, r.category, r.source, r.subCategories, r.initialManufacturers, r.initialBrands, r.initialSubBrands, r.initialPacks), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Map<String, Map<String, OwnElasticityModel>>> getOwnElasticityPerScope(GetElasticitiesRequest r) throws Exception {
		logger.info("API call to retrieve Own Elasticity Per Scope for the given OwnProducts: " + r.hierarchyLevel);
		return new ResponseEntity<>(ownDataService.getOwnElasticityModelsPerScope(r.country, r.initialNodeValues,
				r.hierarchyLevel, r.scope,  r.topNBottomN, r.category, r.source, r.subCategories, r.initialManufacturers, r.initialBrands, r.initialSubBrands, r.initialPacks),
				HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ElasticityProductHierarchy> getKCProductHierarchy(String country, String scope, String source, String levelIndicator) throws Exception {
		logger.info("API call to retrieve KCProduct Hierarchy for the country: " + country);
		return new ResponseEntity<>(crossDataService.getKCProductHierarchy(country.trim(), scope, source, levelIndicator), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<ElasticityProductHierarchy> getTargetProductHierarchy(String country, List<String> leafValues,
																				String levelIndicator, String scope, String source) throws Exception {
		logger.info("API call to retrieve TargetProduct Hierarchy for the given KCProducts: " + leafValues);
		return new ResponseEntity<>(crossDataService.getTargetProductHierarchy(country, leafValues, levelIndicator, scope, source),
				HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<OwnElasticityModel>> getCrossElasticityAnalysis(String country,
																			   String hierarchyLevel,
																			   List<String> initialNodeValues,
																			   List<String> targetNodeValues,
																			   String source,
																			   String category,
																			   List<String> initialManufacturers,
																			   List<String> targetManufacturers,
																			   List<String> initialSubCategories,
																			   List<String> targetSubCategories,
																			   List<String> initialBrands,
																			   List<String> targetBrands,
																			   List<String> initialSubBrands,
																			   List<String> targetSubBrands,
																			   List<String> initialPacks,
																			   List<String> targetPacks) throws Exception {
		logger.info("API call to get Cross Elasticity values for given KC and Target Products: " + initialNodeValues + "::"
				+ targetNodeValues);
		return new ResponseEntity<>(crossDataService.getCrossElasticityAnalysis(country,
				initialNodeValues, targetNodeValues, hierarchyLevel, source,
				category, initialSubCategories, targetSubCategories, initialManufacturers, targetManufacturers,
				initialBrands, targetBrands, initialSubBrands, targetSubBrands, initialPacks, targetPacks), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Map<String, List<OwnElasticityModel>>> getCrossElasticityAnalysisPerScope(String country,
																									String hierarchyLevel, String scope, List<String> initialNodeValues, List<String> targetNodeValues, String source, String category, List<String> initialManufacturers, List<String> targetManufacturers, List<String> initialSubCategories, List<String> targetSubCategories, List<String> initialBrands, List<String> targetBrands, List<String> initialSubBrands, List<String> targetSubBrands, List<String> initialPacks, List<String> targetPacks) throws Exception {
		logger.info("API call to get Cross Elasticity values Per Scope for given KC and Target Products: " + initialNodeValues + "::"
				+ targetNodeValues);
		return new ResponseEntity<>(crossDataService.getCrossElasticityAnalysisPerScope(country, initialNodeValues, targetNodeValues, hierarchyLevel, scope, initialSubCategories, targetSubCategories, source, category, initialManufacturers, targetManufacturers, initialBrands, targetBrands, initialSubBrands, targetSubBrands, initialPacks, targetPacks), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Map<String, Map<String, String>>> getCorrelationAnalysis(GetCorrelationRequest r)
			throws Exception {
		logger.info("API call to get Correlation values for given KC and Target Products: " + r.initialNodeValues + "::"
				+ r.targetNodeValues);
		return new ResponseEntity<>(correlationDataService.getCorrelationAnalysis(r.country, r.initialNodeValues, r.targetNodeValues, r.hierarchyLevel, r.scope),
				HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Map<String, Boolean>> getMarketScopeToggles(String country, String category, String levelIndicator, String source) throws Exception {
		return new ResponseEntity<>(ownDataService.getMarketScopeToggles(country, category, levelIndicator, source), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Map<String, Boolean>> getAvailableSources(String country, String productLevel) throws Exception {
		return new ResponseEntity<>(ownDataService.getAvailableSources(country, productLevel), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Resource> downloadElasticity(GetElasticitiesRequest downloadRequest) throws Exception {
		logger.info("API call to download Own Elasticity Excel file for the filters selected: " + downloadRequest.country);
		String filename = "own.xlsx";
		InputStreamResource file = new InputStreamResource(ownDataService.getOwnElasticityFile(downloadRequest));

		HttpHeaders headers = new HttpHeaders(); headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");
		return ResponseEntity.ok()
				.headers(headers)
				//.contentLength(file.length())
				.contentType(MediaType.APPLICATION_OCTET_STREAM)
				.body(file);
	}

	@Override
	public ResponseEntity<Map<String, String>> getLastModelRunDate(String country) throws Exception {
		String modelDate = ownDataService.lastModelUpdateDate(country);
		Map<String, String> resultMap = new HashMap<String, String>() {{
			put(country, modelDate);
		}};
		return new ResponseEntity<>(resultMap, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<LineFittingDataPoint>> getLineFittingDataPoints(String country, String initial, String target, String levelIndicator, String customer) {
		return new ResponseEntity<>(ownDataService.getLineFittingDataPoints(country, initial, target, levelIndicator, customer), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<RegressionStats> dataPointsForRegression(GetRegressionStatsRequest r) throws Exception {
		return new ResponseEntity<>(ownDataService.runRegression(r), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<String>> getSubCategories( String country,  String category) throws Exception {
		return new ResponseEntity<>(ownDataService.getSubCategories(country, category), HttpStatus.OK);
	}
}
