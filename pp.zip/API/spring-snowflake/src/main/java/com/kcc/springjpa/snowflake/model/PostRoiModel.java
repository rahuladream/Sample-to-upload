package com.kcc.springjpa.snowflake.model;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Component
@Getter
@Setter
public class PostRoiModel {
	
	public String groupBy;
	
	public double promoProfit;
	
	public double baseLineProfit;
	
	public double netProfit;
	
	public double totalVolume;
	
	public double baseLineVolume;
	
	public double lift;
	
	public double promoInvestment;
	
	public double roi;
	
	public double cogsPerCase;
	
	public double nppPerCase;
	
	public double retailerMargin;
	
	public double retailerMarginPercentage;

	public String tier;

	public String tacticType;

	public String roll;

	public String pack;

	public String size;

	private List<Object> mechanic, feature;

	private double pricePoint;

	private long duration;
}
