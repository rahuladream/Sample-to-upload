package com.kcc.springjpa.snowflake.service.impl;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.kcc.springjpa.snowflake.dtos.CreateImpactorRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.kcc.springjpa.snowflake.dao.BaseLineDao;
import com.kcc.springjpa.snowflake.dao.ImpactorDao;
import com.kcc.springjpa.snowflake.model.ImpactorHistoryModel;
import com.kcc.springjpa.snowflake.model.ImpactorInfoModel;
import com.kcc.springjpa.snowflake.service.ImpactorService;
import com.kcc.springjpa.snowflake.utility.StringResponse;

@Service
public class ImpactorServiceImpl implements ImpactorService {

	private static final Logger logger = LogManager.getLogger(ImpactorServiceImpl.class);

	@Autowired
	ImpactorDao impactorDao;

	@Autowired
	BaseLineDao baseLineDao;

	@Override
	public List<String> getImactorNames() throws SQLException {
		logger.info("Get Existing Impactor Names Service");
		//All Existing Impactor Names 
		return impactorDao.getImpactorNamesInOrder(null, false);
	}

	@Override
	public Map<String, ImpactorHistoryModel> getImpactorHistory(String country, String granularity) throws SQLException {
		logger.info("Get Impactor History Service");
		return impactorDao.getImpactorHistory(country, false, granularity);
	}

	@Override
	public Map<String, ImpactorHistoryModel> getDeletedImpactorHistory(String country, String granularity) throws SQLException {
		logger.info("Get Deleted Impactor History Service");
		return impactorDao.getImpactorHistory(country, true, granularity);
	}

	@Override
	public ImpactorInfoModel getImpactorInfo(String impactorName) throws SQLException {
		logger.info("Get Impactor Info Service");
		return impactorDao.getImpactorInfo(impactorName);
	}

	@Override
	@Transactional
	public StringResponse deleteImpactor(String deletedBy, String impactorName) throws Exception {

		logger.info("Delete Impactor Info Service");

		// Marking Impactor as deleted in META table
		String message = impactorDao.deleteImpactor(deletedBy, impactorName) + " number of Impactors deleted";

		// UNDO operations in adjusted table
		ImpactorInfoModel impactorInfoModel = impactorDao.getImpactorInfo(impactorName);
		String undoMessage = impactorDao.undoImpactorAfterDelete(impactorInfoModel.getAbsValue(), impactorName,
				impactorInfoModel.getCountry(), impactorInfoModel.isAbs()) + " number of Impactor records reverted";

		StringResponse sr = new StringResponse();
		sr.setResponse(message + " :: AND :: " + undoMessage);
		return sr;
	}

	@Override
	@Transactional
	public StringResponse createImpactor(String createdBy, CreateImpactorRequest r) throws SQLException {

		logger.info("Snowflake call to get baseLineData for Creating Impactor");
		String description = this.formDescription(r.country, r.year, r.planLevels, r.customers, r.categories, r.subCategories, r.brands, r.subBrands,
				r.eans);

		boolean forDaily = r.granularity.equalsIgnoreCase("daily");
		Map<Integer, List<Integer>> daysForMonth = null;
		if(forDaily) {
			daysForMonth = new HashMap<>();
			buildDaysForMonth(daysForMonth, r.days);
		}
		String metaImpactorMessage = impactorDao.createImpactorMeta(createdBy, r.impactorName, r.isAbs, r.impactorValue, r.country.toUpperCase(), description)
				+ " number of Impactors Meta Created";
		int numberOfImpactorDataRecordsCreated = impactorDao.createImpactorData(r.country.toUpperCase(), r.year, r.planLevels,
				r.customers, r.categories, r.subCategories, r.brands, r.subBrands, r.eans, r.impactorName, r.weeks, forDaily, daysForMonth);
		String impactorDataRecordsCreated = numberOfImpactorDataRecordsCreated + " number of Impactors Data Records Created";

		int impactorRecordsApplied = 0;
		if(numberOfImpactorDataRecordsCreated > 0) {
			if (r.isAbs) {
				int numberOfWeeksOrDays = forDaily ? r.days.size() : r.weeks.size();
				impactorRecordsApplied = impactorDao.applyImpactorAbs(numberOfImpactorDataRecordsCreated, numberOfWeeksOrDays, r.impactorName, r.impactorValue, r.country, forDaily);
			} else {
				impactorRecordsApplied = impactorDao.applyImpactorNotAbs(r.impactorName, r.impactorValue, r.country, forDaily);
			}
		}
		StringResponse sr = new StringResponse();
		sr.setResponse(
				metaImpactorMessage + " :: AND :: " + impactorDataRecordsCreated + " :: " + String.format( "%s number of Impactors Data Records Applied", impactorRecordsApplied));
		return sr;
	}

	private void buildDaysForMonth(Map<Integer, List<Integer>> daysForMonth, List<String> days) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		for (String day : days) {
			LocalDate d = LocalDate.parse(day, formatter);
			List<Integer> days1 = daysForMonth.get(d.getMonthValue());
			if (days1 == null) {
				days1 = new ArrayList<>();
				days1.add(d.getDayOfMonth());
				daysForMonth.put(d.getMonthValue(), days1);
			} else {
				days1.add(d.getDayOfMonth());
			}
		}
	}

	private String formDescription(String country, Integer year, List<String> planLevels, List<String> customers, List<String> categories,
			List<String> subCategories, List<String> brands, List<String> subBrands, List<String> eans) {
		
//		StringBuilder whereClause = new StringBuilder();
//		whereClause.append("WHERE COUNTRY = '" + country + "' AND ACTIVE = TRUE AND YEAR = '" + year + "'");
		
		// "planLevels=p1,p2,p3:customers=c1,c2,c3:categories-ca1,ca2,ca3:";
		StringBuilder builder = new StringBuilder();
		if (!CollectionUtils.isEmpty(planLevels)) {
			builder.append(":PlanLevels=");
			builder.append(String.join(", ", planLevels));
			
//			whereClause.append(" AND PLAN_LEVEL IN (");
//			//StringBuilder plansBuilder = new StringBuilder();
//			StringJoiner plansBuilder = new StringJoiner(",");
//			for (String planLevel : planLevels) {
//				plansBuilder.add("'" + planLevel + "'"); 
//			}
//			whereClause.append(")");
		}
		if (!CollectionUtils.isEmpty(customers)) {
			builder.append(":Customers=");
			builder.append(String.join(", ", customers));
		}
		if (!CollectionUtils.isEmpty(categories)) {
			builder.append(":Categories=");
			builder.append(String.join(", ", categories));
		}
		if (!CollectionUtils.isEmpty(subCategories)) {
			builder.append(":SubCategories=");
			builder.append(String.join(", ", subCategories));
		}
		if (!CollectionUtils.isEmpty(brands)) {
			builder.append(":Brands=");
			builder.append(String.join(", ", brands));
		}
		if (!CollectionUtils.isEmpty(subBrands)) {
			builder.append(":SubBrands=");
			builder.append(String.join(", ", subBrands));
		}
		if (!CollectionUtils.isEmpty(eans)) {
			builder.append(":Eans=");
			builder.append(String.join(", ", eans));
		}

		String str = builder.toString();
		if (str.length() > 1023)
			str = builder.substring(0, 1023).toString();
		
		return str;
	}

	@Override
	public Map<String, Float> getMinimumAdjustmentValue(String country, Integer year,
			List<String> planLevels, List<String> customers, List<String> categories, List<String> subCategories,
			List<String> brands, List<String> subBrands, List<String> eans, List<Integer> weeks) throws SQLException, Exception {
		logger.info("Snowflake call to get minimum adjustment value for Creating Impactor");
		return impactorDao.minimumAdjustmentValue(country, year, planLevels, customers, categories, subCategories, brands, subBrands, eans, weeks);
	}

}
