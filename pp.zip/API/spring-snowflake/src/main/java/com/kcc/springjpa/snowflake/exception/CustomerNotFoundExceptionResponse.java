package com.kcc.springjpa.snowflake.exception;

import lombok.Data;

import java.util.Date;

@Data
public class CustomerNotFoundExceptionResponse extends ExceptionResponse{
    String cusomerId;

    public CustomerNotFoundExceptionResponse(Date timestamp, String message, String details, String cusomerId) {
        super(timestamp, message, details);
        this.cusomerId = cusomerId;
    }
}
