package com.kcc.springjpa.snowflake.model;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component
@Getter
@Setter
public class PreRoiSimulatedROIAndNPLModel {

	public PreRoiSimulatedROIAndNPLModel() {
	}

	// PE Constructor
	public PreRoiSimulatedROIAndNPLModel(Double avgTradeAllowanceIOnInv, Double avgFinDiscount, Double avgCashDiscount,
			Double avgTradeAllowance, Double avgTotalCashSale, Double avgDistribution, Double avgSalesVolume,
			Double avgSalesValue, Double avgTradePromotionsOnInv, Double avgConsumerPromotionsRir, Double cogsPerCase,
			Double nppPerCase, Double retailerMargin, Double retailerMarginPercent, Double taPct, Double tpPct, Double historicalVolume) {
		super();
		if (avgTradeAllowanceIOnInv != null) {
			this.avgTradeAllowanceIOnInv = avgTradeAllowanceIOnInv;
		} else {
			this.avgTradeAllowanceIOnInv = 0.0;
		}

		if (avgFinDiscount != null) {
			this.avgFinDiscount = avgFinDiscount;
		} else {
			this.avgFinDiscount = 0.0;
		}

		if (avgCashDiscount != null) {
			this.avgCashDiscount = avgCashDiscount;
		} else {
			this.avgCashDiscount = 0.0;
		}

		if (avgTradeAllowance != null) {
			this.avgTradeAllowance = avgTradeAllowance;
		} else {
			this.avgTradeAllowance = 0.0;
		}

		if (avgTotalCashSale != null) {
			this.avgTotalCashSale = avgTotalCashSale;
		} else {
			this.avgTotalCashSale = 0.0;
		}

		if (avgDistribution != null) {
			this.avgDistribution = avgDistribution;
		} else {
			this.avgDistribution = 0.0;
		}

		if (avgSalesVolume != null) {
			this.avgSalesVolume = avgSalesVolume;
		} else {
			this.avgSalesVolume = 0.0;
		}

		if (avgSalesValue != null) {
			this.avgSalesValue = avgSalesValue;
		} else {
			this.avgSalesValue = 0.0;
		}

		if (avgTradePromotionsOnInv != null) {
			this.avgTradePromotionsOnInv = avgTradePromotionsOnInv;
		} else {
			this.avgTradePromotionsOnInv = 0.0;
		}

		if (avgConsumerPromotionsRir != null) {
			this.avgConsumerPromotionsRir = avgConsumerPromotionsRir;
		} else {
			this.avgConsumerPromotionsRir = 0.0;
		}

		if (cogsPerCase != null) {
			this.cogsPerCase = cogsPerCase;
		} else {
			this.cogsPerCase = 0.0;
		}

		if (nppPerCase != null) {
			this.nppPerCase = nppPerCase;
		} else {
			this.nppPerCase = 0.0;
		}
		
		if (retailerMargin != null) {
			this.retailerMargin = retailerMargin;
		} else {
			this.retailerMargin = 0.0;
		}
		
		if (retailerMarginPercent != null) {
			this.retailerMarginPercent = retailerMarginPercent;
		} else {
			this.retailerMarginPercent = 0.0;
		}
		
		if (taPct != null) {
			this.taPct = taPct;
		} else {
			this.taPct = 0.0;
		}
		
		if (tpPct != null) {
			this.tpPct = tpPct;
		} else {
			this.tpPct = 0.0;
		}
		
		if (historicalVolume != null) {
			this.historicalVolume = historicalVolume;
		} else {
			this.historicalVolume = 0.0;
		}
	}

	// UK Constructor
	public PreRoiSimulatedROIAndNPLModel(Double avgSalesVolume, Double avgDAOnInv, Double avgOnInvPromoDisc,
			Double avgNetInvValue, Double avgDAOffInv, Double avgOffInvPromoDisc, Double avgNetSalesValue,
			Double avgGrossProfit, Double costOfSalesTotal, Double grossSalesAfterDisc, Double volumeCases,
			Double cogsPerCase, Double nppPerCase, Double retailerMargin, Double retailerMarginPercent) {
		super();
		if (avgSalesVolume != null) {
			this.avgSalesVolume = avgSalesVolume;
		} else {
			this.avgSalesVolume = 0.0;
		}

		if (avgDAOnInv != null) {
			this.avgDAOnInv = avgDAOnInv;
		} else {
			this.avgDAOnInv = 0.0;
		}

		if (avgOnInvPromoDisc != null) {
			this.avgOnInvPromoDisc = avgOnInvPromoDisc;
		} else {
			this.avgOnInvPromoDisc = 0.0;
		}

		if (avgNetInvValue != null) {
			this.avgNetInvValue = avgNetInvValue;
		} else {
			this.avgNetInvValue = 0.0;
		}

		if (avgDAOffInv != null) {
			this.avgDAOffInv = avgDAOffInv;
		} else {
			this.avgDAOffInv = 0.0;
		}

		if (avgOffInvPromoDisc != null) {
			this.avgOffInvPromoDisc = avgOffInvPromoDisc;
		} else {
			this.avgOffInvPromoDisc = 0.0;
		}

		if (avgNetSalesValue != null) {
			this.avgNetSalesValue = avgNetSalesValue;
		} else {
			this.avgNetSalesValue = 0.0;
		}

		if (avgGrossProfit != null) {
			this.avgGrossProfit = avgGrossProfit;
		} else {
			this.avgGrossProfit = 0.0;
		}

		if (costOfSalesTotal != null) {
			this.costOfSalesTotal = costOfSalesTotal;
		} else {
			this.costOfSalesTotal = 0.0;
		}

		if (grossSalesAfterDisc != null) {
			this.grossSalesAfterDisc = grossSalesAfterDisc;
		} else {
			this.grossSalesAfterDisc = 0.0;
		}

		if (volumeCases != null) {
			this.volumeCases = volumeCases;
		} else {
			this.volumeCases = 0.0;
		}

		if (cogsPerCase != null) {
			this.cogsPerCase = cogsPerCase;
		} else {
			this.cogsPerCase = 0.0;
		}

		if (nppPerCase != null) {
			this.nppPerCase = nppPerCase;
		} else {
			this.nppPerCase = 0.0;
		}
		
		if (retailerMargin != null) {
			this.retailerMargin = retailerMargin;
		} else {
			this.retailerMargin = 0.0;
		}
		
		if (retailerMarginPercent != null) {
			this.retailerMarginPercent = retailerMarginPercent;
		} else {
			this.retailerMarginPercent = 0.0;
		}
	}

	// KR Constructor
	public PreRoiSimulatedROIAndNPLModel(Double avgSalesVolume, Double distributionExpense, Double nonPromotionRir,
			Double promotionRir, Double cogsPerCase, Double nppPerCase) {
		super();
		if (avgSalesVolume != null) {
			this.avgSalesVolume = avgSalesVolume;
		} else {
			this.avgSalesVolume = 0.0;
		}
		
		if (distributionExpense != null) {
			this.distributionExpense = distributionExpense;
		} else {
			this.distributionExpense = 0.0;
		}

		if (nonPromotionRir != null) {
			this.nonPromotionRir = nonPromotionRir;
		} else {
			this.nonPromotionRir = 0.0;
		}
		
		if (promotionRir != null) {
			this.promotionRir = promotionRir;
		} else {
			this.promotionRir = 0.0;
		}

		if (cogsPerCase != null) {
			this.cogsPerCase = cogsPerCase;
		} else {
			this.cogsPerCase = 0.0;
		}

		if (nppPerCase != null) {
			this.nppPerCase = nppPerCase;
		} else {
			this.nppPerCase = 0.0;
		}
	}

	// PE properties
	private Double avgTradeAllowanceIOnInv;

	private Double avgFinDiscount;

	private Double avgCashDiscount;

	private Double avgTradeAllowance;

	private Double avgTotalCashSale;

	private Double avgDistribution;

	private Double avgSalesValue;

	private Double avgTradePromotionsOnInv;

	private Double avgConsumerPromotionsRir;

	private Double avgSalesVolume;

	private Double cogsPerCase;

	private Double nppPerCase;
	
	private Double retailerMargin;
	
	private Double retailerMarginPercent;
	
	private Double taPct;
	
	private Double tpPct;
	
	private Double historicalVolume;

	// UK properties
	private Double avgDAOnInv;

	private Double avgOnInvPromoDisc;

	private Double avgNetInvValue;

	private Double avgDAOffInv;

	private Double avgOffInvPromoDisc;

	private Double avgNetSalesValue;

	private Double avgGrossProfit;

	private Double costOfSalesTotal;

	private Double grossSalesAfterDisc;

	private Double volumeCases;
	
	// KR properties
	private Double distributionExpense;
	
	private Double nonPromotionRir;
	
	private Double promotionRir;

}
