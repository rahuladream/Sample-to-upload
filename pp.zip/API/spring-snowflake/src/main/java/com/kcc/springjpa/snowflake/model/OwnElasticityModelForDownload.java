package com.kcc.springjpa.snowflake.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Component
@Getter
@Setter
public class OwnElasticityModelForDownload {
	
	private float priceIndex;
	
	private String range;
	
	private float rsquared;
	
	private float averagePrice;
	
	private float promoPrice;
	
	private float basePrice;
	
	private boolean isViewMore;

	private int nWeeks;

	private String periodBegin;

	private String periodEnd;

	private String modelRun;

	private String category;

	private String subCategoryInitial;
	private String subCategoryTarget;

	private String brandInitial;
	private String brandTarget;

	private String subBrandInitial;
	private String subBrandTarget;

	private String manufacturerInitial;
	private String manufacturerTarget;

	private String tierInitial;
	private String tierTarget;

	private String packInitial;
	private String packTarget;


	private String eanInitial;
	private String eanTarget;

	private String eanDescriptionInitial;
	private String eanDescriptionTarget;

	private float slope;

	private float intercept;

	private String customer;
	private float averageQuantity;
	private String pValue;
	private double elasticity;

}
