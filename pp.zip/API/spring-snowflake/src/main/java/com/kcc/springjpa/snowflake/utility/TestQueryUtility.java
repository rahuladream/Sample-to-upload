package com.kcc.springjpa.snowflake.utility;

import com.kcc.springjpa.snowflake.model.TestData;

public class TestQueryUtility {
    public static TestData getPromoTypes() {
        TestData _data =  new TestData(
                "Promo types",
                "select top 10  country, promo_type  from RGM_ADV_ANLTCS.REPORTING.V_RGM_MD_DIM_PROMO_TYPE GROUP BY  country, promo_type"
        );
        return _data;
    }

    public static TestData getVarietiesOfOwnEanType() {
        TestData _data =  new TestData(
                "Varieties of own_ean type field, should be WC, Customer, Channel",
                "select distinct type FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN "
        );
        return _data;
    }

    public static TestData getVarietiesOfOwnEanFlag() {
        TestData _data =  new TestData(
                "Varieties of own_ean flag field, should only be CROSS and OWN",
                "select distinct flag FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN "
        );
        return _data;
    }

    public static TestData getVarietiesOfOwnEanCountry() {
        TestData _data =  new TestData(
                "Varieties of own_ean country field, should only be CROSS and OWN",
                "select distinct country FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN ORDER BY country "
        );
        return _data;
    }

    public static TestData getDataSourcesInPostROI() {
        TestData _data =  new TestData(
                "Data sources in Post ROI",
                "select distinct country, data_source FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_POST_ROI GROUP BY country, data_source"
        );
        return _data;
    }

    public static TestData getCurrentActiveBaselineModelRuns() {
        TestData _data =  new TestData(
                "Current active baseline model_runs",
                "SELECT MODEL_RUN,COUNTRY FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_BASELINE WHERE active=true GROUP BY COUNTRY, MODEL_RUN"
        );
        return _data;
    }

    public static TestData assertNoNegativeAdjustedBaselineValues() {
        TestData _data =  new TestData(
                "There should be no negative adjusted baseline values",
                "SELECT  country, BASELINE_ADJUSTED_QUANTITY FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_BASELINE WHERE BASELINE_ADJUSTED_QUANTITY < 0.0 LIMIT 10"
        );
        return _data;
    }

    public static TestData getCountOfOwnElasticityAtEanLevelForAllMarketScope() {
        TestData _data =  new TestData(
                "Count of Own elasticity at EAN level for Market Scope All",
                "SELECT COUNT(1) FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN WHERE country='KR' AND type='WC' AND FLAG='OWN';"
        );
        return _data;
    }

    public static TestData getCountOfOwnElasticityAtEanLevelForCustomerMarketScope() {
        TestData _data =  new TestData(
                "Count of Own elasticity at EAN level for Market Scope Customer",
                "SELECT COUNT(1) FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN WHERE country='KR' AND (type ILIKE 'Customer') AND FLAG='OWN'"
        );
        return _data;
    }

    public static TestData getCountOfOwnElasticityAtEanLevelForChannelMarketScope() {
        TestData _data =  new TestData(
                "Count of Own elasticity at EAN level for Market Scope Channel",
                "SELECT COUNT(1) FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN WHERE country='KR' AND (type='Channel' OR type='CHANNEL') AND FLAG='OWN'"
        );
        return _data;
    }

    public static TestData getCountOfCrossElasticityAtEanLevelForAllMarketScope() {
        TestData _data =  new TestData(
                "Count of Cross elasticity at EAN level for Market Scope All",
                "SELECT COUNT(1) FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN WHERE country='KR' AND type='WC' AND FLAG='CROSS';"
        );
        return _data;
    }

    public static TestData getCountOfCrossElasticityAtEanLevelForCustomerMarketScope() {
        TestData _data =  new TestData(
                "Count of Cross elasticity at EAN level for Market Scope Customer",
                "SELECT COUNT(1) FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN WHERE country='KR' AND (type='Customer' OR type='CUSTOMER') AND FLAG='CROSS'"
        );
        return _data;
    }

    public static TestData getCountOfCrossElasticityAtEanLevelForChannelMarketScope() {
        TestData _data =  new TestData(
                "Count of Cross elasticity at EAN level for Market Scope Channel",
                "SELECT COUNT(1) FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN WHERE country='KR' AND (type='Channel' OR type='CHANNEL') AND FLAG='CROSS'"
        );
        return _data;
    }

    public static TestData getCategoryLevelElasticityByCountryAndMarketScope() {
        TestData _data =  new TestData(
                "Category level elasticity by country and Market Scope",
                "SELECT top 10 country, type, flag, count(1) FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_SUB_CATEGORY GROUP BY country,type,flag ORDER BY country,type,flag;"
        );
        return _data;
    }

    public static TestData getBrandLevelElasticityByCountryAndMarketScope() {
        TestData _data =  new TestData(
                "Brand level elasticity by country and Market Scope",
                "SELECT top 10 country, type, flag, count(1) FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_BRAND GROUP BY country,type,flag ORDER BY country,type,flag;"
        );
        return _data;
    }

    public static TestData getSubBrandLevelElasticityByCountryAndMarketScope() {
        TestData _data =  new TestData(
                "SubBrand level elasticity by country and Market Scope",
                "SELECT top 10 country, type, flag, count(1) FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_SUB_BRAND GROUP BY country,type,flag ORDER BY country,type,flag;"
        );
        return _data;
    }

    public static TestData getPackLevelElasticityByCountryAndMarketScope() {
        TestData _data =  new TestData(
                "Pack level elasticity by country and Market Scope",
                "SELECT top 10 country, type, flag, count(1) FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_PACK GROUP BY country,type,flag ORDER BY country,type,flag;"
        );
        return _data;
    }

    public static TestData getEanLevelElasticityByCountryAndMarketScope() {
        TestData _data =  new TestData(
                "EAN level elasticity by country and Market Scope",
                "SELECT top 10 country, type, flag, count(1) FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_CROSS_OWN_EAN GROUP BY country,type,flag ORDER BY country,type,flag;"
        );
        return _data;
    }

    public static TestData getSelloutBaselineRecordsByCountry() {
        TestData _data =  new TestData(
                "Sell Out baseline records by country",
                "SELECT country, COUNT(1) FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_BASELINE WHERE SELL_IN_OUT='out' GROUP BY country;"
        );
        return _data;
    }

    public static TestData getSellInBaselineRecordsByCountry() {
        TestData _data =  new TestData(
                "Sell In baseline records by country",
                "SELECT country, COUNT(1) FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_BASELINE WHERE SELL_IN_OUT='in' GROUP BY country;"
        );
        return _data;
    }

    public static TestData getHistoryOfModelRunsInBaseline() {
        TestData _data =  new TestData(
                "History of model runs in baseline",
                "SELECT distinct country, model_run, active, COUNT(1) FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_BASELINE GROUP BY country, model_run, active"
        );
        return _data;
    }

    public static TestData assertNoCountryHaveMoreThanOneModelRunActive() {
        TestData _data =  new TestData(
                "Assert no country should have more than one model_run active (good if no results)",
                "SELECT  top 10 country, count(1) FROM(SELECT distinct model_run, country FROM RGM_ADV_ANLTCS.REPORTING.V_RGM_SLS_FCT_DATA_BASELINE WHERE active GROUP BY model_run, country) GROUP BY country HAVING count(1)>1"
        );
        return _data;
    }

    public static TestData assertThereShouldBeNoDuplicateBaselineRecords() {
        TestData _data =  new TestData(
                "Assert there should be no duplicate baseline records",
                "SELECT top 10 country, sold_to, ean, year, month, week, day, count(*) FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_BASELINE WHERE active GROUP BY country, sold_to, ean, year, month, week, day HAVING count(*)>1"
        );
        return _data;
    }

    public static TestData assertThereShouldBeNoDuplicateAdjustedBaselineRecords() {
        TestData _data =  new TestData(
                "Assert there should be no duplicate adjusted baseline records",
                "SELECT top 10 country, sold_to, ean, year, month, week, day, count(*) FROM RGM_ADV_ANLTCS.INT.RGM_SLS_FCT_DATA_ADJUSTED_BASELINE GROUP BY country, sold_to, ean, year, month, week, day HAVING count(*)>1"
        );
        return _data;
    }
}
