package com.kcc.springjpa.snowflake.service;

import java.net.MalformedURLException;
import java.util.concurrent.ExecutionException;

import javax.naming.ServiceUnavailableException;

import com.kcc.springjpa.snowflake.model.EmbedConfig;
import com.kcc.springjpa.snowflake.model.EmbedInfo;
import com.kcc.springjpa.snowflake.model.EmbedToken;

public interface PowerBIService {

	public String getAccessTokenUsingServicePrincipal() throws MalformedURLException, InterruptedException, ExecutionException;

	public EmbedToken getMultiResourceEmbedToken(String reportId, String datasetId, String accessToken);

	public EmbedConfig getReportEmbedDetails(String reportId, String groupId, String accessToken);

	public EmbedInfo getPowerBIEmbedDetails(String reportId) throws MalformedURLException,
			ServiceUnavailableException, InterruptedException, ExecutionException;

}
