package com.kcc.springjpa.snowflake.entity;

import java.io.Serializable;
import java.util.Objects;

public class OwnCrossKey implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public int hashCode() {
		return Objects.hash(eanDescriptionInitial, eanDescriptionTarget, eanInitial, eanTarget, type, typeDescription);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OwnCrossKey other = (OwnCrossKey) obj;
		return Objects.equals(eanDescriptionInitial, other.eanDescriptionInitial)
				&& Objects.equals(eanDescriptionTarget, other.eanDescriptionTarget)
				&& Objects.equals(eanInitial, other.eanInitial) && Objects.equals(eanTarget, other.eanTarget)
				&& Objects.equals(type, other.type) && Objects.equals(typeDescription, other.typeDescription);
	}

	private String eanInitial;
	
	private String eanTarget;
	
	private String eanDescriptionInitial;
	
	private String eanDescriptionTarget;
	
	private String type;
	
	private String typeDescription;

}
