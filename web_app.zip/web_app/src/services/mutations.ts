import { useMutation } from 'react-query';
import { ApiRequestService } from './api-service';
import { AppQueryClient } from './clients/query-client';
import {  IROIPost , ISimulationPost} from '../models/common/post';



export const useDeleteImpactor = () => {
  const apiRequestService = ApiRequestService.createInstance();

  const mutation = useMutation((data:string) => apiRequestService.getImpactorDelete(data), {
    onSuccess: () => {
      // Query Invalidations
      AppQueryClient.invalidateQueries('useGetImpactorHistory');
    },
  });
  return mutation;
};


export const useCreateNewImpactorHistory = () => {
  const apiRequestService = ApiRequestService.createInstance();

  const mutation = useMutation((data:object) => apiRequestService.createImpactorHistory(data), {
    onSuccess: () => {
      // Query Invalidations
      AppQueryClient.invalidateQueries('useGetImpactorHistory');
    },
  });
  return mutation;
};

export const useGetBaseLineValue = () => {
  const apiRequestService = ApiRequestService.createInstance();

  const mutation = useMutation((data:string) => apiRequestService.getBaseLineValue(data), {
    onSuccess: () => {
      // Query Invalidations
      AppQueryClient.invalidateQueries('useGetBaseLineValue');
    },
  });
  return mutation;
};


export const useGetSimulatedValues = () => {
  const apiRequestService = ApiRequestService.createInstance();

  const mutation = useMutation((data:string) => apiRequestService.getSimulatedValues(data), {
    onSuccess: () => {
      // Query Invalidations
      AppQueryClient.invalidateQueries('useGetSimulatedValues');
    },
  });
  return mutation;
};


export const useGetSimulatedPAndLValues = () => {
  const apiRequestService = ApiRequestService.createInstance();

  const mutation = useMutation((data:string) => apiRequestService.getSimulatedPAndL(data), {
    onSuccess: () => {
      // Query Invalidations
      AppQueryClient.invalidateQueries('useGetSimulatedPAndLValues');
    },
  });
  return mutation;
};

export const useGetPromoInvMagicValues = () => {
  const apiRequestService = ApiRequestService.createInstance();

  const mutation = useMutation((data:string) => apiRequestService.getPromoInvMagic(data), {
    onSuccess: () => {
      // Query Invalidations
      AppQueryClient.invalidateQueries('useGetPromoInvMagicValues');
    },
  });
  return mutation;
};


export const useGetCalculatedIncVolume = () => {
  const apiRequestService = ApiRequestService.createInstance();

  const mutation = useMutation((data:string) => apiRequestService.getCalculatedIncVolume(data), {
    onSuccess: () => {
      // Query Invalidations
      AppQueryClient.invalidateQueries('UseGetCalculatedIncVolume');
    },
  });
  return mutation;
};


export const usePostSimulatedData = () => {
  const apiRequestService = ApiRequestService.createInstance();

  const mutation = useMutation((data:IROIPost) => apiRequestService.simulatedSaveURL(data), {
    onSuccess: () => {
      // Query Invalidations
      AppQueryClient.invalidateQueries('PostSimulatedData');
    },
  });
  return mutation;
};


export const useSimulationsForTallyURL = () => {
  const apiRequestService = ApiRequestService.createInstance();

  const mutation = useMutation((data:ISimulationPost) => apiRequestService.simulationsForTallyURL(data), {
    onSuccess: () => {
      // Query Invalidations
      AppQueryClient.invalidateQueries('useSimulationsForTallyURL');
    },
  });
  return mutation;
};