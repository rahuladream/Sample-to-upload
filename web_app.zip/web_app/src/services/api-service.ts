import axios, { AxiosRequestConfig } from 'axios';
import { IAddPost, IROIPost, ISimulationPost, PriceElasticityDownloadData } from '../models/common/post';

import { apiClient } from './clients/api-client';
/*
const header = {
  headers: {
    'Access-Control-Allow-Origin': '*',
    'Cache-Control': 'max-age=0, no-cache, private',
  }
}
*/

export class ApiRequestService {
  config?: AxiosRequestConfig = {};

  private cancellationToken = axios.CancelToken.source();

  static createInstance(): ApiRequestService {
    const activeInstance = new ApiRequestService();
    activeInstance.cancellationToken = axios.CancelToken.source();
    if (activeInstance.config) {
      activeInstance.config.cancelToken = activeInstance.cancellationToken.token;
    }
    return activeInstance;
  }

  cancelRequests() {
    this.cancellationToken.cancel('RequestCancellation');
    return ApiRequestService.createInstance();
  }

  countriesList = () => apiClient.get(`/getCountriesList`);
  customerHierarchy = (data:string) => apiClient.get(`/customerHierarchy?country=${data}`);
  productHierarchy = (data:string) => apiClient.get(`/productHierarchy?country=${data}`);
  baseLineData  =(data:string) => apiClient.get(`/baseLineData?country=${data}`);
  getEventIds  =(data:string) => apiClient.get(`/getEventIds?country=${data}`);

  postRoi  =(data:string) => apiClient.get(`/postRoi?country=${data}`);
  postRoiQuadrant  =(data:string) => apiClient.get(`/postRoiQuadrant?country=${data}`);
  roiQuadrant  = (data:string) => apiClient.get(`/getTpQuadrant?country=${data}`);
  roiFileDownload  = (data:string) => apiClient.get(`/downloadRoiFile?country=${data}`,{ responseType: 'blob' });

  // CORRELATION API
  kcproductHierarchy = (data:string, hierarchyLevel?: string) => apiClient.get(`kcproductHierarchy?country=${data}${hierarchyLevel ? `&hierarchyLevel=${hierarchyLevel.toUpperCase()}` : ''}`);
  targetProductHierarchy = (data: string) => apiClient.get(`targetProductHierarchy?${data}`);

  correlationAnalysis = (data: any) => apiClient.post(`correlationAnalysis`, data);

  ownProductHierarchy = (data:string) => apiClient.get(`ownProductHierarchy?country=${data}`);
  ownAnalysis = (data: object) => apiClient.post(`ownElasticity`, data);
  ownScopeSelector = (data : object) => apiClient.post(`ownElasticityPerScope`, data);
  ownAvailableSource = (data: string) => apiClient.get(`availableSources?${data}`);
  getSimulationsData = (data: string) => apiClient.get(`simulations?${data}`);

  crossElasticityAnalysis = (data1:string) => apiClient.get(`crossElasticityAnalysis?${data1}`);
  crossScopeSelector = (data: string) => apiClient.get(`crossElasticityAnalysisPerScope?${data}`);

  biToken = (reportId: string) => apiClient.get(`/powerBiToken?reportId=${reportId}`);

  addPost = (data: IAddPost) => apiClient.post('/posts', data);

  getImpactorNamesList = () => apiClient.get(`/getImpactorNames`);
  getDeleteImpactorHistory = (data:string) => apiClient.get(`/getDeletedImpactorHistory?country=${data}`);
  getImpactorHistory = (data:string) => apiClient.get(`/getImpactorHistory?country=${data}`);
  createImpactorHistory = (data:object) => apiClient.post(`/admin/createImpactor`,data);

  getImpactorInfo = (data:string) => apiClient.get(`/getImpactorInfo?impactorName=${data}`);
  getImpactorDelete = (data:string) => apiClient.delete(`/admin/deleteImpactor?${data}`);

  // validateAccessToken = (token:string) => apiClient.post('/validateAccessToken',{accessToken: token});
  validateAccessToken = (token:string) => apiClient.post(`/validateAccessToken?accessToken=${token}`);

  validateIdToken = (token:string) => apiClient.post('/validateIdToken',{idToken: token});

  autenticateWithAPI = (data: object)=> apiClient.post('/generateApiToken',data);

  testAPI = ()=> apiClient.get('/api-docs/testrun');

  ///PrePOI
  getBaseLineValue = (data:string) => apiClient.get(`/getBaseLineValue?country=${data}`);
  getPrePOIPromoTypes = (data:string) => apiClient.get(`/preRoiPromoTypes?country=${data}`); 
  getSimulatedValues = (data:string) => apiClient.get(`/getSimulatedValues?country=${data}`);
  hasSellInSelloutData = (data:string) => apiClient.get(`/hasSellInSelloutData?country=${data}`);
  getSimulatedPAndL = (data:string) => apiClient.get(`/getSimulatedPAndL?country=${data}`);
  simulatedSaveURL = (data:IROIPost) => apiClient.post(`/admin/savePromoSim?country=${data.country}`, data);
  getPromoInvMagic = (data:string) => apiClient.get(`/getPromoInvMagicWand?country=${data}`);
  simulationsForTallyURL = (data:ISimulationPost) => apiClient.post(`/simulationsForTally`, data);
  
  getCalculatedIncVolume = (data:string) => apiClient.get(`/getCalculatedIncrementalVolume?country=${data}`);

  //Baseline daily datacheck
  dailyAvailable = (data:string) => apiClient.get(`/dailyAvailable?country=${data}`);

  //Price elasticity scope datacheck
  marketScopeToggles = (data:string) => apiClient.get(`/marketScopeToggles?${data}`);

  elasticityFileDownload  = (data: PriceElasticityDownloadData) => apiClient.post('/downloadElasticity', data, { responseType: 'blob' });

  getLastModelRunDate = (country:string) => apiClient.get(`/lastModelRunDate?country=${country}`);

  deletePromoSimulation = (country:string, names:string[]) => apiClient.post('/deleteSimulations', {country: country, names})

  testDataAPI = ()=> apiClient.get('/api-docs/data-test');

  //To fetch Price elasticity sub category values
  getSubCategories = (data:string) => apiClient.get(`/getSubCategories?${data}`);
  
  //To fetch Price elasticity Source and Scope values
  getCountryMasterData = (data:string) => apiClient.get(`/countryMaster?${data}`);

  //To fetch Regression Values
  getRegressionValues = (data:object) => apiClient.post(`/dataPointsForRegression`,data);

  //To fetch week Values
  getLineFittingWeeks = (data:object) => apiClient.get(`/dataPointsForLineFitting?${data}`);
  
}