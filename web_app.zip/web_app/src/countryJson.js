export const countryValuesList = [
    {
        "statisticalBaseLine": {
          "totalQuantity": 210611122,
          "averageQuantity": 17550926,
          "januaryMonth": {
            "W1": 127101976,
            "W2": 266048719,
            "W3": 265581434,
            "W4": 265110696,
            "W5": 138468367
          },
          "februaryMonth": {
            "W7": 263714526,
            "W8": 263248669,
            "W9": 137535604,
            "W5": 126175168,
            "W6": 264179102
          },
          "marchMonth": {
            "W9": 125248375,
            "W11": 261856548,
            "W10": 262320394,
            "W13": 260928256,
            "W12": 261392242,
            "W14": 136374772
          },
          "aprilMonth": {
            "W15": 260000946,
            "W14": 124089931,
            "W17": 259073225,
            "W16": 259537039,
            "W18": 135446439
          },
          "mayMonth": {
            "W20": 257038945,
            "W22": 255535137,
            "W21": 256352814,
            "W19": 257593448,
            "W18": 122616648
          },
          "juneMonth": {
            "W24": 134054667,
            "W23": 254116953,
            "W26": 133590956,
            "W25": 133822779,
            "W27": 133359097
          },
          "julyMonth": {
            "W31": 285914703,
            "W30": 132663725,
            "W28": 133127298,
            "W29": 132895492
          },
          "augustMonth": {
            "W33": 282147993,
            "W32": 279816082,
            "W35": 279689425,
            "W34": 284587440,
            "W36": 131273213
          },
          "septemberMonth": {
            "W40": 273547381,
            "W37": 275808029,
            "W36": 145436484,
            "W39": 274675083,
            "W38": 275823850
          },
          "octoberMonth": {
            "W42": 272479784,
            "W41": 272899995,
            "W44": 271202897,
            "W43": 271852997
          },
          "novemberMonth": {
            "W46": 270176519,
            "W45": 270659859,
            "W48": 269144872,
            "W47": 269670490,
            "W49": 128260585
          },
          "decemberMonth": {
            "W51": 267705404,
            "W50": 268181159,
            "W53": 127333694,
            "W52": 267220172,
            "W1": 139413060,
            "W49": 140391453
          }
        },
        "adjustedBaseLine": {
          "totalQuantity": 210611122,
          "averageQuantity": 17550926,
          "januaryMonth": {
            "W1": 127101976,
            "W2": 266048719,
            "W3": 265581434,
            "W4": 265110696,
            "W5": 138468367
          },
          "februaryMonth": {
            "W7": 263714526,
            "W8": 263248669,
            "W9": 137535604,
            "W5": 126175168,
            "W6": 264179102
          },
          "marchMonth": {
            "W9": 125248375,
            "W11": 261856548,
            "W10": 262320394,
            "W13": 260928256,
            "W12": 261392242,
            "W14": 136374772
          },
          "aprilMonth": {
            "W15": 260000946,
            "W14": 124089931,
            "W17": 259073225,
            "W16": 259537039,
            "W18": 135446439
          },
          "mayMonth": {
            "W20": 257038945,
            "W22": 255535137,
            "W21": 256352814,
            "W19": 257593448,
            "W18": 122616648
          },
          "juneMonth": {
            "W24": 134054667,
            "W23": 254116953,
            "W26": 133590956,
            "W25": 133822779,
            "W27": 133359097
          },
          "julyMonth": {
            "W31": 285914703,
            "W30": 132663725,
            "W28": 133127298,
            "W29": 132895492
          },
          "augustMonth": {
            "W33": 282147993,
            "W32": 279816082,
            "W35": 279689425,
            "W34": 284587440,
            "W36": 131273213
          },
          "septemberMonth": {
            "W40": 273547381,
            "W37": 275808029,
            "W36": 145436484,
            "W39": 274675083,
            "W38": 275823850
          },
          "octoberMonth": {
            "W42": 272479784,
            "W41": 272899995,
            "W44": 271202897,
            "W43": 271852997
          },
          "novemberMonth": {
            "W46": 270176519,
            "W45": 270659859,
            "W48": 269144872,
            "W47": 269670490,
            "W49": 128260585
          },
          "decemberMonth": {
            "W51": 267705404,
            "W50": 268181159,
            "W53": 127333694,
            "W52": 267220172,
            "W1": 139413060,
            "W49": 140391453
          }
        },
        "upperBand": {
          "totalQuantity": null,
          "averageQuantity": null,
          "januaryMonth": null,
          "februaryMonth": null,
          "marchMonth": null,
          "aprilMonth": null,
          "mayMonth": null,
          "juneMonth": null,
          "julyMonth": null,
          "augustMonth": null,
          "septemberMonth": null,
          "octoberMonth": null,
          "novemberMonth": null,
          "decemberMonth": null
        },
        "lowerBand": {
          "totalQuantity": null,
          "averageQuantity": null,
          "januaryMonth": null,
          "februaryMonth": null,
          "marchMonth": null,
          "aprilMonth": null,
          "mayMonth": null,
          "juneMonth": null,
          "julyMonth": null,
          "augustMonth": null,
          "septemberMonth": null,
          "octoberMonth": null,
          "novemberMonth": null,
          "decemberMonth": null
        }
      }
   
  ];
  