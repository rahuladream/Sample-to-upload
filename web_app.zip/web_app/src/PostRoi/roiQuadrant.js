import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import useStore from "../store";
import { useRoiQuadrant } from "../services/queries";
import { currencySymbol } from "../helper";
import { updateUrl } from "../UpdateUrl";

const useStyles = makeStyles((theme) => ({
  disFlex: {
    display: "flex",
    minHeight: "138px",
  },

  manContainer: {
    padding: 15,
  },

  quradent: {
    flex: 1,
    textAlign: "center",
    border: "1px solid #000",
    position: "relative",
    fontSize: "18px",
    fontWeight: 600,
  },
  btmtxt: {
    position: "absolute",
    textAlign: "center",
    bottom: 0,
    width: "100%",
  },

  lightGreen: {
    background: "#ceeece",
  },
  lightgray: {
    background: "#d3ddd3",
  },
  lightred: {
    background: "#e8a3a3",
  },
  lightsgreen: {
    background: "#f3f4f3",
  },
}));

export default function PostRoi(props) {
  const classes = useStyles();

  //store value
  let selectedContry = useStore((state) => state.selectedCountry);
  let selectedBaseLineFilters = useStore(
    (state) => state.selectedBaseLineFilters
  );
  let selectedBaseLineCustomerNew = useStore(
    (state) => state.selectedBaseLineCustomerNew
  );
  let selectedBaseLineProductNew = useStore(
    (state) => state.selectedBaseLineProductNew
  );
  let groupBy = useStore((state) => state.groupBy);
  const startMonth = useStore((state) => state.startMonth);
  const endMonth = useStore((state) => state.endMonth);
  let selectedEventIdNew = useStore((state) => state.selectedEventIdNew);

  const [data, setData] = useState("");
  let updatedBaseLineFilter = updateUrl(selectedBaseLineFilters);
  let selectedSource = useStore(
    (state) => state.selectedSource
  );
  let sourceUrl = "";
  for (var source of selectedSource) {
      sourceUrl += `&source=${source}`
  }

  //calling api
  const { isLoading: isRoiData, data: RoiData, isError: roiDataError} = useRoiQuadrant(
    `${selectedContry}${updatedBaseLineFilter}&fromDate=${startMonth}&toDate=${endMonth}&groupBy=${groupBy}&eventIds=${selectedEventIdNew}${sourceUrl}&kpiType=${props.kpiType}`
  );

  useEffect(() => {
    if (!isRoiData) {
      setData(RoiData);
    }
  }, [isRoiData, groupBy, selectedBaseLineFilters]);

  let Quadrant1 =
    "Quadrant 1 - Promo Investments with ROI > 0 and Lift Volume > 0";
  let Quadrant2 =
    "Quadrant 2 - Promo Investments with ROI <= 0 and Lift Volume > 0";
  let Quadrant3 =
    "Quadrant 3 - Promo Investments with ROI <=0  and Lift Volume <= 0";
  let Quadrant4 =
    "Quadrant 4 - Promo Investments with ROI > 0 and Lift Volume <= 0";

  return (
    <div className={classes.manContainer1}>
      {roiDataError && alert("Some thing went wrong, please reload page")}
      {data && selectedContry && (
        <>
          <div className={classes.disFlex}>
            <div
              className={`${classes.quradent}  ${classes.lightgray}`}
              title={Quadrant2}
            >
              <p>
                {data.q2PromoPercent.toLocaleString("en-US", {
                  maximumFractionDigits: 0,
                  minimumFractionDigits: 0,
                })}
              </p>
              <p className={classes.btmtxt}>
                {currencySymbol(selectedContry)}
                {data.q2PromoInvestment.toLocaleString("en-US", {
                  maximumFractionDigits: 0,
                  minimumFractionDigits: 0,
                })}
              </p>
            </div>
            <div
              className={`${classes.quradent}  ${classes.lightGreen}`}
              title={Quadrant1}
            >
              <p>
                {data.q1PromoPercent.toLocaleString("en-US", {
                  maximumFractionDigits: 0,
                  minimumFractionDigits: 0,
                })}
              </p>
              <p className={classes.btmtxt}>
                {currencySymbol(selectedContry)}
                {data.q1PromoInvestment.toLocaleString("en-US", {
                  maximumFractionDigits: 0,
                  minimumFractionDigits: 0,
                })}
              </p>
            </div>
          </div>

          <div className={classes.disFlex}>
            <div
              className={`${classes.quradent}  ${classes.lightred}`}
              title={Quadrant3}
            >
              <p>
                {data.q3PromoPercent.toLocaleString("en-US", {
                  maximumFractionDigits: 0,
                  minimumFractionDigits: 0,
                })}
              </p>
              <p className={classes.btmtxt}>
                {currencySymbol(selectedContry)}
                {data.q3PromoInvestment.toLocaleString("en-US", {
                  maximumFractionDigits: 0,
                  minimumFractionDigits: 0,
                })}
              </p>
            </div>
            <div
              className={`${classes.quradent}  ${classes.lightsgreen}`}
              title={Quadrant4}
            >
              <p>
                {data.q4PromoPercent.toLocaleString("en-US", {
                  maximumFractionDigits: 0,
                  minimumFractionDigits: 0,
                })}
              </p>
              <p className={classes.btmtxt}>
                {" "}
                {currencySymbol(selectedContry)}
                {data.q4PromoInvestment.toLocaleString("en-US", {
                  maximumFractionDigits: 0,
                  minimumFractionDigits: 0,
                })}
              </p>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
