import React, { useEffect, useState } from 'react';
import { useEventIDData } from '../services/queries';
import { makeStyles } from '@material-ui/core/styles';
import CustomSearch from '../CustomSearch';
import { updateUrl } from "../UpdateUrl";

import useStore from '../store';

const useStyles = makeStyles((theme) => ({
  button: {
    display: 'block',
    marginTop: theme.spacing(2),
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
}));

export default function EventIdList() {
  const classes = useStyles();
  const [selectedID, setSelectedID] = React.useState(0);
  const [open, setOpen] = React.useState(false);

  //store
  const setSelectedCountry = useStore((state) => state.setSelectedCountry);



  const selectedCountry = useStore((state) => state.selectedCountry);

  const startMonth = useStore((state) => state.startMonth);
  const endMonth = useStore((state) => state.endMonth);

  let selectedBaseLineFilters = useStore((state) => state.selectedBaseLineFilters);    
  let selectedSource = useStore((state) => state.selectedSource);
  let sourceUrl = "";
  for (var source of selectedSource) {
      sourceUrl += `&source=${source}`
  }
  let updatedBaseLineFilter = updateUrl(selectedBaseLineFilters);
  const setSelectedEventId = useStore((state) => state.setSelectedEventId);
  const setSelectedEventIdNew = useStore((state) => state.setSelectedEventIdNew);

  const { isLoading: isEventIDData, data: eventIDData, isError: eventIdDataError } = useEventIDData(`${selectedCountry}${updatedBaseLineFilter.trim()}&fromDate=${startMonth}&toDate=${endMonth}${sourceUrl}`);
  const [eventIDService, seteventIDService] = useState([]);

  const [apidata, setApidata] = useState([]);

  useEffect(() => {
    if (!isEventIDData) {
      seteventIDService(eventIDData);
    }
    setApidata(generateEventId(eventIDData));
  }, [isEventIDData]);


  useEffect(() => {
    setSelectedID('');
    setSelectedEventId('');
    setSelectedEventIdNew('');
  }, []) 



  let getKeyByValue = (object, value) => {
    return Object.keys(object).find((key) => object[key] === value);
  };

  const handleChange = (event) => {
    setSelectedID(event.target.value)
   setSelectedEventId(event.target.value)
   setSelectedEventIdNew(event.target.value);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleOpen = () => {
    setOpen(true);
  };



  const generateEventId = (eventData) => {

    const events = eventData;  

    let eventsLevel = [];
    for (const key in events) {
      let cuslis = [];
      //for (const item of events[key]) {
        let itemList = {
          label: events[key],
          value:  events[key],
        };

        eventsLevel.push(itemList);
    //  }

      /* eventsLevel.push({
        label: key,
        value: key,
        children: cuslis,
      }) */

    }



    return eventsLevel;

  };




  return (
   
      <>

      {/*   <Select
          labelId="demo-controlled-open-select-label"
          id="demo-controlled-open-select"
          open={open}
          onClose={handleClose}
          onOpen={handleOpen}
          value={selectedID}
          onChange={handleChange}
        >
          <MenuItem value={0} disabled>
            <em>Select Event</em>
          </MenuItem>

          {!isEventIDData &&
            eventIDService &&
            eventIDService.map((item) => (
              <MenuItem value={item}>{item}</MenuItem>
            ))}
        </Select> */}

       {eventIdDataError && alert("Some thing went wrong, please reload page")}
        <CustomSearch data={apidata} dataFor='EventId' />


     </>
   
  );
}