import React, { useEffect, useState } from "react";

import { ApiRequestService } from './services/api-service';
import { useCustomerHierarchy, useProductHierarchy, useRoiFileDownload,useSellInSellOutCheck} from "./services/queries";
import { useEventIDData } from './services/queries';
import { makeStyles } from "@material-ui/core/styles";
import { productDataJson } from "./ProductJson";
import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import CustomSearch from "./CustomSearch";
import useStore from "./store";
import PostRoiGrid from "./PostRoi/PostRoiGrid";
import RoiDetails from "./PostRoi/roiDetails";
import RoiQuadrant from "./PostRoi/roiQuadrant";
import PromoReport from "./PostRoi/promoReport";
import GroupSelect from "./PostRoi/groupSelect";
import QuadrantSelector from "./PostRoi/QuadrantSelector";

import "react-date-range/dist/styles.css"; // main style file
import "react-date-range/dist/theme/default.css"; // theme css file
import { updateUrl } from "./UpdateUrl";

import NewCal from "./calender";
import { FormControl, FormControlLabel, Radio, RadioGroup } from '@material-ui/core';
import Dialog from "@material-ui/core/Dialog";
import DialogTitle from "@material-ui/core/DialogTitle";

const useStyles = makeStyles((theme) => ({
  root: {
    margin: theme.spacing(3),
    width: 345,
  },
  appBar: {
    backgroundColor: theme.palette.primary.light,
  },
  media: {
    height: 140,
  },
  title: {
    color: theme.palette.primary.main,
  },
  container: {
    backgroundColor: theme.palette.background.paper,
    height: "100vh",
  },
  paperDiv: {
    display: "flex",
    flexWrap: "wrap",
    "& > *": {
      margin: theme.spacing(2),
      width: "100%",
      height: theme.spacing(12),
    },
  },

  chartDiv: {
    display: "flex",
    flexWrap: "wrap",
    "& > *": {
      margin: theme.spacing(2),
      width: "100%",
      height: theme.spacing(100),
    },
  },

  defaultTxt: {
    padding: "20px",
    margin: "15px auto",
    fontSize: "1.3rem",
    textAlign: "center",
  },

  dateLinks: {
    cursor: "pointer",

    fontWeight: 700,
    marginLeft: "30px",
  },
  dateLinksSpan: {
    marginRight: "40px",
    paddingBottom: "5px",
    color: "#0000b3",
  },
  dateLinksSpanActive: {
    borderBottom: "2px solid",
  },
  datedefaultText: {
    marginRight: "40px",
  },
  dataDiv: {
    // border: '1px solid',
    padding: theme.spacing(1),
    width: 390,
    backgroundColor: theme.palette.background.light,
  },
  paper: {
    backgroundColor: theme.palette.primary.light,
    height: "35rem",
  },
  note: {
    alignSelf: "centre",
  },
  clearAll: {
    color: "#0000b3",
    opacity: 0.8,
    fontWeight: 400,
    cursor: "pointer",
    marginLeft: "15px",
  },
  btnSucess: {
    background: '#163c62',
    color: '#fff',
    textTransform: 'none',
    margin: '0 10px',
    padding: '6px 35px',
    borderRadius: '10px',
    textDecoration: 'none',
    cursor: 'pointer'
  },
  btnContainer: {
    float: 'right',
    marginTop: 20
  }
}));

const RoiSimulatorLayout = () => {
  const classes = useStyles();
  const productDataJsonNew = productDataJson.map((data, key) => {
    return data.countries.PE.categories;
  });
  const [kcProductData,setKcProductData]= useState();
  const [kcEventData,setKcEventData] = useState();
  const [isROIFileDownloading, setIsROIFileDownloading] = useState(false);

  //store
  let selectedCountry = useStore((state) => state.selectedCountry);

  const setSelectedEventId = useStore((state) => state.setSelectedEventId);
  const setSelectedEventIdNew = useStore((state) => state.setSelectedEventIdNew);

  const [kpiType, setkpiType] = useState("case")

  let selectedSource = useStore(
    (state) => state.selectedSource
  );

  const setSelectedSource = useStore(
    (state) => state.setSelectedSource
  );
  
  let sourceUrl = "";
  for (var source of selectedSource) {
    sourceUrl += `&source=${source}`
  }

  const generateEventId = (events) => {
    let eventsLevel = [];
    for (const key in events) {
      let itemList = {
        name: events[key],
        isChecked: false,
      };
      eventsLevel.push(itemList);
    }
    return eventsLevel;
  };

  //services
  const { isLoading: isCustomerData, data: customerData } =
    useCustomerHierarchy(`${selectedCountry}${sourceUrl}&feature=Promo Performance`);

  const { isLoading: isSellInCustomerData, data: sellInCustomerData } =
    useCustomerHierarchy(`${selectedCountry}&source=SELL IN&feature=Promo Performance`);

  let selectedBaseLineFilters = useStore((state) => state.selectedBaseLineFilters); 
  let updatedBaseLineFilter = updateUrl(selectedBaseLineFilters);
  let selectedEventIdNew  =   useStore((state) => state.selectedEventIdNew);

  const startMonth = useStore((state) => state.startMonth);
  const endMonth = useStore((state) => state.endMonth);

  const setSelectedBaseLineProductNew = useStore(
    (state) => state.setSelectedBaseLineProductNew
  );

    let groupBy = useStore((state) => state.groupBy);


  let selectedBaseLineCustomerNew = useStore((state) => state.selectedBaseLineCustomerNew);    
  let selectedBaseLineProductNew = useStore((state) => state.selectedBaseLineProductNew);

  const { isLoading: isProductData, data: productData } =
    useProductHierarchy(`${selectedCountry}${sourceUrl}`);

  const setSelectedBaseLineCustomerNew = useStore(
    (state) => state.setSelectedBaseLineCustomerNew
  );

  const setSelectedEventIdState = useStore((state) => state.setSelectedEventIdState);

  let setSelectedBaseLineFilter = useStore(
    (state) => state.setSelectedBaseLineFilter
  ); 

  const setSelectedEventIdValues = useStore((state) => state.setSelectedEventIdValues);

  const { isLoading: isSourceData, data: sourceData } =
    useSellInSellOutCheck(selectedCountry);

  const { isLoading: isEventIDData, data: eventIDData } = 
    useEventIDData(`${selectedCountry}${updatedBaseLineFilter.trim()}&fromDate=${startMonth}&toDate=${endMonth}${sourceUrl}`);
  
  useEffect(() => {
    if (!isEventIDData) {
      setKcEventData(generateEventId(eventIDData));
      setSelectedEventIdState(generateEventId(eventIDData));
    }
  }, [isEventIDData]);
    
  const [apidataLocal, setApidataLocal] = useState([]);
 

  useEffect(() => {
    if (!isProductData && selectedCountry !== undefined && productData) {
      setApidataLocal(productData);
      setKcProductData(productData['countries'][selectedCountry]);
    }
  }, [isProductData, productData]);

  const [clear,setClear]=useState(false);

  const clearData = () => {
    setSelectedBaseLineProductNew(' ');
    setSelectedBaseLineCustomerNew(' ');
    setSelectedEventId('');
    setClear(true);
    
  };

  const [clearProduct, setClearProduct ]=useState(false);
  const [clearCustomer, setClearCustomer ]=useState(false)

  const clearProductData = () => {
    setSelectedBaseLineProductNew(" ");
    setSelectedBaseLineFilter(selectedBaseLineCustomerNew);
    setClearProduct(true);
  }

  const clearCustomerData = () => {
    setSelectedBaseLineCustomerNew(" ");
    setSelectedBaseLineFilter(selectedBaseLineProductNew);
    setClearCustomer(true);
    setSelectedSource([]);
  }

  const [clearEventId,setClearEventId] = useState(false);

  const clearEventData = () => { 
    setSelectedEventIdState(generateEventId(eventIDData));
    setSelectedEventId('');
    setSelectedEventIdValues([]);
    setClearEventId(true);
    setSelectedEventIdNew('');
  }
  useEffect(()=>{
    setSelectedEventId('');
    setSelectedEventIdNew('');
    setSelectedEventIdValues([]);
    setSelectedEventIdState(generateEventId(eventIDData));
  },[])
  const resetEventId = () =>{
    setClearEventId(false);
  }

  const [clearTime,setClearTime] = useState(false);

  const clearTimeData = () =>{
    setClearTime(true);
  }

  const resetTime = () =>{
    setClearTime(false);
  }

  const resetProduct = () =>{
    setClearProduct(false);
  }

  const resetCustomer = () =>{
    setClearCustomer(false);
  }

  const downloadFile = async () => {
    try {
      setIsROIFileDownloading(true);
      const apiRequestService =  ApiRequestService.createInstance();
      const res = await apiRequestService.roiFileDownload(`${selectedCountry}${selectedBaseLineCustomerNew.trim()}${selectedBaseLineProductNew.trim()}&fromDate=${startMonth}&toDate=${endMonth}&groupBy=${groupBy}&&eventIds=${selectedEventIdNew}${sourceUrl}&kpiType=${kpiType}`);
      const url = window.URL.createObjectURL(res.data);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'PromoPerformance.xlsx'); //or any other extension
      document.body.appendChild(link);
      link.click();
      setIsROIFileDownloading(false);
    } catch (error) {
      console.log('ROI download error')
      console.log(error)
    }
  }

  const changeKPIType = (e) => {
    setkpiType(e.target.value)
  }

  return (
    <Grid item xs={12} sm={12}>
      <Grid container spacing={1}>
        <Grid item xs={12} sm={6}>
          <div className={classes.paperDiv}>
            <div style={{ height: 5, color: "black", fontWeight: "bold" }}>
              Customer
              <span className={classes.clearAll} id="clearCustomer" onClick={() => clearCustomerData()}>
                Clear 
              </span>
            </div>
            { !isCustomerData && !isSourceData && !isSellInCustomerData &&(
              <CustomSearch data={customerData} sellInData={sellInCustomerData} dataFor="customer" tabName="postROI" hasScopeData={sourceData?.available} clear={clearCustomer} reset={resetCustomer}/>
            )}

            { ( isCustomerData || isSourceData || isSellInCustomerData) && (
              <>
                <CustomSearch dataFor="customer" clear={clearCustomer} tabName="postROI" hasScopeData={sourceData?.available} reset={resetCustomer} /> Loading...!
              </>
            )}
          </div>
        </Grid>
        <Grid item xs={12} sm={6}>
          <div className={classes.paperDiv}>
            <div style={{ height: 5, color: "black", fontWeight: "bold" }}>
              Product
              <span className={classes.clearAll}  id="clearProducts" onClick={() => clearProductData()}>
                Clear
              </span>
            </div>

            {!isProductData && (
              <>
                <CustomSearch data={kcProductData} dataFor="Product" tabName="postROI" clear={clearProduct} reset={resetProduct}/>
              </>
            )}

            {isProductData && (
              <>
                <CustomSearch dataFor="Product" clear={clearProduct} tabName="postROI" reset={resetProduct} /> Loading...!
              </>
            )}
          </div>
        </Grid>
        <Grid item xs={12} sm={6}>
          <div className={classes.paperDiv}>
            <div style={{ height: 5, color: "black", fontWeight: "bold" }}>
              Select Time Interval
              <span className={classes.clearAll} onClick={() => clearTimeData()}>
                Clear 
              </span>
            </div>

            <Paper className={classes.paperDiv}>
              <NewCal clear={clearTime} reset={resetTime} />
            </Paper>
          </div>
        </Grid>



        {/*  {selectedCountry !== 'KR' &&  ( */}
        <Grid item xs={12} sm={6}>
          <div className={classes.paperDiv}>
            <div style={{ height: 5, color: "black", fontWeight: "bold" }}>
              Event ID
              <span className={classes.clearAll} onClick={() => clearEventData()}>
                Clear 
              </span>
            </div>
            {
              !isEventIDData && (
                <CustomSearch data={kcEventData} dataFor="EventId" clear={clearEventId} reset={resetEventId} />
              )
            }
            {
              isEventIDData && (
                <CustomSearch dataFor="EventId" clear={clearEventId} reset={resetEventId} />
              )
            }
          </div>
        </Grid>
        {/*     )} */}
      </Grid>


      

      <Grid item xs={12} sm={12}>
        <Grid item xs={12} sm={12} container>
          <Grid item xs={12} sm={4}>
            <div className={classes.paperDiv}>
              <Paper className={classes.paperDiv} style={{ height: 300 }}>
                <div>
                  <RoiQuadrant kpiType={kpiType}  />
                </div>
              </Paper>
            </div>
          </Grid>

          <Grid item xs={12} sm={4}>
            <div className={classes.paperDiv}>
              <Paper className={classes.paperDiv} style={{ height: 300 }}>
               

                {selectedCountry &&  <div>
                  <PromoReport  kpiType={kpiType} />
                </div>}

              {!selectedCountry && (
                <p className={classes.defaultTxt}>
                  Please select country to view Reports/Graph.
                </p>
              )}
              </Paper>
            </div>
          </Grid>

          <Grid item xs={12} sm={4}>
            <div className={classes.paperDiv}>
              <Paper className={classes.paperDiv} style={{ height: 300 }}>
                <div>
                  <RoiDetails  kpiType={kpiType}/>
                </div>
              </Paper>
            </div>
          </Grid>
        </Grid>
      </Grid>

      {
        selectedCountry === 'UK' &&
        <div className="flex flex-col ml-2 p-2 mt-3 border border-gray-400 w-fit">
          <div className="font-bold ">
              KPI Type
          </div>
          <div>
            <FormControl  required
                component="fieldset"
                sx={{ m: 3 }}
                variant="standard"
                defaultValue="case"
                color="primary"
                onChange={changeKPIType}
                id="kpiType">
                    <RadioGroup className="flex mt-1 " row="true">
                        <FormControlLabel checked={kpiType === "case"} value="case"  control={<Radio color='primary' />} label="Per Case" className="w-32"   />
                        <FormControlLabel checked={kpiType === "osku"} value="osku" control={<Radio color='primary' />} label="Per SU" className="w-32" />
                    </RadioGroup>
                </FormControl>
          </div>
        </div> 
      }

      <Grid item xs={12} sm={12}>
        <Paper className={classes.paper}>
          <Grid item xs={12} sm={12} container>
            <Grid item xs={12} sm={1}>
              <h3
                style={{
                  justifyContent: "left",
                  display: "flex",
                  marginTop: 25,
                  marginLeft: 10,
                }}
              >
                Group by{" "}
              </h3>
            </Grid>
            <Grid item xs={12} sm={1}>
              <GroupSelect style={{ justifyContent: "left" }} />
            </Grid>
            <Grid item xs={12} sm={1}>
              <h3
                style={{
                  justifyContent: "right",
                  display: "flex",
                  marginTop: 23,
                  marginLeft: 10,
                  marginRight: 10
                }}>
                Quadrant :
              </h3>
            </Grid>
            <Grid item xs={12} sm={2}>
              <QuadrantSelector style={{ justifyContent: "center" }} />
            </Grid>
            <Grid item xs={12} sm={6}>
              <div className={classes.btnContainer}>              
                <a onClick={downloadFile} className={classes.btnSucess}> Download </a>
              </div>
              </Grid>
          </Grid>

          

          <div className={classes.chartDiv}>
            <PostRoiGrid kpiType={kpiType} />
          </div>
        </Paper>
      </Grid>
      <Dialog
        open={isROIFileDownloading}
        keepMounted
        aria-describedby="alert-dialog-slide-description">
        <DialogTitle className="pt-0">
            {"Your request is being processed"}
        </DialogTitle>
      </Dialog>
    </Grid>
  );
};

export default RoiSimulatorLayout;
