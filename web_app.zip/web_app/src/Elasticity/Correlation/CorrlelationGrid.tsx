import React from 'react'
import Table from "@material-ui/core/Table";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import { Toolbar } from "@material-ui/core";
import TableContainer from "@material-ui/core/TableContainer";
import { makeStyles } from "@material-ui/core/styles";
import Tooltip from '@material-ui/core/Tooltip';
import Typography from '@material-ui/core/Typography';
import { textAlign } from '@mui/system';
const useStyles = makeStyles((theme)=> ({
    button: {
        display: "block",
        marginTop: theme.spacing(2),
      },
      formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
      },
      table: {
        minWidth: 650,
        background: "#fff",
        border: "1px solid rgba(0,0,0,0.2)",
      },
      cellData: {
        borderLeft: "1px solid #ccc",
        textTransform: "capitalize",
      },
      xAddButtonCell: {
        fontWeight: "bold",
        color: "#2662FF",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        width: 100,
        borderLeft: "1px solid rgba(224, 224, 224, 1)",
        borderTop: "1px solid rgba(224, 224, 224, 1)",
      },
      yAddButtonCell: {
        fontWeight: "bold",
        color: "#2662FF",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        width: 100,
        borderLeft: "1px solid rgba(224, 224, 224, 1)",
      },
      correlationTable: {
        background: "inherit",
        width: "100%",
        alignItems: "flex-start",
      },
      gridHeader: {
        textAlign: "center",
        padding: "2.5rem",
      },
      tableHeadCell: {
        fontWeight: "bold",
        color: "#494949",
        whiteSpace: "nowrap",
        width: 100,
      },
      correlationCell: {
        fontWeight: "bold",
        color: "#494949",
        whiteSpace: "nowrap",
        width: 100,
        border: "1px solid rgba(224, 224, 224, 1)",
      },
      cellTable: {
        padding: "0",
        verticalAlign: "top",
      },
      high: {
        backgroundColor: "#CBF2DB",
        fontWeight: "bold",
        color: "#2ECC71",
        textAlign: "center",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
      },
      medium: {
        backgroundColor: "#FDF2C5",
        fontWeight: "bold",
        textAlign: "center",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        color: "#DFB202",
      },
      low: {
        backgroundColor: "#FBCCCC",
        fontWeight: "bold",
        textAlign: "center",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        color: "#F03434",
      },
      emptyHeader: {
        borderBottom: "none",
        borderRight: "none",
      },
      emptyCell: {
        border: "1px solid rgba(224, 224, 224, 1)",
      },
      circleActive: {
        marginLeft: "1px",
        cursor: "pointer",
      },
      circleInActive: {
        marginLeft: "1px",
        color: "#808080",
      },c0: {
        backgroundColor: "#fee4e5",
        fontWeight: "bold",
        textAlign: "center",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
      },
      c1: {
        backgroundColor: "#fee4e5",
        fontWeight: "bold",
        textAlign: "center",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        color: "#000000",
      },c2: {
        backgroundColor: "#fee0e1",
        fontWeight: "bold",
        textAlign: "center",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        color: "#000000",
      },c3: {
        backgroundColor: "#fdd1d2",
        fontWeight: "bold",
        textAlign: "center",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        color: "#000000",
      },c4: {
        backgroundColor: "#fcbabb",
        fontWeight: "bold",
        textAlign: "center",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        color: "#000000",
      },c5: {
        backgroundColor: "#fcb3b4",
        fontWeight: "bold",
        textAlign: "center",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        color: "#000000",
      },c6: {
        backgroundColor: "#fb999a",
        fontWeight: "bold",
        textAlign: "center",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        color: "#000000",
      },c7: {
        backgroundColor: "#fb9697",
        fontWeight: "bold",
        textAlign: "center",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        color: "#000000",
      },c8: {
        backgroundColor: "#fa8789",
        fontWeight: "bold",
        textAlign: "center",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        color: "#000000",
      },c9: {
        backgroundColor: "#f97f81",
        fontWeight: "bold",
        textAlign: "center",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        color: "#000000",
      },
      c10: {
        backgroundColor: "#000000",
        fontWeight: "bold",
        textAlign: "center",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        color: "#382d2d",
      },
      container: {

      }
}))

type CorrelationData = {
  [key: string] : string 
}
type Props = {
    initialProductSelected: string[],
    targetProductSelected: string[],
    headCells: string[],
    correlationDataNew: CorrelationData,
    customer: string,
    productLevel: string
}
const CorrlelationGrid = ({initialProductSelected,targetProductSelected,headCells,correlationDataNew,customer,productLevel}:Props) => {
  const classes = useStyles();

  return (
    <div className="flex justify-center items-center" style={{border: "1px solid rgba(224, 224, 224, 1)"}}>
        <TableContainer className={classes.container} style={{ display: "flex" ,flexDirection:'column'}}>
          <Table>
          <div className="flex h-16 justify-center items-center font-semibold" >{customer}</div>
          </Table>
          <Table className={classes.correlationTable}>
            <TableBody>
              <TableRow>
                <TableCell
                  colSpan={1}
                  className={classes.correlationCell}
                >
                </TableCell>
                {targetProductSelected.length > 0
                  ? targetProductSelected.map((targetCell:any,i:any) => (
                      <TableCell
                        colSpan={1}
                        className={classes.xAddButtonCell}
                        key={i}
                      >
                        <Tooltip
                          title={<Typography>{targetCell}</Typography>}
                          placement="top"
                          disableFocusListener
                          disableTouchListener
                          >
                            <div className="targetOvalShape targetProduct" style={{ display: "flex" ,justifyContent: 'center'}}>{targetCell}</div>
                          </Tooltip>
                      </TableCell>
                    ))
                  : headCells.map((headCell:any) => (
                      <TableCell
                        colSpan={1}
                
                        className={classes.xAddButtonCell}
                        key={headCell.id}
                      >
                        {headCell.label}
                      </TableCell>
                    ))}
              </TableRow>

              {initialProductSelected.length > 0
                ? initialProductSelected.map((kcCellVal:any, i:any) => (
                    <TableRow key={i}>
                      <TableCell
                        className={classes.yAddButtonCell}
                      >
                        <Tooltip
                          title={<Typography>{kcCellVal}</Typography>}
                          placement="top"
                          disableFocusListener
                          disableTouchListener
                          >
                            <div className="kcOvalShape initialProduct" style={{ display: "flex" ,justifyContent: 'center'}}>{kcCellVal}</div>
                          </Tooltip>
                      </TableCell>
                      {
                        targetProductSelected.map((targetCell:any, j:any) => {

                        let initial = initialProductSelected[i];
                        let target = targetProductSelected[j];
                        

                        if(productLevel === 'EAN') {
                          initial = initialProductSelected[i]?.split(" - ")[0];
                          target = targetProductSelected[j]?.split(" - ")[0];
                        }
                        const value = correlationDataNew[`${initial}:${target}`];
                        
                        const values = value ? (parseFloat(value)).toFixed(2) : 0;
                        const valuess = value ? null : '' ;

                        // if( values == ''){
                        //   return <TableCell
                        //   className={classes.c0}
                        //   key={j}>
                        //     {value ? (parseFloat(value)).toFixed(3) : ''}
                        // </TableCell>
                        // }
                        
                        ///
                          if((values >= 0.00 && values <= 0.09) || (values <= -0.00 && values >= -0.09) || values == ''){
                            return <TableCell
                            className={classes.c0}
                            key={j}>
                              {value ? (parseFloat(value)).toFixed(3) : ''}
                          </TableCell>
                          }
                        

                        
                          else if((values >= 0.10 && values <= 0.19) || (values <= -0.10 && values >=-0.19)){
                            return <TableCell
                    
                            className={classes.c1}
                            key={j}>
                              {value ? (parseFloat(value)).toFixed(3) : ''}
                          </TableCell>
                          }else if((values >= 0.20 && values <= 0.29) || (values <= -0.20 && values >=-0.29)){
                            return <TableCell
                    
                            className={classes.c2}
                            key={j}>
                              {value ? (parseFloat(value)).toFixed(3) : ''}
                          </TableCell>
                          }else if((values >= 0.30 && values <= 0.39) || (values <= -0.30 && values >=-0.39)){
                            return <TableCell
                    
                            className={classes.c3}
                            key={j}>
                              {value ? (parseFloat(value)).toFixed(3) : ''}
                          </TableCell>
                          }else if((values >= 0.40 && values <= 0.49) || (values <= -0.40 && values >=-0.49)){
                            return <TableCell
                    
                            className={classes.c4}
                            key={j}>
                              {value ? (parseFloat(value)).toFixed(3) : ''}
                          </TableCell>
                          }else if((values >= 0.50 && values <= 0.59) || (values <= -0.50 && values >=-0.59)){
                            return <TableCell
                    
                            className={classes.c5}
                            key={j}>
                              {value ? (parseFloat(value)).toFixed(3) : ''}
                          </TableCell>
                          }else if((values >= 0.60 && values <= 0.69) || (values <= -0.60 && values >=-0.69)){
                            return <TableCell
                    
                            className={classes.c6}
                            key={j}>
                              {value ? (parseFloat(value)).toFixed(3) : ''}
                          </TableCell>
                          }else if((values >= 0.70 && values <= 0.79) || (values <= -0.70 && values >=-0.79)){
                            return <TableCell
                    
                            className={classes.c7}
                            key={j}>
                              {value ? (parseFloat(value)).toFixed(3) : ''}
                          </TableCell>
                          }else if((values >= 0.80 && values <= 0.89) || (values <= -0.80 && values >=-0.89)){
                            return <TableCell
                    
                            className={classes.c8}
                            key={j}>
                              {value ? (parseFloat(value)).toFixed(3) : ''}
                          </TableCell>
                          }else if((values >= 0.90 && values <= 0.99) || (values <= -0.90 && values >=-0.99)){
                            return <TableCell
                    
                            className={classes.c9}
                            key={j}>
                              {value ? (parseFloat(value)).toFixed(3) : ''}
                          </TableCell>
                          }
                          else{
                            return <TableCell
                    
                            className={classes.c10}
                            key={j}>
                              {value ? (parseFloat(value)).toFixed(3) : ''}
                          </TableCell>
                          }
                          
                        })
                      }

                      
                    </TableRow>
                  ))
                : headCells.map((headCell:any) => (
                    <TableRow>
                      <TableCell
                        className={classes.yAddButtonCell}
                        key={headCell.id}
                      >
                        {headCell.label}
                      </TableCell>
                    </TableRow>
                  ))
              }
            </TableBody>
          </Table>
          
        {/* </div> */}
        </TableContainer>

    </div>
  )
}

export default CorrlelationGrid