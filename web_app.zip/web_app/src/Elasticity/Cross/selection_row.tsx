import { useEffect, useState } from "react";
import { useTargetProductHierarchy } from "../../services/queries";
import NestedSearch from "../NestedSearch";

type SelectionRowProps = {
    handleSelectedValues: (obj:any) => void,
    initialProductData: any,
    emptySelection: boolean,
    comparisonAdded: () => void,
    scope?: String,
    source?: String,
    selectedProducts: any,
    selectedTargetProducts: any

}

export const SelectionRow = ({handleSelectedValues, initialProductData, emptySelection, comparisonAdded, scope, source, selectedProducts, selectedTargetProducts}:SelectionRowProps) => {
    const [canShowSearch, setcanShowSearch] = useState(false);
    const [canShowTargetSearch, setcanShowTargetSearch] = useState(false);
    const [targetProductUrl, settargetProductUrl] = useState('');

    const { isSuccess: haveTargetData, data: targetData } = useTargetProductHierarchy(targetProductUrl);

    const handleSelectedProducts = (kcObject: any) => {
        if (kcObject.dataFor === "initial") {
            let apiURL = kcObject.apiUrl
            if (scope) {
                apiURL = `${apiURL}&scope=${scope}`
            }else if(source){
                apiURL = `${apiURL}&source=${source}`
            }
            settargetProductUrl(apiURL);
            // setcanShowSearch(false)
        }
        handleSelectedValues(kcObject)
    }

    const [SelectionFixed, setSelectionFixed] = useState(false)
    // useEffect(() => {
    //     const scrollEvent = (e:any) => {
    //         const table = document.getElementById('crossTable')!
    //         const body = document.getElementsByTagName('body')[0]
    //         if (body.scrollTop > table.offsetTop){
    //             setSelectionFixed(true)
    //         }else{
    //             setSelectionFixed(false)
    //         }
    //     }
    //     document.addEventListener('scroll',scrollEvent)
        
    //     return () => {
    //         document.removeEventListener('scroll', scrollEvent)
    //     }
    // }, [])
    
    
    return  <div className={`min-h-20  flex flex-col  mt-2 top-0 ${SelectionFixed ? 'fixed' : ''}`}>
                <div className="flex pb-4">
                    <span>Initial Products: </span>
                    <div className={`relative flex pr-2 ${canShowSearch ? 'z-30' : ''}`}>
                        <div onClick={() => setcanShowSearch(true)} className="cursor-pointer px-2 py-1">
                            <svg  className="fill-primary cursor-pointer" focusable="false" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" id="prod_picker1"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"></path></svg>
                        </div>
                        {
                            canShowSearch && initialProductData
                            ?  <div className="absolute z-6 z-30">
                                <NestedSearch
                                data={initialProductData}
                                handleSelectedValues={handleSelectedProducts}
                                tabName="cross"
                                dataFor="initial"
                                id="initialSearch"
                                previouslySelected={selectedProducts}
                                onMouseLeave={() => setcanShowSearch(false)} />
                                 </div>
                            : null
                        }
                    
                    </div>
                    <div className="flex flex-wrap">
                        {
                            selectedProducts.map((x:string)=> {
                                return <div className="text-xs p-2 bg-gray-300 rounded mt-1.5 ml-1.5">{x}</div>
                            })
                        }
                    </div>
                </div>
                <div className="flex pb-4">
                    <span>Target Products: </span>
                    <div className=" relative flex pr-2 z-20">
                        <div onClick={() => setcanShowTargetSearch(true)} className="cursor-pointer px-2 py-1">
                            <svg  className="fill-purple-700 cursor-pointer" focusable="false" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" id="prod_picker1"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"></path></svg>
                        </div>
                       
                        {
                            canShowTargetSearch && targetData
                            ?  <div className="absolute z-30">
                                <NestedSearch
                                data={targetData}
                                handleSelectedValues={handleSelectedProducts}
                                tabName="cross"
                                dataFor="target"
                                id="targetSearch"
                                previouslySelected={selectedTargetProducts}
                                onMouseLeave={() => setcanShowTargetSearch(false)} />
                                 </div>
                            : null
                        }
                        
                       
                    </div>
                    <div className="flex flex-wrap">
                        {
                            selectedTargetProducts.map((x:string)=> {
                                return <div className="text-xs p-2 bg-gray-300 rounded mt-1.5 ml-1.5">{x}</div>
                            })
                        }
                    </div>
                </div>
                <div>
                </div>
        </div>
}