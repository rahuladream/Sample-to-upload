import { AxiosResponse } from "axios";
import { useCallback, useEffect, useState } from "react";
import { TableColumn } from "react-data-table-component";
import { ApiRequestService } from "../../services/api-service";
import { useCrossAnalysis, useCrossScopeSelector, useKcProductHierarchy, useLastModelRunDate } from "../../services/queries";
import useStore from "../../store";
import { ElasticityScopeRecord, ElasticityRecord, SelectedProduct, Scope, ProductsOnComparison, PriceType } from "../types";
import { getCrossURLParams, getHierarchyLevel, parseCrossAnalysisData, sortScopeData, getCrossViewMoreURL, paginationPerPageDataLimit} from "../utils";
import ProductLevelSelector from "../Widgets/ProductLevelSelector";
import { CrossCountryScope } from "./country_scope";
import { CrossMarketScope } from "./market_scope";
import Dialog from "@material-ui/core/Dialog";
import DialogTitle from "@material-ui/core/DialogTitle";
import AppPagination from '../Pagination';

export const CrossTab = () => {
    
    const initialProducts: SelectedProduct =  {
        crossAnalysisApiUrl: "",
        flag: false,
        selectedKcArr: []
    }
    const [crossTabData, setCrossTabData] = useState<any[]>([]);
    const [crossTabScopeData, setCrossTabScopeData] = useState<any[]>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [crossTabDataCount, setCrossTabPaginationCount] = useState(0);

    let selectedCountry = useStore((state) => state.selectedCountry);

    let source = useStore((state) => state.selectedSourceChoice);

    let selectedScopeLevel = useStore((state) =>
        state.selectedScopeLevel ? state.selectedScopeLevel : "WC"
    );

    let selectedCategoryLevel = useStore((state) =>state.selectedCategoryLevel);

    const {  data: lastModelRunData, isError: lastModelRunError} = useLastModelRunDate(selectedCountry);

    const setSelectedScopeLevel = useStore(
        (state) => state.setSelectedScopeLevel
    );

    let setTargetCrossValue = useStore((state) => state.setTargetCrossValue);

    let setPriceElasticityTab = useStore((state) => state.setPriceElasticityTab);
  
    const setSelectedCategoryLevel = useStore(
      (state) => state.setSelectedCategoryLevel
    );

    let selectedProductLevel = useStore((state) => state.selectedProductLevel);
    const setSelectedProductLevel = useStore(
      (state) => state.setSelectedProductLevel
    );
    let selectedSubCategoryLevel = useStore((state) => state.selectedSubCategoryLevel);
 
    const [selectedKcProducts, setSelectedKcProducts] = useState<SelectedProduct>(initialProducts);
    const [selectedTargetProducts, setSelectedTargetProducts] = useState<SelectedProduct>(initialProducts);

    const { isLoading: isKcProductData, data: kcProductData } = useKcProductHierarchy(`${selectedCountry}${source ? `&source=${source}` : '' }`, getHierarchyLevel(selectedProductLevel));

    const [hasCategoryLevel, setHasCategoryLevel] = useState(false);
    const [lastInitialProduct, setlastInitialProduct] = useState('');
  
    useEffect(() => {
        onClickClear()
    },[selectedCountry])
    
    const handleSelectedValues = (kcObject: any) => {
        if (kcObject.dataFor === "initial") {
            setSelectedKcProducts({
                ...selectedKcProducts,
                selectedKcArr: kcObject.selectedKcArr,
                crossAnalysisApiUrl: kcObject.crossAnalysisApiUrl,
                flag: true,
                selectedBrand: kcObject.selectedBrand,
                selectedManufacturer: kcObject.selectedManufacturer,
                selectedSubBrands: kcObject.selectedSubBrands,
                selectedPacks: kcObject.selectedPacks
            });
            // setSelectedTargetProducts({
            //     ...selectedTargetProducts,
            //     selectedKcArr: [],
            //     crossAnalysisApiUrl: '',
            //     flag:false,
            // })
           
            setlastInitialProduct(kcObject.selectedKcArr[0])
        } else {
            setSelectedTargetProducts({
                ...selectedTargetProducts,
                selectedKcArr: kcObject.selectedKcArr,
                crossAnalysisApiUrl: kcObject.crossAnalysisApiUrlT,
                flag: true,
                selectedBrand: kcObject.selectedBrand,
                selectedManufacturer: kcObject.selectedManufacturer,
                selectedSubBrands: kcObject.selectedSubBrands,
                selectedPacks: kcObject.selectedPacks                
            });
        }
        if (!kcObject.selectedKcArr || kcObject.selectedKcArr.length === 0){
            setParsedData([])
            setSubCustomerHead([]);
            setSubCustomerData([]);
        }
    };

    const [crossURLParams, setcrossURLParams] = useState<string | null>('')
    const [crossScopeURLParams, setcrossScopeURLParams] = useState<string  | null>('')

    useEffect(() => {

        let url = getCrossURLParams(  
                selectedKcProducts.selectedKcArr, 
                selectedTargetProducts.selectedKcArr, 
                selectedCategoryLevel,
                getHierarchyLevel(selectedProductLevel), 
                selectedCountry, 
                source, 
                selectedScopeLevel,
                selectedSubCategoryLevel,
                selectedSubCategoryLevel,
                selectedKcProducts.selectedManufacturer??[''],
                selectedTargetProducts.selectedManufacturer??[''],
                selectedKcProducts.selectedBrand??[''],
                selectedTargetProducts.selectedBrand??['']
            )

 
        if (selectedScopeLevel === 'WC'){
            setcrossURLParams(url)
        }else{
            setcrossScopeURLParams(url)
        }
    }, [selectedKcProducts.selectedKcArr, selectedTargetProducts.selectedKcArr, selectedProductLevel, selectedCountry, source, selectedScopeLevel])
    

    const { isLoading: isCrossDataLoading, data: crossData, isError: crossDataError } = useCrossAnalysis(crossURLParams || '')
    
    const { isLoading: isCrossScopeLoading, data: crossScopeData, isError: crossScopeDataError } = useCrossScopeSelector(crossScopeURLParams || '')

    
    let setKcProductCrossValue = useStore(
        (state) => state.setKcProductCrossValue
    );

    const [parsedData, setParsedData] = useState<ElasticityRecord[]>([]);

    const [subCustomerData, setSubCustomerData] = useState<ElasticityScopeRecord[]>([]);
    const [subCustomerHead, setSubCustomerHead] = useState<string[]>([]);
    const [customerOriginal, setcustomerOriginal] = useState<ElasticityScopeRecord[]>([]);

    useEffect(() => {
        if (crossData && selectedKcProducts.flag && selectedTargetProducts.flag){
            const record = parseCrossAnalysisData(crossData)
            if (record){
                setParsedData(record)
            }
        } else {
            setParsedData([])
        }
        
    }, [crossData, selectedKcProducts, selectedTargetProducts]);

    useEffect(() => {
        if (!isCrossScopeLoading && selectedKcProducts.flag && selectedTargetProducts.flag){
            if (crossScopeData && Object.entries(crossScopeData).length > 0){
                const scopeResult: ElasticityScopeRecord[] = []
                for (const scope in crossScopeData) {
                    const  scopeData: ElasticityScopeRecord  = {
                        customer: scope,
                        data: parseCrossAnalysisData(crossScopeData[scope],scope)
                    }
                    scopeResult.push(scopeData)
                }
                setSubCustomerData(scopeResult)
                setcustomerOriginal(scopeResult)
                
            } else {
                setSubCustomerData([])
            }
           
        }
    }, [isCrossScopeLoading, crossScopeData, selectedKcProducts, selectedTargetProducts]);

   
    const handleUnselect = (initial:string, target?: string) => {
        setParsedData(data => {
            const newData = data.filter( row => !(row.initial ===  initial && row.target === target))
            if (!newData.length) {
                setSelectedKcProducts(initialProducts);
                setSelectedTargetProducts(initialProducts);
                setSubCustomerHead([]);
                setSubCustomerData([]);
            }
            return newData
        });
        
    }

    const handleViewMore = (initial: string, target?: string, customer?:string, category?:string, subCategoryInitial?:string, subCategoryTarget?:string, manufacturerInitial?:string, manufacturerTarget?:string, brandInitial?:string, brandTarget?:string) => {
        const _source = useStore.getState().selectedSourceChoice
        setKcProductCrossValue(
          `${initial.split("-")[0]}`
        );
        setTargetCrossValue(
            `${target?.split("-")[0]}`
        );
        setPriceElasticityTab("Cross");
        const pl = getHierarchyLevel(useStore.getState().selectedProductLevel)
        let url = getCrossViewMoreURL(
            selectedCountry,initial,target!,pl,_source,selectedScopeLevel,category!,subCategoryInitial!,subCategoryTarget!,manufacturerInitial!,manufacturerTarget!,brandInitial!,brandTarget!,customer!
        )

        window.open(`/price-elasticity/cross-dashboard?${url}`);
    }
    const elasticityPrice = {
        avgPrice: true,
        promoPrice: false,
        basePrice: false
    }

    let priceType = useStore((state) =>
        state.priceType ? state.priceType : elasticityPrice
    );
    const setPriceType = useStore(
        (state) => state.setPriceType
    );

    const onClickClear = () => {
        setParsedData([]);
        setSubCustomerData([]);
        setSelectedKcProducts(initialProducts);
        setSelectedTargetProducts(initialProducts);
        setCrossTabPaginationCount(0);
    };

    const onchange = (data: any) => {
        if (data[0] === "productLevel") {
          setSelectedProductLevel(data[1]);
          setSubCustomerData([])
          setcustomerOriginal([])
          setSelectedKcProducts(initialProducts);
          setSelectedTargetProducts(initialProducts);
        } else if (data[0] === "categoryLevel") {
          setSelectedCategoryLevel(data[1]);
          setSelectedKcProducts(initialProducts);
          setSelectedTargetProducts(initialProducts);
          setSubCustomerData([])
          setcustomerOriginal([])
          setHasCategoryLevel(true);
        } else{
            setPriceType(data[1])
        }
      };
    
    const onScopeChange = (data: any) => {
        setSelectedScopeLevel(data);
        setSubCustomerData([])
        setcustomerOriginal([])
        // setproductsInComparison([])
    };

    const handleScopeLevelSort = (field:  TableColumn<ElasticityRecord>, direction: string) => {
        const sorted  = sortScopeData(subCustomerData, field, direction)
        setSubCustomerData(sorted)
    }
    
    const filterCustomer = (names: string[]) => {
        setSubCustomerData(customerOriginal.filter(x=> !names.includes(x.customer)))
    }

    const [isDownloading, setisDownloading] = useState(false)

    const downloadOwnElasticity = async () => {
        const {selectedKcArr, selectedBrand, selectedManufacturer, selectedSubBrands, selectedPacks} = selectedKcProducts;
        const selectedHeirarchyLevel = getHierarchyLevel(selectedProductLevel);
        
        const crossElasticityDownloadData = {
            country: selectedCountry,
            source: source,
            scope: selectedScopeLevel,
            hierarchyLevel: selectedHeirarchyLevel,
            category: selectedCategoryLevel,
            forOwn: false,
            subCategories: selectedSubCategoryLevel,
            initialNodeValues: selectedKcArr,
            targetNodeValues: selectedTargetProducts.selectedKcArr,
            initialManufacturers: selectedManufacturer,
            targetManufacturers: selectedTargetProducts.selectedManufacturer,
            initialBrands: selectedHeirarchyLevel === 'BRAND' ? [] : selectedBrand,
            targetBrands: selectedHeirarchyLevel === 'BRAND' ? [] : selectedTargetProducts.selectedBrand,
            initialSubBrands: selectedHeirarchyLevel === 'SUB_BRAND' ? [] :selectedSubBrands,
            targetSubBrands: selectedHeirarchyLevel === 'SUB_BRAND' ? [] : selectedTargetProducts.selectedSubBrands,
            initialPacks: selectedHeirarchyLevel === 'PACK' ? [] :selectedPacks,
            targetPacks: selectedHeirarchyLevel === 'PACK' ? [] :selectedTargetProducts.selectedPacks,
        }

        try {
            setisDownloading(true)
            const api =  ApiRequestService.createInstance()
            const res: AxiosResponse = await api.elasticityFileDownload(crossElasticityDownloadData);
            const url = window.URL.createObjectURL(res.data);
            const link = document.createElement('a');
            link.href = url;
            const modelRun =  lastModelRunData &&  lastModelRunData[selectedCountry] ? new Date(lastModelRunData[selectedCountry]).toLocaleDateString() : ''
            link.setAttribute('download', `${selectedCountry}_Elasticity_${modelRun}.xlsx`); 
            document.body.appendChild(link);
            link.click();
            setisDownloading(false)
        } catch (error) {
            setisDownloading(false)
            console.log('Own Elasticity download error')
            console.log(error)
        }
    
    }

    const [canShowProgress, setcanShowProgress] = useState(false)

    const handleClickClose = () => {
        setcanShowProgress(false);
    };
        

    useEffect(() => {
        if (isCrossDataLoading || isCrossScopeLoading ){
            setcanShowProgress(true)
        }else{
            setcanShowProgress(false)
        }
    }, [isCrossDataLoading, isCrossScopeLoading])

    let disableDownloadbtn = (selectedCountry === '' || source === '' || selectedProductLevel === '' || selectedScopeLevel === '') ?  true : isDownloading ? true : false;
    
    useEffect(() => {
        const startIndex = currentPage * paginationPerPageDataLimit - paginationPerPageDataLimit;
        const endIndex = startIndex + paginationPerPageDataLimit;
 
        if(selectedScopeLevel === Scope.COUNTRY){
            setCrossTabPaginationCount(parsedData.length);
            setCrossTabData(parsedData ? parsedData.slice(startIndex, endIndex) : []);
        } else {
            let maxCount = 0;
            const customerData = subCustomerData.map(({customer,data}) => {
                if (data.length > maxCount) {
                    setCrossTabPaginationCount(data.length);
                    maxCount = data.length;
                }                
                return {customer: customer, data: data.slice(startIndex, endIndex)};
            });
            setCrossTabScopeData(customerData);
        }
    }, [currentPage, crossData, crossScopeData, parsedData, subCustomerData]);

    const handleCrossData = (currentPage:any) => {    
        setCurrentPage(currentPage);
    }

    return <div className="flex flex-col p-5">
            <ProductLevelSelector onchange={(e:any) => {
                onchange(e)
            }} onScopeChange={(e:any) => {
                onScopeChange(e)
            }}
            onSourceChange={(e:any) => {
                onClickClear()
              }}
            tabName="cross"
            />
            <div className="flex flex-row w-full justify-between my-5">
                <button className="border border-primary text-primary rounded p-1 w-20 " onClick={() => onClickClear()}>Clear</button>
                <button className={`border border-primary text-primary rounded p-1 w-20 ${disableDownloadbtn ? 'cursor-not-allowed' : ''}`} onClick={disableDownloadbtn ? () => { return null } : () => downloadOwnElasticity()} disabled={disableDownloadbtn}>
                    {
                        isDownloading
                        ?  <svg className="animate-spin ml-1 mr-3 h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="#0000b3" stroke-width="4"></circle>
                            <path className="opacity-75" fill="#0000b3" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        : null
                    }
                    
                    <span > Download</span>
                </button>

            </div>
            {
                parsedData && parsedData.length > 0 && parsedData[0].modelRun
                ?   <div className="text-right w-full">
                        <span className="text-primary">Last model update: <strong>{new Date(parsedData[0].modelRun).toLocaleDateString()}</strong> </span>
                    </div>
                : null
            }
         
            <div className="w-full flex felx-col">
                {
                    selectedScopeLevel === Scope.COUNTRY
                    ?  <CrossCountryScope 
                            records={crossTabData} 
                            selectedCountry={selectedCountry} 
                            priceType={priceType}
                            handleViewMore={handleViewMore} 
                            unselectRow={handleUnselect} 
                            loading={isCrossDataLoading} 
                            initialProductData={kcProductData}
                            handleSelectedValues={handleSelectedValues} 
                            source={source} 
                            selectedProducts={selectedKcProducts.selectedKcArr || []} 
                            selectedTargetProducts={selectedTargetProducts.selectedKcArr || []}
                            pageData={selectedScopeLevel === Scope.COUNTRY ? crossData : crossScopeData}
                            dataCount={crossTabDataCount}
                            handlePageData={handleCrossData}
                        />
                    
                    : null
                }
                {
                    selectedScopeLevel !== Scope.COUNTRY
                    ?  <CrossMarketScope 
                            records={crossTabScopeData} 
                            selectedCountry={selectedCountry} 
                            customSort={handleScopeLevelSort} 
                            filterCustomer={filterCustomer} 
                            allCustomers={customerOriginal.map(x=>x.customer)}
                            handleViewMore={handleViewMore} 
                            unselectRow={handleUnselect} 
                            loading={isCrossScopeLoading} 
                            initialProductData={kcProductData} 
                            scope={selectedScopeLevel as Scope}
                            handleSelectedValues={handleSelectedValues} 
                            priceType={priceType} 
                            source={source} 
                            selectedProducts={selectedKcProducts.selectedKcArr  || []} 
                            selectedTargetProducts={selectedTargetProducts.selectedKcArr || []}
                            pageData={selectedScopeLevel === Scope.COUNTRY ? crossData : crossScopeData}
                            dataCount={crossTabDataCount}
                            handlePageData={handleCrossData}
                        />
                    : null
                }               
            </div>
            <Dialog
                open={canShowProgress}
                keepMounted
                onClose={handleClickClose}
                aria-describedby="alert-dialog-slide-description">
                <DialogTitle className="pt-0">
                    {"Your request is being processed"}
                </DialogTitle>
            </Dialog>
    </div>
    
}