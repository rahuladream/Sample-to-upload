import { ProductsOnComparison } from "../types"
import CancelIcon from '@material-ui/icons/Cancel';

type ViewMoreProps = {
    records: ProductsOnComparison[],
    unselectRow: (initial: string, target: string) => void,
    handleViewMore: (initial: string, target: string) => void,
}
const cancelIconStyle = {
    color: '#0000b3',
    display: 'inline', 
    cursor: 'pointer'
}

export const ViewMore = ({records, unselectRow, handleViewMore}:ViewMoreProps) => {
    return  <div className="h-full  pt-16">
                    {
                        records.map(record => {
                            return <div className="h-24 w-60 flex justify-center items-center  border-gray-300 p-2 m-0">
                                <CancelIcon style={cancelIconStyle} onClick={() => {
                                    unselectRow(record.initial, record.target || '')}}/>
                                <div className="ml-2 flex gap-5 cursor-pointer" onClick={()=> handleViewMore(record.initial, record.target || '')}>
                                    <svg className=" bg-primary w-10 h-10 fill-white rounded-full p-1" focusable="false" viewBox="0 0 24 24" aria-hidden="true" ><path d="M12 8V4l8 8-8 8v-4H4V8z"></path></svg>    
                                    <span className="text-primary font-bold text-lg hover:underline">View more</span>
                                </div>
                            </div>
                        })
                    }
                </div>
           
}