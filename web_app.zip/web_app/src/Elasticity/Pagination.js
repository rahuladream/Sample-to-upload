import React, {Fragment, useEffect, useState} from 'react';
import {Box, Pagination} from '@mui/material';

import {paginationPerPageDataLimit} from './utils';

const AppPagination = ({pageData, handlePageData, dataCount, fromTab, applyPadding}) => {
  const [currentPage, setCurrentPage] = useState(1); 
  
  useEffect(() => {
    handlePageData(currentPage);
  },[pageData, currentPage]);
  
  const handlePageChange = (evt, currentPage) => {
    setCurrentPage(currentPage);
  }
  
  return (
    <Fragment>
      {dataCount > paginationPerPageDataLimit ? <div className="block w-full left-9">
        <Box className='Pagination' justifyContent="end" alignItems="center" display="flex" >
          <Pagination
            size="large"
            sx={{padding: (fromTab === 'cross' || 'correlation') ? applyPadding ? "20px 0" : "5px 0" : "20px 0 0"}}
            count={Math.ceil(dataCount / paginationPerPageDataLimit)}
            onChange={handlePageChange}
          />
        </Box>
      </div> : null}
    </Fragment>
  )
}

export default AppPagination;