import { ReactNode } from "react"
import { TableColumn } from "react-data-table-component"


export type ElasticityRecord = {
    initial: string,
    target?: string,
    category?: string,
    subCategoryInitial?: string,
    subCategoryTarget?: string,
    manufacturerInitial?: string,
    manufacturerTarget?: string,
    brandInitial?: string,
    brandTarget?: string,
    averagePrice?: number
    basePrice?:number
    priceIndex?: number
    promoPrice?:number
    range?: string
    rsquared?: number
    viewMore?: boolean
    customer? : string,
    elasticity?: string,
    nweeks?: number,
    periodBegin?: string,
    periodEnd?: string,
    modelRun?: string,
    pvalue?: number,
    averageVolume?: number
    channel?: string,
    source?: string,
    scope?: string
}

export type ElasticityScopeRecord = {
    customer: string,
    channel?: string,
    data: ElasticityRecord[]
}

export enum Scope  {
    COUNTRY = 'WC',
    CUSTOMER = 'PCUST',
    CHANNEL = 'CHANNEL'
}

export type SelectedProduct = {
    apiUrl?: string,
    selectedKcArr: any[],
    selectedOwnArr?: any[],
    crossAnalysisApiUrl?: string,
    flag?: boolean,
    selectedBrand?: any[],
    selectedManufacturer?: any[],
    selectedSubBrands?: any[],
    selectedPacks?: any[],
}

export type ProductsOnComparison = {
    initial: string,
    target: string
}

export type CustomSortFuction =  (field:  TableColumn<ElasticityRecord>, direction: string) => void
export type SortSelector = (row: ElasticityRecord, rowIndex: number) => ReactNode

export type PriceType =   {
    avgPrice: boolean,
    promoPrice: boolean,
    basePrice: boolean
}