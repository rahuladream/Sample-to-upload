import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import AppTabs from "../AppTabs";
import useStore from "../store";

const useStyles = makeStyles((theme) => ({
  root: {
    margin: theme.spacing(3),
    width: "100%",
    flexGrow: 1,
  },
  paperDiv: {
    display: "flex",
    flexWrap: "wrap",
    "& > *": {
      margin: theme.spacing(2),
      width: "100%",
    },
  },
  container: {
    backgroundColor: "#F6F8FC",
    height: "100vh",
  },
  paper: {
    backgroundColor: theme.palette.primary.light,
  },
  searchBar: {
    display: "inline-block",
    paddingRight: "2.5rem",
  },
  searchContainer: {
    background: "#F6F8FC",
    width: "100%",
    boxShadow: "none",
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
  header: {
    color: "black",
  },
  checkBox: {
    color: theme.palette.primary.main,
  },
  autoCompleteSearch: {
    boxShadow:
      "0px 2px 4px -1px rgb(0 0 0 / 20%), 0px 4px 5px 0px rgb(0 0 0 / 14%), 0px 1px 10px 0px rgb(0 0 0 / 12%)",
    background: "#FFFFFF",
  },
  gridContainer: {
    background: "#F6F8FC",
  },
  showCheckBox: {},
  appTab: {
    fontSize: "20px",
  },
  hide: {
    "& .checkbox-item": {
      display: "none",
    },
    "& .radio-item": {
      display: "none",
    },
  },
}));

const PriceElasticityLayout = (props) => {
    const classes = useStyles();

    let selectedCountry = useStore((state) => state.selectedCountry);

    let setPriceElasticityTab = useStore((state) => state.setPriceElasticityTab);

    const setSelectedSubCategoryLevel = useStore((state) => state.setSelectedSubCategoryLevel)
    const setDefaultSubCategory = useStore((state) => state.setDefaultSubCategory)

    useEffect(() => {
        setPriceElasticityTab("");
        setSelectedSubCategoryLevel([]);
        setDefaultSubCategory([]);
    }, []);

    let tabsToShow = [
        { index: 0, tag: "Correlation", value: "CorrelationTab", id:'CorrelationTab' },
        { index: 1, tag: "Own", value: "OwnTab", id: 'OwnTab' },
        { index: 2, tag: "Cross", value: "CrossTab", id: 'CrossTab' },
    ]



    return (
		<Grid item xs={12} sm={12}>
			<Grid className={classes.paperDiv}>
				<div className={classes.chartDiv}>
					<AppTabs
					className={classes.appTab}
					tabs={tabsToShow}
					logo={null}
					/>
				</div>
			</Grid>
		</Grid>
    );
};

export default PriceElasticityLayout;
