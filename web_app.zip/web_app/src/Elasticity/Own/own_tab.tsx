import {  useEffect, useState } from "react";
import { useOwnAnalysis, useOwnProductHierarchy, useOwnScopeSelector, useLastModelRunDate } from "../../services/queries";
import useStore from "../../store";
import NestedSearch from "../NestedSearch";
import ProductLevelSelector from "../Widgets/ProductLevelSelector";
import { CountryScope } from "./country_scope";
import { MarketScope } from "./market_scope";
import { ElasticityScopeRecord, ElasticityRecord, SelectedProduct, Scope } from "../types";
import { parseOwnAnalysisData, sortScopeData, getHierarchyLevel, getOwnViewMoreURL, getOwnURLParams, paginationPerPageDataLimit} from "../utils";
import { TableColumn } from "react-data-table-component";
import { ApiRequestService } from '../../services/api-service';
import { AxiosResponse } from "axios";
import Dialog from "@material-ui/core/Dialog";
import DialogTitle from "@material-ui/core/DialogTitle";
import AppPagination from '../Pagination';

export const OwnTab = () => {
    const selectedCountry = useStore((state) => state.selectedCountry);
    const selectedSourceChoice = useStore(state => state.selectedSourceChoice);

    const initialProducts: SelectedProduct =  {
        selectedOwnArr: [],
        apiUrl: '',
        selectedKcArr: []
    }

	let setPriceOwnsValue = useStore((state) => state.setPriceOwnsValue);
    const setPriceElasticityTab = useStore(
        (state) => state.setPriceElasticityTab
    );
    let displayTopItems = useStore(
        (state) => state.displayTopItems
    );

    useEffect(() => {
        onClickClear();
    }, [selectedSourceChoice])
    
    let selectedProductLevel = useStore((state) => state.selectedProductLevel);
    let selectedScopeLevel = useStore<string>((state) =>
        state.selectedScopeLevel ? state.selectedScopeLevel : "WC"
    );
    
    const [selectedOwnProducts, setSelectedOwnProducts] = useState<SelectedProduct>(initialProducts);
    const [clear, setClear] = useState(false);
    const [count, setCount] = useState(selectedCountry === 'KR' ? 0 : displayTopItems);
    const [ownTabData, setOwnTabData] = useState<any>([]);
    const [ownTabScopeData, setOwnTabScopeData] = useState<any>([]);
    const [ownTabDataCount, setOwnTabPaginationCount] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    
    const {  data: kcProductData, isError: kcProductDataError} = useOwnProductHierarchy(`${selectedCountry}${selectedSourceChoice ? `&source=${selectedSourceChoice}` : '' }${selectedProductLevel ? `&hierarchyLevel=${getHierarchyLevel(selectedProductLevel)}` : '' }${`&scope=${selectedScopeLevel}`}`);

    const {  data: lastModelRunData, isError: lastModelRunError} = useLastModelRunDate(selectedCountry);
   
    
    let selectedCategoryLevel = useStore(
        (state) => state.selectedCategoryLevel
    );
    const handleSelectedValues = (kcObject:SelectedProduct) => {
        setSelectedOwnProducts({
          ...selectedOwnProducts,
          selectedOwnArr: kcObject.selectedKcArr,
          apiUrl: kcObject.apiUrl,
          selectedBrand: kcObject.selectedBrand,
          selectedManufacturer: kcObject.selectedManufacturer,
          selectedSubBrands: kcObject.selectedSubBrands,
          selectedPacks: kcObject.selectedPacks,
        })
    
    }
    const onDisplayItemChange = (data: any) => {
        setCount(data);
    };

    const [ownElasticityPayload, setOwnElasticityPayload] = useState({});
    const [ownScopeElasticityPayload, setOwnScopeElasticityPayload] = useState({});

    useEffect(() => {
        let topNItems = selectedCountry === 'KR' ? 0 : displayTopItems;
        const {selectedOwnArr, selectedManufacturer, selectedBrand, selectedSubBrands, selectedPacks} = selectedOwnProducts;
        const selectedHierarchyLevel = getHierarchyLevel(selectedProductLevel);
        let ownElasticityPayload = {
            category: selectedCategoryLevel,
            forOwn: true,
            country : '',
            hierarchyLevel: getHierarchyLevel(selectedProductLevel),
            initialBrands: selectedHierarchyLevel === 'BRAND' ? [] : selectedBrand,
            initialManufacturers: selectedManufacturer,
            initialNodeValues: selectedOwnArr ? selectedOwnArr : [],
            initialPacks: selectedHierarchyLevel === 'PACK' ? [] :selectedPacks,
            initialSubBrands: selectedHierarchyLevel === 'SUB_BRAND' ? [] :selectedSubBrands,
            scope: selectedScopeLevel,
            source: selectedSourceChoice,
            subCategories: selectedSubCategoryLevel,
            targetBrands: null,
            targetManufacturers: null,
            targetNodeValues: null,
            targetPacks: null,
            targetSubBrands: null,
            topNBottomN: topNItems
        }

        if (selectedScopeLevel === 'WC') {
            ownElasticityPayload["country"] = selectedCountry
            setOwnElasticityPayload(ownElasticityPayload);
        } else {
            ownElasticityPayload["country"] = selectedCountry
            setOwnScopeElasticityPayload(ownElasticityPayload);
        }

    }, [selectedOwnProducts, selectedProductLevel, selectedCountry, selectedSourceChoice, selectedScopeLevel, selectedCategoryLevel, displayTopItems])

    const { isLoading: isOwnDataLoading, data: ownData } = useOwnAnalysis(ownElasticityPayload);
    const { isLoading: isOwnScopeSelectorLoading, data: ownScopeSelector } = useOwnScopeSelector(ownScopeElasticityPayload);

    const setSelectedScopeLevel = useStore(
        (state) => state.setSelectedScopeLevel
    );

    const setSelectedCategoryLevel = useStore(
        (state) => state.setSelectedCategoryLevel
    );

    const setSelectedProductLevel = useStore(
        (state) => state.setSelectedProductLevel
    );

    const selectedSubCategoryLevel = useStore((state) => state.selectedSubCategoryLevel);

    const [ParsedData, setParsedData] = useState<ElasticityRecord[]>([]);
    const [selectedProducts,setSelectedProducts] = useState(['']);

    useEffect(() => {
        if (selectedOwnProducts.selectedOwnArr && ownTabData) {
            if(ownTabData[0]){
                const parsed = parseOwnAnalysisData(selectedOwnProducts,ownTabData,selectedCategoryLevel)
                if (parsed){
                    setParsedData(parsed);
                }
                if(selectedProductLevel !== 'category') {
                    setSelectedProducts(selectedOwnProducts.selectedOwnArr);
                } else {
                    setSelectedProducts([selectedCategoryLevel]);
                }
            }
           
        }
    }, [selectedOwnProducts, ownTabData, ownData]);

    const [subCustomerData, setSubCustomerData] = useState<ElasticityScopeRecord[]>([]);
    const [customerOriginal, setcustomerOriginal] = useState<ElasticityScopeRecord[]>([]);

    useEffect(() => {
        if (!ownTabScopeData || !selectedOwnProducts.selectedOwnArr) return;
        let customerData: ElasticityScopeRecord[] = [];
        let customerHead: string[] = [];

        for (const productName of Object.keys(ownTabScopeData)) {
            for (const customerName of Object.keys(ownTabScopeData[productName])) {
                if (!customerHead.includes(customerName)){
                    customerHead.push(customerName);
                }
            }
        }

        let selectedOwnProdArr = [];
        if(ownTabScopeData) {            
            for (const productName in ownTabScopeData) {
                selectedOwnProdArr.push(productName);
            }
        }

        for (const customer of customerHead) {
            const _customerEntry: ElasticityScopeRecord  = {
                customer,
                data: []
            }
            let productInfoArray = selectedProductLevel === 'category'? [selectedCategoryLevel] :  selectedOwnProdArr ;
            for (const productName of productInfoArray) {
                if (Object.keys(ownTabScopeData).includes(productName)) {
            let productInfoArray = selectedProductLevel === 'category'? [selectedCategoryLevel] :  selectedOwnProdArr ;
           
                    const obj:ElasticityRecord = {
                        initial: productName,
                        averageVolume: ownTabScopeData[productName][customer]?.averageVolume,
                        averagePrice: ownTabScopeData[productName][customer]?.averagePrice,
                        basePrice : ownTabScopeData[productName][customer]?.basePrice,
                        priceIndex : ownTabScopeData[productName][customer]?.priceIndex,
                        promoPrice : ownTabScopeData[productName][customer]?.promoPrice,
                        range: ownTabScopeData[productName][customer]?.range,
                        rsquared: ownTabScopeData[productName][customer]?.rsquared,
                        viewMore: ownTabScopeData[productName][customer]?.viewMore,
                        customer: customer,
                        modelRun: ownTabScopeData[productName][customer]?.modelRun,
                        periodBegin:  ownTabScopeData[productName][customer]?.periodBegin,
                        periodEnd:  ownTabScopeData[productName][customer]?.periodEnd,
                        nweeks:  ownTabScopeData[productName][customer]?.nweeks,
                        pvalue: ownTabScopeData[productName][customer]?.pvalue,
                        category: selectedCategoryLevel
                    }
                    _customerEntry.data.push(obj)
                }else{
                    const initialData :ElasticityRecord = {
                        initial: productName,
                        customer: customer
                    }
                    _customerEntry.data.push(initialData)
                }
             
            }
            customerData.push(_customerEntry)

        }
        setSubCustomerData(customerData);
        setcustomerOriginal(customerData);

        if(selectedProductLevel !== 'category') {
            setSelectedProducts(selectedOwnProdArr);
        } else {
            setSelectedProducts([selectedCategoryLevel]);
        }
    }, [ownScopeSelector, ownTabScopeData, selectedOwnProducts]);

    const elasticityPrice = {
        avgPrice: true,
        promoPrice: false,
        basePrice: false
    }

    let priceType = useStore((state) =>
        state.priceType ? state.priceType : elasticityPrice
    );
    const setPriceType = useStore(
        (state) => state.setPriceType
    );

    const setDisplayTopItems = useStore(
        (state) => state.setDisplayTopItems
    );

    const onchange = (data: any[]) => {
        if (data[0] !== `categoryLevel` && data[0] !== 'productLevel'){
            setPriceType(data[1])
        }else{
            data[0] === "categoryLevel" ? setSelectedCategoryLevel(data[1]) : setSelectedProductLevel(data[1]);
            setSelectedOwnProducts(initialProducts);
            setParsedData([]);
            setSubCustomerData([])
            setParsedData([])
            setCount(0);
            let x = selectedCountry === 'KR' ? data[0] === "categoryLevel" ? 3 : 0 : 0; 
            setDisplayTopItems(x);
        }
    };
    
    const onScopeChange = (data: any) => {
        setSelectedScopeLevel(data);
        setCount(0);
        setDisplayTopItems(0);
    };


    const handleUnselect = (name:string) => {
        console.log(name)
        console.log(selectedOwnProducts)
        setSelectedOwnProducts({
            ...selectedOwnProducts,
            selectedOwnArr: selectedOwnProducts.selectedOwnArr ? selectedOwnProducts.selectedOwnArr.filter(x=> x !== name) : []
        })
    }

    
    const handleViewMore = (name: string,target?:string,customer?:string, category?:string) => {
        const source = useStore.getState().selectedSourceChoice;
        const pl = getHierarchyLevel(useStore.getState().selectedProductLevel)
        setPriceOwnsValue(name.split('-')[0])
        setPriceElasticityTab("Own")
        let url = getOwnViewMoreURL(selectedCountry,name,category,pl,source,selectedScopeLevel,customer);
        window.open(`/price-elasticity/own-dashboard?${url}`, '_blank')
    }

    const [canShowSearch, setcanShowSearch] = useState(false);

    const onClickClear = () => {
        setSelectedOwnProducts(initialProducts);
        setParsedData([]);
        setSubCustomerData([]);
        setClear(true);
        setCount(0);
        setDisplayTopItems(0);
        setOwnTabPaginationCount(0);
    };

    useEffect(() => {
        onClickClear()
    },[selectedCountry])

    const filterCustomer = (names: string[]) => {
        setSubCustomerData(customerOriginal.filter(x=> !names.includes(x.customer)))
    }

    const handleScopeLevelSort = (field:  TableColumn<ElasticityRecord>, direction: string) => {
        const sorted  = sortScopeData(subCustomerData, field, direction)
        setSubCustomerData(sorted)
    }

    const [isDownloading, setisDownloading] = useState(false)

    const downloadOwnElasticity = async () => {
        const {selectedOwnArr, selectedManufacturer, selectedBrand, selectedSubBrands, selectedPacks} = selectedOwnProducts;
        const selectedHierarchyLevel = getHierarchyLevel(selectedProductLevel);

        const ownElasticityDownloadData = {
            country: selectedCountry,
            source: selectedSourceChoice,
            scope: selectedScopeLevel,
            hierarchyLevel: selectedHierarchyLevel,
            category: selectedCategoryLevel,
            forOwn: true,
            subCategories: selectedSubCategoryLevel,
            initialNodeValues: selectedOwnArr,
            targetNodeValues: null,
            initialManufacturers: selectedManufacturer,
            targetManufacturers: null,
            initialBrands: selectedHierarchyLevel === 'BRAND' ? [] : selectedBrand,
            targetBrands: null,
            initialSubBrands: selectedHierarchyLevel === 'SUB_BRAND' ? [] :selectedSubBrands,
            targetSubBrands: null,
            initialPacks: selectedHierarchyLevel === 'PACK' ? [] :selectedPacks,
            targetPacks: null
        }

        try {
            setisDownloading(true)
            const api =  ApiRequestService.createInstance();
            const res: AxiosResponse = await api.elasticityFileDownload(ownElasticityDownloadData);
            const url = window.URL.createObjectURL(res.data);
            const link = document.createElement('a');
            link.href = url;
            const modelRun =  lastModelRunData &&  lastModelRunData[selectedCountry] ? new Date(lastModelRunData[selectedCountry]).toLocaleDateString() : ''
            link.setAttribute('download', `${selectedCountry}_Elasticity_${modelRun}.xlsx`); //or any other extension
            document.body.appendChild(link);
            link.click();
            setisDownloading(false)
        } catch (error) {
            setisDownloading(false)
            console.log('Own Elasticity download error')
            console.log(error)
        }
    
    }

    
    const [canShowProgress, setcanShowProgress] = useState(false)

    const handleClickClose = () => {
        setcanShowProgress(false);
    };
        

    useEffect(() => {
        if (isOwnDataLoading || isOwnScopeSelectorLoading ){
            setcanShowProgress(true)
        }else{
            setcanShowProgress(false)
        }
    }, [isOwnDataLoading, isOwnScopeSelectorLoading])
    
    let disableDownloadbtn = (selectedCountry === '' || selectedSourceChoice === '' || selectedProductLevel === '' || selectedScopeLevel === '') ?  true : isDownloading ? true : false;

    useEffect(() => {
        const startIndex = currentPage * paginationPerPageDataLimit - paginationPerPageDataLimit;
        const endIndex = startIndex + paginationPerPageDataLimit;
 
        if(selectedScopeLevel === Scope.COUNTRY){
            let data = ownData && ownData[0] !== undefined ? Object.entries(ownData[0]) : [];
            setOwnTabPaginationCount(data.length);
            setOwnTabData([Object.fromEntries(data.slice(startIndex, endIndex))]);
        } else {
            let scopeData = ownScopeSelector && ownScopeSelector !== undefined ? Object.entries(ownScopeSelector) : [];
            setOwnTabPaginationCount(scopeData.length);
            setOwnTabScopeData(Object.fromEntries(scopeData.slice(startIndex, endIndex)));
        }                
    }, [currentPage, ownData, ownScopeSelector, selectedOwnProducts]);

    const handleOwnData = (currentPage:any) => {
        setCurrentPage(currentPage);
    }

    return <div className="flex flex-col p-5">
        <ProductLevelSelector onchange={(e:any) => {
            onchange(e)
          }} onScopeChange={(e:any) => {
            onScopeChange(e)
          }}
          onDisplayItemChange={(e:any) => {
            onDisplayItemChange(e)
          }}
          onSourceChange={(e:any) => {
            onClickClear()
          }}
          tabName="own"
        />
        <div className="flex flex-row w-full justify-between my-5">
            <button className="border border-primary text-primary rounded p-1 w-20 " onClick={() => onClickClear()}>Clear</button>
            <button className={`border border-primary text-primary rounded p-2 flex justify-center align-middle ${disableDownloadbtn ? 'cursor-not-allowed' : '' }`} onClick={disableDownloadbtn ? () => { return null } : () => downloadOwnElasticity()} disabled={disableDownloadbtn}>
                {
                    isDownloading
                    ?  <svg className="animate-spin ml-1 mr-3 h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="#0000b3" stroke-width="4"></circle>
                        <path className="opacity-75" fill="#0000b3" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    : null
                }
                
               <span > Download</span>
            </button>
        </div>
        {
            ParsedData && ParsedData.length > 0 && ParsedData[0].modelRun
            ?   <div className="flex flex-row-reverse w-full">
                    <span className="text-primary w-fit">Last model update: <strong>{new Date(ParsedData[0].modelRun).toLocaleDateString()}</strong> </span>
                </div>
            : null
        }
        <AppPagination
            pageData={selectedScopeLevel === Scope.COUNTRY ? ParsedData : subCustomerData}
            dataCount={ownTabDataCount}
            handlePageData={handleOwnData}
            fromTab='own'
            applyPadding={false}
        /> 
        <div className="relative  w-full">
            <div className="top-20 absolute z-50">
                {
                    canShowSearch && selectedProductLevel !== 'category'
                    ? <NestedSearch
                        data={kcProductData}
                        handleSelectedValues={handleSelectedValues}
                        tabName="own"
                        dataFor=""
                        clear={clear}
                        handleClear={() => setClear(false)}
                        id="searchOwn"
                        onMouseLeave={() => setcanShowSearch(false)}
                        previouslySelected={selectedOwnProducts.selectedOwnArr} />
                        : null
                }
            </div>
            {
                selectedScopeLevel === Scope.COUNTRY
                ? <CountryScope records={ParsedData} selectedCountry={selectedCountry} priceType={priceType}
                handleViewMore={handleViewMore} unselectRow={handleUnselect} loading={isOwnDataLoading}
                addProductClick={() => setcanShowSearch(!canShowSearch)} selectedProducts={selectedProducts || []}></CountryScope>
                : null
            }
            {
                selectedScopeLevel !== Scope.COUNTRY
                ? <MarketScope records={subCustomerData} selectedCountry={selectedCountry} allCustomers={customerOriginal.map(x=>x.customer)} priceType={priceType}
                handleViewMore={handleViewMore} unselectRow={handleUnselect} loading={isOwnScopeSelectorLoading} filterCustomer={filterCustomer} scope={selectedScopeLevel as Scope}
                addProductClick={() => setcanShowSearch(!canShowSearch)} selectedProducts={selectedProducts || []} customSort={handleScopeLevelSort}></MarketScope>
                : null
            }        
            
        </div>        
 
        <Dialog
            open={canShowProgress}
            keepMounted
            onClose={handleClickClose}
            aria-describedby="alert-dialog-slide-description">
            <DialogTitle className="pt-0">
                {"Your request is being processed"}
            </DialogTitle>
        </Dialog>
        
    </div>
}