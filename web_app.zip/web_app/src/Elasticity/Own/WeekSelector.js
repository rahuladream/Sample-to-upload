import React,{ useState } from 'react'
import useStore from "../../store";
import DropdownTreeSelect from "react-dropdown-tree-select";
import "react-dropdown-tree-select/dist/styles.css";
import { makeStyles } from '@material-ui/core';
import "../.././searchStyles.css";
import DialogActions from "@material-ui/core/DialogActions";
import {Button} from "@material-ui/core";

const useStyles = makeStyles((theme)=> ({
  root: {
    backgroundColor: theme.palette.primary.light,
    padding: theme.spacing(1),
    display: "flex",
    alignItems: "center",
    width: "100%",
    height: 'auto',
  },
  btnContainer: {
		marginTop: "10px",
		float: "right",
    justifyContent:'space-evenly'
	},
  btnReset: {
		background: "#cb0c0c",
		color: "#fff",
		textTransform: "none",
		margin: "0 20px",
		padding: "6px 20px",
		borderRadius: "10px",
	},
	btnSucess: {
		background: "#163c62",
		color: "#fff",
		textTransform: "none",
		margin: "0 10px",
		padding: "6px 35px",
		borderRadius: "10px",
	},
  WeekSelectorRoot: {
    width:'400px',
    display:'flex',
    flexDirection:'column', 
    justifyContent:'center',
    height:'100%'
  },
  memorizedRoot: {
    height:'500px',
    width:'100%'
  }
  
}))
let x = [];
export const DropDown = (props) => {
  const classes = useStyles();
  let originalData = props.originalData;

  const handleChange = (item) => {
    let depth = item._depth;
    let val = depth === 1 ? item._parent : item._id ;
    let parIndex = parseInt(val.split('-')[1]);
    let parNode = Object.keys(originalData)[parIndex];
    let allParNodes = Object.keys(originalData);

    if(item.checked) {
      if(depth === 0) { //Parent node selected
        x = [...x  ,...originalData[parNode]];
      } else { //Child node selected
        let week = item.label.split(' ')[1];
        let aux = originalData[parNode].filter(obj => obj.week==week && obj.year == parNode)
        x = [...x,...aux];
      }
      x = [...new Set(x)];
    }
    else {
      if(depth === 0) { //Parent node de selected
        x = x.filter( val => val.year ==  parNode ? false: true );
      } else { //Child node de selected
        let week = item.label.split(' ')[1];
        x = x.filter( val => val.year ==  parNode && val.week == week ? false: true ) 
      }
      if(x.length === 0) { //removed all the years/weeks ; so add all the weeks
        for(let i =0; i<allParNodes.length; i++) {
          x = [...x  ,...originalData[allParNodes[i]]];
        }
      }
    }
  }
  return (
  <div>
    <DropdownTreeSelect
      disableUnderline
      texts={{ placeholder: "Search" }}
      className={classes.root}
      data={props.treeData}
      onChange={handleChange}
    />
  </div>
  )
}
export const MemoizedDropDown = React.memo(DropDown);

export const WeekSelector = (props) => {
  const classes = useStyles();

  const setReset = useStore((state) => state.setReset);
  let reset = useStore((state) => state.reset);
  let selectedCountry = useStore((state) => state.selectedCountry);
  const setRegressionApiBodyOwn = useStore((state) => state.setRegressionApiBodyOwn);
  const setRegressionApiBodyCross = useStore((state) => state.setRegressionApiBodyCross);

  
  const handleSelection = () => {
  let result = {};
  result['country'] = selectedCountry;
  result['dataPoints'] = x;
  props.tabName === 'own' ? setRegressionApiBodyOwn(result) : setRegressionApiBodyCross(result);
  props.handleClose();

  }
  const handleClear = () => {
    setReset(!reset);
    x=[];
  }
  return (
    <div className={classes.WeekSelectorRoot}>
      <div className={classes.memorizedRoot}>
        <MemoizedDropDown 
          treeData={props.treeDataInstance} 
          reset={reset}
          originalData={props.originalDataInstance}
        />
      </div>
        <DialogActions className={classes.btnContainer}>
          <Button onClick={handleClear} className={classes.btnReset}>
            Clear
          </Button>
          <Button
            onClick={handleSelection}
            className={classes.btnSucess}
          >
            Apply
          </Button>
        </DialogActions>
    </div>
  )
}

export const MemoizedWeekSelector = React.memo(WeekSelector);