
type SimulatedResultProps = {
   
    simulatedGridData: [ {[key: string]: string }],
    
}



export const NetPromotedSales = ({simulatedGridData}:SimulatedResultProps ) => {

    console.log("response11", simulatedGridData)
    function formatNum(n:any) {
        let k = Math.floor(n * 100) / 100;
        return k;
    }

    return <div className="flex flex-col">
        {
            simulatedGridData.map((item : any ) => 
              /*   return {'123'} */
                
                 (
                <div className="flex justify-between py-4 items-center bg-gray-100-test text-sm  px-2">
                 <div className="min-w-50 w-[260px] font-bold text-left">{item.name}</div>
                <div className="min-w-40 text-left">{ Number.parseFloat(item.actuals).toFixed(2)}</div>
                <div className="min-w-40 text-left">{ Number.parseFloat(item.baselineScenario).toFixed(2)}</div>
                <div className="min-w-40 text-left">{ Number.parseFloat(item.promoScenario).toFixed(2)}</div>
                <div className="min-w-40 text-left">{ Number.parseFloat(item.liftScenario).toFixed(2)}</div> 
            </div>
                 ) 
            )
        }

    </div>
}