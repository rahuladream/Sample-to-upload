import Update from '../../images/sync-alt.svg';
import duplicate from '../../images/copy.svg';
import save from '../../images/save.svg';
import reset from '../../images/undo.svg';
import { makeStyles } from "@material-ui/core/styles";
import bolt from '../../images/bolt.svg';


type ActionProps = {
    calculateData: Function,
    setCalcutateTotalInvest: Function,
    resetForm: Function,
    savePromo: Function,
    handleModalOpen: Function,
    duplicateFun: Function,
    tidy?: boolean

}

const useStyles = makeStyles((theme) => ({
	
	actionsTxt: {
		fontWeight: 700,
	},
	actionsBtn: {
		cursor: 'pointer'
	},
	actionsIconText: {
		color: '#2663ff',
		lineHeight: '16px',
	},
	flexEnd: {
		alignItems: 'end'
	},

}))

export const PromoActions = ({calculateData, duplicateFun, setCalcutateTotalInvest, handleModalOpen, resetForm, savePromo, tidy=false}:ActionProps) => {
	const classes = useStyles();

    return <div className="flex justify-start gap-10 w-full px-3 mt-2">
        <div className="flex flex-col gap-2 w-1/2">
            <div className={` ${!tidy ? 'p-5 pt-10' : 'p-1'} flex flex-col gap-10`}>

            </div>
        </div>
        <div className={`flex flex-col gap-2 w-1/2  place ${classes.flexEnd}`}>
            <div className={` ${!tidy ? 'p-5 pt-10' : 'p-1'} flex flex-row gap-5`}>
                <span className={classes.actionsTxt}>Actions </span>
                <span className={`flex flex-row gap-1 ${classes.actionsBtn}`} onClick={() => { calculateData(); setCalcutateTotalInvest(true); }}><img src={bolt} /> <span className={`${tidy ? 'text-sm font-semibold' : 'text-md font-bold'} ${classes.actionsIconText}`}>Calculate</span></span>
                <span className={`flex flex-row gap-1 ${classes.actionsBtn}`} ><img src={Update} /> <span className={`${tidy ? 'text-sm font-semibold' : 'text-md font-bold'} ${classes.actionsIconText}`}>Update</span></span>
                <span className={`flex flex-row gap-1 ${classes.actionsBtn}`} onClick={() => resetForm()}><img src={reset} /> <span className={`${tidy ? 'text-sm font-semibold' : 'text-md font-bold'} first-letter: ${classes.actionsIconText}`}>Reset</span></span>
                <span className={`flex flex-row gap-1 ${classes.actionsBtn}`} onClick={() => { savePromo() }}><img src={save} /> <span className={`${tidy ? 'text-sm font-semibold' : 'text-md font-bold'} first-letter: ${classes.actionsIconText}`}>Save</span></span>
                <span className={`flex flex-row gap-1 ${classes.actionsBtn}`} onClick={() => handleModalOpen()}><img src={Update} /> <span className={`${tidy ? 'text-sm font-semibold' : 'text-md font-bold'} first-letter: ${classes.actionsIconText}`}>Load</span></span>
                <span className={`flex flex-row gap-1 ${classes.actionsBtn}`} onClick={(e) => duplicateFun(e)} ><img src={duplicate} /> <span className={`${tidy ? 'text-sm font-semibold' : 'text-md font-bold'} ${classes.actionsIconText}`}>Duplicate</span></span>
            </div>
        </div>
    </div>
}