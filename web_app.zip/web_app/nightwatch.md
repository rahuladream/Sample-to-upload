# Getting Started with Integration testing with NightwatchJS

Nightwatch.js https://nightwatchjs.org/ under the hood uses the same webdrvier framework selenium uses to run the integration tests in the actual browser environment. All the required libraries required are already configured as dev dependency. It supportals all major browsers (Chrome, Firefox, IE and Safari) out of the box. Just make sure to install the actual browser you intend to test before running the tests.

## Tests

All integration tests are under __tests__ folder in th web_app root directory. To add a new test for a page that you are about to test, its recommended to add that as a separate js or ts file.  For example, you can have a look at the `login_tests.js` (SSO login flow testing) or `baseline_tests.js` (Baseline page) file.

Check the below test suite in  `baseline_tests.js` file. Here are the few things to consider

- Test suits starts with `"test suite name": async (browser) => {}` syntax.
- Every test suite will have `browser` object passed to it.
- You can use that to access the `DOM` elements and write tests against it
- Make sure to use `async` as most of the dom retrieval happens asynchronously
- You can see how to work with DOM elements here in more detail https://nightwatchjs.org/guide/using-nightwatch/finding-and-interacting-with-elements.html
- It supports both `assert` and `expect` test validators. You can read about them more here https://nightwatchjs.org/api/ 


```
module.exports = {

    'Baseline report tests' : async (browser) => {

        browser.click('#country-list')

        browser
            .waitForElementVisible('.countryItem',2000)
            .expect.elements('.countryItem').count.to.equal(4)

        browser.click('#countryItem_XX')

        browser
            .waitForElementVisible('#powerBIFrame',30000)

        const result = await browser.frame('powerBIFrame').findElements('.bodyCells  .pivotTableCellWrap') 
        browser.assert.equal(result.status, 0); 
        console.log(result.value)
        browser.assert.equal(result.value.length, 2 )
        const firstNode = result.value[0]
        const ratioText = await browser.elementIdAttribute(firstNode.ELEMENT, 'innerText')
        browser.assert.equal(ratioText.status, 0); 
        console.log(ratioText.value)
        // assert.include(ratioText, '%')
        const ratio = ratioText.value.split('%')[0]
        browser.assert.ok(parseInt(ratio) > 0)

    },
}

```

Once you have the tests written, now you need to add the reference in `base.js` file

```
var newTestSuite = require("./new_tests.ts");
module.exports = extend(module.exports, newTestSuite)
```

This is to make sure to run the tests in the same browser instance. Without this every test suite will run seperately each time. That is an issue for applications like ourselves where we need to tdo run tests against a logged in user.

`base.js` avoid this by reusing the same browser instance. 


## Configuring tests

All nightwatch related configurations are found in `nightwatch.conf.js` in the web_app root folder. 

```
	globals: {
				"username" :  process.env.OKTA_USER_NAME,
				"password" :  process.env.OKTA_PASSWORD,
			}
```

Since our application now accessed using the  Okta SSO, its very important to pass your username and password to it.

Please avoid hardcoding the values here `process.env.OKTA_USER_NAME` and `process.env.OKTA_PASSWORD`. Instead create a new file called `.env.nightwatch` and place this content iside

```
OKTA_USER_NAME = your_kcc_email_id
OKTA_PASSWORD = password
```

This file is already on the `.gitignore` list. so you dont have to worry about accidentally committing your credentials to the codebase.


## Running tests


Please do `npm install` before starting the tests to have all the dependencies installed. Currently this is configured to run in Chrome browser. So make sure chrome is installed in your system.

If you want to change it to a different browser, please change it in `nightwatch.conf.js` file.

If everything is confgiured as per the above steps, now you can able run the tests by `  node nightwatch.js ./__tests__/base.js` from the web_app root folder.