 const sleep = (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

const searchBarTesting = async (browser, type, levels, clickIndex) => {
    await browser.frameParent()
            .waitForElementPresent(`.icon_${type}`,2000)
            .click(`.icon_${type}`)

    await browser.frameParent()
        .waitForElementPresent(`.${type}Label`, 3000)

    const labels =  await browser.frameParent().findElements(`.${type}Label`)
    await browser.assert.equal(labels.status, 0,` ${type} labels should be present in the ${type} searchbox`);
    
    await browser.assert.equal(labels.value.length, levels, `${type} searchbox should display ${levels} child levels`)

    const expanderItems =  await browser.frameParent().findElements(`.${type}Expander`)
    browser.assert.equal(expanderItems.status, 0, 'All sub levels should be expandable');

    await browser.frameParent().elementIdClick(expanderItems.value[expanderItems.value.length-1].getId())

    await browser.waitForElementPresent('.checker', 5000)

    const checkerNames =  await browser.frameParent().findElements('.checkerName')
    await browser.assert.equal(checkerNames.status, 0, `Checkbox label for ${type} should be visible`); 
    const selectedValue = await browser.frameParent().elementIdAttribute(checkerNames.value[clickIndex].getId(), 'innerText')
    const selectedText  = selectedValue.value


    const checkerItems =  await browser.frameParent().findElements('.checker')
    await browser.frameParent().elementIdClick(checkerItems.value[clickIndex].getId())

    const displayedInTable = await browser.frameParent().findElements(`.selected_${type}`)
    const displayedText = []
    for (const row of displayedInTable.value) {
        const rowText = await browser.frameParent().elementIdAttribute(row.getId(), 'innerText')
        displayedText.push(rowText.value)
    }
    console.log(selectedText)
    console.log(displayedText)  
    await browser.assert.equal(displayedText.includes(selectedText),true,`Selected ${type} ${selectedText} should be present in the table `)
        
}

module.exports = {
    searchBarTesting,
    sleep
}