
const {searchBarTesting, sleep} = require( "./test_utils")

module.exports = {

    'Goto promo performance page' : async(browser) => {
        browser.frameParent().click('#tab-promo-performace')
        browser.waitForElementPresent('.icon_customer',5000)
        await sleep(5000)
    },
   
    'Promo performance Customer searchBar testing' :  async(browser) => {
        await searchBarTesting(browser,'customer',4,0)
        browser.frameParent()
            .waitForElementPresent(`.icon_customer`,2000)
            .click(`.icon_customer`)
        await searchBarTesting(browser,'customer',4,1)

    },

    'Promo performance  Product searchBar testing' :  async(browser) => {
        await searchBarTesting(browser,'product',5, 0)
        browser.frameParent()
            .waitForElementPresent(`.icon_product`,2000)
            .click(`.icon_product`)
        await searchBarTesting(browser,'product',5,1)
    },

    'Clear customer testing in promo performane' : async (browser) => {
        browser.frameParent()
            .waitForElementPresent('#clearCustomer')
        
        browser.frameParent().click('#clearCustomer')
        const displayedInTable = await browser.frameParent().findElements(`.selected_customer`)
        browser.assert.equal(0,displayedInTable.status)
        browser.assert.equal(0,displayedInTable.value.length)

        await searchBarTesting(browser,'customer',4,0)
        browser.frameParent()
            .waitForElementPresent(`.icon_customer`,2000)
            .click(`.icon_customer`)
        await searchBarTesting(browser,'customer',4,1)

    },

    'Clear products testing in promo perforamnce' : async (browser) => {
        browser.frameParent()
            .waitForElementPresent('#clearProducts')
        
        browser.frameParent().click('#clearProducts')
        const displayedInTable = await browser.frameParent().findElements(`.selected_product`)
        browser.assert.equal(0,displayedInTable.status)
        browser.assert.equal(0,displayedInTable.value.length)

        await searchBarTesting(browser,'product',5, 0)
        browser.frameParent()
            .waitForElementPresent(`.icon_product`,2000)
            .click(`.icon_product`)
        await searchBarTesting(browser,'product',5,1)

    }
}