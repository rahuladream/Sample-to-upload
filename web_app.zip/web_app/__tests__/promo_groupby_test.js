const { sleep } = require("./test_utils");
let arrOfObjOriginal = [];

const extractSortItems = async (browser) => {
  const displayedGroupBy = await browser
    .frameParent()
    .findElements(`#table_item`);
  const displayedText = [];
  for (const row of displayedGroupBy.value) {
    const rowText = await browser
      .frameParent()
      .elementIdAttribute(row.getId(), "innerText");
    displayedText.push(rowText.value);
  }

  const displayedPromoProfit = await browser
    .frameParent()
    .findElements(`#promoProfit`);
  const displayedValues = [];
  for (const row of displayedPromoProfit.value) {
    const rowText = await browser
      .frameParent()
      .elementIdAttribute(row.getId(), "innerText");
    displayedValues.push(rowText.value);
  }

  for (let i = 0; i < displayedValues.length; i++) {
    arrOfObjOriginal.push({
      name: displayedText[i],
      promoValue: displayedValues[i],
    });
  }
};
const ascendingSortTesting = async (browser, sortColumn) => {
  await browser.click(`#header_${sortColumn}`);
  browser.pause(2000);

  let ascSortValuesInGrid = [];

  const displayedGroupBy = await browser
    .frameParent()
    .findElements(`#table_item`);
  const displayedText = [];
  for (const row of displayedGroupBy.value) {
    const rowText = await browser
      .frameParent()
      .elementIdAttribute(row.getId(), "innerText");
    displayedText.push(rowText.value);
  }

  const displayedPromoProfit = await browser
    .frameParent()
    .findElements(`#promoProfit`);
  const displayedValues = [];
  for (const row of displayedPromoProfit.value) {
    const rowText = await browser
      .frameParent()
      .elementIdAttribute(row.getId(), "innerText");
    displayedValues.push(rowText.value);
  }

  for (let i = 0; i < displayedValues.length; i++) {
    ascSortValuesInGrid.push({
      name: displayedText[i],
      promoValue: displayedValues[i],
    });
  }

  arrOfObjOriginal.sort(function (a, b) {
    let x = parseFloat(a.promoValue.replace(/,/g, ""));
    let y = parseFloat(b.promoValue.replace(/,/g, ""));

    return x > y ? 1 : -1;
  });

  let flag = true;

  for (let i = 0; i < arrOfObjOriginal.length; i++) {
    if (
      arrOfObjOriginal[i].name !== ascSortValuesInGrid[i].name ||
      arrOfObjOriginal[i].promoValue !== ascSortValuesInGrid[i].promoValue
    ) {
      flag = false;
    }
  }

  browser.assert.equal(
    flag,
    true,
    `Values are present in ascending order as per ${sortColumn} column`
  );
};
const descendingSortTesting = async (browser, sortColumn) => {
  await browser.click(`#header_${sortColumn}`);
  browser.pause(2000);

  let descSortValuesInGrid = [];

  const displayedGroupBy = await browser
    .frameParent()
    .findElements(`#table_item`);
  const displayedText = [];
  for (const row of displayedGroupBy.value) {
    const rowText = await browser
      .frameParent()
      .elementIdAttribute(row.getId(), "innerText");
    displayedText.push(rowText.value);
  }

  const displayedPromoProfit = await browser
    .frameParent()
    .findElements(`#promoProfit`);
  const displayedValues = [];
  for (const row of displayedPromoProfit.value) {
    const rowText = await browser
      .frameParent()
      .elementIdAttribute(row.getId(), "innerText");
    displayedValues.push(rowText.value);
  }

  for (let i = 0; i < displayedValues.length; i++) {
    descSortValuesInGrid.push({
      name: displayedText[i],
      promoValue: displayedValues[i],
    });
  }

  arrOfObjOriginal.sort(function (a, b) {
    let x = parseFloat(a.promoValue.replace(/,/g, ""));
    let y = parseFloat(b.promoValue.replace(/,/g, ""));

    return x < y ? 1 : -1;
  });

  let flag = true;

  for (let i = 0; i < arrOfObjOriginal.length; i++) {
    if (
      arrOfObjOriginal[i].name !== descSortValuesInGrid[i].name ||
      arrOfObjOriginal[i].promoValue !== descSortValuesInGrid[i].promoValue
    ) {
      flag = false;
    }
  }

  browser.assert.equal(
    flag,
    true,
    `Values are present in descending order as per ${sortColumn} column`
  );
};
module.exports = {
  "Go to Post ROI tab": async (browser) => {
    browser.frameParent().click("#tab-promo-performace");
    browser.waitForElementPresent(".icon_customer", 5000);
    await sleep(5000);
  },
  "Select test country": async (browser) => {
    await browser.click("#country-list");

    await browser.waitForElementVisible(".countryItem", 2000);

    browser.expect.elements(".countryItem").count.to.equal(4);

    await browser.click("#countryItem_KR");

    browser.pause(5000);
  },

  "Select group by Promo Type": async (browser) => {
    await browser.click("#demo-controlled-open-select");

    await browser.waitForElementVisible(".groupByItem", 2000);

    browser.expect.elements(".groupByItem").count.to.equal(16);

    browser.pause(2000);

    await browser.click("#groupByItem_PromoType");

    await browser.waitForElementVisible(".roiGrid", 2000);

    browser.pause(2000);

    await extractSortItems(browser);
  },

  "Promo profit ascending sort testing": async (browser) => {
    await ascendingSortTesting(browser, "promoProfit");
  },

  "Promo profit descending sort testing": async (browser) => {
    await descendingSortTesting(browser, "promoProfit");
  },
};
