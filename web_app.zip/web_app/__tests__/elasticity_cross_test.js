/* eslint-disable no-unused-expressions */
require( "./test_utils")

const selectComparisonIn = async (browser, type, searchBox, productClass) => {
    browser.frameParent()
        .click(`${searchBox} .selector_${type}`)

    browser.frameParent()
        .waitForElementVisible(`${searchBox} #searcher_${type} .checker`,2000)


    const resultName = await browser.frameParent().findElements(`${searchBox} #searcher_${type} .checkerName`)
    browser.assert.equal(resultName.status, 0, 'Checkbox label for product should be visible'); 

    console.log(resultName.value)

    const selectedValue = await browser.frameParent().elementIdAttribute(resultName.value[0].getId(), 'innerText')
    browser.assert.equal(selectedValue.status, 0, 'Checkbox label for product should be visible'); 

    const selectedText  = selectedValue.value

    let result = await browser.frameParent().findElements(`${searchBox} #searcher_${type} .checker`)
    browser.elementIdClick(result.value[0].getId())
    browser.assert.equal(result.status, 0, "Checkbox should be visible"); 


    browser.frameParent()
        .waitForElementVisible(productClass, 50000)


    const displayedInTable = await browser.frameParent().findElements(productClass)
    const displayedText = []
    for (const row of displayedInTable.value) {
        const rowText = await browser.frameParent().elementIdAttribute(row.getId(), 'innerText')
        displayedText.push(rowText.value)
    }
    console.log(selectedText)
    console.log(displayedText)  
    browser.assert.equal(displayedText.includes(selectedText),true,`Selected product ${selectedText} should be present in the table `)
    
}

module.exports = {

    'Elasticity Crosss Tests' : async (browser) => {

        const windows = await browser.windowHandles()
        const mainWindow = windows.value[0]
        await browser.switchWindow(mainWindow)

        browser.frameParent()
            .waitForElementVisible('#tab-CrossTab', 2000)

        browser.frameParent()
            .click('#tab-CrossTab')

        browser.frameParent()
            .waitForElementVisible('.rdn.categorySelector',5000)

        browser.frameParent().click('.rdn.categorySelector')

        browser.frameParent()
            .waitForElementVisible('.categoryItem',5000)
            .expect.elements('.categoryItem').count.to.equal(5)

        browser.frameParent().click('.categoryItem:nth-of-type(1)')

        browser.frameParent().click('.rdn.levelSelector')

        browser.frameParent()
            .waitForElementVisible('.levelItem',10000)
            .expect.elements('.levelItem').count.to.equal(5)
    
        browser.frameParent()
            .expect.element(`.levelItem.level_ean`).to.be.visible
    
        browser.frameParent().click(`.levelItem.level_ean`)

        browser.frameParent()
            .waitForElementVisible('#initialPicker',2000)

        browser.frameParent().click('#initialPicker')

        browser.frameParent().waitForElementVisible('#initialSearch',1000)

        await selectComparisonIn(browser, 'ean', '#initialSearch', '.kcOvalShape' )
        browser.frameParent().click('.kcOvalShape')
        browser.frameParent()
            .waitForElementVisible('#targetPicker',5000)
        browser.frameParent().click('#targetPicker')
        browser.waitForElementNotPresent('#initialSearch', 5000)
        await selectComparisonIn(browser, 'ean', '#targetSearch', '.targetOvalShape')

    }

}