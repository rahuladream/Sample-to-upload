var extend = function(target) {
    var sources = [].slice.call(arguments, 1);
    sources.forEach(function (source) {
        for (var prop in source) {
            target[prop] = source[prop];
        }
    });
    return target;
};

var hook = require("./hook.ts");
module.exports = extend(module.exports, hook)

var login = require("./login_test.ts");
module.exports = extend(module.exports, login)

var baseline = require("./baseline_test.ts");
module.exports = extend(module.exports, baseline)

var synced_selector = require("./synced_selector_test");
module.exports = extend(module.exports, synced_selector)

var baseline_daily_test = require("./baseline_dailydata_test.js");
module.exports = extend(module.exports, baseline_daily_test)

var promoGroupBy_tests = require("./promo_groupby_test");
module.exports = extend(module.exports, promoGroupBy_tests)

var elasticity_correlation = require("./elasticity_correlation_test");
module.exports = extend(module.exports, elasticity_correlation)

var elasticity_own = require("./elasticity_own_test");
module.exports = extend(module.exports, elasticity_own)

var elasticity_cross = require("./elasticity_cross_test");
module.exports = extend(module.exports, elasticity_cross)

var promo_tests = require("./promo_tests");
module.exports = extend(module.exports, promo_tests)

var pre_roi_tests = require("./pre_roi_test");
module.exports = extend(module.exports, pre_roi_tests)