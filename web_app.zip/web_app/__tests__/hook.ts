module.exports = {
    before: async (browser) => {
        await browser
            .url('http://localhost:3000/')
           
        await browser.waitForElementPresent("#okta-signin-username",30000)

    
        await browser
            .setValue('#okta-signin-username',browser.globals.username)
            .setValue('#okta-signin-password',browser.globals.password)
            .click('#okta-signin-submit')
    },
    after: (browser) => {
        browser.end()
    }
}