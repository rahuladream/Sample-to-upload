/* eslint-disable @typescript-eslint/no-unused-expressions */
/* eslint-disable no-unused-expressions */

const {sleep} = require( "./test_utils")

const searchBarTesting = async (browser, type, levels) => {
  await browser
    .frameParent()
    .waitForElementPresent(`.icon_${type}`, 2000)
    .click(`.icon_${type}`);

  await browser.frameParent().waitForElementPresent(`.${type}Label`, 30000);

  const label = await browser.frameParent().findElements(`.${type}Label`)

  browser.assert.equal(
    label.status,
    0,
    ` ${type} labels should be present in the ${type} searchbox`
  );

  browser.assert.equal(
    label.value.length,
    levels,
    `${type} searchbox should display ${levels} child levels`
  );

  const expanderItems = await browser
    .frameParent()
    .findElements(`.${type}Expander`);
  browser.assert.equal(
    expanderItems.status,
    0,
    "All sub levels should be expandable"
  );

  await browser
    .frameParent()
    .elementIdClick(
      expanderItems.value[expanderItems.value.length - 1].getId()
    );

    await browser.waitForElementPresent(".checker", 5000);

  const checkerNames = await browser.frameParent().findElements(".checkerName");
  browser.assert.equal(
    checkerNames.status,
    0,
    `Checkbox label for ${type} should be visible`
  );

  const displayedInTable = await browser
    .frameParent()
    .findElements(`.selected_${type}`);
  const displayedText = [];
  for (const row of displayedInTable.value) {
    const rowText = await browser
      .frameParent()
      .elementIdAttribute(row.getId(), "innerText");
    displayedText.push(rowText.value);
  }

  for (const element of displayedText) {
    await browser.getElementProperty(
      "xpath",
      `//input[@name='${element}']`,
      "checked",
      function (result) {
        browser.assert.equal(
          result.value,
          true,
          `${element} is checked in ${type} selector`
        );
      }
    );
  }
};

const searchBarSelectionTesting = async (browser, type, levels, clickIndex) => {
  await browser
    .frameParent()
    .waitForElementPresent(`.icon_${type}`, 2000)
    .click(`.icon_${type}`);

  await browser.frameParent().waitForElementPresent(`.${type}Label`, 3000);

  const expanderItems = await browser
    .frameParent()
    .findElements(`.${type}Expander`);

  await browser
    .frameParent()
    .elementIdClick(
      expanderItems.value[expanderItems.value.length - 1].getId()
    );

  await browser.waitForElementPresent(".checker", 5000);

  const checkerNames = await browser.frameParent().findElements(".checkerName");
  const selectedValue = await browser
    .frameParent()
    .elementIdAttribute(checkerNames.value[clickIndex].getId(), "innerText");
  const selectedText = selectedValue.value;

  const checkerItems = await browser.frameParent().findElements(".checker");
  await browser
    .frameParent()
    .elementIdClick(checkerItems.value[clickIndex].getId());
  browser.pause(1000);

  const displayedInTable = await browser
    .frameParent()
    .findElements(`.selected_${type}`);
  const displayedText = [];
  for (const row of displayedInTable.value) {
    const rowText = await browser
      .frameParent()
      .elementIdAttribute(row.getId(), "innerText");
    displayedText.push(rowText.value);
  }
  console.log("selectedText:",selectedText);
  browser.assert.equal(
    displayedText.includes(selectedText),
    true,
    `Selected ${type} ${selectedText} should be present in the table `
  );
};

module.exports = {
  "PostROI report tests": async (browser) => {
    await browser.frameParent().click("#tab-promo-performace");
    await sleep(2000)
    await browser.frameParent().waitForElementPresent('.icon_customer',5000)
    
  },

  "Post ROI customer searchBar testing": async (browser) => {
    await searchBarTesting(browser, "customer", 4);
    await browser
      .frameParent()
      .waitForElementPresent(`.icon_customer`, 2000)
      .click(`.icon_customer`);
    await browser.waitForElementVisible("#powerBIFrame", 30000);
  },

  "Post ROI product searchBar testing": async (browser) => {
    await searchBarTesting(browser, "product", 5);
    browser
      .frameParent()
      .waitForElementPresent(`.icon_product`, 2000)
      .click(`.icon_product`);
    browser.waitForElementVisible("#powerBIFrame", 30000);
  },

  "Post ROI customer selection testing": async (browser) => {
    await searchBarSelectionTesting(browser, "customer", 4, 2);
    await browser
      .frameParent()
      .waitForElementPresent(`.icon_customer`, 2000)
      .click(`.icon_customer`);
    await browser.waitForElementVisible("#powerBIFrame", 30000);
  },

  "Post ROI product selection testing": async (browser) => {
    await searchBarSelectionTesting(browser, "product", 5, 2);
    browser
      .frameParent()
      .waitForElementPresent(`.icon_product`, 2000)
      .click(`.icon_product`);
    browser.waitForElementVisible("#powerBIFrame", 30000);
  },

  "Baseline new report tests": async (browser) => {
    browser.frameParent().click("#tab-baseline-forcasting");
    browser.pause(1000);

    browser.waitForElementVisible("#powerBIFrame", 30000);
    browser.pause(10000);
  },

  "Baseline customer searchBar testing": async (browser) => {
    await searchBarTesting(browser, "customer", 4);
    browser
      .frameParent()
      .waitForElementPresent(`.icon_customer`, 2000)
      .click(`.icon_customer`);
    browser.waitForElementVisible("#powerBIFrame", 30000);
  },

  "Baseline Product searchBar testing": async (browser) => {
    await searchBarTesting(browser, "product", 5);
    browser
      .frameParent()
      .waitForElementPresent(`.icon_product`, 2000)
      .click(`.icon_product`);
    browser.waitForElementVisible("#powerBIFrame", 30000);
  },

  "Go to pre ROI": async (browser) => {
    browser.frameParent().click("#tab-pre-roi");
    browser.pause(1000);
    await browser
      .frameParent()
      .waitForElementPresent(`.icon_customer`, 2000)
      .click(`.icon_customer`);

    await browser
      .frameParent()
      .waitForElementPresent(`.icon_product`, 2000)
      .click(`.icon_product`);
  },

  "Pre ROI customer searchBar testing": async (browser) => {
    await searchBarTesting(browser, "customer", 4);
  },

  "Pre ROI Product searchBar testing": async (browser) => {
    await searchBarTesting(browser, "product", 5);
  },
};
