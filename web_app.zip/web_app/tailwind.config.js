module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
		extend: {
			minHeight: {
				'10' : '2.5rem',
				'20' : '5rem',
				'30' : '7.5rem'
			},
			minWidth: {
				'20' : '5rem',
				'30' : '7.5rem',
				'40' : '10rem',
				'50' : '12.5rem'
			},
			colors: {
				'primary' : '#0000b3'
			  }
		},
	},
  plugins: [],
}