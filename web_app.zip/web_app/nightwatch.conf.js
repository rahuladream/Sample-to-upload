const fs = require('fs')
const dotenv = require('dotenv')
const envConfig = dotenv.parse(fs.readFileSync('.env.nightwatch'))
for (const k in envConfig) {
  process.env[k] = envConfig[k]
}
module.exports = {
  // An array of folders (excluding subfolders) where your tests are located;
  // if this is not specified, the test source must be passed as the second argument to the test runner.
  src_folders: ['__tests__'],

	webdriver: {
		start_process: true,
		port: 4444,
		server_path: require('chromedriver').path,
		cli_args: [
			"--verbose"
		],
	},

	test_settings: {
		default: {
			launch_url: 'http://localhost:3000/',
			desiredCapabilities : {
				browserName : 'chrome',
				"chromeOptions": {
					"args" : ["--no-sandbox","--incognito"]
				  },
			},
			globals: {
				"username" :  process.env.OKTA_USER_NAME,
				"password" :  process.env.OKTA_PASSWORD,
			}
		}
	}
}